import axios from "axios";

// 1. Create a custom Axios instance
const api = axios.create({
  baseURL: "http://localhost:5000/api", // Base URL for your backend
  headers: {
    "Content-Type": "application/json",
  },
});

// 2. REQUEST INTERCEPTOR: Automatically attach the token
api.interceptors.request.use(
  (config) => {
    // Grab the token from localStorage before the request leaves
    const token = localStorage.getItem("token");
    
    // If the token exists, attach it to the Authorization header
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Note: Do NOT set Content-Type if we are sending FormData (for file uploads)
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 3. RESPONSE INTERCEPTOR: Catch expired tokens globally
api.interceptors.response.use(
  (response) => {
    // If the response is successful, just pass it through
    return response;
  },
  (error) => {
    // If the backend returns a 401 Unauthorized (Expired/Invalid Token)
    if (error.response && error.response.status === 401) {
      console.warn("Session expired. Redirecting to login...");
      
      // Wipe the invalid credentials
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      
      // Force redirect to login screen
      window.location.href = "/login";
    }
    
    return Promise.reject(error);
  }
);

export default api;