import { Navigate } from "react-router-dom";

function ProtectedRoute({
  children,
  role,
}) {
  const token =
    localStorage.getItem("token");

  const loggedInFaculty =
    localStorage.getItem(
      "loggedInFaculty"
    );

  const loggedInAdmin =
    localStorage.getItem(
      "loggedInAdmin"
    );

  if (!token) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  if (
    role === "admin" &&
    !loggedInAdmin
  ) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  if (
    role === "faculty" &&
    !loggedInFaculty
  ) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  return children;
}

export default ProtectedRoute;