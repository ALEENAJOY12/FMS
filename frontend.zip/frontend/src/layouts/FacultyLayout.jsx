
import {
  NavLink,
  Outlet,
  useNavigate,
} from "react-router-dom";

import "./FacultyLayout.css";

function FacultyLayout() {
  const navigate = useNavigate();

  const faculty = JSON.parse(
    localStorage.getItem("loggedInFaculty") || "null"
  );

  // LOGOUT
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("loggedInFaculty");
    localStorage.removeItem("loggedInAdmin");

    navigate("/", {
      replace: true,
    });
  };

  // NO FACULTY SESSION
  if (!faculty) {
    return (
      <div className="faculty-layout__no-user">
        <h1>No faculty login found</h1>

        <p>Please login again.</p>

        <button
          type="button"
          onClick={() =>
            navigate("/", {
              replace: true,
            })
          }
        >
          Back to Login
        </button>
      </div>
    );
  }

  // NAVIGATION CLASS
  const getNavClass = ({ isActive }) =>
    isActive
      ? "faculty-layout__nav-link faculty-layout__nav-link--active"
      : "faculty-layout__nav-link";

  return (
    <div className="faculty-layout">
      {/* SIDEBAR */}

      <aside className="faculty-layout__sidebar">
        {/* BRAND */}

        <div className="faculty-layout__brand">
          <div className="faculty-layout__brand-mark">
            S
          </div>

          <div>
            <p>SCMS</p>
            <h2>Faculty Management</h2>
          </div>
        </div>

        {/* NAVIGATION */}

        <nav className="faculty-layout__navigation">
          <NavLink
            to="/faculty/dashboard"
            end
            className={getNavClass}
          >
            <span>⌂</span>
            Dashboard
          </NavLink>

          <NavLink
            to="/faculty/profile"
            className={getNavClass}
          >
            <span>♙</span>
            My Profile
          </NavLink>

          {/* NEW HISTORICAL ANALYTICS LINK */}

          <NavLink
            to="/faculty/historical-analytics"
            className={getNavClass}
          >
            <span>▥</span>
            My Historical Analytics
          </NavLink>

          <NavLink
            to="/faculty/fdp"
            className={getNavClass}
          >
            <span>▤</span>
            FDP
          </NavLink>

          <NavLink
            to="/faculty/nptel"
            className={getNavClass}
          >
            <span>◫</span>
            NPTEL Courses
          </NavLink>

          <NavLink
            to="/faculty/research"
            className={getNavClass}
          >
            <span>⌕</span>
            Research Papers
          </NavLink>

          <NavLink
            to="/faculty/journals"
            className={getNavClass}
          >
            <span>▧</span>
            Journal Publications
          </NavLink>

          <NavLink
            to="/faculty/patents"
            className={getNavClass}
          >
            <span>◆</span>
            Patents / IPR
          </NavLink>

          <NavLink
            to="/faculty/knowledge-transfer"
            className={getNavClass}
          >
            <span>⇄</span>
            Knowledge Transfer
          </NavLink>

          <NavLink
            to="/faculty/impact-score"
            className={getNavClass}
          >
            <span>⌁</span>
            Faculty Impact Score
          </NavLink>

          <NavLink
            to="/faculty/reports"
            className={getNavClass}
          >
            <span>▥</span>
            Reports
          </NavLink>
        </nav>

        {/* SIDEBAR FOOTER */}

        <div className="faculty-layout__sidebar-footer">
          <div className="faculty-layout__profile">
            <div className="faculty-layout__avatar">
              {faculty.name
                ? faculty.name.charAt(0).toUpperCase()
                : "F"}
            </div>

            <div>
              <strong>
                {faculty.name || "Faculty"}
              </strong>

              <span>
                {faculty.designation || "Faculty Member"}
              </span>
            </div>
          </div>

          <button
            type="button"
            className="faculty-layout__logout"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}

      <main className="faculty-layout__main">
        {/* TOP BAR */}

        <header className="faculty-layout__topbar">
          <div>
            <p>SCMS</p>
            <h1>Faculty Management System</h1>
          </div>

          <div className="faculty-layout__top-profile">
            <div className="faculty-layout__avatar faculty-layout__avatar--small">
              {faculty.name
                ? faculty.name.charAt(0).toUpperCase()
                : "F"}
            </div>

            <div>
              <strong>
                {faculty.name || "Faculty"}
              </strong>

              <span>
                {faculty.department || "Department"}
              </span>
            </div>
          </div>
        </header>

        {/* PAGE CONTENT */}

        <div className="faculty-layout__content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default FacultyLayout;
