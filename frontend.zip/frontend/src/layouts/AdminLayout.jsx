
import {
  useEffect,
  useState,
} from "react";

import {
  NavLink,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";

import "./AdminLayout.css";

const FACULTY_API = "http://localhost:5000/api/faculty";
const ACTIVITY_API = "http://localhost:5000/api/activities";

function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();

  const loggedInAdmin = JSON.parse(
    localStorage.getItem("loggedInAdmin") || "null"
  );

  const [pendingRegistrations, setPendingRegistrations] = useState(0);
  const [pendingActivities, setPendingActivities] = useState(0);

  // Load pending registrations and activities
  const loadAdminCounts = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        throw new Error("Authentication token not found.");
      }

      const [facultyResponse, activityResponse] = await Promise.all([
        fetch(FACULTY_API, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }),

        fetch(ACTIVITY_API, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }),
      ]);

      const facultyData = await facultyResponse.json();
      const activityData = await activityResponse.json();

      if (!facultyResponse.ok) {
        throw new Error(
          facultyData.message || "Unable to load faculty data."
        );
      }

      if (!activityResponse.ok) {
        throw new Error(
          activityData.message || "Unable to load activity data."
        );
      }

      const facultyList =
        facultyData.faculty ||
        facultyData.faculties ||
        [];

      const activityList = activityData.activities || [];

      const registrationCount = facultyList.filter(
        (faculty) =>
          (faculty.registrationStatus || "Pending") === "Pending"
      ).length;

      const activityCount = activityList.filter(
        (activity) =>
          (activity.status || "Pending") === "Pending"
      ).length;

      setPendingRegistrations(registrationCount);
      setPendingActivities(activityCount);
    } catch (error) {
      console.error("Unable to load admin layout data:", error);
    }
  };

  useEffect(() => {
    loadAdminCounts();
  }, [location.pathname]);

  // Logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("loggedInAdmin");
    localStorage.removeItem("loggedInFaculty");

    navigate("/", {
      replace: true,
    });
  };

  // Navigation link styling
  const getNavClass = ({ isActive }) =>
    isActive
      ? "admin-layout__nav-link admin-layout__nav-link--active"
      : "admin-layout__nav-link";

  const adminName = loggedInAdmin?.name || "Administrator";

  return (
    <div className="admin-layout">
      {/* SIDEBAR */}

      <aside className="admin-layout__sidebar">
        {/* BRAND */}

        <div className="admin-layout__brand">
          <div className="admin-layout__brand-logo">
            S
          </div>

          <div className="admin-layout__brand-text">
            <p>SCMS</p>
            <h2>Faculty Management</h2>
          </div>
        </div>

        {/* NAVIGATION */}

        <nav className="admin-layout__navigation">
          <NavLink
            to="/admin/dashboard"
            end
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">⌂</span>
            <span className="admin-layout__nav-label">Dashboard</span>
          </NavLink>

          <NavLink
            to="/admin/approvals"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">✓</span>
            <span className="admin-layout__nav-label">
              Registration Approvals
            </span>

            {pendingRegistrations > 0 && (
              <small className="admin-layout__badge">
                {pendingRegistrations}
              </small>
            )}
          </NavLink>

          <NavLink
            to="/admin/faculty"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">♙</span>
            <span className="admin-layout__nav-label">
              Faculty Directory
            </span>
          </NavLink>

          <NavLink
            to="/admin/activities"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">▤</span>
            <span className="admin-layout__nav-label">
              Activity Review
            </span>

            {pendingActivities > 0 && (
              <small className="admin-layout__badge">
                {pendingActivities}
              </small>
            )}
          </NavLink>

          {/* EXISTING FIS ANALYTICS */}

          <NavLink
            to="/admin/analytics"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">⌁</span>
            <span className="admin-layout__nav-label">
              Impact Analytics
            </span>
          </NavLink>

          {/* NEW HISTORICAL ANALYTICS */}

          <NavLink
            to="/admin/historical-analytics"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">▥</span>
            <span className="admin-layout__nav-label">
              Historical Analytics
            </span>
          </NavLink>

          <NavLink
            to="/admin/reports"
            className={getNavClass}
          >
            <span className="admin-layout__nav-icon">▧</span>
            <span className="admin-layout__nav-label">Reports</span>
          </NavLink>
        </nav>

        {/* SIDEBAR FOOTER */}

        <div className="admin-layout__sidebar-footer">
          <div className="admin-layout__profile">
            <div className="admin-layout__avatar">A</div>

            <div className="admin-layout__profile-details">
              <strong>{adminName}</strong>
              <span>System Admin</span>
            </div>
          </div>

          <button
            type="button"
            className="admin-layout__logout"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}

      <main className="admin-layout__main">
        {/* TOP BAR */}

        <header className="admin-layout__topbar">
          <div className="admin-layout__topbar-title">
            <p>SCMS</p>
            <h1>Faculty Management System</h1>
          </div>

          <div className="admin-layout__topbar-profile">
            <div className="admin-layout__avatar admin-layout__avatar--small">
              A
            </div>

            <div>
              <strong>{adminName}</strong>
              <span>SCMS</span>
            </div>
          </div>
        </header>

        {/* PAGE CONTENT */}

        <div className="admin-layout__page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default AdminLayout;
