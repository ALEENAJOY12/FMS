
import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";

import ProtectedRoute from "./components/ProtectedRoute";

import AdminLayout from "./layouts/AdminLayout";
import FacultyLayout from "./layouts/FacultyLayout";

// Admin pages
import AdminOverview from "./pages/admin/AdminOverview";
import RegistrationApprovals from "./pages/admin/RegistrationApprovals";
import FacultyDirectory from "./pages/admin/FacultyDirectory";
import ActivityReview from "./pages/admin/ActivityReview";
import ImpactAnalytics from "./pages/admin/ImpactAnalytics";
import HistoricalAnalytics from "./pages/admin/HistoricalAnalytics";
import AdminReports from "./pages/admin/AdminReports";

// Faculty pages
import FacultyOverview from "./pages/faculty/FacultyOverview";
import FacultyProfile from "./pages/faculty/FacultyProfile";
import FDP from "./pages/faculty/FDP";
import NPTELCourses from "./pages/faculty/NPTELCourses";
import ResearchPapers from "./pages/faculty/ResearchPapers";
import JournalPublications from "./pages/faculty/JournalPublications";
import PatentsIPR from "./pages/faculty/PatentsIPR";
import KnowledgeTransfer from "./pages/faculty/KnowledgeTransfer";
import FacultyImpactScore from "./pages/faculty/FacultyImpactScore";
import FacultyReports from "./pages/faculty/FacultyReports";
import FacultyHistoricalAnalytics from "./pages/faculty/FacultyHistoricalAnalytics";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* PUBLIC ROUTES */}

        <Route
          path="/"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />

        {/* ADMIN PROTECTED ROUTES */}

        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          <Route
            index
            element={
              <Navigate
                to="dashboard"
                replace
              />
            }
          />

          <Route
            path="dashboard"
            element={<AdminOverview />}
          />

          <Route
            path="approvals"
            element={<RegistrationApprovals />}
          />

          <Route
            path="faculty"
            element={<FacultyDirectory />}
          />

          <Route
            path="activities"
            element={<ActivityReview />}
          />

          {/* Existing FIS Impact Analytics */}
          <Route
            path="analytics"
            element={<ImpactAnalytics />}
          />

          {/* College-wide Historical Analytics */}
          <Route
            path="historical-analytics"
            element={<HistoricalAnalytics />}
          />

          <Route
            path="reports"
            element={<AdminReports />}
          />
        </Route>

        {/* FACULTY PROTECTED ROUTES */}

        <Route
          path="/faculty"
          element={
            <ProtectedRoute role="faculty">
              <FacultyLayout />
            </ProtectedRoute>
          }
        >
          <Route
            index
            element={
              <Navigate
                to="dashboard"
                replace
              />
            }
          />

          <Route
            path="dashboard"
            element={<FacultyOverview />}
          />

          <Route
            path="profile"
            element={<FacultyProfile />}
          />

          {/* Personal Historical Analytics */}
          <Route
            path="historical-analytics"
            element={<FacultyHistoricalAnalytics />}
          />

          <Route
            path="fdp"
            element={<FDP />}
          />

          <Route
            path="nptel"
            element={<NPTELCourses />}
          />

          <Route
            path="research"
            element={<ResearchPapers />}
          />

          <Route
            path="journals"
            element={<JournalPublications />}
          />

          <Route
            path="patents"
            element={<PatentsIPR />}
          />

          <Route
            path="knowledge-transfer"
            element={<KnowledgeTransfer />}
          />

          <Route
            path="impact-score"
            element={<FacultyImpactScore />}
          />

          <Route
            path="reports"
            element={<FacultyReports />}
          />
        </Route>

        {/* UNKNOWN ROUTE */}

        <Route
          path="*"
          element={
            <Navigate
              to="/"
              replace
            />
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
