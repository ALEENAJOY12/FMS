import { useState } from "react";
import "./Login.css";

import logo from "../assets/logo.png";
import college from "../assets/college.jpg";

// ========================================
// BACKEND CONFIGURATION
// ========================================

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

const AUTH_API = `${BACKEND_URL}/api/auth`;

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // ========================================
  // ADMIN LOGIN IDENTIFIER
  // ========================================

  const adminEmail = "admin@scmsgroup.org";

  const emailPattern =
    /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i;

  // ========================================
  // LOGIN
  // ========================================

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage("");

    const cleanEmail = email.trim().toLowerCase();

    if (!emailPattern.test(cleanEmail)) {
      setErrorMessage("Enter a valid email address.");
      return;
    }

    if (!password) {
      setErrorMessage("Enter your password.");
      return;
    }

    setIsLoading(true);

    try {
      // ======================================
      // ADMIN LOGIN
      // ======================================

      if (cleanEmail === adminEmail.toLowerCase()) {
        const response = await fetch(`${AUTH_API}/admin/login`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: cleanEmail,
            password,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          setErrorMessage(
            data.message || "Unable to login as administrator."
          );
          return;
        }

        if (!data.admin || !data.token) {
          setErrorMessage(
            "Administrator authentication information was not returned by the server."
          );
          return;
        }

        localStorage.setItem("token", data.token);

        localStorage.setItem(
          "loggedInAdmin",
          JSON.stringify(data.admin)
        );

        localStorage.removeItem("loggedInFaculty");

        window.location.href = "/admin/dashboard";
        return;
      }

      // ======================================
      // FACULTY LOGIN
      // ======================================

      const response = await fetch(`${AUTH_API}/faculty/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: cleanEmail,
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setErrorMessage(data.message || "Unable to login.");
        return;
      }

      if (!data.faculty) {
        setErrorMessage(
          "Faculty information was not returned by the server."
        );
        return;
      }

      if (!data.token) {
        setErrorMessage(
          "Authentication token was not returned by the server."
        );
        return;
      }

      localStorage.setItem("token", data.token);

      localStorage.setItem(
        "loggedInFaculty",
        JSON.stringify(data.faculty)
      );

      localStorage.removeItem("loggedInAdmin");

      window.location.href = "/faculty/dashboard";
    } catch (error) {
      console.error("Login error:", error);

      setErrorMessage(
        "Unable to connect to the server. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================
  // REGISTER
  // ========================================

  const handleCreateAccount = () => {
    window.location.href = "/register";
  };

  // ========================================
  // JSX
  // ========================================

  return (
    <div className="login-page">
      {/* BACKGROUND */}

      <div className="login-bg" aria-hidden="true">
        <span className="login-orb login-orb--1" />
        <span className="login-orb login-orb--2" />
        <span className="login-orb login-orb--3" />
      </div>

      <div className="login-shell">
        {/* LEFT SIDE */}

        <aside className="login-hero">
          <img
            src={college}
            alt="SCMS School of Engineering and Technology"
            className="login-hero__image"
          />

          <div className="login-hero__overlay" />

          <div className="login-hero__content">
            <header className="login-brand">
              <div className="login-brand__top">
                <img
                  src={logo}
                  alt="SCMS Logo"
                  className="login-brand__logo"
                />

                <div className="login-brand__meta">
                  <p className="login-brand__eyebrow">SCMS</p>

                  <p className="login-brand__institution">
                    School of Engineering
                    &amp; Technology
                  </p>
                </div>
              </div>

              <div
                className="login-brand__rule"
                aria-hidden="true"
              />

              <h1 className="login-brand__title">
                <span>FACULTY</span>
                <span>MANAGEMENT SYSTEM</span>
              </h1>

              <p className="login-brand__tagline">
                MANAGE · TRACK · EVALUATE · EXCEL
              </p>
            </header>
          </div>
        </aside>

        {/* RIGHT SIDE */}

        <section className="login-panel">
          <div className="login-card">
            <header className="login-card__header">
              <h2 className="login-card__heading">
                WELCOME BACK
              </h2>

              <p className="login-card__subheading">
                Sign in with your account credentials to continue
              </p>

              <div
                className="login-card__rule"
                aria-hidden="true"
              />
            </header>

            {/* LOGIN FORM */}

            <form
              className="login-form"
              onSubmit={handleSubmit}
              autoComplete="off"
              noValidate
            >
              {/* EMAIL */}

              <div className="login-field">
                <label htmlFor="email">Username</label>

                <div className="login-input">
                  <span
                    className="login-input__icon"
                    aria-hidden="true"
                  >
                    <svg viewBox="0 0 24 24" fill="none">
                      <path
                        d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"
                        stroke="currentColor"
                        strokeWidth="1.75"
                      />

                      <path
                        d="m22 6-10 7L2 6"
                        stroke="currentColor"
                        strokeWidth="1.75"
                        strokeLinecap="round"
                      />
                    </svg>
                  </span>

                  <input
                    id="email"
                    name="fms-login-email"
                    type="email"
                    placeholder="name@scmsgroup.org"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setErrorMessage("");
                    }}
                    autoComplete="off"
                    required
                  />
                </div>
              </div>

              {/* PASSWORD */}

              <div className="login-field">
                <div className="login-field__row">
                  <label htmlFor="password">Password</label>
                </div>

                <div className="login-input">
                  <span
                    className="login-input__icon"
                    aria-hidden="true"
                  >
                    <svg viewBox="0 0 24 24" fill="none">
                      <rect
                        x="3"
                        y="11"
                        width="18"
                        height="11"
                        rx="2"
                        stroke="currentColor"
                        strokeWidth="1.75"
                      />

                      <path
                        d="M7 11V7a5 5 0 0 1 10 0v4"
                        stroke="currentColor"
                        strokeWidth="1.75"
                        strokeLinecap="round"
                      />
                    </svg>
                  </span>

                  <input
                    id="password"
                    name="fms-login-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setErrorMessage("");
                    }}
                    autoComplete="new-password"
                    required
                  />

                  {/* SHOW / HIDE PASSWORD */}

                  <button
                    type="button"
                    className="login-input__toggle"
                    onClick={() =>
                      setShowPassword((previous) => !previous)
                    }
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                    aria-pressed={showPassword}
                  >
                    {showPassword ? (
                      <svg viewBox="0 0 24 24" fill="none">
                        <path
                          d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"
                          stroke="currentColor"
                          strokeWidth="1.75"
                          strokeLinecap="round"
                        />

                        <path
                          d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"
                          stroke="currentColor"
                          strokeWidth="1.75"
                          strokeLinecap="round"
                        />

                        <line
                          x1="1"
                          y1="1"
                          x2="23"
                          y2="23"
                          stroke="currentColor"
                          strokeWidth="1.75"
                          strokeLinecap="round"
                        />
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" fill="none">
                        <path
                          d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"
                          stroke="currentColor"
                          strokeWidth="1.75"
                        />

                        <circle
                          cx="12"
                          cy="12"
                          r="3"
                          stroke="currentColor"
                          strokeWidth="1.75"
                        />
                      </svg>
                    )}
                  </button>
                </div>
              </div>

              {/* ERROR MESSAGE */}

              {errorMessage && (
                <div className="login-error" role="alert">
                  {errorMessage}
                </div>
              )}

              {/* SIGN IN BUTTON */}

              <button
                type="submit"
                className="login-submit"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span
                      className="login-submit__spinner"
                      aria-hidden="true"
                    />
                    SIGNING IN…
                  </>
                ) : (
                  "SIGN IN"
                )}
              </button>
            </form>

            {/* REGISTER */}

            <p className="login-register">
              New to the system?{" "}

              <button
                type="button"
                className="login-register__link"
                onClick={handleCreateAccount}
              >
                Create an account
              </button>
            </p>
          </div>
        </section>
      </div>

      {/* FOOTER */}

      <footer className="login-footer">
        <span>
          SCMS School of Engineering &amp; Technology, Karukutty,
          Ernakulam, Kerala
        </span>

        <span
          className="login-footer__divider"
          aria-hidden="true"
        />

        <span>0484 2450330</span>

        <span
          className="login-footer__divider"
          aria-hidden="true"
        />

        <a
          href="https://www.scmsgroup.org/sset"
          target="_blank"
          rel="noreferrer"
        >
          www.scmsgroup.org/sset
        </a>
      </footer>
    </div>
  );
}

export default Login;