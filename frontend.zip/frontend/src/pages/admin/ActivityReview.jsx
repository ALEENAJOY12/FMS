import {
  useEffect,
  useMemo,
  useState,
} from "react";

import jsPDF from "jspdf";
import "./ActivityReview.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "http://localhost:5000";

const API_BASE_URL =
  `${BACKEND_URL}/api`;

const API_URL =
  `${API_BASE_URL}/activities`;

const activityCategories = [
  "All",
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
];

const statusOptions = [
  "All",
  "Pending",
  "Approved",
  "Rejected",
];

function ActivityReview() {
  const [activities, setActivities] =
    useState([]);

  const [searchText, setSearchText] =
    useState("");

  const [
    categoryFilter,
    setCategoryFilter,
  ] = useState("All");

  const [
    statusFilter,
    setStatusFilter,
  ] = useState("All");

  const [
    contributionFilter,
    setContributionFilter,
  ] = useState("All");

  const [
    selectedActivity,
    setSelectedActivity,
  ] = useState(null);

  const [loading, setLoading] =
    useState(true);

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [
    successMessage,
    setSuccessMessage,
  ] = useState("");

  const [
    actionLoadingId,
    setActionLoadingId,
  ] = useState("");


  // =========================================================
  // LOAD ALL ACTIVITIES FROM MONGODB
  // =========================================================

  const loadActivities = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response =
        await fetch(
          API_URL,
          {
            headers: {
              Authorization:
                `Bearer ${token}`,
            },
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load faculty activities."
        );
      }

      setActivities(
        data.activities || []
      );
    } catch (error) {
      console.error(
        "Activity load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  // =========================================================
  // UPDATE ACTIVITY IN MONGODB
  // =========================================================

  const updateActivityInDatabase =
    async (id, updates) => {
      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response =
        await fetch(
          `${API_URL}/${id}`,
          {
            method: "PUT",

            headers: {
              "Content-Type":
                "application/json",

              Authorization:
                `Bearer ${token}`,
            },

            body:
              JSON.stringify(
                updates
              ),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to update activity."
        );
      }

      return data.activity;
    };

  // =========================================================
  // UPDATE FRONTEND STATE
  // =========================================================

  const updateActivityState = (
    updatedActivity
  ) => {
    setActivities(
      (previous) =>
        previous.map(
          (activity) =>
            activity._id ===
            updatedActivity._id
              ? updatedActivity
              : activity
        )
    );

    if (
      selectedActivity?._id ===
      updatedActivity._id
    ) {
      setSelectedActivity(
        updatedActivity
      );
    }
  };

  // =========================================================
  // HELPERS
  // =========================================================

  const toClassSuffix = (
    value,
    fallback = "pending"
  ) =>
    String(value || fallback)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "-");

  const resolveProofUrl = (
    value
  ) => {
    if (!value) {
      return "";
    }

    const cleanValue =
      String(value).trim();

    if (
      cleanValue.startsWith(
        "data:"
      )
    ) {
      return cleanValue;
    }

    if (
      cleanValue.startsWith(
        "http://localhost:5000"
      )
    ) {
      try {
        const parsed =
          new URL(
            cleanValue
          );

        return `${BACKEND_URL}${parsed.pathname}${parsed.search}`;
      } catch {
        return cleanValue;
      }
    }

    if (
      /^https?:\/\//i.test(
        cleanValue
      )
    ) {
      return cleanValue;
    }

    return `${BACKEND_URL}${
      cleanValue.startsWith("/")
        ? ""
        : "/"
    }${cleanValue}`;
  };

  const runActivityAction =
    async (
      id,
      updates,
      successText
    ) => {
      try {
        setActionLoadingId(id);
        setErrorMessage("");
        setSuccessMessage("");

        const updatedActivity =
          await updateActivityInDatabase(
            id,
            updates
          );

        updateActivityState(
          updatedActivity
        );

        setSuccessMessage(
          successText
        );
      } catch (error) {
        setErrorMessage(
          error.message ||
            "Unable to update activity."
        );
      } finally {
        setActionLoadingId("");
      }
    };

  // =========================================================
  // MAIN ACTIVITY APPROVAL
  // =========================================================

  const handleApprove =
    async (activity) => {
      const updates = {
        status: "Approved",
        rejectionReason: "",
        reviewedAt:
          new Date().toISOString(),
      };

      /*
        Do NOT automatically approve a contribution
        when the main activity is approved.

        If a contribution exists and has never been
        reviewed, it remains Pending for separate
        administrator review.
      */
      if (
        activity.contributionDone ===
          "Yes" &&
        !activity.contributionStatus
      ) {
        updates.contributionStatus =
          "Pending";

        updates.contributionReviewComment =
          "";

        updates.contributionReviewedAt =
          null;
      }

      await runActivityAction(
        activity._id,
        updates,
        "Activity approved successfully."
      );
    };

  const handleReject =
    async (activity) => {
      const reason =
        window.prompt(
          "Enter the reason for rejecting this activity:"
        );

      if (reason === null) {
        return;
      }

      const cleanReason =
        reason.trim();

      if (!cleanReason) {
        setErrorMessage(
          "Please enter a rejection reason."
        );
        return;
      }

      const updates = {
        status: "Rejected",
        rejectionReason:
          cleanReason,
        reviewedAt:
          new Date().toISOString(),
      };

      /*
        A contribution cannot stay Approved
        when its parent/main activity is Rejected.
        Reset contribution review to Pending so
        the workflow remains consistent after the
        faculty corrects and resubmits the activity.
      */
      if (
        activity.contributionDone ===
        "Yes"
      ) {
        updates.contributionStatus =
          "Pending";

        updates.contributionReviewComment =
          "";

        updates.contributionReviewedAt =
          null;
      }

      await runActivityAction(
        activity._id,
        updates,
        "Activity rejected."
      );
    };

  const handleMoveToPending =
    async (activity) => {
      const updates = {
        status: "Pending",
        rejectionReason: "",
        reviewedAt: null,
      };

      /*
        If the main activity is reopened,
        its contribution review must also
        return to Pending.
      */
      if (
        activity.contributionDone ===
        "Yes"
      ) {
        updates.contributionStatus =
          "Pending";

        updates.contributionReviewComment =
          "";

        updates.contributionReviewedAt =
          null;
      }

      await runActivityAction(
        activity._id,
        updates,
        "Activity moved to Pending."
      );
    };

  // =========================================================
  // CONTRIBUTION APPROVAL
  // =========================================================

  const handleApproveContribution =
    async (activity) => {
      if (
        activity.status !==
        "Approved"
      ) {
        setErrorMessage(
          "Approve the main activity before approving its contribution."
        );
        return;
      }

      await runActivityAction(
        activity._id,
        {
          contributionStatus:
            "Approved",
          contributionReviewComment:
            "",
          contributionReviewedAt:
            new Date().toISOString(),
        },
        "Contribution approved successfully."
      );
    };

  const handleRejectContribution =
    async (activity) => {
      if (
        activity.status !==
        "Approved"
      ) {
        setErrorMessage(
          "Approve the main activity before reviewing its contribution."
        );
        return;
      }

      const reason =
        window.prompt(
          "Enter the reason for rejecting this contribution:"
        );

      if (reason === null) {
        return;
      }

      const cleanReason =
        reason.trim();

      if (!cleanReason) {
        setErrorMessage(
          "Please enter a contribution rejection reason."
        );
        return;
      }

      await runActivityAction(
        activity._id,
        {
          contributionStatus:
            "Rejected",
          contributionReviewComment:
            cleanReason,
          contributionReviewedAt:
            new Date().toISOString(),
        },
        "Contribution rejected."
      );
    };

  const handleContributionPending =
    async (activity) => {
      if (
        activity.status !==
        "Approved"
      ) {
        setErrorMessage(
          "Approve the main activity before reviewing its contribution."
        );
        return;
      }

      await runActivityAction(
        activity._id,
        {
          contributionStatus:
            "Pending",
          contributionReviewComment:
            "",
          contributionReviewedAt:
            null,
        },
        "Contribution moved to Pending."
      );
    };

  // =========================================================
  // DELETE ACTIVITY
  // =========================================================

  const handleDelete =
    async (activity) => {
      const confirmed =
        window.confirm(
          `Are you sure you want to permanently delete "${
            activity.title ||
            "this activity"
          }"?`
        );

      if (!confirmed) {
        return;
      }

      try {
        setActionLoadingId(
          activity._id
        );
        setErrorMessage("");
        setSuccessMessage("");

        const token =
          localStorage.getItem(
            "token"
          );

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/${activity._id}`,
            {
              method:
                "DELETE",

              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to delete activity."
          );
        }

        setActivities(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !==
                activity._id
            )
        );

        if (
          selectedActivity?._id ===
          activity._id
        ) {
          setSelectedActivity(
            null
          );
        }

        setSuccessMessage(
          "Activity deleted successfully."
        );
      } catch (error) {
        setErrorMessage(
          error.message ||
            "Unable to delete activity."
        );
      } finally {
        setActionLoadingId("");
      }
    };

  // =========================================================
  // FILTERING
  // =========================================================

  const filteredActivities =
    useMemo(() => {
      const searchValue =
        searchText
          .trim()
          .toLowerCase();

      return activities.filter(
        (activity) => {
          const status =
            activity.status ||
            "Pending";

          const searchableValues =
            [
              activity.facultyName,
              activity.facultyId,
              activity.department,
              activity.type,
              activity.title,
              activity.organizer,
              activity.publisher,
              activity.institution,
              activity.journalName,
              activity.conferenceName,
              activity.contributionTitle,
              activity.contributionType,
              activity.contributionFor,
              activity.targetGroup,
              activity.departmentTarget,
            ];

          const matchesSearch =
            !searchValue ||
            searchableValues.some(
              (item) =>
                String(
                  item || ""
                )
                  .toLowerCase()
                  .includes(
                    searchValue
                  )
            );

          const matchesCategory =
            categoryFilter ===
              "All" ||
            activity.type ===
              categoryFilter;

          const matchesStatus =
            statusFilter ===
              "All" ||
            status ===
              statusFilter;

          const normalizedContributionStatus =
            activity.contributionDone ===
            "Yes"
              ? activity.contributionStatus ||
                "Pending"
              : "Not Applicable";

          const matchesContribution =
            contributionFilter ===
              "All" ||
            activity.contributionFor ===
              contributionFilter ||
            normalizedContributionStatus ===
              contributionFilter;

          return (
            matchesSearch &&
            matchesCategory &&
            matchesStatus &&
            matchesContribution
          );
        }
      );
    }, [
      activities,
      searchText,
      categoryFilter,
      statusFilter,
      contributionFilter,
    ]);

  // =========================================================
  // COUNTS
  // =========================================================

  const pendingCount =
    activities.filter(
      (activity) =>
        (activity.status ||
          "Pending") ===
        "Pending"
    ).length;

  const approvedCount =
    activities.filter(
      (activity) =>
        activity.status ===
        "Approved"
    ).length;

  const rejectedCount =
    activities.filter(
      (activity) =>
        activity.status ===
        "Rejected"
    ).length;

  const contributionCount =
    activities.filter(
      (activity) =>
        activity.contributionDone ===
        "Yes"
    ).length;

  const pendingContributionCount =
    activities.filter(
      (activity) =>
        activity.contributionDone ===
          "Yes" &&
        (activity.contributionStatus ||
          "Pending") ===
          "Pending"
    ).length;

  const approvedContributionCount =
    activities.filter(
      (activity) =>
        activity.status ===
          "Approved" &&
        activity.contributionDone ===
          "Yes" &&
        activity.contributionStatus ===
          "Approved"
    ).length;

  const rejectedContributionCount =
    activities.filter(
      (activity) =>
        activity.status ===
          "Approved" &&
        activity.contributionDone ===
          "Yes" &&
        activity.contributionStatus ===
          "Rejected"
    ).length;

  const studentContributionCount =
    activities.filter(
      (activity) =>
        activity.contributionDone ===
          "Yes" &&
        (
          activity.contributionFor ===
            "Students" ||
          activity.contributionFor ===
            "Both"
        )
    ).length;

  const departmentContributionCount =
    activities.filter(
      (activity) =>
        activity.contributionDone ===
          "Yes" &&
        (
          activity.contributionFor ===
            "Department" ||
          activity.contributionFor ===
            "Both"
        )
    ).length;

  // =========================================================
  // DATE FORMAT
  // =========================================================

  const formatDate = (
    dateValue
  ) => {
    if (!dateValue) {
      return "-";
    }

    const date =
      new Date(dateValue);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return String(dateValue);
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  // =========================================================
  // DOWNLOAD COMPLETE ACTIVITY REPORT AS PDF
  // =========================================================

  const downloadActivityPdf = async () => {
    if (!selectedActivity) return;

    const activity = selectedActivity;
    const pdf = new jsPDF({ unit: "mm", format: "a4" });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 16;
    const contentWidth = pageWidth - margin * 2;
    let y = 18;

    const clean = (value) => {
      if (value === null || value === undefined || value === "") return "Not recorded";
      if (typeof value === "object") return JSON.stringify(value);
      return String(value);
    };

    const dateText = (value) => {
      if (!value) return "Not recorded";
      const date = new Date(value);
      return Number.isNaN(date.getTime())
        ? clean(value)
        : date.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
    };

    const newPage = () => {
      pdf.addPage();
      y = 18;
      drawPageHeader();
    };

    const ensureSpace = (height) => {
      if (y + height > pageHeight - 18) newPage();
    };

    const drawPageHeader = () => {
      // Elegant navy header with a slim teal accent.
      pdf.setFillColor(12, 35, 64);
      pdf.rect(0, 0, pageWidth, 13, "F");
      pdf.setFillColor(20, 184, 166);
      pdf.rect(0, 13, pageWidth, 1.2, "F");
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(8);
      pdf.setTextColor(255, 255, 255);
      pdf.text("FACULTY MANAGEMENT SYSTEM", margin, 8.2);
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(7);
      pdf.text("ACTIVITY RECORDS  /  REVIEW REPORT", pageWidth - margin, 8.2, { align: "right" });
      pdf.setTextColor(35, 48, 65);
    };

    const heading = (title) => {
      ensureSpace(18);
      y += 3;
      pdf.setFillColor(239, 246, 255);
      pdf.roundedRect(margin, y - 4, contentWidth, 10, 2, 2, "F");
      pdf.setFillColor(20, 184, 166);
      pdf.roundedRect(margin, y - 4, 1.5, 10, 0.7, 0.7, "F");
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      pdf.setTextColor(12, 35, 64);
      pdf.text(title, margin + 4, y + 2.5);
      y += 12;
      pdf.setTextColor(40, 52, 68);
    };

    const paragraph = (label, value) => {
      const textValue = clean(value);
      const lines = pdf.splitTextToSize(textValue, contentWidth - 8);
      const lineHeight = 4.6;
      const boxHeight = Math.max(19, lines.length * lineHeight + 13);
      ensureSpace(boxHeight + 3);
      pdf.setFillColor(248, 250, 252);
      pdf.setDrawColor(225, 232, 240);
      pdf.roundedRect(margin, y - 2, contentWidth, boxHeight, 2, 2, "FD");
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(8);
      pdf.setTextColor(71, 85, 105);
      pdf.text(label.toUpperCase(), margin + 4, y + 4);
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(9);
      pdf.setTextColor(30, 41, 59);
      pdf.text(lines, margin + 4, y + 10, { lineHeightFactor: 1.25 });
      y += boxHeight + 4;
    };

    const field = (label, value) => {
      const valueLines = pdf.splitTextToSize(clean(value), contentWidth - 2);
      const blockHeight = Math.max(8, valueLines.length * 4.2 + 5);
      ensureSpace(blockHeight);
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(8.5);
      pdf.setTextColor(78, 94, 112);
      pdf.text(`${label}`, margin, y);
      y += 4;
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(9);
      pdf.setTextColor(30, 41, 59);
      pdf.text(valueLines, margin, y);
      y += valueLines.length * 4.2 + 3;
    };

    const loadImageData = async (value) => {
      if (!value) return null;
      const url = resolveProofUrl(value);
      if (url.startsWith("data:image/")) return url;
      try {
        const response = await fetch(url, { credentials: "include" });
        if (!response.ok) return null;
        const blob = await response.blob();
        if (!blob.type.startsWith("image/")) return null;
        return await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : null);
          reader.onerror = () => resolve(null);
          reader.readAsDataURL(blob);
        });
      } catch (error) {
        console.warn("Could not load proof image for PDF:", error);
        return null;
      }
    };

    const addProofImage = async (title, proofValue) => {
      heading(title);
      if (!proofValue) {
        field("Evidence", "No proof uploaded");
        return;
      }
      const imageData = await loadImageData(proofValue);
      if (!imageData) {
        field("Evidence", "A proof file is recorded, but an image preview could not be embedded. The file may be a PDF/document or the server may block image access.");
        return;
      }
      try {
        const props = pdf.getImageProperties(imageData);
        const maxWidth = contentWidth;
        const maxHeight = 95;
        const ratio = Math.min(maxWidth / props.width, maxHeight / props.height);
        const imageWidth = props.width * ratio;
        const imageHeight = props.height * ratio;
        ensureSpace(imageHeight + 8);
        pdf.setDrawColor(220, 228, 237);
        pdf.roundedRect(margin, y - 2, imageWidth + 4, imageHeight + 4, 2, 2, "S");
        pdf.addImage(imageData, props.fileType || "JPEG", margin + 2, y, imageWidth, imageHeight, undefined, "FAST");
        y += imageHeight + 8;
      } catch (error) {
        console.warn("Could not embed proof image in PDF:", error);
        field("Evidence", "The proof image could not be embedded in this PDF.");
      }
    };

    drawPageHeader();
    // Report title block
    pdf.setFillColor(247, 250, 253);
    pdf.roundedRect(margin, y - 3, contentWidth, 25, 3, 3, "F");
    pdf.setFillColor(20, 184, 166);
    pdf.roundedRect(margin, y - 3, 2, 25, 1, 1, "F");
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(18);
    pdf.setTextColor(12, 35, 64);
    pdf.text("Activity Review Report", margin + 6, y + 6);
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8.5);
    pdf.setTextColor(100, 116, 139);
    pdf.text("Faculty activity record, review decisions and supporting evidence", margin + 6, y + 13);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(8);
    pdf.setTextColor(51, 65, 85);
    pdf.text(`Generated: ${new Date().toLocaleString("en-IN")}`, pageWidth - margin - 5, y + 19, { align: "right" });
    y += 30;

    heading("Faculty and Activity Information");
    [
      ["Faculty Name", activity.facultyName],
      ["Faculty ID", activity.facultyId],
      ["Department", activity.department],
      ["Activity Title", activity.title],
      ["Activity Type", activity.type],
      ["Organizer / Publisher / Institution", activity.organizer || activity.publisher || activity.institution || activity.journalName || activity.conferenceName],
      ["Activity Date", dateText(activity.activityDate || activity.date || activity.startDate || activity.publicationDate || activity.filingDate)],
      ["Academic Year", activity.academicYear],
      ["Submitted Date", dateText(activity.submissionDate || activity.createdAt || activity.submittedAt)],
      ["Description", activity.description],
      ["Main Activity Status", activity.status || "Pending"],
    ].forEach(([label, value]) => field(label, value));

    heading("Activity Summary");
    paragraph(
      "Summary of the Activity",
      activity.description || activity.summary || activity.activitySummary ||
        `This ${clean(activity.type).toLowerCase()} activity titled “${clean(activity.title)}” was submitted by ${clean(activity.facultyName)}${activity.department ? ` from the ${activity.department} department` : ""}. The activity was organized or published by ${clean(activity.organizer || activity.publisher || activity.institution || activity.journalName || activity.conferenceName)}. Its current review status is ${clean(activity.status || "Pending")}.`
    );

    heading("Main Activity Review History");
    [
      ["Review Status", activity.status || "Pending"],
      ["Reviewed By", activity.reviewedByName || activity.reviewerName || activity.reviewedBy],
      ["Review Date", dateText(activity.reviewedAt || activity.reviewDate)],
      ["Approved By", activity.approvedByName || activity.approverName || activity.approvedBy],
      ["Rejection Reason / Review Note", activity.rejectionReason || activity.reviewComment || activity.reviewNote],
    ].forEach(([label, value]) => field(label, value));
    await addProofImage("Main Activity Evidence", activity.proof);

    heading("Contribution and Impact Details");
    [
      ["Contribution Submitted", activity.contributionDone],
      ["Contribution Type", activity.contributionType],
      ["Contribution Title", activity.contributionTitle],
      ["Contribution Date", dateText(activity.contributionDate)],
      ["Contribution For", activity.contributionFor],
      ["Impact Level", activity.impactLevel],
      ["Contribution Description", activity.contributionDescription],
      ["Target Group", activity.targetGroup],
      ["Participant Count", activity.participantCount],
      ["Department Target", activity.departmentTarget],
      ["Contribution Status", activity.contributionStatus],
      ["Contribution Reviewed By", activity.contributionReviewedByName || activity.contributionReviewedBy],
      ["Contribution Review Date", dateText(activity.contributionReviewedAt)],
      ["Contribution Review Comment", activity.contributionReviewComment],
    ].forEach(([label, value]) => field(label, value));
    if (activity.contributionDone === "Yes" || activity.contributionProof) {
      await addProofImage("Contribution Evidence", activity.contributionProof);
    }

    const totalPages = pdf.getNumberOfPages();
    for (let page = 1; page <= totalPages; page += 1) {
      pdf.setPage(page);
      pdf.setDrawColor(220, 228, 237);
      pdf.line(margin, pageHeight - 13, pageWidth - margin, pageHeight - 13);
      pdf.setFillColor(20, 184, 166);
      pdf.rect(margin, pageHeight - 13, 18, 0.7, "F");
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(7.5);
      pdf.setTextColor(115, 128, 144);
      pdf.text("CONFIDENTIAL  |  FACULTY MANAGEMENT SYSTEM", margin, pageHeight - 7);
      pdf.text(`Page ${page} of ${totalPages}`, pageWidth - margin, pageHeight - 7, { align: "right" });
    }

    const safeFacultyId = clean(activity.facultyId).replace(/[^a-zA-Z0-9_-]/g, "_");
    const safeTitle = clean(activity.title).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40);
    pdf.save(`Activity_Report_${safeFacultyId}_${safeTitle}.pdf`);
  };

  // =========================================================
  // JSX
  // =========================================================

  return (
    <div className="activity-review">
      {/* HEADER */}

      <section className="activity-review__heading">
        <div>
          <p className="activity-review__eyebrow">
            ACADEMIC RECORDS
          </p>

          <h1>
            Activity Review
          </h1>

          <p>
            Review faculty activities,
            supporting documents,
            knowledge-transfer
            contributions and their
            impact.
          </p>
        </div>

        <div className="activity-review__heading-badges">
          <span className="activity-review__pending-badge">
            {pendingCount} Activities
            Pending
          </span>

          <span className="activity-review__contribution-badge">
            {pendingContributionCount}{" "}
            Contributions Pending
          </span>

          {rejectedCount > 0 && (
            <span className="activity-review__contribution-badge">
              {rejectedCount}{" "}
              Activities Rejected
            </span>
          )}
        </div>
      </section>

      {/* MESSAGES */}

      {errorMessage && (
        <div className="activity-review__message activity-review__message--error">
          {errorMessage}
        </div>
      )}

      {successMessage && (
        <div className="activity-review__message activity-review__message--success">
          {successMessage}
        </div>
      )}

      {/* STATS */}

      <section className="activity-review__stats">
        <article>
          <span>
            Total Activities
          </span>

          <strong>
            {activities.length}
          </strong>

          <small>
            All faculty submissions
          </small>
        </article>

        <article>
          <span>
            Approved Activities
          </span>

          <strong>
            {approvedCount}
          </strong>

          <small>
            Verified records
          </small>
        </article>

        <article>
          <span>
            Pending Contributions
          </span>

          <strong>
            {
              pendingContributionCount
            }
          </strong>

          <small>
            Waiting for review
          </small>
        </article>

        <article>
          <span>
            Approved Contributions
          </span>

          <strong>
            {
              approvedContributionCount
            }
          </strong>

          <small>
            Verified knowledge transfer
          </small>
        </article>
      </section>

      {/* EXTRA STATS */}

      <section className="activity-review__mini-stats">
        <article>
          <span>
            Total Contributions
          </span>

          <strong>
            {contributionCount}
          </strong>
        </article>

        <article>
          <span>
            Student Contributions
          </span>

          <strong>
            {
              studentContributionCount
            }
          </strong>
        </article>

        <article>
          <span>
            Department Contributions
          </span>

          <strong>
            {
              departmentContributionCount
            }
          </strong>
        </article>

        <article>
          <span>
            Rejected Contributions
          </span>

          <strong>
            {
              rejectedContributionCount
            }
          </strong>
        </article>
      </section>

      {/* MAIN CARD */}

      <section className="activity-review__card">
        {/* TOOLBAR */}

        <div className="activity-review__toolbar">
          <div className="activity-review__search">
            <span>⌕</span>

            <input
              type="text"
              placeholder="Search faculty, activity, department or contribution"
              value={
                searchText
              }
              onChange={(event) =>
                setSearchText(
                  event.target
                    .value
                )
              }
            />
          </div>

          <div className="activity-review__filters">
            <select
              value={
                categoryFilter
              }
              onChange={(event) =>
                setCategoryFilter(
                  event.target
                    .value
                )
              }
            >
              {activityCategories.map(
                (category) => (
                  <option
                    value={
                      category
                    }
                    key={
                      category
                    }
                  >
                    {category ===
                    "All"
                      ? "All Activity Types"
                      : category}
                  </option>
                )
              )}
            </select>

            <select
              value={
                contributionFilter
              }
              onChange={(event) =>
                setContributionFilter(
                  event.target
                    .value
                )
              }
            >
              <option value="All">
                All Contribution Targets
              </option>

              <option value="Students">
                Students
              </option>

              <option value="Department">
                Department
              </option>

              <option value="Both">
                Both
              </option>

              <option value="Pending">
                Contribution Pending
              </option>

              <option value="Approved">
                Contribution Approved
              </option>

              <option value="Rejected">
                Contribution Rejected
              </option>
            </select>

            <select
              value={
                statusFilter
              }
              onChange={(event) =>
                setStatusFilter(
                  event.target
                    .value
                )
              }
            >
              {statusOptions.map(
                (status) => (
                  <option
                    value={status}
                    key={status}
                  >
                    {status === "All"
                      ? "All Activity Statuses"
                      : status}
                  </option>
                )
              )}
            </select>
          </div>
        </div>

        <div className="activity-review__summary-row">
          <span>
            Showing{" "}
            <strong>
              {
                filteredActivities.length
              }
            </strong>{" "}
            of{" "}
            <strong>
              {activities.length}
            </strong>{" "}
            activities
          </span>
        </div>

        {/* TABLE */}

        {loading ? (
          <div className="activity-review__empty">
            <h3>
              Loading activities...
            </h3>
          </div>
        ) : (
          <div className="activity-review__table-wrapper">
            <table className="activity-review__table">
              <thead>
                <tr>
                  <th>
                    Faculty
                  </th>

                  <th>
                    Activity
                  </th>

                  <th>
                    Title
                  </th>

                  <th>
                    Contribution
                  </th>

                  <th>
                    Contribution For
                  </th>

                  <th>
                    Main Proof
                  </th>

                  <th>
                    Activity Status
                  </th>

                  <th>
                    Contribution Status
                  </th>

                  <th>
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredActivities.map(
                  (activity) => {
                    const status =
                      activity.status ||
                      "Pending";

                    const contributionStatus =
                      activity.contributionDone ===
                      "Yes"
                        ? activity.contributionStatus ||
                          "Pending"
                        : "Not Applicable";

                    return (
                      <tr
                        key={
                          activity._id
                        }
                      >
                        {/* FACULTY */}

                        <td>
                          <div className="activity-review__faculty">
                            <div className="activity-review__avatar">
                              {activity.facultyName
                                ?.charAt(
                                  0
                                )
                                .toUpperCase() ||
                                "F"}
                            </div>

                            <div>
                              <strong>
                                {activity.facultyName ||
                                  "Faculty Member"}
                              </strong>

                              <span>
                                {activity.facultyId ||
                                  "-"}{" "}
                                ·{" "}
                                {activity.department ||
                                  "-"}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* TYPE */}

                        <td>
                          <span className="activity-review__type">
                            {activity.type ||
                              "-"}
                          </span>
                        </td>

                        {/* TITLE */}

                        <td className="activity-review__title-cell">
                          <strong>
                            {activity.title ||
                              "-"}
                          </strong>

                          <span>
                            {formatDate(
                              activity.activityDate ||
                                activity.date ||
                                activity.startDate ||
                                activity.publicationDate ||
                                activity.filingDate
                            )}
                          </span>
                        </td>

                        {/* CONTRIBUTION */}

                        <td>
                          {activity.contributionDone ===
                          "Yes" ? (
                            <div className="activity-review__contribution-cell">
                              <strong>
                                {activity.contributionType ||
                                  "Contribution"}
                              </strong>

                              <span>
                                {activity.contributionTitle ||
                                  "-"}
                              </span>

                              <small>
                                Impact:{" "}
                                {activity.impactLevel ||
                                  "-"}
                              </small>
                            </div>
                          ) : (
                            <span className="activity-review__no-contribution">
                              No contribution
                            </span>
                          )}
                        </td>

                        {/* CONTRIBUTION TARGET */}

                        <td>
                          {activity.contributionDone ===
                          "Yes" ? (
                            <span
                              className={`activity-review__target activity-review__target--${toClassSuffix(
                                activity.contributionFor,
                                "unknown"
                              )}`}
                            >
                              {activity.contributionFor ||
                                "-"}
                            </span>
                          ) : (
                            "-"
                          )}
                        </td>

                        {/* PROOF */}

                        <td>
                          {activity.proof ? (
                            <a
                              className="activity-review__proof"
                              href={
                                resolveProofUrl(
                                  activity.proof
                                )
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            <span className="activity-review__no-proof">
                              Not uploaded
                            </span>
                          )}
                        </td>

                        {/* ACTIVITY STATUS */}

                        <td>
                          <span
                            className={`activity-review__status activity-review__status--${toClassSuffix(
                              status
                            )}`}
                          >
                            {status}
                          </span>
                        </td>

                        {/* CONTRIBUTION STATUS */}

                        <td>
                          <span
                            className={`activity-review__status activity-review__status--${toClassSuffix(
                              contributionStatus,
                              "not-applicable"
                            )}`}
                          >
                            {
                              contributionStatus
                            }
                          </span>

                          {activity.contributionDone ===
                            "Yes" &&
                            status !==
                              "Approved" && (
                              <small>
                                Main approval required
                              </small>
                            )}
                        </td>

                        {/* ACTIONS */}

                        <td>
                          <div className="activity-review__actions">
                            <button
                              type="button"
                              className="activity-review__button activity-review__button--view"
                              onClick={() =>
                                setSelectedActivity(
                                  activity
                                )
                              }
                            >
                              Review
                            </button>

                            <button
                              type="button"
                              className="activity-review__button activity-review__button--delete"
                              disabled={
                                actionLoadingId ===
                                activity._id
                              }
                              onClick={() =>
                                handleDelete(
                                  activity
                                )
                              }
                            >
                              {actionLoadingId ===
                              activity._id
                                ? "Working..."
                                : "Delete"}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>

            {filteredActivities.length ===
              0 && (
              <div className="activity-review__empty">
                <div>
                  📑
                </div>

                <h3>
                  No activities found
                </h3>

                <p>
                  Faculty submissions
                  will appear here after
                  they add their
                  activities.
                </p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* =====================================================
          REVIEW MODAL
      ====================================================== */}

      {selectedActivity && (
        <div
          className="activity-review__modal-backdrop"
          onClick={() =>
            setSelectedActivity(
              null
            )
          }
        >
          <div
            className="activity-review__modal activity-review__modal--large"
            onClick={(event) =>
              event.stopPropagation()
            }
          >
            {/* HEADER */}

            <div className="activity-review__modal-header">
              <div>
                <p>
                  ACTIVITY AND
                  CONTRIBUTION REVIEW
                </p>

                <h2>
                  {selectedActivity.title ||
                    "Faculty Activity"}
                </h2>
              </div>

              <button
                type="button"
                aria-label="Close"
                onClick={() =>
                  setSelectedActivity(
                    null
                  )
                }
              >
                ×
              </button>
            </div>

            {/* MAIN ACTIVITY */}

            <section className="activity-review__review-section">
              <div className="activity-review__section-heading">
                <div>
                  <h3>
                    Main Activity Review
                  </h3>

                  <p>
                    Verify the activity
                    details and
                    supporting document.
                  </p>
                </div>

                <span
                  className={`activity-review__status activity-review__status--${toClassSuffix(
                    selectedActivity.status ||
                      "Pending"
                  )}`}
                >
                  {selectedActivity.status ||
                    "Pending"}
                </span>
              </div>

              <div className="activity-review__detail-grid">
                <div>
                  <span>
                    Faculty Name
                  </span>

                  <strong>
                    {selectedActivity.facultyName ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Faculty ID
                  </span>

                  <strong>
                    {selectedActivity.facultyId ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Department
                  </span>

                  <strong>
                    {selectedActivity.department ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Activity Type
                  </span>

                  <strong>
                    {selectedActivity.type ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Organizer / Publisher / Institution
                  </span>

                  <strong>
                    {selectedActivity.organizer ||
                      selectedActivity.publisher ||
                      selectedActivity.institution ||
                      selectedActivity.journalName ||
                      selectedActivity.conferenceName ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Activity Date
                  </span>

                  <strong>
                    {formatDate(
                      selectedActivity.activityDate ||
                        selectedActivity.date ||
                        selectedActivity.startDate ||
                        selectedActivity.publicationDate ||
                        selectedActivity.filingDate
                    )}
                  </strong>
                </div>

                <div>
                  <span>
                    Academic Year
                  </span>

                  <strong>
                    {selectedActivity.academicYear ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Submitted Date
                  </span>

                  <strong>
                    {formatDate(
                      selectedActivity.submissionDate ||
                        selectedActivity.createdAt
                    )}
                  </strong>
                </div>
              </div>

              {selectedActivity.description && (
                <div className="activity-review__description">
                  <span>
                    Activity Description
                  </span>

                  <p>
                    {
                      selectedActivity.description
                    }
                  </p>
                </div>
              )}

              <div className="activity-review__modal-proof">
                <span>
                  Main Supporting Proof
                </span>

                {selectedActivity.proof ? (
                  <a
                    href={
                      resolveProofUrl(
                        selectedActivity.proof
                      )
                    }
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open Main Activity Proof
                  </a>
                ) : (
                  <p>
                    No main proof has
                    been uploaded.
                  </p>
                )}
              </div>

              {selectedActivity.rejectionReason && (
                <div className="activity-review__rejection">
                  <span>
                    Activity Rejection
                    Reason
                  </span>

                  <p>
                    {
                      selectedActivity.rejectionReason
                    }
                  </p>
                </div>
              )}

              <div className="activity-review__section-actions">
                {(selectedActivity.status ||
                  "Pending") !==
                  "Approved" && (
                  <button
                    type="button"
                    className="activity-review__button activity-review__button--approve"
                    disabled={
                      actionLoadingId ===
                      selectedActivity._id
                    }
                    onClick={() =>
                      handleApprove(
                        selectedActivity
                      )
                    }
                  >
                    Approve Activity
                  </button>
                )}

                {(selectedActivity.status ||
                  "Pending") !==
                  "Rejected" && (
                  <button
                    type="button"
                    className="activity-review__button activity-review__button--reject"
                    disabled={
                      actionLoadingId ===
                      selectedActivity._id
                    }
                    onClick={() =>
                      handleReject(
                        selectedActivity
                      )
                    }
                  >
                    Reject Activity
                  </button>
                )}

                {(selectedActivity.status ||
                  "Pending") !==
                  "Pending" && (
                  <button
                    type="button"
                    className="activity-review__button activity-review__button--pending"
                    disabled={
                      actionLoadingId ===
                      selectedActivity._id
                    }
                    onClick={() =>
                      handleMoveToPending(
                        selectedActivity
                      )
                    }
                  >
                    Move Activity to
                    Pending
                  </button>
                )}
              </div>
            </section>

            {/* CONTRIBUTION */}

            {selectedActivity.contributionDone ===
            "Yes" ? (
              <section className="activity-review__review-section activity-review__review-section--contribution">
                <div className="activity-review__section-heading">
                  <div>
                    <h3>
                      Contribution and
                      Impact Review
                    </h3>

                    <p>
                      Verify the
                      knowledge-transfer
                      contribution,
                      beneficiaries and
                      supporting evidence.
                    </p>
                  </div>

                  <span
                    className={`activity-review__status activity-review__status--${toClassSuffix(
                      selectedActivity.contributionStatus ||
                        "Pending"
                    )}`}
                  >
                    {selectedActivity.contributionStatus ||
                      "Pending"}
                  </span>
                </div>

                <div className="activity-review__detail-grid">
                  <div>
                    <span>
                      Contribution Type
                    </span>

                    <strong>
                      {selectedActivity.contributionType ||
                        "-"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Contribution Title
                    </span>

                    <strong>
                      {selectedActivity.contributionTitle ||
                        "-"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Contribution Date
                    </span>

                    <strong>
                      {formatDate(
                        selectedActivity.contributionDate
                      )}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Contribution For
                    </span>

                    <strong>
                      {selectedActivity.contributionFor ||
                        "-"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Impact Level
                    </span>

                    <strong>
                      {selectedActivity.impactLevel ||
                        "-"}
                    </strong>
                  </div>
                </div>

                <div className="activity-review__description">
                  <span>
                    Contribution Details
                  </span>

                  <p>
                    {selectedActivity.contributionDescription ||
                      "Not provided"}
                  </p>
                </div>

                {(selectedActivity.contributionFor ===
                  "Students" ||
                  selectedActivity.contributionFor ===
                    "Both") && (
                  <div className="activity-review__impact-section activity-review__impact-section--student">
                    <div className="activity-review__impact-heading">
                      <div>
                        <span>
                          STUDENT IMPACT
                        </span>

                        <h4>
                          Student
                          Contribution
                        </h4>
                      </div>

                      <span className="activity-review__target activity-review__target--students">
                        Students
                      </span>
                    </div>

                    <div className="activity-review__detail-grid">
                      <div>
                        <span>
                          Target Class /
                          Student Group
                        </span>

                        <strong>
                          {selectedActivity.targetGroup ||
                            "-"}
                        </strong>
                      </div>

                      <div>
                        <span>
                          Number of
                          Students
                        </span>

                        <strong>
                          {selectedActivity.participantCount ||
                            0}
                        </strong>
                      </div>
                    </div>

                    <div className="activity-review__impact-description">
                      <span>
                        Impact on
                        Students
                      </span>

                      <p>
                        {selectedActivity.studentImpact ||
                          "No student impact description provided."}
                      </p>
                    </div>
                  </div>
                )}

                {(selectedActivity.contributionFor ===
                  "Department" ||
                  selectedActivity.contributionFor ===
                    "Both") && (
                  <div className="activity-review__impact-section activity-review__impact-section--department">
                    <div className="activity-review__impact-heading">
                      <div>
                        <span>
                          DEPARTMENT
                          IMPACT
                        </span>

                        <h4>
                          Department
                          Contribution
                        </h4>
                      </div>

                      <span className="activity-review__target activity-review__target--department">
                        Department
                      </span>
                    </div>

                    <div className="activity-review__detail-grid">
                      <div>
                        <span>
                          Department /
                          Target Area
                        </span>

                        <strong>
                          {selectedActivity.departmentTarget ||
                            "-"}
                        </strong>
                      </div>
                    </div>

                    <div className="activity-review__impact-description">
                      <span>
                        Impact on
                        Department
                      </span>

                      <p>
                        {selectedActivity.departmentImpact ||
                          "No department impact description provided."}
                      </p>
                    </div>
                  </div>
                )}

                <div className="activity-review__modal-proof">
                  <span>
                    Contribution
                    Supporting Proof
                  </span>

                  {selectedActivity.contributionProof ? (
                    <a
                      href={
                        resolveProofUrl(
                          selectedActivity.contributionProof
                        )
                      }
                      target="_blank"
                      rel="noreferrer"
                    >
                      Open Contribution
                      Proof
                    </a>
                  ) : (
                    <p>
                      No contribution
                      proof has been
                      uploaded.
                    </p>
                  )}
                </div>

                {selectedActivity.contributionReviewComment && (
                  <div className="activity-review__rejection">
                    <span>
                      Contribution Review
                      Comment
                    </span>

                    <p>
                      {
                        selectedActivity.contributionReviewComment
                      }
                    </p>
                  </div>
                )}

                {selectedActivity.status ===
                  "Approved" &&
                  selectedActivity.contributionStatus ===
                    "Pending" && (
                    <div className="activity-review__description">
                      <span>
                        Contribution Review Status
                      </span>

                      <p>
                        This contribution is waiting for administrator
                        review. If it was previously rejected, the
                        faculty member may have corrected and
                        resubmitted it.
                      </p>
                    </div>
                  )}

                {selectedActivity.status ===
                "Approved" ? (
                  <div className="activity-review__section-actions">
                    {(selectedActivity.contributionStatus ||
                      "Pending") !==
                      "Approved" && (
                      <button
                        type="button"
                        className="activity-review__button activity-review__button--approve"
                        disabled={
                          actionLoadingId ===
                          selectedActivity._id
                        }
                        onClick={() =>
                          handleApproveContribution(
                            selectedActivity
                          )
                        }
                      >
                        Approve
                        Contribution
                      </button>
                    )}

                    {(selectedActivity.contributionStatus ||
                      "Pending") !==
                      "Rejected" && (
                      <button
                        type="button"
                        className="activity-review__button activity-review__button--reject"
                        disabled={
                          actionLoadingId ===
                          selectedActivity._id
                        }
                        onClick={() =>
                          handleRejectContribution(
                            selectedActivity
                          )
                        }
                      >
                        Reject
                        Contribution
                      </button>
                    )}

                    {(selectedActivity.contributionStatus ||
                      "Pending") !==
                      "Pending" && (
                      <button
                        type="button"
                        className="activity-review__button activity-review__button--pending"
                        disabled={
                          actionLoadingId ===
                          selectedActivity._id
                        }
                        onClick={() =>
                          handleContributionPending(
                            selectedActivity
                          )
                        }
                      >
                        Move Contribution
                        to Pending
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="activity-review__no-contribution-panel">
                    <strong>
                      Main Activity Approval Required
                    </strong>

                    <p>
                      Approve the main activity before reviewing
                      the contribution.
                    </p>
                  </div>
                )}
              </section>
            ) : (
              <section className="activity-review__review-section">
                <div className="activity-review__no-contribution-panel">
                  <strong>
                    No Contribution
                    Submitted
                  </strong>

                  <p>
                    The faculty member
                    did not report a
                    knowledge-transfer
                    contribution for
                    this activity.
                  </p>
                </div>
              </section>
            )}

            {/* FOOTER */}

            <div className="activity-review__modal-footer">
              <button
                type="button"
                className="activity-review__button activity-review__button--approve"
                onClick={downloadActivityPdf}
              >
                Download Activity PDF
              </button>

              <button
                type="button"
                className="activity-review__modal-close"
                onClick={() =>
                  setSelectedActivity(
                    null
                  )
                }
              >
                Close Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ActivityReview;
