
import { useEffect, useMemo, useState } from "react";
import "./HistoricalAnalytics.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

function countBy(records, field) {
  const counts = {};

  records.forEach((record) => {
    const key = record[field] || "Unknown";
    counts[key] = (counts[key] || 0) + 1;
  });

  return Object.entries(counts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
}

function BarChart({ title, data }) {
  const maxValue = Math.max(...data.map((item) => item.count), 1);

  return (
    <section className="ha-card ha-chart-card">
      <h3>{title}</h3>

      {data.length === 0 ? (
        <p className="ha-muted">No records available.</p>
      ) : (
        <div className="ha-bars">
          {data.map((item) => (
            <div className="ha-bar-row" key={item.name}>
              <span className="ha-bar-label" title={item.name}>
                {item.name}
              </span>

              <div className="ha-bar-track">
                <div
                  className="ha-bar-fill"
                  style={{
                    width: `${(item.count / maxValue) * 100}%`,
                  }}
                />
              </div>

              <strong>{item.count}</strong>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function HistoricalLineChart({ title, data }) {
  const left = 48;
  const right = 30;
  const top = 30;
  const bottom = 62;
  const chartHeight = 290;
  const chartWidth = Math.max(720, data.length * 105 + left + right);
  const plotWidth = chartWidth - left - right;
  const plotHeight = chartHeight - top - bottom;

  const maxValue = Math.max(...data.map((item) => item.count), 1);
  const yMax = Math.max(5, Math.ceil(maxValue / 5) * 5);
  const ticks = [...new Set([0, Math.round(yMax / 2), yMax])];

  const points = data.map((item, index) => {
    const x =
      data.length === 1
        ? left + plotWidth / 2
        : left + (index / (data.length - 1)) * plotWidth;

    const y = top + plotHeight - (item.count / yMax) * plotHeight;

    return { ...item, x, y };
  });

  const linePath = points
    .map(
      (point, index) =>
        `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`
    )
    .join(" ");

  const areaPath =
    points.length > 1
      ? `${linePath} L ${points[points.length - 1].x} ${
          top + plotHeight
        } L ${points[0].x} ${top + plotHeight} Z`
      : "";

  return (
    <section className="ha-card ha-line-card">
      <div className="ha-line-heading">
        <div>
          <h3>{title}</h3>
          <p className="ha-muted">
            Number of historical records in each academic year
          </p>
        </div>

        <span className="ha-line-total">
          {data.reduce((sum, item) => sum + item.count, 0)} records
        </span>
      </div>

      {data.length === 0 ? (
        <p className="ha-muted">No historical trend data available.</p>
      ) : (
        <>
          <div className="ha-line-chart">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              style={{ width: `${chartWidth}px`, maxWidth: "none" }}
              role="img"
              aria-label="Historical activity record counts by academic year"
            >
              <defs>
                <linearGradient
                  id="haLineGradient"
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1"
                >
                  <stop offset="0%" stopColor="#f97316" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#f97316" stopOpacity="0.01" />
                </linearGradient>
              </defs>

              {ticks.map((tick) => {
                const y = top + plotHeight - (tick / yMax) * plotHeight;

                return (
                  <g key={tick}>
                    <line
                      className="ha-line-grid"
                      x1={left}
                      y1={y}
                      x2={chartWidth - right}
                      y2={y}
                    />

                    <text
                      className="ha-line-label"
                      x={left - 10}
                      y={y + 4}
                      textAnchor="end"
                    >
                      {tick}
                    </text>
                  </g>
                );
              })}

              {areaPath && <path className="ha-line-area" d={areaPath} />}

              {points.length > 1 && (
                <path className="ha-line-path" d={linePath} />
              )}

              {points.map((point) => (
                <g key={point.name}>
                  <circle
                    className="ha-line-point"
                    cx={point.x}
                    cy={point.y}
                    r="5"
                  >
                    <title>{`${point.name}: ${point.count} records`}</title>
                  </circle>

                  <text
                    className="ha-line-value"
                    x={point.x}
                    y={Math.max(top + 12, point.y - 12)}
                    textAnchor="middle"
                  >
                    {point.count}
                  </text>

                  <text
                    className="ha-line-label ha-line-year"
                    x={point.x}
                    y={chartHeight - 20}
                    textAnchor="middle"
                  >
                    {point.name}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {data.length === 1 && (
            <p className="ha-muted ha-line-note">
              Only one academic year matches these filters. Select
              "All academic years" to compare years.
            </p>
          )}

          <div className="ha-line-legend">
            <span />
            Historical records
          </div>
        </>
      )}
    </section>
  );
}

// Convert API values safely to numbers.
function getActualFDP(item) {
  return Number(item.actualFDPCount) || 0;
}

function getForecastFDP(item) {
  return (
    Number(
      item.predictedFDPCountRounded ?? item.predictedFDPCount
    ) || 0
  );
}

// Historical-versus-forecast comparison chart.
function ForecastComparisonChart({ data }) {
  const chartData = [...data]
    .sort((a, b) => getActualFDP(b) - getActualFDP(a))
    .slice(0, 10);

  const maxValue = Math.max(
    1,
    ...chartData.flatMap((item) => [
      getActualFDP(item),
      getForecastFDP(item),
    ])
  );

  return (
    <section className="ha-card ha-comparison-card">
      <div className="ha-comparison-heading">
        <div>
          <h3>Historical vs Forecast FDP Activities</h3>
          <p className="ha-muted">
            Top 10 faculty by historical FDP count
          </p>
        </div>
      </div>

      <div className="ha-comparison-legend">
        <span>
          <i className="ha-legend-actual" />
          Actual FDP
        </span>

        <span>
          <i className="ha-legend-forecast" />
          Estimated FDP
        </span>
      </div>

      {chartData.length === 0 ? (
        <p className="ha-muted">No comparison data available.</p>
      ) : (
        <div className="ha-comparison-rows">
          {chartData.map((item, index) => {
            const actual = getActualFDP(item);
            const forecast = getForecastFDP(item);

            return (
              <div
                className="ha-comparison-row"
                key={item.facultyId || index}
              >
                <div className="ha-comparison-label">
                  <strong>{item.facultyId || "Unknown faculty"}</strong>
                  <span>
                    Actual: {actual} · Forecast: {forecast}
                  </span>
                </div>

                <div className="ha-paired-bars">
                  <div className="ha-paired-track">
                    <div
                      className="ha-paired-fill ha-paired-actual"
                      style={{
                        width: `${(actual / maxValue) * 100}%`,
                      }}
                    />
                  </div>

                  <div className="ha-paired-track">
                    <div
                      className="ha-paired-fill ha-paired-forecast"
                      style={{
                        width: `${(forecast / maxValue) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function HistoricalAnalytics() {
  const [activities, setActivities] = useState([]);
  const [totalFaculty, setTotalFaculty] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [academicYear, setAcademicYear] = useState("All");
  const [type, setType] = useState("All");
  const [department, setDepartment] = useState("All");
  const [search, setSearch] = useState("");

  const [forecastData, setForecastData] = useState([]);
  const [forecastLoading, setForecastLoading] = useState(true);
  const [forecastError, setForecastError] = useState("");
  const [forecastSearch, setForecastSearch] = useState("");

  // Existing historical analytics request.
  useEffect(() => {
    const controller = new AbortController();

    async function fetchAnalytics() {
      try {
        setLoading(true);
        setError("");

        const token = localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Please log in again to view historical analytics."
          );
        }

        const response = await fetch(
          `${BACKEND_URL}/api/historical-analytics/admin`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            signal: controller.signal,
          }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(
            result.message || "Unable to load historical analytics."
          );
        }

        setActivities(
          Array.isArray(result.activities) ? result.activities : []
        );

        setTotalFaculty(
          Number.isFinite(Number(result.totalFaculty))
            ? Number(result.totalFaculty)
            : 0
        );
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(err.message || "Something went wrong.");
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    fetchAnalytics();

    return () => controller.abort();
  }, []);

  // Forecast request remains separate from historical analytics.
  useEffect(() => {
    const controller = new AbortController();

    async function fetchForecast() {
      try {
        setForecastLoading(true);
        setForecastError("");

        const response = await fetch(
          `${BACKEND_URL}/api/growth-forecast/fdp`,
          { signal: controller.signal }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(
            result.message || "Unable to load FDP forecast."
          );
        }

        setForecastData(
          Array.isArray(result.data) ? result.data : []
        );
      } catch (err) {
        if (err.name !== "AbortError") {
          setForecastError(
            err.message || "Unable to load the forecast."
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setForecastLoading(false);
        }
      }
    }

    fetchForecast();

    return () => controller.abort();
  }, []);

  const academicYears = useMemo(
    () =>
      [...new Set(activities.map((item) => item.academicYear).filter(Boolean))]
        .sort(),
    [activities]
  );

  const types = useMemo(
    () =>
      [...new Set(activities.map((item) => item.type).filter(Boolean))].sort(),
    [activities]
  );

  const departments = useMemo(
    () =>
      [...new Set(activities.map((item) => item.department).filter(Boolean))]
        .sort(),
    [activities]
  );

  const filteredActivities = useMemo(() => {
    const query = search.trim().toLowerCase();

    return activities.filter((item) => {
      const matchesYear =
        academicYear === "All" || item.academicYear === academicYear;

      const matchesType = type === "All" || item.type === type;

      const matchesDepartment =
        department === "All" || item.department === department;

      const matchesSearch =
        !query ||
        [
          item.facultyName,
          item.facultyId,
          item.title,
          item.department,
          item.type,
          item.academicYear,
        ].some((value) =>
          String(value || "").toLowerCase().includes(query)
        );

      return (
        matchesYear &&
        matchesType &&
        matchesDepartment &&
        matchesSearch
      );
    });
  }, [activities, academicYear, type, department, search]);

  const analytics = useMemo(
    () => ({
      totalActivities: filteredActivities.length,

      facultyCount: new Set(
        filteredActivities.map(
          (item) => item.facultyId || item.facultyName
        )
      ).size,

      byType: countBy(filteredActivities, "type"),

      byAcademicYear: countBy(
        filteredActivities,
        "academicYear"
      ).sort((a, b) => a.name.localeCompare(b.name)),

      byDepartment: countBy(filteredActivities, "department"),

      byFaculty: countBy(filteredActivities, "facultyName").slice(0, 10),
    }),
    [filteredActivities]
  );

  const filteredForecast = useMemo(() => {
    const query = forecastSearch.trim().toLowerCase();

    return forecastData.filter((item) =>
      String(item.facultyId || "").toLowerCase().includes(query)
    );
  }, [forecastData, forecastSearch]);

  const forecastComparison = useMemo(() => {
    const actualTotal = forecastData.reduce(
      (sum, item) => sum + getActualFDP(item),
      0
    );

    const forecastTotal = forecastData.reduce(
      (sum, item) => sum + getForecastFDP(item),
      0
    );

    return {
      actualTotal,
      forecastTotal,
      difference: forecastTotal - actualTotal,
    };
  }, [forecastData]);

  function resetFilters() {
    setAcademicYear("All");
    setType("All");
    setDepartment("All");
    setSearch("");
  }

  function formatDate(value) {
    if (!value) return "—";

    const date = new Date(value);

    return Number.isNaN(date.getTime())
      ? "—"
      : date.toLocaleDateString("en-IN");
  }

  if (loading) {
    return (
      <div className="ha-page">
        <p className="ha-message">Loading historical analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="ha-page">
        <h2>Historical Analytics</h2>
        <div className="ha-error">{error}</div>
        <p className="ha-muted">
          Check that the backend is running, the admin is logged in, and
          the historical analytics route is registered.
        </p>
      </div>
    );
  }

  return (
    <div className="ha-page">
      <header className="ha-header">
        <div>
          <p className="ha-eyebrow">FACULTY MANAGEMENT SYSTEM</p>
          <h1>Historical Analytics</h1>
          <p className="ha-subtitle">
            Explore historical faculty activities across the institution.
          </p>
        </div>

        <button
          className="ha-reset-button"
          onClick={resetFilters}
          type="button"
        >
          Reset filters
        </button>
      </header>

      <section className="ha-filters">
        <div className="ha-filter">
          <label htmlFor="ha-year">Academic year</label>
          <select
            id="ha-year"
            value={academicYear}
            onChange={(event) => setAcademicYear(event.target.value)}
          >
            <option value="All">All academic years</option>
            {academicYears.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>

        <div className="ha-filter">
          <label htmlFor="ha-type">Activity type</label>
          <select
            id="ha-type"
            value={type}
            onChange={(event) => setType(event.target.value)}
          >
            <option value="All">All activity types</option>
            {types.map((activityType) => (
              <option key={activityType} value={activityType}>
                {activityType}
              </option>
            ))}
          </select>
        </div>

        <div className="ha-filter">
          <label htmlFor="ha-department">Department</label>
          <select
            id="ha-department"
            value={department}
            onChange={(event) => setDepartment(event.target.value)}
          >
            <option value="All">All departments</option>
            {departments.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>

        <div className="ha-filter ha-search">
          <label htmlFor="ha-search">Search records</label>
          <input
            id="ha-search"
            type="search"
            placeholder="Faculty, ID, title..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
      </section>

      <section className="ha-stat-grid">
        <article className="ha-stat-card">
          <span>Total historical records</span>
          <strong>{analytics.totalActivities}</strong>
          <small>Matching current filters</small>
        </article>

        <article className="ha-stat-card">
          <span>Total Faculty</span>
          <strong>{totalFaculty}</strong>
          <small>Official faculty master records</small>
        </article>

        <article className="ha-stat-card">
          <span>Activity categories</span>
          <strong>{analytics.byType.length}</strong>
          <small>Categories represented</small>
        </article>

        <article className="ha-stat-card">
          <span>Academic years</span>
          <strong>
            {
              new Set(
                filteredActivities
                  .map((item) => item.academicYear)
                  .filter(Boolean)
              ).size
            }
          </strong>
          <small>Years represented</small>
        </article>
      </section>

      {/* Faculty Activity Growth Forecast */}
      <section className="ha-card ha-forecast-card">
        <div className="ha-forecast-heading">
          <div>
            <p className="ha-forecast-eyebrow">PREDICTIVE ANALYTICS</p>
            <h2>Faculty Activity Growth Forecast</h2>
            <p className="ha-muted">
              Historical FDP activity counts compared with the forecast year.
            </p>
          </div>

          <span className="ha-forecast-badge">Experimental</span>
        </div>

        <div className="ha-forecast-notice">
          <strong>Forecast limitations</strong>
          <p>
            Estimates use a faculty-wise recency-weighted historical average,
            giving more weight to recent recorded activity. Reliability depends
            on the amount of historical data available for each faculty member.
            These experimental estimates have not been sufficiently validated
            and should not be used as faculty performance evaluations.
          </p>
        </div>

        {forecastLoading ? (
          <p className="ha-muted">Loading activity forecast...</p>
        ) : forecastError ? (
          <div className="ha-error">{forecastError}</div>
        ) : forecastData.length === 0 ? (
          <p className="ha-muted">No forecast records available.</p>
        ) : (
          <>
            <div className="ha-forecast-summary">
              <div>
                <span>Forecast academic year</span>
                <strong>
                  {forecastData[0]?.forecastAcademicYear || "—"}
                </strong>
              </div>

              <div>
                <span>Estimated FDP count per record</span>
                <strong>{getForecastFDP(forecastData[0])}</strong>
              </div>
            </div>

            <div className="ha-forecast-summary ha-comparison-stats">
              <div>
                <span>
                  Actual FDP activities ·{" "}
                  {forecastData[0]?.basedOnAcademicYear || "Historical year"}
                </span>
                <strong>{forecastComparison.actualTotal}</strong>
              </div>

              <div>
                <span>
                  Estimated FDP activities ·{" "}
                  {forecastData[0]?.forecastAcademicYear || "Forecast year"}
                </span>
                <strong>{forecastComparison.forecastTotal}</strong>
              </div>

              <div>
                <span>Difference vs historical total</span>
                <strong
                  className={
                    forecastComparison.difference > 0
                      ? "ha-change-positive"
                      : forecastComparison.difference < 0
                        ? "ha-change-negative"
                        : ""
                  }
                >
                  {forecastComparison.difference > 0 ? "+" : ""}
                  {forecastComparison.difference}
                </strong>
                <small>Estimated total minus actual total</small>
              </div>
            </div>

            <ForecastComparisonChart data={forecastData} />

            <input
              className="ha-forecast-search"
              type="search"
              placeholder="Search faculty ID..."
              value={forecastSearch}
              onChange={(event) => setForecastSearch(event.target.value)}
              aria-label="Search forecast by faculty ID"
            />

            <div className="ha-table-wrapper">
              <table className="ha-table">
                <thead>
                  <tr>
                    <th>Faculty ID</th>
                    <th>Based on year</th>
                    <th>Actual FDP</th>
                    <th>Forecast year</th>
                    <th>Estimated FDP</th>
                    <th>History years</th>
                    <th>Years available</th>
                    <th>Status</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredForecast.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="ha-empty">
                        No faculty IDs match your search.
                      </td>
                    </tr>
                  ) : (
                    filteredForecast.map((item, index) => (
                      <tr
                        key={
                          item.facultyId ||
                          `${item.forecastAcademicYear}-${index}`
                        }
                      >
                        <td>{item.facultyId || "—"}</td>
                        <td>{item.basedOnAcademicYear || "—"}</td>
                        <td>{getActualFDP(item)}</td>
                        <td>{item.forecastAcademicYear || "—"}</td>
                        <td>
                          <strong>{getForecastFDP(item)}</strong>
                        </td>
                        <td>{item.historyYears || "—"}</td>
                        <td>{item.historyYearsAvailable ?? "—"}</td>
                        <td>
                          <span className="ha-type-badge">
                            {item.status || "Experimental estimate"}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <p className="ha-muted ha-forecast-method">
              Method: {forecastData[0]?.method || "Baseline estimate"}
            </p>
          </>
        )}
      </section>

      <section className="ha-chart-grid">
        <BarChart
          title="Activities by Academic Year"
          data={analytics.byAcademicYear}
        />

        <BarChart
          title="Activities by Type"
          data={analytics.byType}
        />

        <BarChart
          title="Department-wise Activities"
          data={analytics.byDepartment}
        />

        <BarChart
          title="Top 10 Faculty by Record Count"
          data={analytics.byFaculty}
        />

        <HistoricalLineChart
          title="Historical Activity Trends"
          data={analytics.byAcademicYear}
        />
      </section>

      <section className="ha-card ha-table-card">
        <div className="ha-table-heading">
          <div>
            <h3>Historical Activity Records</h3>
            <p className="ha-muted">
              {filteredActivities.length} matching records
            </p>
          </div>
        </div>

        <div className="ha-table-wrapper">
          <table className="ha-table">
            <thead>
              <tr>
                <th>Faculty</th>
                <th>Faculty ID</th>
                <th>Department</th>
                <th>Activity Type</th>
                <th>Title</th>
                <th>Academic Year</th>
                <th>Date</th>
              </tr>
            </thead>

            <tbody>
              {filteredActivities.length === 0 ? (
                <tr>
                  <td colSpan="7" className="ha-empty">
                    No historical records match these filters.
                  </td>
                </tr>
              ) : (
                filteredActivities.map((item, index) => (
                  <tr key={item._id || `${item.facultyId}-${index}`}>
                    <td>{item.facultyName || "—"}</td>
                    <td>{item.facultyId || "—"}</td>
                    <td>{item.department || "—"}</td>
                    <td>
                      <span className="ha-type-badge">
                        {item.type || "Unknown"}
                      </span>
                    </td>
                    <td className="ha-title-cell">
                      {item.title || "—"}
                    </td>
                    <td>{item.academicYear || "—"}</td>
                    <td>
                      {formatDate(
                        item.activityDate ||
                          item.publicationDate ||
                          item.startDate
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      <p className="ha-footer-note">
        These analytics use historical records only. They do not modify
        current activity approvals or Faculty Impact Score calculations.
      </p>
    </div>
  );
}

export default HistoricalAnalytics;
