import {

  useEffect,

  useMemo,

  useState,

} from "react";



import "./AdminReports.css";



const BACKEND_URL =

  import.meta.env.VITE_BACKEND_URL ||

  "http\://localhost:5000";



const FACULTY_API =

  `${BACKEND_URL}/api/faculty`;



const ACTIVITY_API =

  `${BACKEND_URL}/api/activities`;



const ACTIVITY_TYPES = [

  "FDP",

  "NPTEL",

  "Research Paper",

  "Journal Publication",

  "Patent / IPR",

];



const ACTIVITY_CONFIG = {

  FDP: {

    pointsPerActivity: 2,

    maxScore: 12,

  },

  NPTEL: {

    pointsPerActivity: 3,

    maxScore: 12,

  },

  "Research Paper": {

    pointsPerActivity: 5,

    maxScore: 15,

  },

  "Journal Publication": {

    pointsPerActivity: 5,

    maxScore: 20,

  },

  "Patent / IPR": {

    pointsPerActivity: 5,

    maxScore: 15,

  },

};



const CONTRIBUTION_WEIGHTS = {

  Students: 4,

  Department: 5,

  Both: 8,

};



const ACTIVITY_SCORE_MAX = 74;

const KNOWLEDGE_TRANSFER_MAX = 26;



const normalizeFacultyId = (value) =>

  String(value || "")

    .trim()

    .toUpperCase();



const normalizeDepartment = (department) => {

  const cleanValue =

    String(department || "").trim();



  const normalized =

    cleanValue

      .toUpperCase()

      .replace(/[^A-Z0-9]/g, "");



  const cseAliases =

    new Set([

      "CSE",

      "COMPUTERSCIENCE",

      "COMPUTERSCIENCEENGINEERING",

      "COMPUTERSCIENCEANDENGINEERING",

      "DEPARTMENTOFCOMPUTERSCIENCE",

      "DEPARTMENTOFCOMPUTERSCIENCEENGINEERING",

      "DEPARTMENTOFCOMPUTERSCIENCEANDENGINEERING",

    ]);



  if (

    cseAliases.has(normalized)

  ) {

    return "CSE";

  }



  return cleanValue || "Other";

};



const getEffectiveAccountStatus = (faculty) => {

  const registrationStatus =

    faculty?.registrationStatus ||

    "Not Registered";



  if (registrationStatus !== "Approved") {

    return "Inactive";

  }



  return faculty?.accountStatus || "Inactive";

};



const calculateBalancedImpact = (

  facultyIdValue,

  sourceActivities = []

) => {

  const facultyId =

    normalizeFacultyId(

      facultyIdValue

    );



  const approvedActivities =

    sourceActivities.filter(

      (activity) =>

        ACTIVITY_TYPES.includes(

          activity.type

        ) &&

        normalizeFacultyId(

          activity.facultyId

        ) === facultyId &&

        activity.status ===

          "Approved"

    );



  const categoryScores =

    Object.entries(

      ACTIVITY_CONFIG

    ).map(

      ([type, config]) => {

        const approvedCount =

          approvedActivities.filter(

            (activity) =>

              activity.type === type

          ).length;



        const rawCategoryScore =

          approvedCount *

          config.pointsPerActivity;



        const cappedCategoryScore =

          Math.min(

            rawCategoryScore,

            config.maxScore

          );



        return {

          type,

          approvedCount,

          rawCategoryScore,

          cappedCategoryScore,

          maxScore:

            config.maxScore,

        };

      }

    );



  const rawActivityScore =

    categoryScores.reduce(

      (total, category) =>

        total +

        category.rawCategoryScore,

      0

    );



  const activityScore =

    categoryScores.reduce(

      (total, category) =>

        total +

        category.cappedCategoryScore,

      0

    );



  const approvedContributions =

    approvedActivities.filter(

      (activity) =>

        activity.contributionDone ===

          "Yes" &&

        activity.contributionStatus ===

          "Approved"

    );



  const rawKnowledgeTransferScore =

    approvedContributions.reduce(

      (total, activity) =>

        total +

        (CONTRIBUTION_WEIGHTS[

          activity.contributionFor

        ] || 0),

      0

    );



  const knowledgeTransferScore =

    Math.min(

      rawKnowledgeTransferScore,

      KNOWLEDGE_TRANSFER_MAX

    );



  const rawScore =

    rawActivityScore +

    rawKnowledgeTransferScore;



  const impactScore =

    Math.min(

      activityScore +

        knowledgeTransferScore,

      100

    );



  return {

    approvedActivityCount:

      approvedActivities.length,

    approvedContributionCount:

      approvedContributions.length,

    approvedActivities,

    approvedContributions,

    categoryScores,

    rawActivityScore,

    activityScore,

    rawKnowledgeTransferScore,

    knowledgeTransferScore,

    rawScore,

    impactScore,

  };

};



const reportTypes = [
  "Individual Faculty Report",
  "Overall Faculty Report",
  "Faculty Directory",
  "Registration Status",
  "Activity Submission",
  "Pending Activities",
  "Department Performance",
  "Faculty Impact Score",
];



function AdminReports() {

  const [

    selectedReport,

    setSelectedReport,

  ] = useState(

    "Individual Faculty Report"

  );



  const [selectedFacultyId, setSelectedFacultyId] = useState("");



  const [

    departmentFilter,

    setDepartmentFilter,

  ] = useState("All");



  const [

    statusFilter,

    setStatusFilter,

  ] = useState("All");



  const [

    searchText,

    setSearchText,

  ] = useState("");



  const [

    facultyList,

    setFacultyList,

  ] = useState([]);



  const [

    activities,

    setActivities,

  ] = useState([]);



  const [loading, setLoading] =

    useState(true);



  const [

    errorMessage,

    setErrorMessage,

  ] = useState("");



  // ========================================

  // LOAD DATA FROM MONGODB

  // ========================================



  const loadReportData =

    async () => {

      try {

        setLoading(true);

        setErrorMessage("");



        const token =

          localStorage.getItem("token");



        if (!token) {

          throw new Error(

            "Authentication token not found. Please login again."

          );

        }



        const [

          facultyResponse,

          activityResponse,

        ] = await Promise.all([

          fetch(FACULTY_API, {

            headers: {

              Authorization:

                `Bearer ${token}`,

            },

          }),



          fetch(ACTIVITY_API, {

            headers: {

              Authorization:

                `Bearer ${token}`,

            },

          }),

        ]);



        const facultyData =

          await facultyResponse.json();



        const activityData =

          await activityResponse.json();



        if (!facultyResponse.ok) {

          throw new Error(

            facultyData.message ||

              "Unable to load faculty data."

          );

        }



        if (!activityResponse.ok) {

          throw new Error(

            activityData.message ||

              "Unable to load activity data."

          );

        }



        setFacultyList(

          facultyData.faculty ||

          facultyData.faculties ||

          []

        );



        setActivities(

          activityData.activities ||

            []

        );

        const firstApprovedFaculty = (facultyData.faculty || facultyData.faculties || []).find((faculty) => faculty.registrationStatus === "Approved");
        if (firstApprovedFaculty?.facultyId) setSelectedFacultyId(firstApprovedFaculty.facultyId);

      } catch (error) {

        console.error(

          "Admin report load error:",

          error

        );



        setErrorMessage(

          error.message ||

            "Unable to connect to the server."

        );

      } finally {

        setLoading(false);

      }

    };



  useEffect(() => {

    loadReportData();

  }, []);



  // ========================================

  // FACULTY STATUS

  // ========================================



  const approvedFaculty =

    facultyList.filter(

      (faculty) =>

        faculty.registrationStatus ===

        "Approved"

    );



  const pendingFaculty =

    facultyList.filter(

      (faculty) =>

        faculty.registrationStatus ===

        "Pending"

    );



  const rejectedFaculty =

    facultyList.filter(

      (faculty) =>

        faculty.registrationStatus ===

        "Rejected"

    );



  // ========================================

  // ACTIVITY STATUS

  // ========================================



  const validActivities =

    useMemo(

      () =>

        activities.filter(

          (activity) =>

            ACTIVITY_TYPES.includes(

              activity.type

            )

        ),

      [activities]

    );



  const approvedActivities =

    validActivities.filter(

      (activity) =>

        activity.status ===

        "Approved"

    );



  const pendingActivities =

    validActivities.filter(

      (activity) =>

        (activity.status ||

          "Pending") === "Pending"

    );



  const rejectedActivities =

    validActivities.filter(

      (activity) =>

        activity.status ===

        "Rejected"

    );



  const approvedContributions =

    validActivities.filter(

      (activity) =>

        activity.status ===

          "Approved" &&

        activity.contributionDone ===

          "Yes" &&

        activity.contributionStatus ===

          "Approved"

    );



  const pendingContributions =

    validActivities.filter(

      (activity) =>

        activity.contributionDone ===

          "Yes" &&

        (activity.contributionStatus ||

          "Pending") ===

          "Pending"

    );



  const rejectedContributions =

    validActivities.filter(

      (activity) =>

        activity.status ===

          "Approved" &&

        activity.contributionDone ===

          "Yes" &&

        activity.contributionStatus ===

          "Rejected"

    );



  // ========================================

  // DEPARTMENTS

  // ========================================



  const departments =

    useMemo(() => {

      const values =

        facultyList

          .map((faculty) =>

            normalizeDepartment(

              faculty.department

            )

          )

          .filter(Boolean);



      return [

        "All",

        ...new Set(values),

      ];

    }, [facultyList]);



  // ========================================

  // FACULTY REPORT

  // ========================================



  const facultyReport =

    useMemo(() => {

      const value =

        searchText

          .trim()

          .toLowerCase();



      return facultyList.filter(

        (faculty) => {

          const matchesDepartment =

            departmentFilter ===

              "All" ||

            normalizeDepartment(

              faculty.department

            ) === departmentFilter;



          const status =

            faculty.registrationStatus ||

            "Not Registered";



          const matchesStatus =

            statusFilter ===

              "All" ||

            status ===

              statusFilter;



          const matchesSearch =

            !value ||

            faculty.name

              ?.toLowerCase()

              .includes(value) ||

            faculty.facultyId

              ?.toLowerCase()

              .includes(value) ||

            faculty.email

              ?.toLowerCase()

              .includes(value) ||

            faculty.department

              ?.toLowerCase()

              .includes(value) ||

            faculty.designation

              ?.toLowerCase()

              .includes(value);



          return (

            matchesDepartment &&

            matchesStatus &&

            matchesSearch

          );

        }

      );

    }, [

      facultyList,

      departmentFilter,

      statusFilter,

      searchText,

    ]);



  // ========================================

  // ACTIVITY REPORT

  // ========================================



  const activityReport =

    useMemo(() => {

      const value =

        searchText

          .trim()

          .toLowerCase();



      return validActivities.filter(

        (activity) => {

          const matchesDepartment =

            departmentFilter ===

              "All" ||

            normalizeDepartment(

              activity.department

            ) === departmentFilter;



          const status =

            activity.status ||

            "Pending";



          const matchesStatus =

            statusFilter ===

              "All" ||

            status ===

              statusFilter;



          const matchesSearch =

            !value ||

            activity.facultyName

              ?.toLowerCase()

              .includes(value) ||

            activity.facultyId

              ?.toLowerCase()

              .includes(value) ||

            activity.title

              ?.toLowerCase()

              .includes(value) ||

            activity.type

              ?.toLowerCase()

              .includes(value);



          return (

            matchesDepartment &&

            matchesStatus &&

            matchesSearch

          );

        }

      );

    }, [

      validActivities,

      departmentFilter,

      statusFilter,

      searchText,

    ]);



  // ========================================

  // DEPARTMENT REPORT

  // ========================================



  const departmentReport =

    useMemo(() => {

      const departmentMap = {};



      facultyList.forEach(

        (faculty) => {

          const department =

            normalizeDepartment(

              faculty.department

            );



          if (

            !departmentMap[

              department

            ]

          ) {

            departmentMap[

              department

            ] = {

              department,



              totalFaculty: 0,



              approvedFaculty: 0,



              pendingFaculty: 0,



              rejectedFaculty: 0,



              totalActivities: 0,



              approvedActivities: 0,



              pendingActivities: 0,



              rejectedActivities: 0,



              approvedContributions: 0,



              pendingContributions: 0,



              rejectedContributions: 0,



              activityScore: 0,



              knowledgeTransferScore: 0,

            };

          }



          departmentMap[

            department

          ].totalFaculty += 1;



          if (

            faculty.registrationStatus ===

            "Approved"

          ) {

            departmentMap[

              department

            ].approvedFaculty +=

              1;

          }



          if (

            faculty.registrationStatus ===

            "Pending"

          ) {

            departmentMap[

              department

            ].pendingFaculty +=

              1;

          }



          if (

            faculty.registrationStatus ===

            "Rejected"

          ) {

            departmentMap[

              department

            ].rejectedFaculty +=

              1;

          }

        }

      );



      validActivities.forEach(

        (activity) => {

          const department =

            normalizeDepartment(

              activity.department

            );



          if (

            !departmentMap[

              department

            ]

          ) {

            departmentMap[

              department

            ] = {

              department,



              totalFaculty: 0,



              approvedFaculty: 0,



              pendingFaculty: 0,



              rejectedFaculty: 0,



              totalActivities: 0,



              approvedActivities: 0,



              pendingActivities: 0,



              rejectedActivities: 0,



              approvedContributions: 0,



              pendingContributions: 0,



              rejectedContributions: 0,



              activityScore: 0,



              knowledgeTransferScore: 0,

            };

          }



          departmentMap[

            department

          ].totalActivities += 1;



          const activityStatus =

            activity.status ||

            "Pending";



          if (

            activityStatus ===

            "Approved"

          ) {

            departmentMap[

              department

            ].approvedActivities +=

              1;

          }



          if (

            activityStatus ===

            "Pending"

          ) {

            departmentMap[

              department

            ].pendingActivities +=

              1;

          }



          if (

            activityStatus ===

            "Rejected"

          ) {

            departmentMap[

              department

            ].rejectedActivities +=

              1;

          }



          if (

            activity.contributionDone ===

            "Yes"

          ) {

            const contributionStatus =

              activity.contributionStatus ||

              "Pending";



            if (

              activityStatus ===

                "Approved" &&

              contributionStatus ===

                "Approved"

            ) {

              departmentMap[

                department

              ].approvedContributions +=

                1;

            }



            if (

              contributionStatus ===

              "Pending"

            ) {

              departmentMap[

                department

              ].pendingContributions +=

                1;

            }



            if (

              activityStatus ===

                "Approved" &&

              contributionStatus ===

                "Rejected"

            ) {

              departmentMap[

                department

              ].rejectedContributions +=

                1;

            }

          }

        }

      );



      return Object.values(

        departmentMap

      ).map(

        (department) => {

          const scoringFaculty =

            facultyList.filter(

              (faculty) =>

                normalizeDepartment(

                  faculty.department

                ) ===

                  department.department &&

                faculty.registrationStatus ===

                  "Approved" &&

                faculty.accountStatus ===

                  "Active"

            );



          const facultyScores =

            scoringFaculty.map(

              (faculty) =>

                calculateBalancedImpact(

                  faculty.facultyId,

                  validActivities

                )

            );



          const activityScore =

            facultyScores.reduce(

              (total, score) =>

                total +

                score.activityScore,

              0

            );



          const knowledgeTransferScore =

            facultyScores.reduce(

              (total, score) =>

                total +

                score.knowledgeTransferScore,

              0

            );



          const totalImpactPoints =

            facultyScores.reduce(

              (total, score) =>

                total +

                score.impactScore,

              0

            );



          const averageImpactScore =

            facultyScores.length > 0

              ? Math.round(

                  totalImpactPoints /

                    facultyScores.length

                )

              : 0;



          return {

            ...department,

            activityScore,

            knowledgeTransferScore,

            totalImpactPoints,

            averageImpactScore,

          };

        }

      );

    }, [

      facultyList,

      validActivities,

    ]);



  const visibleDepartmentReport =

    useMemo(() => {

      if (

        departmentFilter === "All"

      ) {

        return departmentReport;

      }



      return departmentReport.filter(

        (department) =>

          department.department ===

          departmentFilter

      );

    }, [

      departmentReport,

      departmentFilter,

    ]);



  // ========================================

  // IMPACT REPORT

  // ========================================



  const activeApprovedFaculty =

    useMemo(

      () =>

        facultyList.filter(

          (faculty) =>

            faculty.registrationStatus ===

              "Approved" &&

            faculty.accountStatus ===

              "Active"

        ),

      [facultyList]

    );



  const impactReport =

    useMemo(() => {

      const searchValue =

        searchText

          .trim()

          .toLowerCase();



      return activeApprovedFaculty

        .filter((faculty) => {

          const matchesDepartment =

            departmentFilter === "All" ||

            normalizeDepartment(

              faculty.department

            ) === departmentFilter;



          const matchesSearch =

            !searchValue ||

            faculty.name

              ?.toLowerCase()

              .includes(searchValue) ||

            faculty.facultyId

              ?.toLowerCase()

              .includes(searchValue) ||

            normalizeDepartment(

              faculty.department

            )

              .toLowerCase()

              .includes(searchValue);



          return (

            matchesDepartment &&

            matchesSearch

          );

        })

        .map((faculty) => {

          const facultyId =

            normalizeFacultyId(

              faculty.facultyId

            );



          const facultyActivities =

            approvedActivities.filter(

              (activity) =>

                normalizeFacultyId(

                  activity.facultyId

                ) === facultyId

            );



          const scoreData =

            calculateBalancedImpact(

              faculty.facultyId,

              validActivities

            );



          return {

            ...faculty,

            ...scoreData,

          };

        })

        .sort(

          (first, second) =>

            second.impactScore -

            first.impactScore

        );

    }, [

      activeApprovedFaculty,

      validActivities,

      departmentFilter,

      searchText,

    ]);



  // ========================================

  // PRINT

  // ========================================



  const handlePrint = () => {
    const printDocument = document.querySelector(
      ".admin-reports__report-content .admin-reports__print-document"
    );

    if (!printDocument) {
      window.alert(
        "Select Individual Faculty Report or Overall Faculty Report before printing."
      );
      return;
    }

    const printWindow = window.open(
      "",
      "FMSFacultyReportPrint",
      "width=1000,height=800"
    );

    if (!printWindow) {
      window.alert(
        "Please allow pop-ups in the browser to generate the PDF report."
      );
      return;
    }

    const reportHtml = printDocument.outerHTML;

    printWindow.document.open();
    printWindow.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Faculty Performance Report</title>
  <style>
    @page { size: A4; margin: 14mm 14mm 16mm; }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; background: #fff; }
    body { font-family: Arial, Helvetica, sans-serif; color: #18232e; }
    .admin-reports__print-document { display: block !important; width: 100%; }
    .admin-reports__print-header {
      display: flex; justify-content: space-between; gap: 24px;
      padding-bottom: 14px; border-bottom: 2px solid #0b2c4e;
    }
    .admin-reports__print-header > div:last-child { text-align: right; }
    .admin-reports__print-header strong { display: block; color: #0b2c4e; font-size: 14px; }
    .admin-reports__print-header span { display: block; margin-top: 4px; color: #687684; font-size: 9px; }
    .admin-reports__print-section { margin-top: 18px; break-inside: avoid; }
    .admin-reports__print-section h2 {
      margin: 0 0 10px; padding-bottom: 5px; border-bottom: 1px solid #dce3ea;
      color: #0b2c4e; font-size: 14px;
    }
    .admin-reports__print-section h3 { margin: 0 0 5px; color: #0b2c4e; font-size: 11px; }
    .admin-reports__print-section p, .admin-reports__print-section li {
      color: #354451; font-size: 10px; line-height: 1.55;
    }
    .admin-reports__print-info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
    .admin-reports__print-info-grid > div { padding: 9px; border: 1px solid #dce3ea; border-radius: 5px; }
    .admin-reports__print-info-grid span, .admin-reports__print-score-grid span {
      display: block; color: #687684; font-size: 8px; text-transform: uppercase;
    }
    .admin-reports__print-info-grid strong { display: block; margin-top: 4px; color: #18232e; font-size: 10px; }
    .admin-reports__print-score-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 10px; }
    .admin-reports__print-score-grid > div { padding: 10px; border: 1px solid #dce3ea; border-radius: 5px; background: #f7f9fb; }
    .admin-reports__print-score-grid strong { display: block; margin-top: 4px; color: #0b2c4e; font-size: 13px; }
    .admin-reports__print-table { width: 100%; border-collapse: collapse; font-size: 9px; }
    .admin-reports__print-table th, .admin-reports__print-table td {
      padding: 6px 7px; border: 1px solid #dce3ea; text-align: left; vertical-align: top;
    }
    .admin-reports__print-table th { background: #0b2c4e; color: #fff; font-weight: 800; }
    .admin-reports__print-table tr { break-inside: avoid; page-break-inside: avoid; }
    .admin-reports__print-table .print-total td { background: #f3f7fa; font-weight: 800; }
    .admin-reports__print-table .print-grand-total td { background: #fff5ef; color: #0b2c4e; font-weight: 900; }
    .admin-reports__print-note { padding: 9px; background: #f7f9fb; color: #687684 !important; }
    .admin-reports__print-analysis { margin-bottom: 8px; padding: 9px 11px; border-left: 3px solid #ef651b; background: #fffaf7; break-inside: avoid; }
    .admin-reports__print-analysis p { margin: 0; }
    .admin-reports__print-section ul { margin: 5px 0; padding-left: 20px; }
    .admin-reports__print-final { padding: 11px; border-left: 4px solid #ef651b; background: #fbfcfd; }
    .admin-reports__print-footer {
      display: flex; justify-content: space-between; gap: 20px; margin-top: 28px;
      padding-top: 9px; border-top: 1px solid #dce3ea; color: #687684; font-size: 8px;
    }
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
  </style>
</head>
<body>
  ${reportHtml}
  <script>
    window.addEventListener('load', function () {
      setTimeout(function () {
        window.focus();
        window.print();
      }, 300);
    });
    window.addEventListener('afterprint', function () {
      window.close();
    });
  <\/script>
</body>
</html>`);
    printWindow.document.close();
  };



  // ========================================

  // EXPORT CSV

  // ========================================



  const handleExportExcel =

    () => {

      let rows = [];



      let fileName =

        "admin-report.csv";



      if (

        selectedReport ===

        "Faculty Directory"

      ) {

        rows =

          facultyReport.map(

            (faculty) => ({

              "Faculty ID":

                faculty.facultyId ||

                "",



              Name:

                faculty.name || "",



              Department:

                normalizeDepartment(

                  faculty.department

                ),



              Designation:

                faculty.designation ||

                "",



              Email:

                faculty.email || "",



              Phone:

                faculty.phone || "",



              "Registration Status":

                faculty.registrationStatus ||

                "Not Registered",



              "Account Status":

                getEffectiveAccountStatus(

                  faculty

                ),

            })

          );



        fileName =

          "faculty-directory-report.csv";

      }



      if (

        selectedReport ===

        "Registration Status"

      ) {

        rows =

          facultyReport.map(

            (faculty) => ({

              "Faculty ID":

                faculty.facultyId ||

                "",



              Name:

                faculty.name || "",



              Department:

                normalizeDepartment(

                  faculty.department

                ),



              Email:

                faculty.email || "",



              "Registration Status":

                faculty.registrationStatus ||

                "Not Registered",



              "Account Status":

                getEffectiveAccountStatus(

                  faculty

                ),

            })

          );



        fileName =

          "registration-status-report.csv";

      }



      if (

        selectedReport ===

          "Activity Submission" ||

        selectedReport ===

          "Pending Activities"

      ) {

        const source =

          selectedReport ===

          "Pending Activities"

            ? activityReport.filter(

                (activity) =>

                  (activity.status ||

                    "Pending") ===

                  "Pending"

              )

            : activityReport;



        rows = source.map(

          (activity) => ({

            "Faculty ID":

              activity.facultyId ||

              "",



            Faculty:

              activity.facultyName ||

              "",



            Department:

              normalizeDepartment(

                activity.department

              ),



            "Activity Type":

              activity.type || "",



            Title:

              activity.title || "",



            "Submission Date":

              activity.submissionDate ||

              activity.createdAt ||

              "",



            Status:

              activity.status ||

              "Pending",



            "Contribution Done":

              activity.contributionDone ||

              "No",



            "Contribution For":

              activity.contributionFor ||

              "",



            "Contribution Status":

              activity.contributionDone ===

                "Yes"

                ? activity.contributionStatus ||

                  "Pending"

                : "Not Applicable",



            "Impact Eligible":

              activity.status ===

                "Approved" &&

              activity.contributionDone ===

                "Yes" &&

              activity.contributionStatus ===

                "Approved"

                ? "Yes"

                : "No",

          })

        );



        fileName =

          selectedReport ===

          "Pending Activities"

            ? "pending-activities-report.csv"

            : "activity-submission-report.csv";

      }



      if (

        selectedReport ===

        "Department Performance"

      ) {

        rows =

          visibleDepartmentReport.map(

            (department) => ({

              Department:

                department.department,



              "Total Faculty":

                department.totalFaculty,



              "Approved Faculty":

                department.approvedFaculty,



              "Pending Faculty":

                department.pendingFaculty,



              "Rejected Faculty":

                department.rejectedFaculty,



              "Total Activities":

                department.totalActivities,



              "Approved Activities":

                department.approvedActivities,



              "Pending Activities":

                department.pendingActivities,



              "Rejected Activities":

                department.rejectedActivities,



              "Approved Contributions":

                department.approvedContributions,



              "Pending Contributions":

                department.pendingContributions,



              "Rejected Contributions":

                department.rejectedContributions,



              "Activity Score Total":

                department.activityScore,



              "Knowledge Transfer Total":

                department.knowledgeTransferScore,



              "Total FIS Points":

                department.totalImpactPoints,



              "Average FIS":

                department.averageImpactScore,

            })

          );



        fileName =

          "department-performance-report.csv";

      }



      if (

        selectedReport ===

        "Faculty Impact Score"

      ) {

        rows =

          impactReport.map(

            (

              faculty,

              index

            ) => ({

              Rank:

                index + 1,



              "Faculty ID":

                faculty.facultyId ||

                "",



              Name:

                faculty.name || "",



              Department:

                normalizeDepartment(

                  faculty.department

                ),



              "Approved Activities":

                faculty.approvedActivityCount,



              "Approved Contributions":

                faculty.approvedContributionCount,



              "Activity Score / 74":

                faculty.activityScore,



              "Knowledge Transfer / 26":

                faculty.knowledgeTransferScore,



              "Raw Activity Points":

                faculty.rawActivityScore,



              "Raw Knowledge Transfer Points":

                faculty.rawKnowledgeTransferScore,



              "Raw Points":

                faculty.rawScore,



              "Impact Score / 100":

                faculty.impactScore,

            })

          );



        fileName =

          "faculty-impact-score-report.csv";

      }



      if (

        rows.length === 0

      ) {

        alert(

          "There is no data available to export."

        );



        return;

      }



      const headers =

        Object.keys(

          rows[0]

        );



      const escapeCsvValue = (

        value

      ) => {

        const stringValue =

          String(

            value ?? ""

          );



        if (

          stringValue.includes(

            ","

          ) ||

          stringValue.includes(

            '"'

          ) ||

          stringValue.includes(

            "\n"

          )

        ) {

          return `"${stringValue.replaceAll(

            '"',

            '""'

          )}"`;

        }



        return stringValue;

      };



      const csvContent = [

        headers

          .map(

            escapeCsvValue

          )

          .join(","),



        ...rows.map((row) =>

          headers

            .map((header) =>

              escapeCsvValue(

                row[header]

              )

            )

            .join(",")

        ),

      ].join("\n");



      const blob =

        new Blob(

          [csvContent],

          {

            type:

              "text/csv;charset=utf-8;",

          }

        );



      const url =

        URL.createObjectURL(

          blob

        );



      const link =

        document.createElement(

          "a"

        );



      link.href = url;



      link.download =

        fileName;



      document.body.appendChild(

        link

      );



      link.click();



      document.body.removeChild(

        link

      );



      URL.revokeObjectURL(

        url

      );

    };



  const formatDate = (value) => {

    if (!value) {

      return "-";

    }



    const date =

      new Date(value);



    if (

      Number.isNaN(

        date.getTime()

      )

    ) {

      return String(value);

    }



    return date.toLocaleDateString(

      "en-IN",

      {

        day: "2-digit",

        month: "short",

        year: "numeric",

      }

    );

  };



  // ========================================

  // FACULTY TABLE

  // ========================================



  const renderFacultyTable =

    () => (

      <div className="admin-reports__table-wrapper">

        <table className="admin-reports__table">

          <thead>

            <tr>

              <th>

                Faculty ID

              </th>



              <th>

                Name

              </th>



              <th>

                Department

              </th>



              <th>

                Designation

              </th>



              <th>

                Email

              </th>



              <th>

                Phone

              </th>



              <th>

                Registration

              </th>



              <th>

                Account

              </th>

            </tr>

          </thead>



          <tbody>

            {facultyReport.map(

              (faculty) => (

                <tr

                  key={

                    faculty._id

                  }

                >

                  <td>

                    {faculty.facultyId ||

                      "-"}

                  </td>



                  <td>

                    {faculty.name ||

                      "-"}

                  </td>



                  <td>

                    {normalizeDepartment(

                      faculty.department

                    )}

                  </td>



                  <td>

                    {faculty.designation ||

                      "-"}

                  </td>



                  <td>

                    {faculty.email ||

                      "-"}

                  </td>



                  <td>

                    {faculty.phone ||

                      "-"}

                  </td>



                  <td>

                    {faculty.registrationStatus ||

                      "Not Registered"}

                  </td>



                  <td>

                    {

                      getEffectiveAccountStatus(

                        faculty

                      )

                    }

                  </td>

                </tr>

              )

            )}

          </tbody>

        </table>



        {facultyReport.length ===

          0 && (

          <div className="admin-reports__empty">

            No faculty records

            found.

          </div>

        )}

      </div>

    );



  // ========================================

  // ACTIVITY TABLE

  // ========================================



  const renderActivityTable = (

    pendingOnly = false

  ) => {

    const source =

      pendingOnly

        ? activityReport.filter(

            (activity) =>

              (activity.status ||

                "Pending") ===

              "Pending"

          )

        : activityReport;



    return (

      <div className="admin-reports__table-wrapper">

        <table className="admin-reports__table">

          <thead>

            <tr>

              <th>

                Faculty

              </th>



              <th>

                Faculty ID

              </th>



              <th>

                Department

              </th>



              <th>

                Activity Type

              </th>



              <th>

                Title

              </th>



              <th>

                Submission Date

              </th>



              <th>

                Status

              </th>



              <th>

                Contribution

              </th>



              <th>

                Contribution Status

              </th>



              <th>

                Impact Eligible

              </th>

            </tr>

          </thead>



          <tbody>

            {source.map(

              (activity) => (

                <tr

                  key={

                    activity._id

                  }

                >

                  <td>

                    {activity.facultyName ||

                      "-"}

                  </td>



                  <td>

                    {activity.facultyId ||

                      "-"}

                  </td>



                  <td>

                    {normalizeDepartment(

                      activity.department

                    )}

                  </td>



                  <td>

                    {activity.type ||

                      "-"}

                  </td>



                  <td>

                    {activity.title ||

                      "-"}

                  </td>



                  <td>

                    {formatDate(

                      activity.submissionDate ||

                        activity.createdAt

                    )}

                  </td>



                  <td>

                    {activity.status ||

                      "Pending"}

                  </td>



                  <td>

                    {activity.contributionDone ===

                    "Yes"

                      ? activity.contributionFor ||

                        "Yes"

                      : "No"}

                  </td>



                  <td>

                    {activity.contributionDone ===

                    "Yes"

                      ? activity.contributionStatus ||

                        "Pending"

                      : "Not Applicable"}

                  </td>



                  <td>

                    {activity.status ===

                      "Approved" &&

                    activity.contributionDone ===

                      "Yes" &&

                    activity.contributionStatus ===

                      "Approved"

                      ? "Yes"

                      : "No"}

                  </td>

                </tr>

              )

            )}

          </tbody>

        </table>



        {source.length ===

          0 && (

          <div className="admin-reports__empty">

            No activity records

            found.

          </div>

        )}

      </div>

    );

  };



  // ========================================

  // DEPARTMENT TABLE

  // ========================================



  const renderDepartmentTable =

    () => (

      <div className="admin-reports__table-wrapper">

        <table className="admin-reports__table">

          <thead>

            <tr>

              <th>

                Department

              </th>



              <th>

                Total Faculty

              </th>



              <th>

                Approved Faculty

              </th>



              <th>

                Pending Faculty

              </th>



              <th>

                Rejected Faculty

              </th>



              <th>

                Total Activities

              </th>



              <th>

                Approved Activities

              </th>



              <th>

                Pending Activities

              </th>



              <th>

                Rejected Activities

              </th>



              <th>

                Approved Contributions

              </th>



              <th>

                Pending Contributions

              </th>



              <th>

                Rejected Contributions

              </th>



              <th>

                Activity Score Total

              </th>



              <th>

                Knowledge Transfer Total

              </th>



              <th>

                Total FIS Points

              </th>



              <th>

                Average FIS

              </th>

            </tr>

          </thead>



          <tbody>

            {visibleDepartmentReport.map(

              (department) => (

                <tr

                  key={

                    department.department

                  }

                >

                  <td>

                    {

                      department.department

                    }

                  </td>



                  <td>

                    {

                      department.totalFaculty

                    }

                  </td>



                  <td>

                    {

                      department.approvedFaculty

                    }

                  </td>



                  <td>

                    {

                      department.pendingFaculty

                    }

                  </td>



                  <td>

                    {

                      department.rejectedFaculty

                    }

                  </td>



                  <td>

                    {

                      department.totalActivities

                    }

                  </td>



                  <td>

                    {

                      department.approvedActivities

                    }

                  </td>



                  <td>

                    {

                      department.pendingActivities

                    }

                  </td>



                  <td>

                    {

                      department.rejectedActivities

                    }

                  </td>



                  <td>

                    {

                      department.approvedContributions

                    }

                  </td>



                  <td>

                    {

                      department.pendingContributions

                    }

                  </td>



                  <td>

                    {

                      department.rejectedContributions

                    }

                  </td>



                  <td>

                    {

                      department.activityScore

                    }

                  </td>



                  <td>

                    {

                      department.knowledgeTransferScore

                    }

                  </td>



                  <td>

                    {

                      department.totalImpactPoints

                    }

                  </td>



                  <td>

                    {

                      department.averageImpactScore

                    }/100

                  </td>

                </tr>

              )

            )}

          </tbody>

        </table>

      </div>

    );



  // ========================================

  // IMPACT TABLE

  // ========================================



  const renderImpactTable =

    () => (

      <div className="admin-reports__table-wrapper">

        <table className="admin-reports__table">

          <thead>

            <tr>

              <th>

                Rank

              </th>



              <th>

                Faculty ID

              </th>



              <th>

                Name

              </th>



              <th>

                Department

              </th>



              <th>

                Approved Activities

              </th>



              <th>

                Approved Contributions

              </th>



              <th>

                Activity Score

              </th>



              <th>

                Knowledge Transfer

              </th>



              <th>

                Raw Points

              </th>



              <th>

                Impact Score

              </th>

            </tr>

          </thead>



          <tbody>

            {impactReport.map(

              (

                faculty,

                index

              ) => (

                <tr

                  key={

                    faculty._id

                  }

                >

                  <td>

                    {index + 1}

                  </td>



                  <td>

                    {faculty.facultyId ||

                      "-"}

                  </td>



                  <td>

                    {faculty.name ||

                      "-"}

                  </td>



                  <td>

                    {normalizeDepartment(

                      faculty.department

                    )}

                  </td>



                  <td>

                    {

                      faculty.approvedActivityCount

                    }

                  </td>



                  <td>

                    {

                      faculty.approvedContributionCount

                    }

                  </td>



                  <td>

                    {

                      faculty.activityScore

                    }/74

                  </td>



                  <td>

                    {

                      faculty.knowledgeTransferScore

                    }/26

                  </td>



                  <td>

                    {

                      faculty.rawScore

                    }

                  </td>



                  <td>

                    {

                      faculty.impactScore

                    }

                    /100

                  </td>

                </tr>

              )

            )}

          </tbody>

        </table>



        {impactReport.length ===

          0 && (

          <div className="admin-reports__empty">

            No impact-score data

            found.

          </div>

        )}

      </div>

    );



  // ========================================
  // DETAILED PRINT REPORTS
  // ========================================

  const selectedFacultyForReport = facultyList.find(
    (faculty) =>
      normalizeFacultyId(faculty.facultyId) ===
      normalizeFacultyId(selectedFacultyId)
  );

  const renderIndividualPrintReport = () => {
    if (!selectedFacultyForReport) {
      return <div className="admin-reports__print-document"><h1>Individual Faculty Report</h1><p>No faculty member selected.</p></div>;
    }

    const score = calculateBalancedImpact(selectedFacultyForReport.facultyId, validActivities);
    const strengths = [];
    const improvements = [];
    const recommendations = [];

    score.categoryScores.forEach((item) => {
      const percentage = item.maxScore ? (item.cappedCategoryScore / item.maxScore) * 100 : 0;
      if (percentage >= 70) strengths.push(`${item.type}: ${item.approvedCount} approved activity record(s) contribute ${item.cappedCategoryScore}/${item.maxScore} points.`);
      if (percentage < 50) improvements.push(`${item.type}: ${item.cappedCategoryScore}/${item.maxScore} points are currently earned. More approved activity can improve this category.`);
    });

    if (score.knowledgeTransferScore >= 15) strengths.push(`Knowledge Transfer is a current strength with ${score.knowledgeTransferScore}/26 points.`);
    else improvements.push(`Knowledge Transfer currently contributes ${score.knowledgeTransferScore}/26 points.`);

    const weakest = [...score.categoryScores].sort((a,b) => a.cappedCategoryScore/a.maxScore - b.cappedCategoryScore/b.maxScore)[0];
    if (weakest) recommendations.push(`Prioritize ${weakest.type}, currently contributing ${weakest.cappedCategoryScore}/${weakest.maxScore} points.`);
    if (score.knowledgeTransferScore < KNOWLEDGE_TRANSFER_MAX) recommendations.push("Increase approved knowledge-transfer contributions to students, the department, or both.");
    recommendations.push(score.impactScore < 60 ? "Build a more balanced profile across professional development, research, publication and patent/IPR activities." : "Maintain the current strengths while improving the lowest-scoring activity categories.");
    if (!strengths.length) strengths.push("No activity category has reached the strong-performance threshold yet.");
    if (!improvements.length) improvements.push("All activity categories are currently at or above the improvement threshold.");

    const scoreCategory = score.impactScore >= 80 ? "Excellent" : score.impactScore >= 60 ? "High" : score.impactScore >= 40 ? "Moderate" : "Needs Improvement";

    return (
      <div className="admin-reports__print-document">
        <header className="admin-reports__print-header">
          <div><strong>SCMS SCHOOL OF ENGINEERING & TECHNOLOGY</strong><span>Faculty Management System</span></div>
          <div><strong>INDIVIDUAL FACULTY PERFORMANCE REPORT</strong><span>Generated: {new Date().toLocaleDateString("en-IN")}</span></div>
        </header>

        <section className="admin-reports__print-section"><h2>1. Faculty Information</h2><div className="admin-reports__print-info-grid">
          <div><span>Faculty Name</span><strong>{selectedFacultyForReport.name || "—"}</strong></div>
          <div><span>Faculty ID</span><strong>{selectedFacultyForReport.facultyId || "—"}</strong></div>
          <div><span>Department</span><strong>{normalizeDepartment(selectedFacultyForReport.department)}</strong></div>
          <div><span>Designation</span><strong>{selectedFacultyForReport.designation || "—"}</strong></div>
          <div><span>Email</span><strong>{selectedFacultyForReport.email || "—"}</strong></div>
          <div><span>Account Status</span><strong>{getEffectiveAccountStatus(selectedFacultyForReport)}</strong></div>
        </div></section>

        <section className="admin-reports__print-section"><h2>2. Executive Performance Summary</h2><div className="admin-reports__print-score-grid">
          <div><span>Final FIS</span><strong>{score.impactScore}/100</strong></div>
          <div><span>Performance Category</span><strong>{scoreCategory}</strong></div>
          <div><span>Approved Activities</span><strong>{score.approvedActivityCount}</strong></div>
          <div><span>Approved Contributions</span><strong>{score.approvedContributionCount}</strong></div>
        </div><p>{selectedFacultyForReport.name || "The faculty member"} has a Faculty Impact Score of {score.impactScore}/100 and is classified as {scoreCategory}. The score is calculated from approved current activities and approved Knowledge Transfer contributions stored in the system.</p></section>

        <section className="admin-reports__print-section"><h2>3. Faculty Impact Score Calculation</h2><table className="admin-reports__print-table"><thead><tr><th>Activity Category</th><th>Approved</th><th>Points / Activity</th><th>Calculated</th><th>Maximum</th><th>Counted</th></tr></thead><tbody>
          {score.categoryScores.map((item) => <tr key={item.type}><td>{item.type}</td><td>{item.approvedCount}</td><td>{ACTIVITY_CONFIG[item.type].pointsPerActivity}</td><td>{item.rawCategoryScore}</td><td>{item.maxScore}</td><td>{item.cappedCategoryScore}</td></tr>)}
          <tr className="print-total"><td colSpan="3">Academic Activity Score</td><td>{score.rawActivityScore}</td><td>{ACTIVITY_SCORE_MAX}</td><td>{score.activityScore}</td></tr>
          <tr className="print-total"><td colSpan="5">Knowledge Transfer</td><td>{score.knowledgeTransferScore}/26</td></tr>
          <tr className="print-grand-total"><td colSpan="5">Final FIS</td><td>{score.impactScore}/100</td></tr>
        </tbody></table><p className="admin-reports__print-note">Only approved current activities are counted. FDP: 2/activity max 12; NPTEL: 3/activity max 12; Research Paper: 5/activity max 15; Journal Publication: 5/activity max 20; Patent / IPR: 5/activity max 15. Academic Activity Score is capped at 74. Knowledge Transfer is Students 4, Department 5 or Both 8, capped at 26.</p></section>

        <section className="admin-reports__print-section"><h2>4. Activity-wise Performance Analysis</h2>{score.categoryScores.map((item) => <div className="admin-reports__print-analysis" key={item.type}><h3>{item.type}</h3><p>{item.approvedCount === 0 ? `No approved ${item.type} activity is currently contributing to the FIS.` : `${item.approvedCount} approved ${item.type.toLowerCase()} record(s) contribute ${item.cappedCategoryScore}/${item.maxScore} points.`}</p></div>)}</section>

        <section className="admin-reports__print-section"><h2>5. Knowledge Transfer Analysis</h2><table className="admin-reports__print-table"><thead><tr><th>Activity</th><th>Contribution For</th><th>Status</th><th>Points</th></tr></thead><tbody>
          {score.approvedContributions.map((activity,index) => <tr key={activity._id || index}><td>{activity.title || activity.type}</td><td>{activity.contributionFor || "—"}</td><td>{activity.contributionStatus || "—"}</td><td>{CONTRIBUTION_WEIGHTS[activity.contributionFor] || 0}</td></tr>)}
          {!score.approvedContributions.length && <tr><td colSpan="4">No approved Knowledge Transfer contributions are currently recorded.</td></tr>}
          <tr className="print-total"><td colSpan="3">Knowledge Transfer Score</td><td>{score.knowledgeTransferScore}/26</td></tr>
        </tbody></table></section>

        <section className="admin-reports__print-section"><h2>6. Strengths</h2><ul>{strengths.map((item,i)=><li key={i}>{item}</li>)}</ul></section>
        <section className="admin-reports__print-section"><h2>7. Areas for Improvement</h2><ul>{improvements.map((item,i)=><li key={i}>{item}</li>)}</ul></section>
        <section className="admin-reports__print-section"><h2>8. Recommendations</h2><ul>{recommendations.map((item,i)=><li key={i}>{item}</li>)}</ul></section>

        <section className="admin-reports__print-section"><h2>9. Detailed Approved Activity Records</h2><table className="admin-reports__print-table"><thead><tr><th>Type</th><th>Title</th><th>Date</th><th>Contribution</th></tr></thead><tbody>
          {score.approvedActivities.map((activity,index)=><tr key={activity._id || index}><td>{activity.type}</td><td>{activity.title || "—"}</td><td>{formatDate(activity.activityDate || activity.date || activity.startDate || activity.publicationDate)}</td><td>{activity.contributionDone === "Yes" ? `${activity.contributionFor || "Yes"} / ${activity.contributionStatus || "Pending"}` : "No"}</td></tr>)}
          {!score.approvedActivities.length && <tr><td colSpan="4">No approved current activities found.</td></tr>}
        </tbody></table></section>

        <section className="admin-reports__print-section admin-reports__print-final"><h2>10. Final Assessment</h2><p>Based on the approved records available in the Faculty Management System, {selectedFacultyForReport.name || "the faculty member"} has achieved a Faculty Impact Score of {score.impactScore}/100. The current performance category is {scoreCategory}.</p><p>This is a rule-based administrative assessment and remains separate from the planned machine-learning prediction module.</p></section>
        <footer className="admin-reports__print-footer"><span>Faculty Management System</span><span>SCMS School of Engineering & Technology</span></footer>
      </div>
    );
  };

  const renderOverallPrintReport = () => {
    const rows = activeApprovedFaculty.map((faculty) => ({ faculty, score: calculateBalancedImpact(faculty.facultyId, validActivities) })).sort((a,b)=>b.score.impactScore-a.score.impactScore);
    const average = rows.length ? rows.reduce((sum,row)=>sum+row.score.impactScore,0)/rows.length : 0;
    const highest = rows.length ? rows[0].score.impactScore : 0;
    const lowest = rows.length ? rows[rows.length-1].score.impactScore : 0;
    const departmentMap = {};
    rows.forEach((row)=>{const name=normalizeDepartment(row.faculty.department);if(!departmentMap[name])departmentMap[name]={department:name,count:0,total:0};departmentMap[name].count+=1;departmentMap[name].total+=row.score.impactScore;});
    const departmentRows = Object.values(departmentMap).sort((a,b)=>b.total/b.count-a.total/a.count);
    const distribution = ACTIVITY_TYPES.map(type=>({type,count:approvedActivities.filter(a=>a.type===type).length}));
    const strongest=[...distribution].sort((a,b)=>b.count-a.count)[0];
    const weakest=[...distribution].sort((a,b)=>a.count-b.count)[0];

    return (
      <div className="admin-reports__print-document">
        <header className="admin-reports__print-header"><div><strong>SCMS SCHOOL OF ENGINEERING & TECHNOLOGY</strong><span>Faculty Management System</span></div><div><strong>OVERALL FACULTY PERFORMANCE REPORT</strong><span>Generated: {new Date().toLocaleDateString("en-IN")}</span></div></header>
        <section className="admin-reports__print-section"><h2>1. Executive Summary</h2><div className="admin-reports__print-score-grid"><div><span>Faculty Included</span><strong>{rows.length}</strong></div><div><span>Average FIS</span><strong>{average.toFixed(1)}/100</strong></div><div><span>Highest FIS</span><strong>{highest}/100</strong></div><div><span>Lowest FIS</span><strong>{lowest}/100</strong></div></div><p>This report evaluates {rows.length} active approved faculty members using approved current activity records and the rule-based Faculty Impact Score. The group average is {average.toFixed(1)}/100, with a highest score of {highest}/100 and a lowest score of {lowest}/100.</p></section>
        <section className="admin-reports__print-section"><h2>2. Faculty Performance Ranking</h2><table className="admin-reports__print-table"><thead><tr><th>Rank</th><th>Faculty</th><th>Department</th><th>Approved Activities</th><th>Activity Score</th><th>KT</th><th>FIS</th><th>Category</th></tr></thead><tbody>{rows.map((row,index)=><tr key={row.faculty.facultyId||index}><td>{index+1}</td><td>{row.faculty.name||"—"}<br/>{row.faculty.facultyId||""}</td><td>{normalizeDepartment(row.faculty.department)}</td><td>{row.score.approvedActivityCount}</td><td>{row.score.activityScore}/74</td><td>{row.score.knowledgeTransferScore}/26</td><td><strong>{row.score.impactScore}/100</strong></td><td>{row.score.impactScore>=80?"Excellent":row.score.impactScore>=60?"High":row.score.impactScore>=40?"Moderate":"Needs Improvement"}</td></tr>)}{!rows.length&&<tr><td colSpan="8">No active approved faculty records found.</td></tr>}</tbody></table></section>
        <section className="admin-reports__print-section"><h2>3. Activity Distribution Analysis</h2>{distribution.map(item=><div className="admin-reports__print-analysis" key={item.type}><h3>{item.type}</h3><p>{item.count} approved record(s) are currently included for this category.</p></div>)}<p>{strongest?.type||"No activity"} is currently the most represented approved activity category with {strongest?.count||0} record(s), while {weakest?.type||"No activity"} has the lowest approved count with {weakest?.count||0} record(s).</p></section>
        <section className="admin-reports__print-section"><h2>4. Knowledge Transfer Analysis</h2><p>Knowledge Transfer is calculated from approved contributions linked to approved current activities. Each faculty member is independently capped at 26 points.</p><table className="admin-reports__print-table"><thead><tr><th>Contribution Area</th><th>Points</th><th>Approved Contributions</th></tr></thead><tbody>{Object.entries(CONTRIBUTION_WEIGHTS).map(([name,points])=>{const count=approvedContributions.filter(a=>a.contributionFor===name).length;return <tr key={name}><td>{name}</td><td>{points}</td><td>{count}</td></tr>;})}</tbody></table></section>
        <section className="admin-reports__print-section"><h2>5. Department Performance Analysis</h2><table className="admin-reports__print-table"><thead><tr><th>Department</th><th>Faculty</th><th>Total FIS</th><th>Average FIS</th></tr></thead><tbody>{departmentRows.map(row=><tr key={row.department}><td>{row.department}</td><td>{row.count}</td><td>{row.total.toFixed(1)}</td><td>{(row.total/row.count).toFixed(1)}/100</td></tr>)}</tbody></table></section>
        <section className="admin-reports__print-section"><h2>6. Strengths</h2><ul><li>The report identifies the highest-performing faculty through the rule-based FIS ranking.</li><li>The most represented approved activity category is {strongest?.type||"not available"}.</li><li>The report separates Academic Activity Score from Knowledge Transfer.</li></ul></section>
        <section className="admin-reports__print-section"><h2>7. Areas for Improvement</h2><ul><li>The least represented approved activity category is {weakest?.type||"not available"}.</li><li>Faculty with low FIS values require a more balanced distribution of approved academic activities.</li><li>Knowledge Transfer can be strengthened through approved student, department or combined contributions.</li></ul></section>
        <section className="admin-reports__print-section"><h2>8. Recommendations</h2><ul><li>Encourage participation in the least represented activity categories.</li><li>Promote approved Knowledge Transfer contributions where appropriate.</li><li>Use ranking and department analysis to identify faculty groups requiring additional support.</li><li>Continue monitoring pending and rejected submissions so eligible work can move through the approval workflow.</li></ul></section>
        <section className="admin-reports__print-section admin-reports__print-final"><h2>9. Overall Conclusion</h2><p>The overall report provides a data-derived administrative assessment of faculty performance using current approved records in the Faculty Management System. The rankings, activity distribution, Knowledge Transfer analysis and recommendations are generated from the defined FIS rules.</p><p>The machine-learning component remains separate from this rule-based assessment and can later be used for prediction and recommendation purposes.</p></section>
        <footer className="admin-reports__print-footer"><span>Faculty Management System</span><span>SCMS School of Engineering & Technology</span></footer>
      </div>
    );
  };

  // ========================================

  // SELECT REPORT

  // ========================================



  const renderSelectedReport =

    () => {

      switch (

        selectedReport

      ) {

        case "Individual Faculty Report":

          return renderIndividualPrintReport();

        case "Overall Faculty Report":

          return renderOverallPrintReport();

        case "Faculty Directory":

        case "Registration Status":

          return renderFacultyTable();



        case "Activity Submission":

          return renderActivityTable(

            false

          );



        case "Pending Activities":

          return renderActivityTable(

            true

          );



        case "Department Performance":

          return renderDepartmentTable();



        case "Faculty Impact Score":

          return renderImpactTable();



        default:

          return null;

      }

    };



  // ========================================

  // JSX

  // ========================================



  return (

    <div className="admin-reports">

      <section className="admin-reports__heading">

        <div>

          <p className="admin-reports__eyebrow">

            REPORT CENTRE

          </p>



          <h1>

            Admin Reports

          </h1>



          <p>

            View, filter, print and

            export faculty, activity,

            knowledge transfer and FIS

            reports using the final

            approval workflow.

          </p>

        </div>



        <div className="admin-reports__heading-actions">

          <button

            type="button"

            onClick={

              handlePrint

            }

          >

            Print / PDF

          </button>



          <button

            type="button"

            onClick={

              handleExportExcel

            }

          >

            Export CSV

          </button>

        </div>

      </section>



      {errorMessage && (

        <div className="admin-reports__empty">

          {errorMessage}

        </div>

      )}



      {loading ? (

        <div className="admin-reports__empty">

          Loading report data...

        </div>

      ) : (

        <>

          <section className="admin-reports__stats">

            <article>

              <span>

                Total Faculty

              </span>



              <strong>

                {

                  facultyList.length

                }

              </strong>



              <small>

                {

                  approvedFaculty.length

                }{" "}

                approved

              </small>

            </article>



            <article>

              <span>

                Pending Registrations

              </span>



              <strong>

                {

                  pendingFaculty.length

                }

              </strong>



              <small>

                {

                  rejectedFaculty.length

                }{" "}

                rejected

              </small>

            </article>



            <article>

              <span>

                Total Activities

              </span>



              <strong>

                {

                  validActivities.length

                }

              </strong>



              <small>

                {

                  approvedActivities.length

                }{" "}

                approved

              </small>

            </article>



            <article>

              <span>

                Pending Activities

              </span>



              <strong>

                {

                  pendingActivities.length

                }

              </strong>



              <small>

                {

                  rejectedActivities.length

                }{" "}

                rejected

              </small>

            </article>



            <article>

              <span>

                Approved Contributions

              </span>



              <strong>

                {

                  approvedContributions.length

                }

              </strong>



              <small>

                Impact-point eligible

              </small>

            </article>



            <article>

              <span>

                Pending Contributions

              </span>



              <strong>

                {

                  pendingContributions.length

                }

              </strong>



              <small>

                {

                  rejectedContributions.length

                }{" "}

                rejected

              </small>

            </article>

          </section>



          <section className="admin-reports__report-types">

            {reportTypes.map(

              (report) => (

                <button

                  type="button"

                  key={

                    report

                  }

                  className={

                    selectedReport ===

                    report

                      ? "admin-reports__report-type admin-reports__report-type--active"

                      : "admin-reports__report-type"

                  }

                  onClick={() =>

                    setSelectedReport(

                      report

                    )

                  }

                >

                  <span>

                    📄

                  </span>



                  {report}

                </button>

              )

            )}

          </section>



          <section className="admin-reports__card">

            <div className="admin-reports__card-header">

              <div>

                <h2>

                  {selectedReport}{" "}

                  Report

                </h2>



                <p>

                  {selectedReport ===

                  "Faculty Impact Score"

                    ? "Balanced approved-only FIS: FDP 2 each (max 12), NPTEL 3 each (max 12), Research Paper 5 each (max 15), Journal Publication 5 each (max 20), Patent / IPR 5 each (max 15). Academic Activity Score is capped at 74. Approved Knowledge Transfer adds Students 4, Department 5 or Both 8, capped at 26. Final FIS is out of 100."

                    : "Review the selected report using the filters below."}

                </p>

              </div>

            </div>



            <div className="admin-reports__toolbar">

              {selectedReport === "Individual Faculty Report" && (
                <select value={selectedFacultyId} onChange={(event) => setSelectedFacultyId(event.target.value)}>
                  {approvedFaculty.map((faculty) => (
                    <option key={faculty.facultyId} value={faculty.facultyId}>
                      {faculty.name} — {faculty.facultyId}
                    </option>
                  ))}
                </select>
              )}

              <div className="admin-reports__search">

                <span>

                  ⌕

                </span>



                <input

                  type="text"

                  placeholder="Search report data"

                  value={

                    searchText

                  }

                  onChange={(event) =>

                    setSearchText(

                      event.target

                        .value

                    )

                  }

                />

              </div>



              <select

                value={

                  departmentFilter

                }

                onChange={(event) =>

                  setDepartmentFilter(

                    event.target

                      .value

                  )

                }

              >

                {departments.map(

                  (department) => (

                    <option

                      value={

                        department

                      }

                      key={

                        department

                      }

                    >

                      {department ===

                      "All"

                        ? "All Departments"

                        : department}

                    </option>

                  )

                )}

              </select>



              <select

                value={

                  statusFilter

                }

                onChange={(event) =>

                  setStatusFilter(

                    event.target

                      .value

                  )

                }

              >

                <option value="All">

                  All Statuses

                </option>



                <option value="Not Registered">

                  Not Registered

                </option>



                <option value="Pending">

                  Pending

                </option>



                <option value="Approved">

                  Approved

                </option>



                <option value="Rejected">

                  Rejected

                </option>

              </select>

            </div>



            <div className="admin-reports__report-content">

              {

                renderSelectedReport()

              }

            </div>

          </section>

        </>

      )}

    </div>

  );

}



export default AdminReports;