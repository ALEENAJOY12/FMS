import { useEffect, useMemo, useRef, useState } from "react";
import api from "../../utils/api";
import "./FacultyDirectory.css";

const MAX_IMPORT_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_IMPORT_EXTENSIONS = ["xlsx", "xls", "csv"];

const normalizeDepartment = (department) => {
  const value = String(department || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");

  const aliases = {
    cse: "CSE",
    "computer science": "CSE",
    "computer science engineering": "CSE",
    "computer science and engineering": "CSE",
    "computer science & engineering": "CSE",
  };

  return (
    aliases[value] ||
    String(department || "").trim() ||
    "Other"
  );
};

const toClassSuffix = (value, fallback = "unknown") =>
  String(value || fallback)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-");


const getRegistrationStatus = (faculty) =>
  faculty?.registrationStatus || "Not Registered";

const getEffectiveAccountStatus = (faculty) => {
  const registrationStatus =
    getRegistrationStatus(faculty);

  // A faculty member must be approved before
  // the account can be considered active.
  if (registrationStatus !== "Approved") {
    return "Inactive";
  }

  return faculty?.accountStatus || "Inactive";
};

const formatFileSize = (bytes) => {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return "0 KB";
  }

  if (bytes < 1024 * 1024) {
    return `${Math.ceil(bytes / 1024)} KB`;
  }

  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};

const BACKEND_ORIGIN =
  "http://localhost:5000";

const getDocumentUrl = (value) => {
  const path = String(value || "").trim();

  if (!path) {
    return "";
  }

  if (
    path.startsWith("http://") ||
    path.startsWith("https://") ||
    path.startsWith("data:")
  ) {
    return path;
  }

  return `${BACKEND_ORIGIN}${
    path.startsWith("/") ? path : `/${path}`
  }`;
};

const isPdfDocument = (value) => {
  const cleanValue = String(value || "")
    .split("?")[0]
    .split("#")[0]
    .toLowerCase();

  return cleanValue.endsWith(".pdf");
};

const getFacultyCertificate = (faculty) => {
  if (faculty?.certificateUrl) {
    return faculty.certificateUrl;
  }

  // Backward compatibility:
  // old versions stored certificates inside profileImage.
  const legacyValue =
    String(faculty?.profileImage || "");

  if (
    legacyValue.startsWith(
      "/uploads/certificates/"
    )
  ) {
    return legacyValue;
  }

  return "";
};

function FacultyDirectory() {
  const [facultyList, setFacultyList] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [accountFilter, setAccountFilter] = useState("All");
  const [selectedFaculty, setSelectedFaculty] = useState(null);
  const [largeImageUrl, setLargeImageUrl] = useState("");

  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  // Excel Import
  const [isImportModalOpen, setIsImportModalOpen] =
    useState(false);

  const [excelFile, setExcelFile] =
    useState(null);

  const [importLoading, setImportLoading] =
    useState(false);

  const [importProgress, setImportProgress] =
    useState(0);

  const [dragActive, setDragActive] =
    useState(false);

  const [importError, setImportError] =
    useState("");

  const [importSummary, setImportSummary] =
    useState(null);

  const fileInputRef = useRef(null);

  // =========================================================
  // LOAD FACULTY FROM MONGODB
  // =========================================================

  const loadFaculty = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const response = await api.get("/faculty");

      setFacultyList(
        response.data.faculty ||
        response.data.faculties ||
        []
      );
    } catch (error) {
      console.error("Faculty load error:", error);
      setErrorMessage(
        error.response?.data?.message || "Unable to load faculty records."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFaculty();
  }, []);

  // =========================================================
  // DEPARTMENTS
  // =========================================================

  const departments = useMemo(() => {
    const values = facultyList
      .map((faculty) =>
        normalizeDepartment(
          faculty.department
        )
      )
      .filter(Boolean);

    return [
      "All",
      ...new Set(values),
    ];
  }, [facultyList]);

  // =========================================================
  // FILTER
  // =========================================================

  const filteredFaculty = useMemo(() => {
    const value = searchText.trim().toLowerCase();

    return facultyList.filter((faculty) => {
      const searchableValues = [
        faculty.name,
        faculty.facultyId,
        faculty.email,
        normalizeDepartment(
          faculty.department
        ),
        faculty.designation,
        faculty.phone,
      ];

      const matchesSearch =
        !value ||
        searchableValues.some((item) =>
          String(item || "")
            .toLowerCase()
            .includes(value)
        );

      const matchesDepartment =
        departmentFilter === "All" ||
        normalizeDepartment(
          faculty.department
        ) === departmentFilter;

      const accountStatus =
        getEffectiveAccountStatus(faculty);

      const matchesAccount =
        accountFilter === "All" ||
        accountStatus === accountFilter;

      return (
        matchesSearch &&
        matchesDepartment &&
        matchesAccount
      );
    });
  }, [
    facultyList,
    searchText,
    departmentFilter,
    accountFilter,
  ]);

  // =========================================================
  // COUNTS
  // =========================================================

  const totalFaculty = facultyList.length;

  const activeCount = facultyList.filter(
    (faculty) =>
      getEffectiveAccountStatus(faculty) === "Active"
  ).length;

  const pendingCount = facultyList.filter(
    (faculty) => faculty.registrationStatus === "Pending"
  ).length;

  const inactiveCount = facultyList.filter(
    (faculty) =>
      getEffectiveAccountStatus(faculty) === "Inactive"
  ).length;

  // =========================================================
  // UPDATE FACULTY
  // =========================================================

  const updateFaculty = async (faculty, updates) => {
    const response = await api.put(`/faculty/${faculty._id}`, updates);
    return response.data.faculty;
  };

  // =========================================================
  // ACTIVATE
  // =========================================================

  const handleActivate = async (faculty) => {
    const registrationStatus =
      getRegistrationStatus(faculty);

    if (registrationStatus !== "Approved") {
      setSuccessMessage("");
      setErrorMessage(
        `${faculty.name || "Faculty"} cannot be activated until registration is approved.`
      );
      return;
    }

    try {
      setErrorMessage("");
      setSuccessMessage("");

      const updatedFaculty = await updateFaculty(
        faculty,
        {
          accountStatus: "Active",
        }
      );

      setFacultyList((previous) =>
        previous.map((item) =>
          item._id === faculty._id
            ? updatedFaculty
            : item
        )
      );

      if (selectedFaculty?._id === faculty._id) {
        setSelectedFaculty(updatedFaculty);
      }

      setSuccessMessage(
        `${faculty.name} has been activated.`
      );
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to activate faculty.");
    }
  };

  // =========================================================
  // DEACTIVATE
  // =========================================================

  const handleDeactivate = async (faculty) => {
    const confirmed = window.confirm(
      `Deactivate ${faculty.name}'s account?`
    );

    if (!confirmed) return;

    try {
      setErrorMessage("");
      setSuccessMessage("");

      const updatedFaculty = await updateFaculty(
        faculty,
        {
          accountStatus: "Inactive",
        }
      );

      setFacultyList((previous) =>
        previous.map((item) =>
          item._id === faculty._id
            ? updatedFaculty
            : item
        )
      );

      if (selectedFaculty?._id === faculty._id) {
        setSelectedFaculty(updatedFaculty);
      }

      setSuccessMessage(
        `${faculty.name}'s account has been deactivated.`
      );
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to deactivate faculty.");
    }
  };

  // =========================================================
  // DELETE MASTER FACULTY
  // =========================================================

  const handleDelete = async (faculty) => {
    const confirmed = window.confirm(
      `Delete ${faculty.name} permanently from the faculty master database?`
    );

    if (!confirmed) return;

    try {
      setErrorMessage("");
      setSuccessMessage("");

      await api.delete(`/faculty/${faculty._id}`);

      setFacultyList((previous) =>
        previous.filter(
          (item) => item._id !== faculty._id
        )
      );

      if (selectedFaculty?._id === faculty._id) {
        setSelectedFaculty(null);
      }

      setSuccessMessage(
        `${faculty.name} has been deleted.`
      );
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to delete faculty.");
    }
  };

  // =========================================================
  // ADD FACULTY MANUALLY
  // =========================================================

  const handleAddFaculty = async () => {
    const facultyId = window.prompt("Enter Faculty ID:");
    if (!facultyId?.trim()) return;

    const name = window.prompt("Enter Faculty Name:");
    if (!name?.trim()) return;

    const email = window.prompt("Enter Faculty Email:");
    if (!email?.trim()) return;

    const department = window.prompt("Enter Department:");
    if (!department?.trim()) return;

    const designation = window.prompt("Enter Designation:");
    if (!designation?.trim()) return;

    try {
      setErrorMessage("");
      setSuccessMessage("");

      const response = await api.post("/faculty", {
        facultyId: facultyId.trim(),
        name: name.trim(),
        email: email.trim(),
        department:
          normalizeDepartment(
            department
          ),
        designation: designation.trim(),
      });

      setFacultyList((previous) => [
        ...previous,
        response.data.faculty,
      ]);

      setSuccessMessage(
        `${name.trim()} has been added to the faculty master list.`
      );
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to add faculty.");
    }
  };

  // =========================================================
  // EXCEL IMPORT
  // =========================================================

  const resetImportState = () => {
    setExcelFile(null);
    setImportError("");
    setImportSummary(null);
    setImportProgress(0);
    setDragActive(false);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleOpenImportModal = () => {
    resetImportState();
    setIsImportModalOpen(true);
  };

  const handleCloseImportModal = () => {
    if (importLoading) {
      return;
    }

    resetImportState();
    setIsImportModalOpen(false);
  };

  const validateImportFile = (file) => {
    if (!file) {
      return "Please select an Excel or CSV file.";
    }

    const extension =
      file.name
        .split(".")
        .pop()
        ?.toLowerCase() || "";

    if (
      !ALLOWED_IMPORT_EXTENSIONS.includes(
        extension
      )
    ) {
      return "Invalid file type. Please upload an .xlsx, .xls, or .csv file.";
    }

    if (
      file.size >
      MAX_IMPORT_FILE_SIZE
    ) {
      return "The selected file is larger than 5 MB.";
    }

    if (file.size === 0) {
      return "The selected file is empty.";
    }

    return "";
  };

  const applySelectedImportFile = (
    file
  ) => {
    const validationError =
      validateImportFile(file);

    if (validationError) {
      setExcelFile(null);
      setImportSummary(null);
      setImportError(
        validationError
      );

      if (fileInputRef.current) {
        fileInputRef.current.value =
          "";
      }

      return;
    }

    setExcelFile(file);
    setImportError("");
    setImportSummary(null);
    setImportProgress(0);
  };

  const handleFileSelect = (
    event
  ) => {
    const file =
      event.target.files?.[0];

    applySelectedImportFile(
      file
    );
  };

  const handleDragEnter = (
    event
  ) => {
    event.preventDefault();
    event.stopPropagation();

    if (!importLoading) {
      setDragActive(true);
    }
  };

  const handleDragOver = (
    event
  ) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDragLeave = (
    event
  ) => {
    event.preventDefault();
    event.stopPropagation();

    setDragActive(false);
  };

  const handleDrop = (
    event
  ) => {
    event.preventDefault();
    event.stopPropagation();

    setDragActive(false);

    if (importLoading) {
      return;
    }

    const file =
      event.dataTransfer.files?.[0];

    applySelectedImportFile(
      file
    );
  };

  const handleUploadExcel =
    async () => {
      const validationError =
        validateImportFile(
          excelFile
        );

      if (validationError) {
        setImportError(
          validationError
        );
        return;
      }

      try {
        setImportLoading(true);
        setImportProgress(0);
        setImportError("");
        setErrorMessage("");
        setSuccessMessage("");

        const formData =
          new FormData();

        formData.append(
          "file",
          excelFile
        );

        const response =
          await api.post(
            "/faculty/bulk-import",
            formData,
            {
              onUploadProgress:
                (progressEvent) => {
                  if (
                    !progressEvent.total
                  ) {
                    return;
                  }

                  const percentage =
                    Math.round(
                      (progressEvent.loaded *
                        100) /
                        progressEvent.total
                    );

                  setImportProgress(
                    Math.min(
                      percentage,
                      100
                    )
                  );
                },
            }
          );

        const summary =
          response.data.summary || {
            totalRows: 0,
            importedCount: 0,
            skippedCount: 0,
            skippedDetails: [],
          };

        setImportProgress(100);
        setImportSummary(
          summary
        );

        setSuccessMessage(
          response.data.message ||
            "Faculty records imported successfully."
        );

        await loadFaculty();
      } catch (error) {
        console.error(
          "Faculty import error:",
          error
        );

        setImportProgress(0);

        setImportError(
          error.response?.data
            ?.message ||
            "Unable to process the selected file. Please verify the spreadsheet and try again."
        );
      } finally {
        setImportLoading(false);
      }
    };

  // =========================================================
  // UPLOAD CERTIFICATE / DOCUMENT
  // =========================================================

  const handleCertificateUpload = async (event, facultyId) => {
    const file = event.target.files[0];
    if (!file) return;

    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/jpg",
      "image/webp",
    ];
    if (!allowedTypes.includes(file.type)) {
      setErrorMessage(
        "Invalid file type. Only PDF, JPG, PNG, and WEBP are allowed."
      );
      return;
    }

    try {
      setErrorMessage("");
      setSuccessMessage("Uploading document...");

      const formData = new FormData();
      formData.append("document", file); 

      // Axios handles the content-type boundary automatically for FormData
      const response = await api.post(`/faculty/${facultyId}/upload-certificate`, formData);

      setFacultyList((previous) =>
        previous.map((item) =>
          item._id === facultyId ? response.data.faculty : item
        )
      );

      setSelectedFaculty(response.data.faculty);
      setSuccessMessage("Document uploaded successfully!");
      event.target.value = null;
    } catch (error) {
      setErrorMessage(error.response?.data?.message || "Failed to upload document.");
    }
  };

  // =========================================================
  // JSX
  // =========================================================

  return (
    <div className="faculty-directory">
      <section className="faculty-directory__heading">
        <div>
          <p className="faculty-directory__eyebrow">
            FACULTY MASTER DATA
          </p>
          <h1>Faculty Directory</h1>
          <p>
            Manage the official faculty master list,
            registration status and account access.
          </p>
        </div>
        <div className="faculty-directory__heading-actions">
          <button
            type="button"
            className="faculty-directory__button faculty-directory__button--secondary"
            onClick={handleOpenImportModal}
          >
            Import Faculty Excel
          </button>
          <button
            type="button"
            className="faculty-directory__button faculty-directory__button--primary"
            onClick={handleAddFaculty}
          >
            + Add Faculty
          </button>
        </div>
      </section>

      {/* STATS */}
      <section className="faculty-directory__stats">
        <article>
          <span>Total Faculty</span>
          <strong>{totalFaculty}</strong>
          <small>Official master records</small>
        </article>
        <article>
          <span>Active Accounts</span>
          <strong>{activeCount}</strong>
          <small>Faculty with active access</small>
        </article>
        <article>
          <span>Pending Registration</span>
          <strong>{pendingCount}</strong>
          <small>Awaiting approval</small>
        </article>
        <article>
          <span>Inactive Accounts</span>
          <strong>{inactiveCount}</strong>
          <small>Access currently disabled</small>
        </article>
      </section>

      {/* MESSAGE */}
      {errorMessage && (
        <div className="faculty-directory__message faculty-directory__message--error">
          {errorMessage}
        </div>
      )}
      {successMessage && (
        <div className="faculty-directory__message faculty-directory__message--success">
          {successMessage}
        </div>
      )}

      {/* INFO */}
      <section className="faculty-directory__info-banner">
        <div>
          <strong>Official Faculty Master List</strong>
          <p>
            Faculty records are now loaded directly
            from MongoDB. Registration approvals are
            managed separately.
          </p>
        </div>
        <span>MongoDB Connected</span>
      </section>

      {/* MAIN CARD */}
      <section className="faculty-directory__card">
        <div className="faculty-directory__toolbar">
          <div className="faculty-directory__search">
            <span>⌕</span>
            <input
              type="text"
              placeholder="Search faculty name, ID, email, department or designation"
              value={searchText}
              onChange={(event) =>
                setSearchText(event.target.value)
              }
            />
          </div>

          <div className="faculty-directory__filters">
            <select
              value={departmentFilter}
              onChange={(event) =>
                setDepartmentFilter(event.target.value)
              }
            >
              {departments.map((department) => (
                <option key={department} value={department}>
                  {department === "All" ? "All Departments" : department}
                </option>
              ))}
            </select>
            <select
              value={accountFilter}
              onChange={(event) =>
                setAccountFilter(event.target.value)
              }
            >
              <option value="All">All Account Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Suspended">Suspended</option>
            </select>
          </div>
        </div>

        <div className="faculty-directory__summary">
          <span>
            Showing{" "}
            <strong>{filteredFaculty.length}</strong>{" "}
            of{" "}
            <strong>{facultyList.length}</strong>{" "}
            faculty records
          </span>
        </div>

        {loading ? (
          <div className="faculty-directory__empty">
            Loading faculty records...
          </div>
        ) : (
          <div className="faculty-directory__table-wrapper">
            <table className="faculty-directory__table">
              <thead>
                <tr>
                  <th>Faculty</th>
                  <th>Faculty ID</th>
                  <th>Department</th>
                  <th>Designation</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Registration</th>
                  <th>Account Status</th>
                  <th>Source</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredFaculty.map((faculty) => {
                  const registrationStatus =
                    getRegistrationStatus(faculty);

                  const accountStatus =
                    getEffectiveAccountStatus(faculty);

                  return (
                    <tr key={faculty._id}>
                      <td>
                        <div className="faculty-directory__faculty">
                          <div className="faculty-directory__avatar">
                            {faculty.name?.charAt(0).toUpperCase() || "F"}
                          </div>
                          <div>
                            <strong>{faculty.name || "-"}</strong>
                            <span>{faculty.qualification || "Faculty Member"}</span>
                          </div>
                        </div>
                      </td>
                      <td>
                        <strong className="faculty-directory__faculty-id">
                          {faculty.facultyId || "-"}
                        </strong>
                      </td>
                      <td>
                        {normalizeDepartment(
                          faculty.department
                        )}
                      </td>
                      <td>{faculty.designation || "-"}</td>
                      <td>{faculty.email || "-"}</td>
                      <td>{faculty.phone || "-"}</td>
                      <td>
                        <span
                          className={`faculty-directory__status faculty-directory__status--${toClassSuffix(
                            registrationStatus
                          )}`}
                        >
                          {registrationStatus}
                        </span>
                      </td>
                      <td>
                        <span
                          className={`faculty-directory__status faculty-directory__status--${toClassSuffix(
                            accountStatus
                          )}`}
                        >
                          {accountStatus}
                        </span>
                      </td>
                      <td>
                        <span className="faculty-directory__source">
                          {faculty.source || "System"}
                        </span>
                      </td>
                      <td>
                        <div className="faculty-directory__actions">
                          <button
                            type="button"
                            className="faculty-directory__action faculty-directory__action--view"
                            onClick={() => setSelectedFaculty(faculty)}
                          >
                            View
                          </button>
                          {registrationStatus === "Approved" &&
                            accountStatus !== "Active" && (
                              <button
                                type="button"
                                className="faculty-directory__action faculty-directory__action--activate"
                                onClick={() => handleActivate(faculty)}
                              >
                                Activate
                              </button>
                            )}
                          {accountStatus === "Active" && (
                            <button
                              type="button"
                              className="faculty-directory__action faculty-directory__action--deactivate"
                              onClick={() => handleDeactivate(faculty)}
                            >
                              Deactivate
                            </button>
                          )}
                          <button
                            type="button"
                            className="faculty-directory__action faculty-directory__action--delete"
                            onClick={() => handleDelete(faculty)}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filteredFaculty.length === 0 && (
              <div className="faculty-directory__empty">
                <div>👥</div>
                <h3>No faculty records found</h3>
                <p>
                  Add a faculty manually or import
                  the official faculty Excel sheet.
                </p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* VIEW MODAL */}
      {selectedFaculty && (
        <div
          className="faculty-directory__modal-backdrop"
          onClick={() => {
              setLargeImageUrl("");
              setSelectedFaculty(null);
            }}
        >
          <div
            className="faculty-directory__modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="faculty-directory__modal-header">
              <div>
                <p>FACULTY MASTER RECORD</p>
                <h2>{selectedFaculty.name || "Faculty Member"}</h2>
              </div>
              <button type="button" onClick={() => {
              setLargeImageUrl("");
              setSelectedFaculty(null);
            }}>×</button>
            </div>

            <div className="faculty-directory__profile-summary">
              <div className="faculty-directory__profile-avatar">
                {selectedFaculty.name?.charAt(0).toUpperCase() || "F"}
              </div>
              <div>
                <strong>{selectedFaculty.name}</strong>
                <span>{selectedFaculty.designation || "Faculty Member"}</span>
                <small>
                  {normalizeDepartment(
                    selectedFaculty.department
                  )}{" "}
                  ·{" "}
                  {selectedFaculty.facultyId || "-"}
                </small>
              </div>
            </div>

            <div className="faculty-directory__detail-grid">
              <div>
                <span>Faculty ID</span>
                <strong>{selectedFaculty.facultyId || "-"}</strong>
              </div>
              <div>
                <span>Email</span>
                <strong>{selectedFaculty.email || "-"}</strong>
              </div>
              <div>
                <span>Phone</span>
                <strong>{selectedFaculty.phone || "-"}</strong>
              </div>
              <div>
                <span>Department</span>
                <strong>
                  {normalizeDepartment(
                    selectedFaculty.department
                  )}
                </strong>
              </div>
              <div>
                <span>Designation</span>
                <strong>{selectedFaculty.designation || "-"}</strong>
              </div>
              <div>
                <span>Qualification</span>
                <strong>{selectedFaculty.qualification || "-"}</strong>
              </div>
              <div>
                <span>Experience</span>
                <strong>{selectedFaculty.experience || "-"}</strong>
              </div>
              <div>
                <span>Date of Joining</span>
                <strong>
                  {selectedFaculty.dateOfJoining
                    ? new Date(selectedFaculty.dateOfJoining).toLocaleDateString("en-IN")
                    : "-"}
                </strong>
              </div>
              <div>
                <span>Registration Status</span>
                <strong>{getRegistrationStatus(selectedFaculty)}</strong>
              </div>
              <div>
                <span>Account Status</span>
                <strong>{getEffectiveAccountStatus(selectedFaculty)}</strong>
              </div>
            </div>

            {/* UPGRADED DOCUMENT UPLOAD SECTION (IMAGE PREVIEW / PDF LINK) */}
            <div style={{ marginTop: "24px", padding: "16px", backgroundColor: "#111827", borderRadius: "8px", border: "1px solid #1f2937" }}>
              <h4 style={{ color: "#9ca3af", fontSize: "0.85rem", fontWeight: "600", marginBottom: "12px", textTransform: "uppercase" }}>
                Proof Documents & Certificates
              </h4>

              {selectedFaculty.certificateName && (
                <p
                  style={{
                    color: "#9ca3af",
                    fontSize: "0.78rem",
                    margin: "0 0 12px",
                  }}
                >
                  {selectedFaculty.certificateName}
                </p>
              )}
              
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "16px" }}>
                <div>
                  {getFacultyCertificate(selectedFaculty) ? (
                    isPdfDocument(
                      getFacultyCertificate(selectedFaculty)
                    ) ? (
                      <a
                        href={getDocumentUrl(
                          getFacultyCertificate(selectedFaculty)
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          color: "#f97316",
                          textDecoration: "none",
                          fontWeight: "600",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "7px",
                          padding: "9px 12px",
                          borderRadius: "7px",
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                        }}
                      >
                        📄 Open PDF Document
                      </a>
                    ) : (
                      <div>
                        <img
                          src={getDocumentUrl(
                            getFacultyCertificate(selectedFaculty)
                          )}
                          alt={`${selectedFaculty.name || "Faculty"} uploaded document`}
                          style={{
                            display: "block",
                            maxWidth: "240px",
                            width: "100%",
                            maxHeight: "180px",
                            borderRadius: "10px",
                            border: "2px solid #374151",
                            objectFit: "contain",
                            backgroundColor: "#ffffff",
                            cursor: "zoom-in",
                          }}
                          title="Click to view large image"
                          onClick={() =>
                            setLargeImageUrl(
                              getDocumentUrl(
                                getFacultyCertificate(selectedFaculty)
                              )
                            )
                          }
                          onError={(event) => {
                            event.currentTarget.style.display =
                              "none";

                            const fallback =
                              event.currentTarget
                                .nextElementSibling;

                            if (fallback) {
                              fallback.style.display =
                                "inline-flex";
                            }
                          }}
                        />

                        <a
                          href={getDocumentUrl(
                            getFacultyCertificate(selectedFaculty)
                          )}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            display: "none",
                            marginTop: "8px",
                            color: "#f97316",
                            textDecoration: "none",
                            fontWeight: "600",
                            alignItems: "center",
                            gap: "7px",
                          }}
                        >
                          📎 Open Uploaded Document
                        </a>

                        <button
                          type="button"
                          onClick={() =>
                            setLargeImageUrl(
                              getDocumentUrl(
                                getFacultyCertificate(selectedFaculty)
                              )
                            )
                          }
                          style={{
                            marginTop: "10px",
                            padding: "8px 13px",
                            border: "1px solid #f97316",
                            borderRadius: "7px",
                            backgroundColor: "transparent",
                            color: "#f97316",
                            fontSize: "0.82rem",
                            fontWeight: "700",
                            cursor: "pointer",
                          }}
                        >
                          🔍 View Large Image
                        </button>
                      </div>
                    )
                  ) : (
                    <span
                      style={{
                        color: "#6b7280",
                        fontSize: "0.9rem",
                        display: "block",
                        marginTop: "8px",
                      }}
                    >
                      No document uploaded yet.
                    </span>
                  )}
                </div>

                {!getFacultyCertificate(selectedFaculty) && (
                  <div style={{ marginTop: "8px" }}>
                    <input
                      type="file"
                      id={`upload-doc-${selectedFaculty._id}`}
                      accept=".pdf,.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                      style={{ display: "none" }}
                      onChange={(e) =>
                        handleCertificateUpload(
                          e,
                          selectedFaculty._id
                        )
                      }
                    />

                    <label
                      htmlFor={`upload-doc-${selectedFaculty._id}`}
                      style={{
                        cursor: "pointer",
                        padding: "8px 16px",
                        backgroundColor: "#374151",
                        color: "#f3f4f6",
                        borderRadius: "6px",
                        fontSize: "0.85rem",
                        fontWeight: "500",
                        border: "1px solid #4b5563",
                        display: "inline-block",
                        transition:
                          "background-color 0.2s",
                      }}
                      onMouseOver={(e) =>
                        (e.currentTarget.style.backgroundColor =
                          "#4b5563")
                      }
                      onMouseOut={(e) =>
                        (e.currentTarget.style.backgroundColor =
                          "#374151")
                      }
                    >
                      Upload File
                    </label>
                  </div>
                )}
              </div>
            </div>

            <div className="faculty-directory__modal-footer" style={{ marginTop: "24px" }}>
              <button type="button" onClick={() => setSelectedFaculty(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LARGE IMAGE PREVIEW */}
      {largeImageUrl && (
        <div
          role="presentation"
          onClick={() =>
            setLargeImageUrl("")
          }
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 3000,
            backgroundColor:
              "rgba(0, 0, 0, 0.88)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "24px",
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="Large image preview"
            onClick={(event) =>
              event.stopPropagation()
            }
            style={{
              position: "relative",
              maxWidth: "95vw",
              maxHeight: "92vh",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "14px",
            }}
          >
            <img
              src={largeImageUrl}
              alt="Large uploaded document preview"
              style={{
                maxWidth: "95vw",
                maxHeight: "82vh",
                width: "auto",
                height: "auto",
                objectFit: "contain",
                borderRadius: "10px",
                backgroundColor: "#ffffff",
                boxShadow:
                  "0 22px 60px rgba(0,0,0,0.45)",
              }}
            />

            <button
              type="button"
              onClick={() =>
                setLargeImageUrl("")
              }
              style={{
                padding: "10px 22px",
                border: "none",
                borderRadius: "8px",
                backgroundColor: "#f97316",
                color: "#ffffff",
                fontWeight: "700",
                cursor: "pointer",
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* EXCEL IMPORT MODAL */}
      {isImportModalOpen && (
        <div
          className="faculty-directory__modal-backdrop"
          role="presentation"
          onClick={
            handleCloseImportModal
          }
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor:
              "rgba(15, 23, 42, 0.72)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
            zIndex: 1000,
            backdropFilter:
              "blur(5px)",
          }}
        >
          <div
            className="faculty-directory__modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="faculty-import-title"
            onClick={(event) =>
              event.stopPropagation()
            }
            style={{
              backgroundColor:
                "#ffffff",
              borderRadius: "16px",
              width: "100%",
              maxWidth: "600px",
              maxHeight: "90vh",
              overflowY: "auto",
              boxShadow:
                "0 24px 60px rgba(15, 23, 42, 0.25)",
            }}
          >
            <div
              style={{
                padding:
                  "22px 24px",
                borderBottom:
                  "1px solid #e5e7eb",
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems:
                  "flex-start",
                gap: "16px",
              }}
            >
              <div>
                <p
                  style={{
                    fontSize:
                      "0.72rem",
                    fontWeight: "800",
                    color: "#f97316",
                    letterSpacing:
                      "0.08em",
                    margin:
                      "0 0 5px",
                  }}
                >
                  BULK FACULTY IMPORT
                </p>

                <h2
                  id="faculty-import-title"
                  style={{
                    fontSize:
                      "1.3rem",
                    fontWeight: "700",
                    color: "#0f172a",
                    margin: 0,
                  }}
                >
                  Import Faculty Records
                </h2>

                <p
                  style={{
                    margin:
                      "7px 0 0",
                    color: "#64748b",
                    fontSize:
                      "0.86rem",
                    lineHeight: 1.5,
                  }}
                >
                  Upload your official
                  faculty master sheet
                  and review the import
                  result before closing.
                </p>
              </div>

              <button
                type="button"
                aria-label="Close import"
                disabled={
                  importLoading
                }
                onClick={
                  handleCloseImportModal
                }
                style={{
                  flexShrink: 0,
                  background:
                    "#f1f5f9",
                  border:
                    "1px solid #e2e8f0",
                  borderRadius: "9px",
                  width: "34px",
                  height: "34px",
                  color: "#475569",
                  cursor:
                    importLoading
                      ? "not-allowed"
                      : "pointer",
                  opacity:
                    importLoading
                      ? 0.55
                      : 1,
                  fontSize: "1rem",
                }}
              >
                ✕
              </button>
            </div>

            {!importSummary ? (
              <div
                style={{
                  padding: "24px",
                  display: "flex",
                  flexDirection:
                    "column",
                  gap: "18px",
                }}
              >
                <div
                  style={{
                    padding:
                      "14px 16px",
                    background:
                      "#f8fafc",
                    border:
                      "1px solid #e2e8f0",
                    borderRadius:
                      "10px",
                  }}
                >
                  <strong
                    style={{
                      display:
                        "block",
                      color: "#0f172a",
                      fontSize:
                        "0.86rem",
                      marginBottom:
                        "6px",
                    }}
                  >
                    Spreadsheet requirements
                  </strong>

                  <p
                    style={{
                      color: "#64748b",
                      fontSize:
                        "0.82rem",
                      margin: 0,
                      lineHeight: 1.55,
                    }}
                  >
                    Supported formats:
                    .xlsx, .xls and .csv.
                    Maximum file size:
                    5 MB. Your sheet
                    should contain the
                    faculty fields
                    expected by the
                    bulk-import backend.
                  </p>
                </div>

                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => {
                    if (
                      !importLoading
                    ) {
                      fileInputRef.current?.click();
                    }
                  }}
                  onKeyDown={(
                    event
                  ) => {
                    if (
                      (event.key ===
                        "Enter" ||
                        event.key ===
                          " ") &&
                      !importLoading
                    ) {
                      event.preventDefault();
                      fileInputRef.current?.click();
                    }
                  }}
                  onDragEnter={
                    handleDragEnter
                  }
                  onDragOver={
                    handleDragOver
                  }
                  onDragLeave={
                    handleDragLeave
                  }
                  onDrop={
                    handleDrop
                  }
                  style={{
                    border:
                      dragActive
                        ? "2px dashed #f97316"
                        : "2px dashed #cbd5e1",
                    borderRadius:
                      "12px",
                    padding:
                      "30px 24px",
                    textAlign:
                      "center",
                    cursor:
                      importLoading
                        ? "not-allowed"
                        : "pointer",
                    backgroundColor:
                      dragActive
                        ? "#fff7ed"
                        : "#f8fafc",
                    transition:
                      "all 0.2s ease",
                    outline: "none",
                  }}
                >
                  <input
                    ref={
                      fileInputRef
                    }
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    style={{
                      display: "none",
                    }}
                    onChange={
                      handleFileSelect
                    }
                  />

                  <div
                    style={{
                      fontSize:
                        "2.2rem",
                      marginBottom:
                        "10px",
                    }}
                  >
                    {excelFile
                      ? "📊"
                      : "📁"}
                  </div>

                  <strong
                    style={{
                      color: "#0f172a",
                      display:
                        "block",
                      fontSize:
                        "0.95rem",
                      fontWeight:
                        "650",
                      wordBreak:
                        "break-word",
                    }}
                  >
                    {excelFile
                      ? excelFile.name
                      : dragActive
                      ? "Drop the file here"
                      : "Choose a spreadsheet or drag it here"}
                  </strong>

                  <small
                    style={{
                      color: "#64748b",
                      marginTop:
                        "6px",
                      display:
                        "block",
                      fontSize:
                        "0.79rem",
                    }}
                  >
                    {excelFile
                      ? `${formatFileSize(
                          excelFile.size
                        )} · Ready to import`
                      : ".xlsx, .xls or .csv · Maximum 5 MB"}
                  </small>
                </div>

                {excelFile &&
                  !importLoading && (
                    <div
                      style={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "center",
                        gap: "12px",
                        padding:
                          "10px 12px",
                        background:
                          "#f8fafc",
                        border:
                          "1px solid #e2e8f0",
                        borderRadius:
                          "9px",
                      }}
                    >
                      <span
                        style={{
                          color:
                            "#475569",
                          fontSize:
                            "0.8rem",
                        }}
                      >
                        Selected file is
                        ready for
                        validation and
                        import.
                      </span>

                      <button
                        type="button"
                        onClick={
                          resetImportState
                        }
                        style={{
                          border:
                            "none",
                          background:
                            "transparent",
                          color:
                            "#dc2626",
                          cursor:
                            "pointer",
                          fontWeight:
                            "600",
                          fontSize:
                            "0.8rem",
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  )}

                {importLoading && (
                  <div
                    style={{
                      padding:
                        "14px 16px",
                      background:
                        "#f8fafc",
                      border:
                        "1px solid #e2e8f0",
                      borderRadius:
                        "10px",
                    }}
                  >
                    <div
                      style={{
                        display:
                          "flex",
                        justifyContent:
                          "space-between",
                        alignItems:
                          "center",
                        marginBottom:
                          "8px",
                        color:
                          "#475569",
                        fontSize:
                          "0.8rem",
                      }}
                    >
                      <span>
                        Uploading and
                        processing...
                      </span>

                      <strong>
                        {importProgress}%
                      </strong>
                    </div>

                    <div
                      style={{
                        width: "100%",
                        height: "7px",
                        borderRadius:
                          "999px",
                        background:
                          "#e2e8f0",
                        overflow:
                          "hidden",
                      }}
                    >
                      <div
                        style={{
                          width:
                            `${importProgress}%`,
                          height:
                            "100%",
                          background:
                            "#0f172a",
                          transition:
                            "width 0.2s ease",
                        }}
                      />
                    </div>
                  </div>
                )}

                {importError && (
                  <div
                    role="alert"
                    style={{
                      padding:
                        "12px 14px",
                      backgroundColor:
                        "#fef2f2",
                      border:
                        "1px solid #fecaca",
                      borderRadius:
                        "9px",
                      color: "#b91c1c",
                      fontSize:
                        "0.84rem",
                      lineHeight: 1.45,
                    }}
                  >
                    <strong>
                      Import failed:
                    </strong>{" "}
                    {importError}
                  </div>
                )}

                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "flex-end",
                    gap: "10px",
                    marginTop:
                      "2px",
                  }}
                >
                  <button
                    type="button"
                    disabled={
                      importLoading
                    }
                    onClick={
                      handleCloseImportModal
                    }
                    style={{
                      padding:
                        "9px 16px",
                      backgroundColor:
                        "#ffffff",
                      border:
                        "1px solid #cbd5e1",
                      color: "#334155",
                      borderRadius:
                        "8px",
                      fontWeight:
                        "600",
                      cursor:
                        importLoading
                          ? "not-allowed"
                          : "pointer",
                      opacity:
                        importLoading
                          ? 0.6
                          : 1,
                    }}
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    disabled={
                      !excelFile ||
                      importLoading
                    }
                    onClick={
                      handleUploadExcel
                    }
                    style={{
                      padding:
                        "9px 18px",
                      backgroundColor:
                        "#0f172a",
                      border: "none",
                      color: "#ffffff",
                      borderRadius:
                        "8px",
                      fontWeight:
                        "600",
                      cursor:
                        !excelFile ||
                        importLoading
                          ? "not-allowed"
                          : "pointer",
                      opacity:
                        !excelFile ||
                        importLoading
                          ? 0.58
                          : 1,
                    }}
                  >
                    {importLoading
                      ? `Importing ${importProgress}%`
                      : "Upload & Import"}
                  </button>
                </div>
              </div>
            ) : (
              <div
                style={{
                  padding: "24px",
                  display: "flex",
                  flexDirection:
                    "column",
                  gap: "20px",
                }}
              >
                <div
                  style={{
                    padding:
                      "14px 16px",
                    background:
                      importSummary.skippedCount >
                      0
                        ? "#fff7ed"
                        : "#ecfdf5",
                    border:
                      importSummary.skippedCount >
                      0
                        ? "1px solid #fed7aa"
                        : "1px solid #a7f3d0",
                    borderRadius:
                      "10px",
                  }}
                >
                  <strong
                    style={{
                      display:
                        "block",
                      color:
                        importSummary.skippedCount >
                        0
                          ? "#9a3412"
                          : "#047857",
                      marginBottom:
                        "4px",
                    }}
                  >
                    {importSummary.skippedCount >
                    0
                      ? "Import completed with skipped records"
                      : "Import completed successfully"}
                  </strong>

                  <span
                    style={{
                      color:
                        "#64748b",
                      fontSize:
                        "0.82rem",
                    }}
                  >
                    The Faculty
                    Directory has been
                    refreshed with the
                    latest MongoDB
                    records.
                  </span>
                </div>

                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(3, minmax(0, 1fr))",
                    gap: "10px",
                    textAlign:
                      "center",
                  }}
                >
                  <div
                    style={{
                      backgroundColor:
                        "#f8fafc",
                      padding:
                        "15px 10px",
                      borderRadius:
                        "10px",
                      border:
                        "1px solid #e2e8f0",
                    }}
                  >
                    <small
                      style={{
                        color:
                          "#64748b",
                        fontWeight:
                          "600",
                      }}
                    >
                      Total Rows
                    </small>

                    <strong
                      style={{
                        display:
                          "block",
                        fontSize:
                          "1.55rem",
                        color:
                          "#0f172a",
                        marginTop:
                          "4px",
                      }}
                    >
                      {
                        importSummary.totalRows
                      }
                    </strong>
                  </div>

                  <div
                    style={{
                      backgroundColor:
                        "#ecfdf5",
                      padding:
                        "15px 10px",
                      borderRadius:
                        "10px",
                      border:
                        "1px solid #a7f3d0",
                    }}
                  >
                    <small
                      style={{
                        color:
                          "#047857",
                        fontWeight:
                          "600",
                      }}
                    >
                      Imported
                    </small>

                    <strong
                      style={{
                        display:
                          "block",
                        fontSize:
                          "1.55rem",
                        color:
                          "#059669",
                        marginTop:
                          "4px",
                      }}
                    >
                      {
                        importSummary.importedCount
                      }
                    </strong>
                  </div>

                  <div
                    style={{
                      backgroundColor:
                        "#fef2f2",
                      padding:
                        "15px 10px",
                      borderRadius:
                        "10px",
                      border:
                        "1px solid #fecaca",
                    }}
                  >
                    <small
                      style={{
                        color:
                          "#b91c1c",
                        fontWeight:
                          "600",
                      }}
                    >
                      Skipped
                    </small>

                    <strong
                      style={{
                        display:
                          "block",
                        fontSize:
                          "1.55rem",
                        color:
                          "#dc2626",
                        marginTop:
                          "4px",
                      }}
                    >
                      {
                        importSummary.skippedCount
                      }
                    </strong>
                  </div>
                </div>

                {importSummary
                  .skippedDetails
                  ?.length > 0 && (
                  <div
                    style={{
                      maxHeight:
                        "190px",
                      overflowY:
                        "auto",
                      backgroundColor:
                        "#f8fafc",
                      padding:
                        "12px 14px",
                      borderRadius:
                        "10px",
                      border:
                        "1px solid #e2e8f0",
                    }}
                  >
                    <p
                      style={{
                        color:
                          "#334155",
                        fontSize:
                          "0.8rem",
                        fontWeight:
                          "700",
                        margin:
                          "0 0 8px",
                      }}
                    >
                      Skipped Records
                    </p>

                    {importSummary.skippedDetails.map(
                      (
                        item,
                        index
                      ) => (
                        <div
                          key={`${item.row}-${index}`}
                          style={{
                            fontSize:
                              "0.79rem",
                            color:
                              "#64748b",
                            borderBottom:
                              "1px solid #e2e8f0",
                            padding:
                              "7px 0",
                            lineHeight:
                              1.4,
                          }}
                        >
                          <strong
                            style={{
                              color:
                                "#ea580c",
                            }}
                          >
                            Row{" "}
                            {item.row ??
                              "-"}:
                          </strong>{" "}
                          {item.reason ||
                            "Record skipped"}
                          {item.email
                            ? ` (${item.email})`
                            : ""}
                        </div>
                      )
                    )}
                  </div>
                )}

                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "flex-end",
                    gap: "10px",
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      resetImportState();
                    }}
                    style={{
                      padding:
                        "9px 16px",
                      backgroundColor:
                        "#ffffff",
                      border:
                        "1px solid #cbd5e1",
                      color: "#334155",
                      borderRadius:
                        "8px",
                      fontWeight:
                        "600",
                      cursor:
                        "pointer",
                    }}
                  >
                    Import Another
                  </button>

                  <button
                    type="button"
                    onClick={
                      handleCloseImportModal
                    }
                    style={{
                      padding:
                        "9px 20px",
                      backgroundColor:
                        "#0f172a",
                      border: "none",
                      color: "#ffffff",
                      borderRadius:
                        "8px",
                      fontWeight:
                        "600",
                      cursor:
                        "pointer",
                    }}
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default FacultyDirectory;