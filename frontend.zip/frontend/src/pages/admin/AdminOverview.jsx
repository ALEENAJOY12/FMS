import {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
} from "chart.js";

import {
  Bar,
  Line,
} from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Tooltip,
  Legend
);

import "./AdminOverview.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "http://localhost:5000";

const API_BASE_URL =
  `${BACKEND_URL}/api`;

const FACULTY_API =
  `${API_BASE_URL}/faculty`;

const ACTIVITY_API =
  `${API_BASE_URL}/activities`;

const ACTIVITY_TYPES = [
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
];

const VALID_ACTIVITY_TYPES =
  new Set(ACTIVITY_TYPES);

const ACTIVITY_CONFIG = {
  FDP: {
    pointsPerActivity: 2,
    maxScore: 12,
    targetCount: 6,
  },
  NPTEL: {
    pointsPerActivity: 3,
    maxScore: 18,
    targetCount: 6,
  },
  "Research Paper": {
    pointsPerActivity: 5,
    maxScore: 15,
    targetCount: 3,
  },
  "Journal Publication": {
    pointsPerActivity: 7,
    maxScore: 14,
    targetCount: 2,
  },
  "Patent / IPR": {
    pointsPerActivity: 5,
    maxScore: 15,
    targetCount: 3,
  },
};

const CONTRIBUTION_WEIGHTS = {
  Students: 4,
  Department: 5,
  Both: 8,
};

const KNOWLEDGE_TRANSFER_MAX = 26;

const normalizeFacultyId = (
  value
) =>
  String(value || "")
    .trim()
    .toUpperCase();

const normalizeDepartment = (
  department
) => {
  const cleanValue =
    String(
      department || ""
    ).trim();

  const normalized =
    cleanValue
      .toUpperCase()
      .replace(
        /[^A-Z0-9]/g,
        ""
      );

  const cseAliases =
    new Set([
      "CSE",
      "COMPUTERSCIENCE",
      "COMPUTERSCIENCEENGINEERING",
      "COMPUTERSCIENCEANDENGINEERING",
      "DEPARTMENTOFCOMPUTERSCIENCE",
      "DEPARTMENTOFCOMPUTERSCIENCEENGINEERING",
      "DEPARTMENTOFCOMPUTERSCIENCEANDENGINEERING",
    ]);

  if (
    cseAliases.has(
      normalized
    )
  ) {
    return "CSE";
  }

  return cleanValue || "Other";
};

function AdminOverview() {
  const [facultyList, setFacultyList] =
    useState([]);

  const [activities, setActivities] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");


  const [
    isLeaderboardModalOpen,
    setIsLeaderboardModalOpen,
  ] = useState(false);

  const [
    leaderboardSearch,
    setLeaderboardSearch,
  ] = useState("");


  const [
    dashboardAiInsight,
    setDashboardAiInsight,
  ] = useState("");

  const [
    dashboardAiLoading,
    setDashboardAiLoading,
  ] = useState(false);

  const [
    dashboardAiError,
    setDashboardAiError,
  ] = useState("");

  // ========================================
  // LOAD DASHBOARD DATA
  // ========================================

  const loadDashboardData =
    async () => {
      try {
        setLoading(true);
        setErrorMessage("");

        // Get Admin JWT
        const token =
          localStorage.getItem(
            "token"
          );

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        // Load faculty + activities
        const [
          facultyResponse,
          activityResponse,
        ] = await Promise.all([
          fetch(
            FACULTY_API,
            {
              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          ),

          fetch(
            ACTIVITY_API,
            {
              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          ),
        ]);

        const facultyData =
          await facultyResponse.json();

        const activityData =
          await activityResponse.json();

        // Faculty API error
        if (!facultyResponse.ok) {
          throw new Error(
            facultyData.message ||
              "Unable to load faculty data."
          );
        }

        // Activity API error
        if (!activityResponse.ok) {
          throw new Error(
            activityData.message ||
              "Unable to load activity data."
          );
        }

        // Save API data
        setFacultyList(
          facultyData.faculty || []
        );

        setActivities(
          activityData.activities ||
            []
        );
      } catch (error) {
        console.error(
          "Admin dashboard load error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to connect to the server."
        );
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    loadDashboardData();
  }, []);

  // ========================================
  // FACULTY COUNTS
  // ========================================

  const approvedFaculty =
    facultyList.filter(
      (faculty) =>
        faculty.registrationStatus ===
        "Approved"
    );

  const pendingRegistrations =
    facultyList.filter(
      (faculty) =>
        faculty.registrationStatus ===
        "Pending"
    );

  const rejectedFaculty =
    facultyList.filter(
      (faculty) =>
        faculty.registrationStatus ===
        "Rejected"
    );

  const activeFaculty =
    facultyList.filter(
      (faculty) =>
        faculty.accountStatus ===
        "Active"
    );

  // ========================================
  // ACTIVITY COUNTS
  // ========================================

  /*
    Dashboard activity metrics use only
    the five official source activity
    types used across the FMS.
  */
  const validActivities =
    activities.filter(
      (activity) =>
        VALID_ACTIVITY_TYPES.has(
          activity.type
        )
    );

  const approvedActivities =
    validActivities.filter(
      (activity) =>
        activity.status ===
        "Approved"
    );

  const pendingActivities =
    validActivities.filter(
      (activity) =>
        (activity.status ||
          "Pending") ===
        "Pending"
    );

  const rejectedActivities =
    validActivities.filter(
      (activity) =>
        activity.status ===
        "Rejected"
    );

  const approvedContributions =
    validActivities.filter(
      (activity) =>
        activity.status ===
          "Approved" &&
        activity.contributionDone ===
          "Yes" &&
        activity.contributionStatus ===
          "Approved"
    );

  const pendingContributions =
    validActivities.filter(
      (activity) =>
        activity.contributionDone ===
          "Yes" &&
        (activity.contributionStatus ||
          "Pending") ===
          "Pending"
    );

  const rejectedContributions =
    validActivities.filter(
      (activity) =>
        activity.status ===
          "Approved" &&
        activity.contributionDone ===
          "Yes" &&
        activity.contributionStatus ===
          "Rejected"
    );


  const totalContributionReviews =
    approvedContributions.length +
    pendingContributions.length +
    rejectedContributions.length;

  const getContributionPercent = (
    count
  ) =>
    totalContributionReviews > 0
      ? Math.round(
          (count /
            totalContributionReviews) *
            100
        )
      : 0;

  const approvedContributionPercent =
    getContributionPercent(
      approvedContributions.length
    );

  const pendingContributionPercent =
    getContributionPercent(
      pendingContributions.length
    );

  const rejectedContributionPercent =
    getContributionPercent(
      rejectedContributions.length
    );

  // ========================================
  // ACTIVITY DISTRIBUTION
  // ========================================

  const activitySummary =
    ACTIVITY_TYPES.map(
      (type) => ({
      type,

        count:
          validActivities.filter(
            (activity) =>
              activity.type ===
              type
          ).length,
      })
    );


  // ========================================
  // DEPARTMENT SUMMARY
  // ========================================

  const departmentData =
    useMemo(() => {
      const sourceFaculty =
        approvedFaculty.length > 0
          ? approvedFaculty
          : facultyList;

      const summary =
        sourceFaculty.reduce(
          (
            result,
            faculty
          ) => {
            const department =
              normalizeDepartment(
                faculty.department
              );

            result[department] =
              (result[
                department
              ] || 0) + 1;

            return result;
          },
          {}
        );

      return Object.entries(
        summary
      ).map(
        ([
          department,
          count,
        ]) => ({
          department,
          count,
        })
      );
    }, [facultyList]);

  const maximumDepartmentCount =
    Math.max(
      1,

      ...departmentData.map(
        (item) => item.count
      )
    );

  // ========================================
  // MONTHLY SUBMISSION TREND
  // Last 6 calendar months.
  //
  // Activity submissions are counted from
  // submissionDate / createdAt / updatedAt.
  // Contribution submissions are counted
  // when contributionDone === "Yes" for the
  // same source submission month.
  // ========================================

  const monthlySubmissionTrend =
    useMemo(() => {
      const now = new Date();

      const months =
        Array.from(
          { length: 6 },
          (_, index) => {
            const date =
              new Date(
                now.getFullYear(),
                now.getMonth() -
                  (5 - index),
                1
              );

            return {
              key: `${date.getFullYear()}-${String(
                date.getMonth() + 1
              ).padStart(2, "0")}`,

              label:
                date.toLocaleString(
                  "en-US",
                  {
                    month: "short",
                  }
                ),

              year:
                date.getFullYear(),

              activities: 0,

              contributions: 0,
            };
          }
        );

      const monthMap =
        new Map(
          months.map(
            (month) => [
              month.key,
              month,
            ]
          )
        );

      validActivities.forEach(
        (activity) => {
          const rawDate =
            activity.submissionDate ||
            activity.createdAt ||
            activity.updatedAt;

          if (!rawDate) {
            return;
          }

          const date =
            new Date(rawDate);

          if (
            Number.isNaN(
              date.getTime()
            )
          ) {
            return;
          }

          const key =
            `${date.getFullYear()}-${String(
              date.getMonth() + 1
            ).padStart(2, "0")}`;

          const month =
            monthMap.get(key);

          if (!month) {
            return;
          }

          month.activities += 1;

          if (
            activity.contributionDone ===
            "Yes"
          ) {
            month.contributions += 1;
          }
        }
      );

      return months.map(
        (month) => ({
          ...month,

          total:
            month.activities +
            month.contributions,
        })
      );
    }, [validActivities]);


  const totalRecentSubmissions =
    monthlySubmissionTrend.reduce(
      (total, month) =>
        total +
        month.activities +
        month.contributions,
      0
    );


  // ========================================
  // CHART.JS CONFIGURATION
  // ========================================

  const activityChartData = {
    labels:
      activitySummary.map(
        (item) => {
          if (
            item.type ===
            "Research Paper"
          ) {
            return "Research";
          }

          if (
            item.type ===
            "Journal Publication"
          ) {
            return "Journal";
          }

          return item.type;
        }
      ),

    datasets: [
      {
        label: "Submissions",

        data:
          activitySummary.map(
            (item) =>
              item.count
          ),

        backgroundColor:
          "rgba(239, 101, 27, 0.78)",

        borderColor:
          "#ef651b",

        borderWidth: 1,

        borderRadius: 8,

        borderSkipped: false,

        maxBarThickness: 52,
      },
    ],
  };

  const activityChartOptions = {
    responsive: true,

    maintainAspectRatio: false,

    plugins: {
      legend: {
        display: false,
      },

      tooltip: {
        callbacks: {
          label: (
            context
          ) =>
            `Submissions: ${context.parsed.y}`,
        },
      },
    },

    scales: {
      x: {
        grid: {
          display: false,
        },

        ticks: {
          color: "#5f6f7f",

          font: {
            size: 11,
            weight: "600",
          },
        },
      },

      y: {
        beginAtZero: true,

        ticks: {
          precision: 0,

          color: "#7c8996",
        },

        grid: {
          color:
            "rgba(11, 44, 78, 0.08)",
        },
      },
    },
  };

  const monthlyTrendChartData = {
    labels:
      monthlySubmissionTrend.map(
        (month) =>
          month.label
      ),

    datasets: [
      {
        label: "Activities",

        data:
          monthlySubmissionTrend.map(
            (month) =>
              month.activities
          ),

        borderColor:
          "#0b2c4e",

        backgroundColor:
          "rgba(11, 44, 78, 0.10)",

        pointBackgroundColor:
          "#0b2c4e",

        pointBorderColor:
          "#ffffff",

        pointBorderWidth: 2,

        pointRadius: 4,

        pointHoverRadius: 6,

        tension: 0.35,

        fill: false,
      },

      {
        label: "Contributions",

        data:
          monthlySubmissionTrend.map(
            (month) =>
              month.contributions
          ),

        borderColor:
          "#ef651b",

        backgroundColor:
          "rgba(239, 101, 27, 0.10)",

        pointBackgroundColor:
          "#ef651b",

        pointBorderColor:
          "#ffffff",

        pointBorderWidth: 2,

        pointRadius: 4,

        pointHoverRadius: 6,

        tension: 0.35,

        fill: false,
      },
    ],
  };

  const monthlyTrendChartOptions = {
    responsive: true,

    maintainAspectRatio: false,

    interaction: {
      mode: "index",
      intersect: false,
    },

    plugins: {
      legend: {
        position: "bottom",

        labels: {
          usePointStyle: true,

          boxWidth: 8,

          color: "#5f6f7f",

          padding: 18,

          font: {
            size: 11,
            weight: "600",
          },
        },
      },
    },

    scales: {
      x: {
        grid: {
          display: false,
        },

        ticks: {
          color: "#5f6f7f",

          font: {
            size: 11,
            weight: "600",
          },
        },
      },

      y: {
        beginAtZero: true,

        ticks: {
          precision: 0,

          color: "#7c8996",
        },

        grid: {
          color:
            "rgba(11, 44, 78, 0.08)",
        },
      },
    },
  };

  // ========================================
  // FACULTY LEADERBOARD
  //
  // Ranking rules:
  // 1. Approved-only impact score
  // 2. Approved contributions
  // 3. Approved activities
  // 4. Total submissions
  //
  // Final score uses category caps:
  // FDP 12 + NPTEL 18 + Research 15 + Journal 14
  // + Patent/IPR 15 + Knowledge Transfer 26 = 100.
  // ========================================

  const facultyLeaderboard =
    useMemo(() => {
      return facultyList
        .filter(
          (faculty) =>
            faculty.registrationStatus ===
              "Approved" ||
            faculty.accountStatus ===
              "Active"
        )
        .map((faculty) => {
          const facultyId =
            normalizeFacultyId(
              faculty.facultyId
            );

          const facultyActivities =
            validActivities.filter(
              (activity) =>
                normalizeFacultyId(
                  activity.facultyId
                ) === facultyId
            );

          const approvedFacultyActivities =
            facultyActivities.filter(
              (activity) =>
                activity.status ===
                "Approved"
            );

          const approvedFacultyContributions =
            approvedFacultyActivities.filter(
              (activity) =>
                activity.contributionDone ===
                  "Yes" &&
                activity.contributionStatus ===
                  "Approved"
            );

          const contributionSubmissions =
            facultyActivities.filter(
              (activity) =>
                activity.contributionDone ===
                "Yes"
            ).length;

          // Balanced FIS: each activity category has its own maximum.
          const activityBreakdown =
            Object.entries(ACTIVITY_CONFIG).map(
              ([type, config]) => {
                const approvedCount =
                  approvedFacultyActivities.filter(
                    (activity) =>
                      activity.type === type
                  ).length;

                const rawCategoryPoints =
                  approvedCount *
                  config.pointsPerActivity;

                const cappedCategoryPoints =
                  Math.min(
                    rawCategoryPoints,
                    config.maxScore
                  );

                return {
                  type,
                  approvedCount,
                  rawCategoryPoints,
                  cappedCategoryPoints,
                };
              }
            );

          const rawActivityPoints =
            activityBreakdown.reduce(
              (total, category) =>
                total +
                category.rawCategoryPoints,
              0
            );

          const activityPoints =
            activityBreakdown.reduce(
              (total, category) =>
                total +
                category.cappedCategoryPoints,
              0
            );

          const rawContributionPoints =
            approvedFacultyContributions.reduce(
              (total, activity) =>
                total +
                (CONTRIBUTION_WEIGHTS[
                  activity.contributionFor
                ] || 0),
              0
            );

          const contributionPoints =
            Math.min(
              rawContributionPoints,
              KNOWLEDGE_TRANSFER_MAX
            );

          // Raw score is kept for transparency.
          const rawScore =
            rawActivityPoints +
            rawContributionPoints;

          const impactScore =
            activityPoints +
            contributionPoints;

          return {
            _id:
              faculty._id ||
              faculty.facultyId,

            facultyId:
              faculty.facultyId ||
              "-",

            name:
              faculty.name ||
              "Faculty Member",

            department:
              normalizeDepartment(
                faculty.department
              ),

            designation:
              faculty.designation ||
              "-",

            totalActivitySubmissions:
              facultyActivities.length,

            totalContributionSubmissions:
              contributionSubmissions,

            totalSubmissions:
              facultyActivities.length +
              contributionSubmissions,

            approvedActivities:
              approvedFacultyActivities.length,

            approvedContributions:
              approvedFacultyContributions.length,

            activityPoints,

            contributionPoints,

            rawScore,

            impactScore,
          };
        })
        .sort(
          (first, second) =>
            second.impactScore -
              first.impactScore ||
            second.approvedContributions -
              first.approvedContributions ||
            second.approvedActivities -
              first.approvedActivities ||
            second.totalSubmissions -
              first.totalSubmissions ||
            first.name.localeCompare(
              second.name
            )
        );
    }, [
      facultyList,
      validActivities,
    ]);

  const displayedLeaderboard =
    facultyLeaderboard.slice(
      0,
      5
    );

  const filteredLeaderboard =
    useMemo(() => {
      const value =
        leaderboardSearch
          .trim()
          .toLowerCase();

      if (!value) {
        return facultyLeaderboard;
      }

      return facultyLeaderboard.filter(
        (faculty) =>
          String(
            faculty.name || ""
          )
            .toLowerCase()
            .includes(value) ||
          String(
            faculty.facultyId || ""
          )
            .toLowerCase()
            .includes(value) ||
          String(
            faculty.department || ""
          )
            .toLowerCase()
            .includes(value) ||
          String(
            faculty.designation || ""
          )
            .toLowerCase()
            .includes(value)
      );
    }, [
      facultyLeaderboard,
      leaderboardSearch,
    ]);

  const dashboardAiContext =
    useMemo(() => {
      const strongestActivity =
        activitySummary
          .slice()
          .sort(
            (first, second) =>
              second.count -
              first.count
          )[0] || null;

      const largestDepartment =
        departmentData
          .slice()
          .sort(
            (first, second) =>
              second.count -
              first.count
          )[0] || null;

      const monthlyData =
        monthlySubmissionTrend.map(
          (month) => ({
            month:
              month.label,

            activities:
              month.activities,

            contributions:
              month.contributions,

            total:
              month.total,
          })
        );

      return {
        faculty: {
          total:
            facultyList.length,

          approved:
            approvedFaculty.length,

          pendingRegistrations:
            pendingRegistrations.length,

          rejected:
            rejectedFaculty.length,

          activeAccounts:
            activeFaculty.length,
        },

        activities: {
          total:
            validActivities.length,

          approved:
            approvedActivities.length,

          pending:
            pendingActivities.length,

          rejected:
            rejectedActivities.length,

          byType:
            activitySummary,

          strongestCategory:
            strongestActivity,
        },

        contributions: {
          approved:
            approvedContributions.length,

          pending:
            pendingContributions.length,

          rejected:
            rejectedContributions.length,

          totalReviews:
            totalContributionReviews,

          approvedPercent:
            approvedContributionPercent,

          pendingPercent:
            pendingContributionPercent,

          rejectedPercent:
            rejectedContributionPercent,
        },

        departments: {
          distribution:
            departmentData,

          largest:
            largestDepartment,
        },

        monthlySubmissions:
          monthlyData,

        sixMonthTotal:
          totalRecentSubmissions,

        ranking: {
          rankedFaculty:
            facultyLeaderboard.length,

          highestImpactScore:
            facultyLeaderboard[0]
              ?.impactScore || 0,

          topFiveScores:
            facultyLeaderboard
              .slice(0, 5)
              .map(
                (faculty) =>
                  faculty.impactScore
              ),
        },
      };
    }, [
      facultyList,
      approvedFaculty.length,
      pendingRegistrations.length,
      rejectedFaculty.length,
      activeFaculty.length,
      validActivities.length,
      approvedActivities.length,
      pendingActivities.length,
      rejectedActivities.length,
      activitySummary,
      approvedContributions.length,
      pendingContributions.length,
      rejectedContributions.length,
      totalContributionReviews,
      approvedContributionPercent,
      pendingContributionPercent,
      rejectedContributionPercent,
      departmentData,
      monthlySubmissionTrend,
      totalRecentSubmissions,
      facultyLeaderboard,
    ]);

  const handleGenerateDashboardInsight =
    async () => {
      try {
        setDashboardAiLoading(
          true
        );

        setDashboardAiError(
          ""
        );

        const token =
          localStorage.getItem(
            "token"
          );

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_BASE_URL}/ai/dashboard-insight`,
            {
              method:
                "POST",

              headers: {
                "Content-Type":
                  "application/json",

                Authorization:
                  `Bearer ${token}`,
              },

              body:
                JSON.stringify({
                  context:
                    dashboardAiContext,
                }),
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to generate AI dashboard insight."
          );
        }

        setDashboardAiInsight(
          data.insight || ""
        );
      } catch (error) {
        setDashboardAiError(
          error.message ||
            "Unable to generate AI dashboard insight."
        );
      } finally {
        setDashboardAiLoading(
          false
        );
      }
    };

  const getRankLabel = (
    index
  ) => {
    if (index === 0) {
      return "🥇";
    }

    if (index === 1) {
      return "🥈";
    }

    if (index === 2) {
      return "🥉";
    }

    return `#${index + 1}`;
  };

  useEffect(() => {
    if (
      !isLeaderboardModalOpen
    ) {
      return undefined;
    }

    const handleKeyDown = (
      event
    ) => {
      if (
        event.key ===
        "Escape"
      ) {
        setIsLeaderboardModalOpen(
          false
        );
      }
    };

    const previousOverflow =
      document.body.style.overflow;

    document.body.style.overflow =
      "hidden";

    window.addEventListener(
      "keydown",
      handleKeyDown
    );

    return () => {
      document.body.style.overflow =
        previousOverflow;

      window.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, [
    isLeaderboardModalOpen,
  ]);

  // ========================================
  // RECENT REGISTERED FACULTY
  // ========================================

  const recentRegistrations =
    [...facultyList]
      .filter(
        (faculty) =>
          faculty.isRegistered ===
            true ||
          faculty.registrationStatus ===
            "Pending" ||
          faculty.registrationStatus ===
            "Approved" ||
          faculty.registrationStatus ===
            "Rejected"
      )
      .sort(
        (first, second) =>
          new Date(
            second.updatedAt ||
              second.createdAt ||
              0
          ) -
          new Date(
            first.updatedAt ||
              first.createdAt ||
              0
          )
      )
      .slice(0, 5);

  // ========================================
  // JSX
  // ========================================

  return (
    <div className="admin-overview">
      {/* HEADER */}

      <section className="admin-overview__heading">
        <div>
          <p className="admin-overview__eyebrow">
            ADMIN CONTROL CENTRE
          </p>

          <h1>
            Faculty Management Dashboard
          </h1>

          <p>
            Monitor faculty accounts,
            the five academic activity
            categories, contribution
            reviews and institutional
            performance.
          </p>
        </div>

        <div className="admin-overview__year">
          <span>
            Academic Year
          </span>

          <strong>
            2026–2027
          </strong>
        </div>
      </section>

      {/* ERROR */}

      {errorMessage && (
        <div className="admin-overview__message admin-overview__message--error">
          {errorMessage}
        </div>
      )}

      {/* LOADING */}

      {loading ? (
        <div className="overview-empty">
          Loading dashboard data...
        </div>
      ) : (
        <>
          {/* STATS */}

          <section className="admin-overview__stats">
            {/* TOTAL FACULTY */}
            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                👥
              </div>

              <div>
                <span>
                  Total Faculty
                </span>

                <strong>
                  {facultyList.length}
                </strong>

                <small>
                  Faculty records in the system
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                ⏳
              </div>

              <div>
                <span>
                  Pending Registrations
                </span>

                <strong>
                  {
                    pendingRegistrations.length
                  }
                </strong>

                <small>
                  Waiting for
                  administrator approval
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                ✓
              </div>

              <div>
                <span>
                  Approved Activities
                </span>

                <strong>
                  {
                    approvedActivities.length
                  }
                </strong>

                <small>
                  {
                    validActivities.length
                  }{" "}
                  valid submissions
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                📑
              </div>

              <div>
                <span>
                  Pending Reviews
                </span>

                <strong>
                  {
                    pendingActivities.length
                  }
                </strong>

                <small>
                  {
                    rejectedActivities.length
                  }{" "}
                  activities rejected
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                ✓
              </div>

              <div>
                <span>
                  Approved Contributions
                </span>

                <strong>
                  {
                    approvedContributions.length
                  }
                </strong>

                <small>
                  Impact-point eligible
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                ⏳
              </div>

              <div>
                <span>
                  Pending Contributions
                </span>

                <strong>
                  {
                    pendingContributions.length
                  }
                </strong>

                <small>
                  Waiting for review
                </small>
              </div>
            </article>

            <article className="overview-stat-card">
              <div className="overview-stat-card__icon">
                ✕
              </div>

              <div>
                <span>
                  Rejected Contributions
                </span>

                <strong>
                  {
                    rejectedContributions.length
                  }
                </strong>

                <small>
                  Faculty can correct
                  and resubmit
                </small>
              </div>
            </article>
          </section>

          {/* AI EXECUTIVE INSIGHT */}

          <section className="overview-ai-insight">
            <div className="overview-ai-insight__accent">
              ✦
            </div>

            <div className="overview-ai-insight__content">
              <div className="overview-ai-insight__heading">
                <div>
                  <span>
                    AI EXECUTIVE INSIGHT
                  </span>

                  <h2>
                    Dashboard Intelligence
                  </h2>

                  <p>
                    Generate a concise AI analysis
                    from the current dashboard
                    statistics.
                  </p>
                </div>

                <button
                  type="button"
                  className="overview-ai-insight__button"
                  onClick={
                    handleGenerateDashboardInsight
                  }
                  disabled={
                    dashboardAiLoading ||
                    validActivities.length ===
                      0
                  }
                >
                  <span aria-hidden="true">
                    ✦
                  </span>

                  {dashboardAiLoading
                    ? "Analyzing..."
                    : dashboardAiInsight
                    ? "Refresh Insight"
                    : "Generate Insight"}
                </button>
              </div>

              {dashboardAiLoading ? (
                <div className="overview-ai-insight__loading">
                  <i />
                  Reviewing faculty,
                  activity, contribution
                  and monthly submission
                  statistics...
                </div>
              ) : dashboardAiError ? (
                <div className="overview-ai-insight__error">
                  {
                    dashboardAiError
                  }
                </div>
              ) : dashboardAiInsight ? (
                <div className="overview-ai-insight__result">
                  {
                    dashboardAiInsight
                  }
                </div>
              ) : (
                <div className="overview-ai-insight__empty">
                  <div>
                    <strong>
                      Smart administrative summary
                    </strong>

                    <span>
                      The AI will identify notable
                      activity patterns, review
                      workload and contribution
                      status using aggregate data
                      only.
                    </span>
                  </div>

                  <div className="overview-ai-insight__chips">
                    <span>
                      Activity mix
                    </span>

                    <span>
                      Review workload
                    </span>

                    <span>
                      6-month trend
                    </span>

                    <span>
                      Contribution status
                    </span>
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* FACULTY PERFORMANCE CHART */}

          <section className="overview-leaderboard">
            <div className="overview-leaderboard__header">
              <div>
                <span className="overview-leaderboard__eyebrow">
                  Faculty Performance
                </span>

                <h2>
                  Faculty Performance Ranking
                </h2>

                <p>
                  Top 5 faculty based on approved
                  academic activity and contribution
                  points. Open the full ranking to
                  review every faculty member.
                </p>
              </div>

              <div className="overview-leaderboard__formula">
                <strong>
                  Impact Score
                </strong>

                <span>
                  Activity + Contribution
                </span>

                <small>
                  Maximum 100 points
                </small>
              </div>
            </div>

            {facultyLeaderboard.length ===
            0 ? (
              <div className="overview-empty">
                No faculty performance data
                available yet.
              </div>
            ) : (
              <div className="overview-leaderboard__chart">
                {displayedLeaderboard.map(
                  (
                    faculty,
                    index
                  ) => (
                    <div
                      className={`overview-leaderboard__chart-row ${
                        index < 3
                          ? "overview-leaderboard__chart-row--top"
                          : ""
                      }`}
                      key={faculty._id}
                    >
                      <div className="overview-leaderboard__rank">
                        {
                          getRankLabel(
                            index
                          )
                        }
                      </div>

                      <div className="overview-leaderboard__faculty">
                        <div className="overview-leaderboard__avatar">
                          {faculty.name
                            .charAt(0)
                            .toUpperCase()}
                        </div>

                        <div className="overview-leaderboard__faculty-text">
                          <strong>
                            {
                              faculty.name
                            }
                          </strong>

                          <span>
                            {
                              faculty.facultyId
                            }
                            {" · "}
                            {
                              faculty.department
                            }
                          </span>
                        </div>
                      </div>

                      <div className="overview-leaderboard__bar-area">
                        <div className="overview-leaderboard__bar-meta">
                          <span>
                            {
                              faculty.approvedActivities
                            }{" "}
                            approved activities
                          </span>

                          <span>
                            {
                              faculty.approvedContributions
                            }{" "}
                            approved contributions
                          </span>
                        </div>

                        <div className="overview-leaderboard__bar-track">
                          <div
                            className="overview-leaderboard__bar-fill"
                            style={{
                              width:
                                faculty.impactScore >
                                0
                                  ? `${faculty.impactScore}%`
                                  : "0%",
                            }}
                          />
                        </div>

                        <div className="overview-leaderboard__bar-detail">
                          <span>
                            Activity points:{" "}
                            <strong>
                              {
                                faculty.activityPoints
                              }
                            </strong>
                          </span>

                          <span>
                            Contribution points:{" "}
                            <strong>
                              {
                                faculty.contributionPoints
                              }
                            </strong>
                          </span>

                          <span>
                            Total submissions:{" "}
                            <strong>
                              {
                                faculty.totalSubmissions
                              }
                            </strong>
                          </span>
                        </div>
                      </div>

                      <div className="overview-leaderboard__score">
                        <strong>
                          {
                            faculty.impactScore
                          }
                        </strong>

                        <span>
                          /100
                        </span>
                      </div>
                    </div>
                  )
                )}
              </div>
            )}

            <div className="overview-leaderboard__footer">
              <div>
                <strong>
                  Top 5 of{" "}
                  {
                    facultyLeaderboard.length
                  }{" "}
                  ranked faculty
                </strong>

                <span>
                  Ranking is calculated from
                  approved activity and contribution
                  points only.
                </span>
              </div>

              <button
                type="button"
                className="overview-leaderboard__view-more"
                onClick={() => {
                  setLeaderboardSearch(
                    ""
                  );

                  setIsLeaderboardModalOpen(
                    true
                  );
                }}
                disabled={
                  facultyLeaderboard.length ===
                  0
                }
              >
                View All Rankings
                <span aria-hidden="true">
                  →
                </span>
              </button>
            </div>

            <div className="overview-leaderboard__legend">
              <span>FDP +5</span>
              <span>NPTEL +8</span>
              <span>Research +15</span>
              <span>Journal +18</span>
              <span>Patent / IPR +20</span>
              <span>Students +4</span>
              <span>Department +5</span>
              <span>Both +8</span>
            </div>
          </section>

          {/* GRID 1 */}

          <section className="admin-overview__grid">
            {/* ACTIVITY DISTRIBUTION */}

            <article className="overview-panel">
              <div className="overview-panel__header">
                <div>
                  <h2>
                    Activity Distribution
                  </h2>

                  <p>
                    Valid faculty submissions
                    across the five official
                    academic activity categories.
                  </p>
                </div>
              </div>

              <div className="overview-chartjs-container overview-chartjs-container--activity">
                <Bar
                  data={
                    activityChartData
                  }
                  options={
                    activityChartOptions
                  }
                />
              </div>
            </article>

            {/* REGISTRATION STATUS */}

            <article className="overview-panel">
              <div className="overview-panel__header">
                <div>
                  <h2>
                    Registration Status
                  </h2>

                  <p>
                    Current distribution
                    of faculty account
                    registration status.
                  </p>
                </div>
              </div>

              <div className="overview-status-list">
                <div>
                  <span className="status-dot status-dot--approved" />

                  <p>
                    Approved
                  </p>

                  <strong>
                    {
                      approvedFaculty.length
                    }
                  </strong>
                </div>

                <div>
                  <span className="status-dot status-dot--pending" />

                  <p>
                    Pending
                  </p>

                  <strong>
                    {
                      pendingRegistrations.length
                    }
                  </strong>
                </div>

                <div>
                  <span className="status-dot status-dot--rejected" />

                  <p>
                    Rejected
                  </p>

                  <strong>
                    {
                      rejectedFaculty.length
                    }
                  </strong>
                </div>
              </div>
            </article>

            {/* CONTRIBUTION WORKFLOW */}

            <article className="overview-panel overview-contribution-panel">
              <div className="overview-panel__header overview-contribution-panel__header">
                <div>
                  <span className="overview-contribution-panel__eyebrow">
                    Contribution Workflow
                  </span>

                  <h2>
                    Contribution Review Status
                  </h2>

                  <p>
                    Approved contributions become
                    impact-point eligible only after
                    the source activity is approved.
                  </p>
                </div>

                <div className="overview-contribution-panel__total">
                  <span>
                    Total Reviews
                  </span>

                  <strong>
                    {
                      totalContributionReviews
                    }
                  </strong>
                </div>
              </div>

              <div className="overview-contribution-cards">
                <div className="overview-contribution-card overview-contribution-card--approved">
                  <div className="overview-contribution-card__top">
                    <span className="overview-contribution-card__icon">
                      ✓
                    </span>

                    <span>
                      Approved
                    </span>
                  </div>

                  <strong>
                    {
                      approvedContributions.length
                    }
                  </strong>

                  <small>
                    {
                      approvedContributionPercent
                    }
                    % of reviewed contributions
                  </small>

                  <div className="overview-contribution-card__progress">
                    <div
                      style={{
                        width: `${approvedContributionPercent}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="overview-contribution-card overview-contribution-card--pending">
                  <div className="overview-contribution-card__top">
                    <span className="overview-contribution-card__icon">
                      ⏳
                    </span>

                    <span>
                      Pending
                    </span>
                  </div>

                  <strong>
                    {
                      pendingContributions.length
                    }
                  </strong>

                  <small>
                    {
                      pendingContributionPercent
                    }
                    % awaiting admin review
                  </small>

                  <div className="overview-contribution-card__progress">
                    <div
                      style={{
                        width: `${pendingContributionPercent}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="overview-contribution-card overview-contribution-card--rejected">
                  <div className="overview-contribution-card__top">
                    <span className="overview-contribution-card__icon">
                      ✕
                    </span>

                    <span>
                      Rejected
                    </span>
                  </div>

                  <strong>
                    {
                      rejectedContributions.length
                    }
                  </strong>

                  <small>
                    {
                      rejectedContributionPercent
                    }
                    % require correction
                  </small>

                  <div className="overview-contribution-card__progress">
                    <div
                      style={{
                        width: `${rejectedContributionPercent}%`,
                      }}
                    />
                  </div>
                </div>
              </div>

              <div className="overview-contribution-summary">
                <div>
                  <span>
                    Impact Eligible
                  </span>

                  <strong>
                    {
                      approvedContributions.length
                    }
                  </strong>

                  <small>
                    Approved contributions
                  </small>
                </div>

                <div>
                  <span>
                    Review Queue
                  </span>

                  <strong>
                    {
                      pendingContributions.length
                    }
                  </strong>

                  <small>
                    Awaiting decision
                  </small>
                </div>

                <div>
                  <span>
                    Needs Resubmission
                  </span>

                  <strong>
                    {
                      rejectedContributions.length
                    }
                  </strong>

                  <small>
                    Faculty action required
                  </small>
                </div>
              </div>
            </article>

            {/* MONTHLY SUBMISSION TREND */}

            <article className="overview-panel overview-monthly-trend">
              <div className="overview-panel__header overview-monthly-trend__header">
                <div>
                  <span className="overview-monthly-trend__eyebrow">
                    Submission Analytics
                  </span>

                  <h2>
                    Monthly Submission Trend
                  </h2>

                  <p>
                    Activity and contribution
                    submissions during the last
                    six months.
                  </p>
                </div>

                <div className="overview-monthly-trend__total">
                  <span>
                    6-Month Total
                  </span>

                  <strong>
                    {
                      totalRecentSubmissions
                    }
                  </strong>
                </div>
              </div>

              <div className="overview-chartjs-container overview-chartjs-container--monthly">
                <Line
                  data={
                    monthlyTrendChartData
                  }
                  options={
                    monthlyTrendChartOptions
                  }
                />
              </div>

              <div className="overview-monthly-trend__footer">
                <div>
                  <span>
                    Activities
                  </span>

                  <strong>
                    {
                      monthlySubmissionTrend.reduce(
                        (
                          total,
                          month
                        ) =>
                          total +
                          month.activities,
                        0
                      )
                    }
                  </strong>
                </div>

                <div>
                  <span>
                    Contributions
                  </span>

                  <strong>
                    {
                      monthlySubmissionTrend.reduce(
                        (
                          total,
                          month
                        ) =>
                          total +
                          month.contributions,
                        0
                      )
                    }
                  </strong>
                </div>
              </div>
            </article>

          </section>

          {/* GRID 2 */}

          <section className="admin-overview__grid">
            {/* DEPARTMENT */}

            <article className="overview-panel">
              <div className="overview-panel__header">
                <div>
                  <h2>
                    Faculty by Department
                  </h2>

                  <p>
                    Department-wise approved
                    faculty distribution.
                  </p>
                </div>
              </div>

              <div className="overview-horizontal-chart">
                {departmentData.length ===
                0 ? (
                  <div className="overview-empty">
                    No faculty
                    department data
                    available.
                  </div>
                ) : (
                  departmentData.map(
                    (item) => (
                      <div
                        className="overview-horizontal-row"
                        key={
                          item.department
                        }
                      >
                        <div className="overview-horizontal-row__label">
                          <span>
                            {
                              item.department
                            }
                          </span>

                          <strong>
                            {
                              item.count
                            }
                          </strong>
                        </div>

                        <div className="overview-horizontal-track">
                          <div
                            className="overview-horizontal-fill"
                            style={{
                              width: `${
                                (item.count /
                                  maximumDepartmentCount) *
                                100
                              }%`,
                            }}
                          />
                        </div>
                      </div>
                    )
                  )
                )}
              </div>
            </article>

            {/* RECENT REGISTRATIONS */}

            <article className="overview-panel">
              <div className="overview-panel__header">
                <div>
                  <h2>
                    Recent Registrations
                  </h2>

                  <p>
                    Latest faculty
                    registrations in the
                    system.
                  </p>
                </div>
              </div>

              <div className="overview-registration-list">
                {recentRegistrations.map(
                  (faculty) => {
                    const status =
                      faculty.registrationStatus ||
                      "Not Registered";

                    return (
                      <div
                        className="overview-registration-item"
                        key={
                          faculty._id
                        }
                      >
                        <div className="overview-registration-avatar">
                          {faculty.name
                            ?.charAt(0)
                            .toUpperCase() ||
                            "F"}
                        </div>

                        <div className="overview-registration-details">
                          <strong>
                            {faculty.name ||
                              "Faculty Member"}
                          </strong>

                          <span>
                            {normalizeDepartment(
                              faculty.department
                            )}{" "}
                            ·{" "}
                            {faculty.designation ||
                              "-"}
                          </span>
                        </div>

                        <span
                          className={`overview-registration-status overview-registration-status--${status
                            .toLowerCase()
                            .replaceAll(
                              " ",
                              "-"
                            )}`}
                        >
                          {status}
                        </span>
                      </div>
                    );
                  }
                )}

                {recentRegistrations.length ===
                  0 && (
                  <div className="overview-empty">
                    No faculty
                    registrations
                    available.
                  </div>
                )}
              </div>
            </article>
          </section>
        </>
      )}

      {isLeaderboardModalOpen && (
        <div
          className="leaderboard-modal"
          role="presentation"
          onMouseDown={(event) => {
            if (
              event.target ===
              event.currentTarget
            ) {
              setIsLeaderboardModalOpen(
                false
              );
            }
          }}
        >
          <section
            className="leaderboard-modal__dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="leaderboard-modal-title"
          >
            <header className="leaderboard-modal__header">
              <div>
                <span className="leaderboard-modal__eyebrow">
                  Faculty Performance
                </span>

                <h2 id="leaderboard-modal-title">
                  Complete Faculty Rankings
                </h2>

                <p>
                  All eligible faculty listed in
                  exact performance rank order.
                </p>
              </div>

              <button
                type="button"
                className="leaderboard-modal__close"
                aria-label="Close leaderboard"
                onClick={() =>
                  setIsLeaderboardModalOpen(
                    false
                  )
                }
              >
                ×
              </button>
            </header>

            <div className="leaderboard-modal__toolbar">
              <div className="leaderboard-modal__search">
                <span aria-hidden="true">
                  ⌕
                </span>

                <input
                  type="text"
                  value={
                    leaderboardSearch
                  }
                  onChange={(event) =>
                    setLeaderboardSearch(
                      event.target.value
                    )
                  }
                  placeholder="Search faculty name, ID, department or designation"
                />
              </div>

              <div className="leaderboard-modal__count">
                <span>
                  Ranked Faculty
                </span>

                <strong>
                  {
                    facultyLeaderboard.length
                  }
                </strong>
              </div>
            </div>

            <div className="leaderboard-modal__table-wrap">
              <table className="leaderboard-modal__table">
                <thead>
                  <tr>
                    <th>
                      Rank
                    </th>

                    <th>
                      Faculty
                    </th>

                    <th>
                      Department
                    </th>

                    <th>
                      Approved
                      Activities
                    </th>

                    <th>
                      Approved
                      Contributions
                    </th>

                    <th>
                      Activity
                      Points
                    </th>

                    <th>
                      Contribution
                      Points
                    </th>

                    <th>
                      Impact
                      Score
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {filteredLeaderboard.map(
                    (
                      faculty,
                      filteredIndex
                    ) => {
                      const actualRank =
                        facultyLeaderboard.findIndex(
                          (item) =>
                            item._id ===
                            faculty._id
                        ) + 1;

                      return (
                        <tr
                          key={
                            faculty._id
                          }
                          className={
                            actualRank <= 3
                              ? "leaderboard-modal__top-rank"
                              : ""
                          }
                        >
                          <td>
                            <span className={`leaderboard-modal__rank leaderboard-modal__rank--${Math.min(
                              actualRank,
                              4
                            )}`}>
                              {actualRank ===
                              1
                                ? "🥇"
                                : actualRank ===
                                  2
                                ? "🥈"
                                : actualRank ===
                                  3
                                ? "🥉"
                                : `#${actualRank}`}
                            </span>
                          </td>

                          <td>
                            <div className="leaderboard-modal__faculty">
                              <div className="leaderboard-modal__avatar">
                                {faculty.name
                                  .charAt(0)
                                  .toUpperCase()}
                              </div>

                              <div>
                                <strong>
                                  {
                                    faculty.name
                                  }
                                </strong>

                                <span>
                                  {
                                    faculty.facultyId
                                  }
                                  {" · "}
                                  {
                                    faculty.designation
                                  }
                                </span>
                              </div>
                            </div>
                          </td>

                          <td>
                            {
                              faculty.department
                            }
                          </td>

                          <td>
                            {
                              faculty.approvedActivities
                            }
                          </td>

                          <td>
                            {
                              faculty.approvedContributions
                            }
                          </td>

                          <td>
                            {
                              faculty.activityPoints
                            }
                          </td>

                          <td>
                            {
                              faculty.contributionPoints
                            }
                          </td>

                          <td>
                            <div className="leaderboard-modal__score">
                              <strong>
                                {
                                  faculty.impactScore
                                }
                              </strong>

                              <span>
                                /100
                              </span>
                            </div>
                          </td>
                        </tr>
                      );
                    }
                  )}
                </tbody>
              </table>

              {filteredLeaderboard.length ===
                0 && (
                <div className="leaderboard-modal__empty">
                  No faculty matches your
                  search.
                </div>
              )}
            </div>

            <footer className="leaderboard-modal__footer">
              <div>
                <span>
                  Approved-only scoring
                </span>

                <strong>
                  FDP 12 · NPTEL 18 · Research 15 · Journal 14 · Patent / IPR 15 · Knowledge Transfer 26
                </strong>
              </div>

              <button
                type="button"
                onClick={() =>
                  setIsLeaderboardModalOpen(
                    false
                  )
                }
              >
                Close
              </button>
            </footer>
          </section>
        </div>
      )}
    </div>
  );
}

export default AdminOverview;