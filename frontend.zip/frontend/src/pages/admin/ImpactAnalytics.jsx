import {
  useEffect,
  useMemo,
  useState,
} from "react";

import "./ImpactAnalytics.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "http://localhost:5000";

const FACULTY_API =
  `${BACKEND_URL}/api/faculty`;

const ACTIVITY_API =
  `${BACKEND_URL}/api/activities`;

const activityCategories = [
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
];

const activityConfig = {
  FDP: {
    pointsPerActivity: 2,
    maxScore: 12,
  },
  NPTEL: {
    pointsPerActivity: 3,
    maxScore: 18,
  },
  "Research Paper": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
  "Journal Publication": {
    pointsPerActivity: 7,
    maxScore: 14,
  },
  "Patent / IPR": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
};

const contributionWeights = {
  Students: 4,
  Department: 5,
  Both: 8,
};

const ACTIVITY_SCORE_MAX = 74;
const KNOWLEDGE_TRANSFER_MAX = 26;

const VALID_ACTIVITY_TYPES =
  new Set(activityCategories);

const normalizeFacultyId = (value) =>
  String(value || "")
    .trim()
    .toUpperCase();

const normalizeDepartment = (value) => {
  const cleanValue =
    String(value || "").trim();

  const normalized =
    cleanValue
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "");

  const cseAliases =
    new Set([
      "CSE",
      "COMPUTERSCIENCE",
      "COMPUTERSCIENCEENGINEERING",
      "COMPUTERSCIENCEANDENGINEERING",
      "DEPARTMENTOFCOMPUTERSCIENCEANDENGINEERING",
    ]);

  if (
    cseAliases.has(normalized)
  ) {
    return "CSE";
  }

  return cleanValue || "Other";
};

function ImpactAnalytics() {
  const [facultyList, setFacultyList] =
    useState([]);

  const [activities, setActivities] =
    useState([]);

  const [
    departmentFilter,
    setDepartmentFilter,
  ] = useState("All");

  const [loading, setLoading] =
    useState(true);

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  // =====================================================
  // LOAD MONGODB DATA
  // =====================================================

  const loadAnalyticsData = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const [
        facultyResponse,
        activityResponse,
      ] = await Promise.all([
        fetch(FACULTY_API, {
          method: "GET",
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }),

        fetch(ACTIVITY_API, {
          method: "GET",
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }),
      ]);

      const facultyData =
        await facultyResponse.json();

      const activityData =
        await activityResponse.json();

      if (!facultyResponse.ok) {
        throw new Error(
          facultyData.message ||
            "Unable to load faculty data."
        );
      }

      if (!activityResponse.ok) {
        throw new Error(
          activityData.message ||
            "Unable to load activity data."
        );
      }

      setFacultyList(
        facultyData.faculty ||
          facultyData.faculties ||
          []
      );

      setActivities(
        activityData.activities || []
      );
    } catch (error) {
      console.error(
        "Impact analytics load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalyticsData();
  }, []);

  // =====================================================
  // ACTIVE / APPROVED FACULTY
  // =====================================================

  const approvedFaculty =
    useMemo(() => {
      return facultyList.filter(
        (faculty) =>
          faculty.registrationStatus ===
            "Approved" &&
          faculty.accountStatus ===
            "Active"
      );
    }, [facultyList]);

  // =====================================================
  // DEPARTMENT LIST
  // =====================================================

  const departments =
    useMemo(() => {
      const values =
        approvedFaculty
          .map(
            (faculty) =>
              normalizeDepartment(
                faculty.department
              )
          )
          .filter(Boolean);

      return [
        "All",
        ...new Set(values),
      ];
    }, [approvedFaculty]);

  // =====================================================
  // FILTER FACULTY
  // =====================================================

  const filteredFaculty =
    useMemo(() => {
      if (
        departmentFilter === "All"
      ) {
        return approvedFaculty;
      }

      return approvedFaculty.filter(
        (faculty) =>
          normalizeDepartment(
            faculty.department
          ) === departmentFilter
      );
    }, [
      approvedFaculty,
      departmentFilter,
    ]);

  const filteredFacultyIds =
    useMemo(() => {
      return new Set(
        filteredFaculty.map(
          (faculty) =>
            normalizeFacultyId(
              faculty.facultyId
            )
        )
      );
    }, [filteredFaculty]);

  // =====================================================
  // FILTER ACTIVITIES BY SELECTED DEPARTMENT
  //
  // Even for "All", only activities belonging to approved
  // and active faculty are included in analytics.
  // =====================================================

  const filteredActivities =
    useMemo(() => {
      return activities.filter(
        (activity) =>
          VALID_ACTIVITY_TYPES.has(
            activity.type
          ) &&
          filteredFacultyIds.has(
            normalizeFacultyId(
              activity.facultyId
            )
          )
      );
    }, [
      activities,
      filteredFacultyIds,
    ]);

  // =====================================================
  // FILTERED ACTIVITY STATUS
  // =====================================================

  const filteredApprovedActivities =
    useMemo(() => {
      return filteredActivities.filter(
        (activity) =>
          activity.status ===
          "Approved"
      );
    }, [filteredActivities]);

  const filteredPendingActivities =
    useMemo(() => {
      return filteredActivities.filter(
        (activity) =>
          (activity.status ||
            "Pending") ===
          "Pending"
      );
    }, [filteredActivities]);

  const filteredRejectedActivities =
    useMemo(() => {
      return filteredActivities.filter(
        (activity) =>
          activity.status ===
          "Rejected"
      );
    }, [filteredActivities]);

  // =====================================================
  // CATEGORY SUMMARY
  // =====================================================

  const categorySummary =
    useMemo(() => {
      return activityCategories.map(
        (category) => {
          const categoryActivities =
            filteredActivities.filter(
              (activity) =>
                activity.type ===
                category
            );

          const approved =
            categoryActivities.filter(
              (activity) =>
                activity.status ===
                "Approved"
            ).length;

          const pending =
            categoryActivities.filter(
              (activity) =>
                (activity.status ||
                  "Pending") ===
                "Pending"
            ).length;

          const rejected =
            categoryActivities.filter(
              (activity) =>
                activity.status ===
                "Rejected"
            ).length;

          return {
            category,
            total:
              categoryActivities.length,
            approved,
            pending,
            rejected,
          };
        }
      );
    }, [filteredActivities]);

  // =====================================================
  // FACULTY SCORE HELPER
  //
  // Same balanced rules as FacultyImpactScore.jsx:
  // 1. Only Approved source activities earn points.
  // 2. Each activity category has its own maximum.
  // 3. Academic Activity Score maximum = 74.
  // 4. Knowledge Transfer maximum = 26.
  // 5. Final FIS maximum = 100.
  // =====================================================

  const calculateFacultyScore = (
    faculty,
    sourceActivities = activities
  ) => {
    const facultyId =
      normalizeFacultyId(
        faculty.facultyId
      );

    const facultyApprovedActivities =
      sourceActivities.filter(
        (activity) =>
          VALID_ACTIVITY_TYPES.has(
            activity.type
          ) &&
          normalizeFacultyId(
            activity.facultyId
          ) === facultyId &&
          activity.status ===
            "Approved"
      );

    const categoryScores =
      Object.entries(
        activityConfig
      ).map(
        ([type, config]) => {
          const approvedCount =
            facultyApprovedActivities.filter(
              (activity) =>
                activity.type === type
            ).length;

          const rawCategoryScore =
            approvedCount *
            config.pointsPerActivity;

          const cappedCategoryScore =
            Math.min(
              rawCategoryScore,
              config.maxScore
            );

          return {
            type,
            approvedCount,
            rawCategoryScore,
            cappedCategoryScore,
            maxScore:
              config.maxScore,
          };
        }
      );

    const rawActivityScore =
      categoryScores.reduce(
        (total, category) =>
          total +
          category.rawCategoryScore,
        0
      );

    const activityScore =
      categoryScores.reduce(
        (total, category) =>
          total +
          category.cappedCategoryScore,
        0
      );

    const rawKnowledgeTransferScore =
      facultyApprovedActivities.reduce(
        (total, activity) => {
          if (
            activity.contributionDone !==
              "Yes" ||
            activity.contributionStatus !==
              "Approved"
          ) {
            return total;
          }

          return (
            total +
            (contributionWeights[
              activity.contributionFor
            ] || 0)
          );
        },
        0
      );

    const knowledgeTransferScore =
      Math.min(
        rawKnowledgeTransferScore,
        KNOWLEDGE_TRANSFER_MAX
      );

    const rawScore =
      rawActivityScore +
      rawKnowledgeTransferScore;

    const impactScore =
      Math.min(
        activityScore +
          knowledgeTransferScore,
        100
      );

    return {
      impactScore,
      rawScore,

      approvedActivityCount:
        facultyApprovedActivities.length,

      activityScore,
      knowledgeTransferScore,

      rawActivityScore,
      rawKnowledgeTransferScore,

      categoryScores,
    };
  };

  // =====================================================
  // FACULTY ANALYTICS
  // =====================================================

  const facultyAnalytics =
    useMemo(() => {
      return filteredFaculty
        .map((faculty) => {
          const facultyId =
            normalizeFacultyId(
              faculty.facultyId
            );

          const facultyApprovedActivities =
            filteredApprovedActivities.filter(
              (activity) =>
                normalizeFacultyId(
                  activity.facultyId
                ) === facultyId
            );

          const activityCounts =
            activityCategories.reduce(
              (
                summary,
                category
              ) => {
                summary[category] =
                  facultyApprovedActivities.filter(
                    (activity) =>
                      activity.type ===
                      category
                  ).length;

                return summary;
              },
              {}
            );

          const scoreData =
            calculateFacultyScore(
              faculty,
              filteredActivities
            );

          return {
            ...faculty,

            totalActivities:
              scoreData.approvedActivityCount,

            impactScore:
              scoreData.impactScore,

            activityScore:
              scoreData.activityScore,

            knowledgeTransferScore:
              scoreData.knowledgeTransferScore,

            rawActivityScore:
              scoreData.rawActivityScore,

            rawKnowledgeTransferScore:
              scoreData.rawKnowledgeTransferScore,

            rawScore:
              scoreData.rawScore,

            categoryScores:
              scoreData.categoryScores,

            activityCounts,
          };
        })
        .sort(
          (first, second) =>
            second.impactScore -
            first.impactScore
        );
    }, [
      filteredFaculty,
      filteredApprovedActivities,
      filteredActivities,
    ]);

  // =====================================================
  // DEPARTMENT ANALYTICS
  // =====================================================

  const departmentAnalytics =
    useMemo(() => {
      const departmentMap = {};

      approvedFaculty.forEach(
        (faculty) => {
          const department =
            normalizeDepartment(
              faculty.department
            );

          if (
            !departmentMap[
              department
            ]
          ) {
            departmentMap[
              department
            ] = {
              department,
              facultyCount: 0,
              totalScore: 0,
              activityCount: 0,
            };
          }

          const scoreData =
            calculateFacultyScore(
              faculty,
              activities
            );

          departmentMap[
            department
          ].facultyCount += 1;

          departmentMap[
            department
          ].totalScore +=
            scoreData.impactScore;

          departmentMap[
            department
          ].activityCount +=
            scoreData.approvedActivityCount;
        }
      );

      return Object.values(
        departmentMap
      )
        .map((department) => ({
          ...department,

          averageScore:
            department.facultyCount >
            0
              ? Math.round(
                  department.totalScore /
                    department.facultyCount
                )
              : 0,
        }))
        .sort(
          (first, second) =>
            second.averageScore -
            first.averageScore
        );
    }, [
      approvedFaculty,
      activities,
    ]);

  // =====================================================
  // MONTHLY SUBMISSION TREND - LAST 6 MONTHS
  // =====================================================

  const monthlySubmissionData =
    useMemo(() => {
      const currentDate =
        new Date();

      const months = [];

      for (
        let index = 5;
        index >= 0;
        index -= 1
      ) {
        const date =
          new Date(
            currentDate.getFullYear(),
            currentDate.getMonth() -
              index,
            1
          );

        months.push({
          key:
            `${date.getFullYear()}-${date.getMonth()}`,

          label:
            date.toLocaleDateString(
              "en-IN",
              {
                month: "short",
              }
            ),

          count: 0,
        });
      }

      filteredActivities.forEach(
        (activity) => {
          const dateValue =
            activity.submissionDate ||
            activity.createdAt ||
            activity.activityDate ||
            activity.startDate ||
            activity.publicationDate ||
            activity.filingDate;

          if (!dateValue) {
            return;
          }

          const activityDate =
            new Date(dateValue);

          if (
            Number.isNaN(
              activityDate.getTime()
            )
          ) {
            return;
          }

          const key =
            `${activityDate.getFullYear()}-${activityDate.getMonth()}`;

          const matchingMonth =
            months.find(
              (month) =>
                month.key === key
            );

          if (matchingMonth) {
            matchingMonth.count +=
              1;
          }
        }
      );

      return months;
    }, [filteredActivities]);

  // =====================================================
  // CONTRIBUTION WORKFLOW SUMMARY
  //
  // Impact eligible only when BOTH:
  // - main activity is Approved
  // - contribution is Approved
  // =====================================================

  const approvedContributions =
    useMemo(
      () =>
        filteredActivities.filter(
          (activity) =>
            activity.status ===
              "Approved" &&
            activity.contributionDone ===
              "Yes" &&
            activity.contributionStatus ===
              "Approved"
        ),
      [filteredActivities]
    );

  const pendingContributions =
    useMemo(
      () =>
        filteredActivities.filter(
          (activity) =>
            activity.contributionDone ===
              "Yes" &&
            (activity.contributionStatus ||
              "Pending") ===
              "Pending"
        ),
      [filteredActivities]
    );

  const rejectedContributions =
    useMemo(
      () =>
        filteredActivities.filter(
          (activity) =>
            activity.status ===
              "Approved" &&
            activity.contributionDone ===
              "Yes" &&
            activity.contributionStatus ===
              "Rejected"
        ),
      [filteredActivities]
    );

  // =====================================================
  // SCORE SUMMARY
  // =====================================================

  const totalImpactScore =
    facultyAnalytics.reduce(
      (total, faculty) =>
        total +
        faculty.impactScore,
      0
    );

  const averageImpactScore =
    facultyAnalytics.length > 0
      ? Math.round(
          totalImpactScore /
            facultyAnalytics.length
        )
      : 0;

  const highestImpactScore =
    facultyAnalytics.length > 0
      ? facultyAnalytics[0]
          .impactScore
      : 0;

  const approvalRate =
    filteredActivities.length > 0
      ? Math.round(
          (filteredApprovedActivities.length /
            filteredActivities.length) *
            100
        )
      : 0;

  // =====================================================
  // CHART CALCULATIONS
  // =====================================================

  const maximumCategoryCount =
    Math.max(
      1,
      ...categorySummary.map(
        (category) =>
          category.total
      )
    );

  const visibleDepartmentAnalytics =
    departmentFilter === "All"
      ? departmentAnalytics
      : departmentAnalytics.filter(
          (department) =>
            department.department ===
            departmentFilter
        );

  const maximumDepartmentScore =
    Math.max(
      1,
      ...visibleDepartmentAnalytics.map(
        (department) =>
          department.averageScore
      )
    );

  const maximumMonthlyCount =
    Math.max(
      1,
      ...monthlySubmissionData.map(
        (month) =>
          month.count
      )
    );

  const approvedPercentage =
    filteredActivities.length > 0
      ? (filteredApprovedActivities.length /
          filteredActivities.length) *
        100
      : 0;

  const pendingPercentage =
    filteredActivities.length > 0
      ? (filteredPendingActivities.length /
          filteredActivities.length) *
        100
      : 0;

  const approvedEnd =
    approvedPercentage * 3.6;

  const pendingEnd =
    approvedEnd +
    pendingPercentage * 3.6;

  // =====================================================
  // PERFORMANCE LABEL
  // =====================================================

  const getPerformanceLabel = (
    score
  ) => {
    if (score >= 80) {
      return "Excellent";
    }

    if (score >= 60) {
      return "Very Good";
    }

    if (score >= 40) {
      return "Good";
    }

    return "Developing";
  };

  // =====================================================
  // LOADING
  // =====================================================

  if (loading) {
    return (
      <div className="impact-analytics">
        <div className="impact-analytics__empty">
          Loading impact analytics...
        </div>
      </div>
    );
  }

  // =====================================================
  // JSX
  // =====================================================

  return (
    <div className="impact-analytics">
      {/* HEADER */}

      <section className="impact-analytics__heading">
        <div>
          <p className="impact-analytics__eyebrow">
            PERFORMANCE ANALYTICS
          </p>

          <h1>
            Impact Analytics
          </h1>

          <p>
            Analyse faculty impact
            scores using the balanced
            FIS model: academic activity
            score up to 74 and approved
            knowledge transfer up to 26,
            for a maximum of 100.
          </p>
        </div>

        <select
          className="impact-analytics__department-filter"
          value={departmentFilter}
          onChange={(event) =>
            setDepartmentFilter(
              event.target.value
            )
          }
        >
          {departments.map(
            (department) => (
              <option
                value={department}
                key={department}
              >
                {department === "All"
                  ? "All Departments"
                  : department}
              </option>
            )
          )}
        </select>
      </section>

      {/* ERROR */}

      {errorMessage && (
        <div className="impact-analytics__empty">
          <p>
            {errorMessage}
          </p>

          <button
            type="button"
            onClick={
              loadAnalyticsData
            }
          >
            Try Again
          </button>
        </div>
      )}

      {/* STATS */}

      <section className="impact-analytics__stats">
        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            👨‍🏫
          </div>

          <div>
            <span>
              Approved Faculty
            </span>

            <strong>
              {filteredFaculty.length}
            </strong>

            <small>
              Active faculty included
              in analytics
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            🎯
          </div>

          <div>
            <span>
              Average Impact Score
            </span>

            <strong>
              {averageImpactScore}
            </strong>

            <small>
              Average score out of
              100
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            🏆
          </div>

          <div>
            <span>
              Highest Impact Score
            </span>

            <strong>
              {highestImpactScore}
            </strong>

            <small>
              Best current faculty
              score
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            ✓
          </div>

          <div>
            <span>
              Activity Approval Rate
            </span>

            <strong>
              {approvalRate}%
            </strong>

            <small>
              Approved submissions
              percentage
            </small>
          </div>
        </article>
      </section>

      {/* CONTRIBUTION WORKFLOW */}

      <section className="impact-analytics__stats">
        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            ✓
          </div>

          <div>
            <span>
              Approved Contributions
            </span>

            <strong>
              {
                approvedContributions.length
              }
            </strong>

            <small>
              Impact-point eligible
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            ⏳
          </div>

          <div>
            <span>
              Pending Contributions
            </span>

            <strong>
              {
                pendingContributions.length
              }
            </strong>

            <small>
              No contribution points yet
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            ✕
          </div>

          <div>
            <span>
              Rejected Contributions
            </span>

            <strong>
              {
                rejectedContributions.length
              }
            </strong>

            <small>
              Can be corrected and resubmitted
            </small>
          </div>
        </article>

        <article className="impact-stat-card">
          <div className="impact-stat-card__icon">
            100
          </div>

          <div>
            <span>
              Score Cap
            </span>

            <strong>
              100
            </strong>

            <small>
              74 activity + 26 knowledge transfer
            </small>
          </div>
        </article>
      </section>

      {/* CATEGORY + STATUS */}

      <section className="impact-analytics__grid">
        <article className="impact-panel impact-panel--wide">
          <div className="impact-panel__header">
            <div>
              <h2>
                Activity Category
                Distribution
              </h2>

              <p>
                Number of faculty
                submissions by activity
                type.
              </p>
            </div>

            <span className="impact-panel__badge">
              {filteredActivities.length}{" "}
              Activities
            </span>
          </div>

          <div className="impact-category-chart">
            {categorySummary.map(
              (category) => {
                const height =
                  category.total === 0
                    ? 4
                    : (category.total /
                        maximumCategoryCount) *
                      100;

                return (
                  <div
                    className="impact-category-chart__item"
                    key={
                      category.category
                    }
                  >
                    <strong>
                      {category.total}
                    </strong>

                    <div className="impact-category-chart__track">
                      <div
                        className="impact-category-chart__fill"
                        style={{
                          height:
                            `${height}%`,
                        }}
                      />
                    </div>

                    <span>
                      {category.category}
                    </span>
                  </div>
                );
              }
            )}
          </div>
        </article>

        <article className="impact-panel">
          <div className="impact-panel__header">
            <div>
              <h2>
                Activity Review
                Status
              </h2>

              <p>
                Approved, pending and
                rejected submissions.
              </p>
            </div>
          </div>

          <div className="impact-review-chart">
            <div
              className="impact-review-chart__donut"
              style={{
                background:
                  `conic-gradient(
                    #22a06b 0deg ${approvedEnd}deg,
                    #f59e0b ${approvedEnd}deg ${pendingEnd}deg,
                    #dc4c4c ${pendingEnd}deg 360deg
                  )`,
              }}
            >
              <div className="impact-review-chart__centre">
                <strong>
                  {filteredActivities.length}
                </strong>

                <span>
                  Total
                </span>
              </div>
            </div>

            <div className="impact-review-chart__legend">
              <div>
                <span className="impact-dot impact-dot--approved" />

                <p>
                  Approved
                </p>

                <strong>
                  {
                    filteredApprovedActivities.length
                  }
                </strong>
              </div>

              <div>
                <span className="impact-dot impact-dot--pending" />

                <p>
                  Pending
                </p>

                <strong>
                  {
                    filteredPendingActivities.length
                  }
                </strong>
              </div>

              <div>
                <span className="impact-dot impact-dot--rejected" />

                <p>
                  Rejected
                </p>

                <strong>
                  {
                    filteredRejectedActivities.length
                  }
                </strong>
              </div>
            </div>
          </div>
        </article>
      </section>

      {/* MONTH + DEPARTMENT */}

      <section className="impact-analytics__grid">
        <article className="impact-panel">
          <div className="impact-panel__header">
            <div>
              <h2>
                Monthly Submission
                Trend
              </h2>

              <p>
                Faculty activity
                submissions during the
                last six months.
              </p>
            </div>
          </div>

          <div className="impact-monthly-chart">
            {monthlySubmissionData.map(
              (month) => {
                const height =
                  month.count === 0
                    ? 4
                    : (month.count /
                        maximumMonthlyCount) *
                      100;

                return (
                  <div
                    className="impact-monthly-chart__item"
                    key={month.key}
                  >
                    <strong>
                      {month.count}
                    </strong>

                    <div className="impact-monthly-chart__track">
                      <div
                        className="impact-monthly-chart__fill"
                        style={{
                          height:
                            `${height}%`,
                        }}
                      />
                    </div>

                    <span>
                      {month.label}
                    </span>
                  </div>
                );
              }
            )}
          </div>
        </article>

        <article className="impact-panel">
          <div className="impact-panel__header">
            <div>
              <h2>
                Department
                Performance
              </h2>

              <p>
                Department-wise
                average faculty impact
                score.
              </p>
            </div>
          </div>

          <div className="impact-department-chart">
            {visibleDepartmentAnalytics.length ===
            0 ? (
              <div className="impact-analytics__empty">
                No department
                analytics available.
              </div>
            ) : (
              visibleDepartmentAnalytics.map(
                (department) => (
                  <div
                    className="impact-department-chart__row"
                    key={
                      department.department
                    }
                  >
                    <div className="impact-department-chart__label">
                      <span>
                        {
                          department.department
                        }
                      </span>

                      <strong>
                        {
                          department.averageScore
                        }
                      </strong>
                    </div>

                    <div className="impact-department-chart__track">
                      <div
                        className="impact-department-chart__fill"
                        style={{
                          width:
                            `${
                              (department.averageScore /
                                maximumDepartmentScore) *
                              100
                            }%`,
                        }}
                      />
                    </div>

                    <small>
                      {
                        department.facultyCount
                      }{" "}
                      faculty ·{" "}
                      {
                        department.activityCount
                      }{" "}
                      approved activities
                    </small>
                  </div>
                )
              )
            )}
          </div>
        </article>
      </section>

      {/* FACULTY RANKING */}

      <section className="impact-table-card">
        <div className="impact-panel__header">
          <div>
            <h2>
              Faculty Impact Score
              Ranking
            </h2>

            <p>
              Ranking based on the
              balanced approved-only
              Faculty Impact Score.
            </p>
          </div>

          <span className="impact-panel__badge">
            Top{" "}
            {Math.min(
              facultyAnalytics.length,
              10
            )}
          </span>
        </div>

        <div className="impact-table-wrapper">
          <table className="impact-table">
            <thead>
              <tr>
                <th>
                  Rank
                </th>

                <th>
                  Faculty
                </th>

                <th>
                  Department
                </th>

                <th>
                  Approved Activities
                </th>

                <th>
                  Activity Score
                </th>

                <th>
                  Knowledge Transfer
                </th>

                <th>
                  Impact Score
                </th>

                <th>
                  Performance
                </th>
              </tr>
            </thead>

            <tbody>
              {facultyAnalytics
                .slice(0, 10)
                .map(
                  (
                    faculty,
                    index
                  ) => (
                    <tr
                      key={
                        faculty._id ||
                        faculty.facultyId
                      }
                    >
                      <td>
                        <span
                          className={`impact-rank impact-rank--${
                            index + 1
                          }`}
                        >
                          {index + 1}
                        </span>
                      </td>

                      <td>
                        <div className="impact-faculty-cell">
                          <div className="impact-faculty-cell__avatar">
                            {faculty.name
                              ?.charAt(0)
                              .toUpperCase() ||
                              "F"}
                          </div>

                          <div>
                            <strong>
                              {
                                faculty.name ||
                                "-"
                              }
                            </strong>

                            <span>
                              {
                                faculty.facultyId ||
                                "-"
                              }
                            </span>
                          </div>
                        </div>
                      </td>

                      <td>
                        {
                          faculty.department ||
                          "-"
                        }
                      </td>

                      <td>
                        {
                          faculty.totalActivities
                        }
                      </td>

                      <td>
                        <strong className="impact-score-value">
                          {
                            faculty.activityScore
                          }
                        </strong>
                        <span className="impact-score-total">
                          /{ACTIVITY_SCORE_MAX}
                        </span>
                      </td>

                      <td>
                        <strong className="impact-score-value">
                          {
                            faculty.knowledgeTransferScore
                          }
                        </strong>
                        <span className="impact-score-total">
                          /{KNOWLEDGE_TRANSFER_MAX}
                        </span>
                      </td>

                      <td>
                        <strong className="impact-score-value">
                          {
                            faculty.impactScore
                          }
                        </strong>

                        <span className="impact-score-total">
                          /100
                        </span>
                      </td>

                      <td>
                        <div className="impact-score-progress">
                          <div
                            style={{
                              width:
                                `${faculty.impactScore}%`,
                            }}
                          />
                        </div>

                        <small>
                          {
                            getPerformanceLabel(
                              faculty.impactScore
                            )
                          }
                        </small>
                      </td>
                    </tr>
                  )
                )}
            </tbody>
          </table>

          {facultyAnalytics.length ===
            0 && (
            <div className="impact-analytics__empty">
              No approved faculty
              activity data is
              available for ranking.
            </div>
          )}
        </div>
      </section>

      {/* CATEGORY SUMMARY */}

      <section className="impact-table-card">
        <div className="impact-panel__header">
          <div>
            <h2>
              Activity Category
              Summary
            </h2>

            <p>
              Review status for every
              academic activity
              category.
            </p>
          </div>
        </div>

        <div className="impact-table-wrapper">
          <table className="impact-table">
            <thead>
              <tr>
                <th>
                  Activity Category
                </th>

                <th>
                  Total
                </th>

                <th>
                  Approved
                </th>

                <th>
                  Pending
                </th>

                <th>
                  Rejected
                </th>

                <th>
                  Approval Rate
                </th>
              </tr>
            </thead>

            <tbody>
              {categorySummary.map(
                (category) => {
                  const categoryApprovalRate =
                    category.total > 0
                      ? Math.round(
                          (category.approved /
                            category.total) *
                            100
                        )
                      : 0;

                  return (
                    <tr
                      key={
                        category.category
                      }
                    >
                      <td>
                        <strong>
                          {
                            category.category
                          }
                        </strong>
                      </td>

                      <td>
                        {category.total}
                      </td>

                      <td>
                        {category.approved}
                      </td>

                      <td>
                        {category.pending}
                      </td>

                      <td>
                        {category.rejected}
                      </td>

                      <td>
                        <span className="impact-approval-rate">
                          {
                            categoryApprovalRate
                          }
                          %
                        </span>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

export default ImpactAnalytics;
