import {
  useEffect,
  useMemo,
  useState,
} from "react";

import "./RegistrationApprovals.css";

const API_URL =
  "http://localhost:5000/api/faculty";

function RegistrationApprovals() {
  const [registrations, setRegistrations] =
    useState([]);

  const [searchText, setSearchText] =
    useState("");

  const [loading, setLoading] =
    useState(true);

  const [errorMessage, setErrorMessage] =
    useState("");

  const [successMessage, setSuccessMessage] =
    useState("");

  // =========================================================
  // LOAD REGISTRATIONS FROM MONGODB
  // =========================================================

  const loadRegistrations = async () => {
    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        API_URL,
        {
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load faculty registrations."
        );
      }

      /*
        We only want faculty who have actually
        submitted a registration.

        Official Excel/master faculty who have not
        registered yet should NOT appear here.
      */

      const facultyList =
        data.faculty ||
        data.faculties ||
        [];

      const registeredFaculty =
        facultyList.filter(
          (faculty) =>
            faculty.isRegistered === true ||
            faculty.registrationStatus ===
              "Pending" ||
            faculty.registrationStatus ===
              "Approved" ||
            faculty.registrationStatus ===
              "Rejected"
        );

      setRegistrations(
        registeredFaculty
      );
    } catch (error) {
      console.error(
        "Registration load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRegistrations();
  }, []);

  // =========================================================
  // UPDATE FACULTY IN MONGODB
  // =========================================================

  const updateFacultyStatus = async (
    faculty,
    updates
  ) => {
    const response = await fetch(
      `${API_URL}/${faculty._id}`,
      {
        method: "PUT",

        headers: {
          "Content-Type":
            "application/json",

          Authorization:
            `Bearer ${localStorage.getItem(
              "token"
            )}`,
        },

        body: JSON.stringify(
          updates
        ),
      }
    );

    const data =
      await response.json();

    if (!response.ok) {
      throw new Error(
        data.message ||
          "Unable to update faculty."
      );
    }

    return data.faculty;
  };

  // =========================================================
  // APPROVE
  // =========================================================

  const handleApprove = async (
    faculty
  ) => {
    const confirmed =
      window.confirm(
        `Approve ${faculty.name} and activate this faculty account?`
      );

    if (!confirmed) {
      return;
    }

    try {
      setErrorMessage("");
      setSuccessMessage("");

      const updatedFaculty =
        await updateFacultyStatus(
          faculty,
          {
            registrationStatus:
              "Approved",

            accountStatus:
              "Active",
          }
        );

      setRegistrations(
        (previous) =>
          previous.map(
            (item) =>
              item._id ===
              faculty._id
                ? updatedFaculty
                : item
          )
      );

      setSuccessMessage(
        `${faculty.name} has been approved and the account is now active.`
      );
    } catch (error) {
      console.error(
        "Approval error:",
        error
      );

      setErrorMessage(
        error.message
      );
    }
  };

  // =========================================================
  // REJECT
  // =========================================================

  const handleReject = async (
    faculty
  ) => {
    const reason =
      window.prompt(
        "Enter the reason for rejecting this registration:"
      );

    if (reason === null) {
      return;
    }

    const rejectionReason =
      reason.trim() ||
      "No reason provided";

    try {
      setErrorMessage("");
      setSuccessMessage("");

      const updatedFaculty =
        await updateFacultyStatus(
          faculty,
          {
            registrationStatus:
              "Rejected",

            accountStatus:
              "Inactive",

            registrationRejectionReason:
              rejectionReason,
          }
        );

      setRegistrations(
        (previous) =>
          previous.map(
            (item) =>
              item._id ===
              faculty._id
                ? updatedFaculty
                : item
          )
      );

      setSuccessMessage(
        `${faculty.name}'s registration has been rejected.`
      );
    } catch (error) {
      console.error(
        "Rejection error:",
        error
      );

      setErrorMessage(
        error.message
      );
    }
  };

  // =========================================================
  // MOVE BACK TO PENDING
  // =========================================================

  const handleMoveToPending =
    async (faculty) => {
      const confirmed =
        window.confirm(
          `Move ${faculty.name}'s registration back to Pending?`
        );

      if (!confirmed) {
        return;
      }

      try {
        setErrorMessage("");
        setSuccessMessage("");

        const updatedFaculty =
          await updateFacultyStatus(
            faculty,
            {
              registrationStatus:
                "Pending",

              accountStatus:
                "Inactive",

              registrationRejectionReason:
                "",
            }
          );

        setRegistrations(
          (previous) =>
            previous.map(
              (item) =>
                item._id ===
                faculty._id
                  ? updatedFaculty
                  : item
            )
        );

        setSuccessMessage(
          `${faculty.name}'s registration has been moved back to Pending.`
        );
      } catch (error) {
        console.error(
          "Pending update error:",
          error
        );

        setErrorMessage(
          error.message
        );
      }
    };

  // =========================================================
  // RESET REGISTRATION
  // =========================================================
  //
  // IMPORTANT:
  // We DO NOT delete the faculty document.
  // That document belongs to the official faculty master list.
  //
  // Resetting registration only clears the account-registration
  // state.
  // =========================================================

  const handleResetRegistration =
    async (faculty) => {
      const confirmed =
        window.confirm(
          `Reset the registration for ${faculty.name}?\n\nThe official faculty master record will remain in the database.`
        );

      if (!confirmed) {
        return;
      }

      try {
        setErrorMessage("");
        setSuccessMessage("");

        await updateFacultyStatus(
          faculty,
          {
            registrationStatus:
              "Not Registered",

            accountStatus:
              "Inactive",

            isRegistered:
              false,

            registrationRejectionReason:
              "",
          }
        );

        setRegistrations(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !==
                faculty._id
            )
        );

        setSuccessMessage(
          `${faculty.name}'s registration has been reset. The faculty master record is still available.`
        );
      } catch (error) {
        console.error(
          "Reset registration error:",
          error
        );

        setErrorMessage(
          error.message
        );
      }
    };

  // =========================================================
  // SEARCH
  // =========================================================

  const filteredRegistrations =
    useMemo(() => {
      const value =
        searchText
          .trim()
          .toLowerCase();

      if (!value) {
        return registrations;
      }

      return registrations.filter(
        (faculty) =>
          [
            faculty.name,
            faculty.facultyId,
            faculty.department,
            faculty.designation,
            faculty.email,
            faculty.phone,
            faculty.registrationStatus,
            faculty.accountStatus,
          ].some((item) =>
            String(item || "")
              .toLowerCase()
              .includes(value)
          )
      );
    }, [
      registrations,
      searchText,
    ]);

  // =========================================================
  // COUNTS
  // =========================================================

  const pendingCount =
    registrations.filter(
      (faculty) =>
        (faculty.registrationStatus ||
          "Pending") === "Pending"
    ).length;

  const approvedCount =
    registrations.filter(
      (faculty) =>
        faculty.registrationStatus ===
        "Approved"
    ).length;

  const rejectedCount =
    registrations.filter(
      (faculty) =>
        faculty.registrationStatus ===
        "Rejected"
    ).length;

  const activeCount =
    registrations.filter(
      (faculty) =>
        faculty.accountStatus ===
        "Active"
    ).length;

  // =========================================================
  // JSX
  // =========================================================

  return (
    <div className="registration-approvals">
      {/* HEADER */}

      <section className="registration-approvals__heading">
        <div>
          <p className="registration-approvals__eyebrow">
            ACCOUNT MANAGEMENT
          </p>

          <h1>
            Registration Approvals
          </h1>

          <p>
            Review faculty registration
            requests and control account
            access.
          </p>
        </div>

        <span className="registration-approvals__pending-badge">
          {pendingCount} Pending
        </span>
      </section>

      {/* STATS */}

      <section className="registration-approvals__stats">
        <article>
          <span>
            Pending
          </span>

          <strong>
            {pendingCount}
          </strong>
        </article>

        <article>
          <span>
            Approved
          </span>

          <strong>
            {approvedCount}
          </strong>
        </article>

        <article>
          <span>
            Rejected
          </span>

          <strong>
            {rejectedCount}
          </strong>
        </article>

        <article>
          <span>
            Active Accounts
          </span>

          <strong>
            {activeCount}
          </strong>
        </article>
      </section>

      {/* MESSAGES */}

      {errorMessage && (
        <div className="registration-message registration-message--error">
          {errorMessage}
        </div>
      )}

      {successMessage && (
        <div className="registration-message registration-message--success">
          {successMessage}
        </div>
      )}

      {/* CARD */}

      <section className="registration-approvals__card">
        <div className="registration-approvals__toolbar">
          <div className="registration-approvals__search">
            <span>⌕</span>

            <input
              type="text"
              placeholder="Search name, faculty ID, department, email or status"
              value={
                searchText
              }
              onChange={(
                event
              ) =>
                setSearchText(
                  event.target
                    .value
                )
              }
            />
          </div>

          <span className="registration-approvals__result-count">
            {
              filteredRegistrations.length
            }{" "}
            Records
          </span>
        </div>

        {/* LOADING */}

        {loading ? (
          <div className="registration-approvals__empty">
            Loading faculty
            registrations...
          </div>
        ) : (
          <div className="registration-approvals__table-wrapper">
            <table className="registration-approvals__table">
              <thead>
                <tr>
                  <th>
                    Faculty
                  </th>

                  <th>
                    Faculty ID
                  </th>

                  <th>
                    Department
                  </th>

                  <th>
                    Designation
                  </th>

                  <th>
                    Phone
                  </th>

                  <th>
                    Registration
                  </th>

                  <th>
                    Account
                  </th>

                  <th>
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredRegistrations.map(
                  (faculty) => {
                    const registrationStatus =
                      faculty.registrationStatus ||
                      "Pending";

                    const accountStatus =
                      faculty.accountStatus ||
                      "Inactive";

                    return (
                      <tr
                        key={
                          faculty._id
                        }
                      >
                        {/* FACULTY */}

                        <td>
                          <div className="registration-approvals__faculty">
                            <div className="registration-approvals__avatar">
                              {faculty.name
                                ?.charAt(
                                  0
                                )
                                .toUpperCase() ||
                                "F"}
                            </div>

                            <div>
                              <strong>
                                {faculty.name ||
                                  "-"}
                              </strong>

                              <span>
                                {faculty.email ||
                                  "-"}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* FACULTY ID */}

                        <td>
                          {faculty.facultyId ||
                            "-"}
                        </td>

                        {/* DEPARTMENT */}

                        <td>
                          {faculty.department ||
                            "-"}
                        </td>

                        {/* DESIGNATION */}

                        <td>
                          {faculty.designation ||
                            "-"}
                        </td>

                        {/* PHONE */}

                        <td>
                          {faculty.phone ||
                            "-"}
                        </td>

                        {/* REGISTRATION STATUS */}

                        <td>
                          <span
                            className={`registration-status registration-status--${registrationStatus
                              .toLowerCase()
                              .replaceAll(
                                " ",
                                "-"
                              )}`}
                          >
                            {
                              registrationStatus
                            }
                          </span>

                          {registrationStatus ===
                            "Rejected" &&
                            faculty.registrationRejectionReason && (
                              <small className="registration-rejection-reason">
                                {
                                  faculty.registrationRejectionReason
                                }
                              </small>
                            )}
                        </td>

                        {/* ACCOUNT */}

                        <td>
                          <span
                            className={`registration-status registration-status--${accountStatus.toLowerCase()}`}
                          >
                            {
                              accountStatus
                            }
                          </span>
                        </td>

                        {/* ACTIONS */}

                        <td>
                          <div className="registration-actions">
                            {registrationStatus !==
                              "Approved" && (
                              <button
                                type="button"
                                className="registration-button registration-button--approve"
                                onClick={() =>
                                  handleApprove(
                                    faculty
                                  )
                                }
                              >
                                Approve
                              </button>
                            )}

                            {registrationStatus !==
                              "Rejected" && (
                              <button
                                type="button"
                                className="registration-button registration-button--reject"
                                onClick={() =>
                                  handleReject(
                                    faculty
                                  )
                                }
                              >
                                Reject
                              </button>
                            )}

                            {registrationStatus !==
                              "Pending" && (
                              <button
                                type="button"
                                className="registration-button registration-button--pending"
                                onClick={() =>
                                  handleMoveToPending(
                                    faculty
                                  )
                                }
                              >
                                Pending
                              </button>
                            )}

                            <button
                              type="button"
                              className="registration-button registration-button--delete"
                              onClick={() =>
                                handleResetRegistration(
                                  faculty
                                )
                              }
                            >
                              Reset
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>

            {filteredRegistrations.length ===
              0 && (
              <div className="registration-approvals__empty">
                No faculty
                registration records
                found.
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

export default RegistrationApprovals;