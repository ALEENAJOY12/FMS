import React, { useState, useRef } from 'react';
import axios from 'axios';

const ImportFacultyModal = ({ isOpen, onClose, onSuccess }) => {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [resultSummary, setResultSummary] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef(null);

  if (!isOpen) return null;

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setErrorMsg('');
      setResultSummary(null);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setErrorMsg('Please select an Excel file (.xlsx, .xls, .csv).');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    setLoading(true);
    setErrorMsg('');

    try {
      const token = localStorage.getItem('token'); // Adjust token key if different
      const response = await axios.post(
        'http://localhost:5000/api/admin/faculty/bulk-import', // Adjust API base URL
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`
          }
        }
      );

      setResultSummary(response.data.summary);
      if (onSuccess) onSuccess(); // Refreshes the faculty table in parent
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Failed to import faculty data.');
    } finally {
      setLoading(false);
    }
  };

  const resetAndClose = () => {
    setFile(null);
    setResultSummary(null);
    setErrorMsg('');
    if (fileInputRef.current) fileInputRef.current.value = '';
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-2xl bg-[#1c1f26] border border-gray-800 p-6 text-white shadow-2xl">
        <div className="flex justify-between items-center pb-4 border-b border-gray-800">
          <h2 className="text-lg font-semibold text-gray-100">Import Faculty via Excel</h2>
          <button 
            onClick={resetAndClose}
            className="text-gray-400 hover:text-white transition"
          >
            ✕
          </button>
        </div>

        {!resultSummary ? (
          <div className="mt-4 space-y-4">
            <p className="text-sm text-gray-400">
              Upload a spreadsheet containing faculty records. The file must include column headers: 
              <span className="text-orange-400 font-medium"> Name, Email, Department, Designation, Phone</span>.
            </p>

            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-700 hover:border-orange-500 rounded-xl p-8 text-center cursor-pointer transition bg-[#14161d]"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                className="hidden"
                onChange={handleFileChange}
              />
              <div className="text-3xl mb-2">📁</div>
              <p className="text-sm font-medium text-gray-300">
                {file ? file.name : 'Click to browse or drag and drop your file here'}
              </p>
              <p className="text-xs text-gray-500 mt-1">Supported formats: .xlsx, .xls, .csv (Max 5MB)</p>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-900/30 border border-red-700 rounded-lg text-red-400 text-xs">
                {errorMsg}
              </div>
            )}

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={resetAndClose}
                className="px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-sm font-medium text-gray-300"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!file || loading}
                onClick={handleUpload}
                className={`px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-sm font-medium text-white transition ${
                  loading || !file ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {loading ? 'Processing...' : 'Upload & Import'}
              </button>
            </div>
          </div>
        ) : (
          /* Summary View */
          <div className="mt-4 space-y-4">
            <div className="p-4 bg-emerald-950/40 border border-emerald-800/60 rounded-xl">
              <h3 className="text-sm font-semibold text-emerald-400">Import Completed</h3>
              <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                <div className="bg-[#14161d] p-2 rounded-lg">
                  <p className="text-xs text-gray-400">Total Rows</p>
                  <p className="text-lg font-bold text-white">{resultSummary.totalRows}</p>
                </div>
                <div className="bg-[#14161d] p-2 rounded-lg">
                  <p className="text-xs text-emerald-400">Imported</p>
                  <p className="text-lg font-bold text-emerald-400">{resultSummary.importedCount}</p>
                </div>
                <div className="bg-[#14161d] p-2 rounded-lg">
                  <p className="text-xs text-red-400">Skipped</p>
                  <p className="text-lg font-bold text-red-400">{resultSummary.skippedCount}</p>
                </div>
              </div>
            </div>

            {resultSummary.skippedDetails?.length > 0 && (
              <div className="max-h-36 overflow-y-auto bg-[#14161d] p-3 rounded-lg border border-gray-800 space-y-2">
                <p className="text-xs font-semibold text-gray-400">Skipped Records Log:</p>
                {resultSummary.skippedDetails.map((item, idx) => (
                  <div key={idx} className="text-xs text-gray-400 border-b border-gray-800/60 pb-1">
                    <span className="text-orange-400">Row {item.row}:</span> {item.reason} ({item.email || 'N/A'})
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={resetAndClose}
                className="px-4 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-sm font-medium text-white"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImportFacultyModal;