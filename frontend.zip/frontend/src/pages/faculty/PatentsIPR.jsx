import { useEffect, useMemo, useState } from "react";
import "./PatentsIPR.css";

const API_URL = "http://localhost:5000/api/activities";

function PatentsIPR() {
  const loggedInFaculty = JSON.parse(
    localStorage.getItem("loggedInFaculty")
  );

  const [formData, setFormData] = useState({
    title: "",
    applicationNumber: "",
    patentType: "",
    filingDate: "",
    inventors: "",
    country: "",
    patentStatus: "",
    grantDate: "",
    academicYear: "2026–2027",
    description: "",
    proof: "",
    proofName: "",

    // Contribution
    contributionDone: "No",
    contributionType: "",
    contributionTitle: "",
    contributionDate: "",
    contributionFor: "",

    // Student
    targetGroup: "",
    participantCount: "",
    studentImpact: "",

    // Department
    departmentTarget: "",
    departmentImpact: "",

    // Common contribution
    contributionDescription: "",
    impactLevel: "",
    contributionProof: "",
    contributionProofName: "",
  });

  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [
    editingActivityId,
    setEditingActivityId,
  ] = useState(null);

  const [
    editingMode,
    setEditingMode,
  ] = useState(null);

  const isEditing =
    Boolean(editingActivityId);

  const isContributionEditing =
    editingMode ===
    "contribution";

  const isMainEditing =
    editingMode ===
    "main";

  const [searchText, setSearchText] = useState("");
  const [statusFilter, setStatusFilter] =
    useState("All");

  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] =
    useState("");

  // =========================================================
  // LOAD FACULTY PATENT / IPR ACTIVITIES FROM MONGODB
  // =========================================================

  const loadActivities = async () => {
    if (!loggedInFaculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(
          loggedInFaculty.facultyId
        )}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load Patent / IPR records."
        );
      }

      setActivities(data.activities || []);
    } catch (error) {
      console.error(
        "Patent / IPR load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  if (!loggedInFaculty) {
    return (
      <div className="patent-no-user">
        <h1>Faculty login not found</h1>

        <p>Please log in again.</p>

        <button
          type="button"
          onClick={() => {
            window.location.href = "/";
          }}
        >
          Back to Login
        </button>
      </div>
    );
  }

  const records = activities.filter(
    (activity) =>
      activity.type === "Patent / IPR"
  );

  const filteredRecords = useMemo(() => {
    const value = searchText
      .trim()
      .toLowerCase();

    return records.filter((activity) => {
      const status =
        activity.status || "Pending";

      const searchableValues = [
        activity.title,
        activity.applicationNumber,
        activity.patentType,
        activity.inventors,
        activity.country,
        activity.patentStatus,
        activity.academicYear,
        activity.contributionTitle,
        activity.contributionType,
        activity.contributionFor,
      ];

      const matchesSearch =
        !value ||
        searchableValues.some((item) =>
          String(item || "")
            .toLowerCase()
            .includes(value)
        );

      const matchesStatus =
        statusFilter === "All" ||
        status === statusFilter;

      return (
        matchesSearch &&
        matchesStatus
      );
    });
  }, [
    records,
    searchText,
    statusFilter,
  ]);

  const pendingCount =
    records.filter(
      (activity) =>
        (activity.status || "Pending") ===
        "Pending"
    ).length;

  const approvedCount =
    records.filter(
      (activity) =>
        activity.status === "Approved"
    ).length;

  const contributionCount =
    records.filter(
      (activity) =>
        activity.contributionDone === "Yes"
    ).length;

  const handleChange = (event) => {
    const { name, value } = event.target;

    let updatedValue = value;

    if (name === "participantCount") {
      updatedValue = value
        .replace(/\D/g, "")
        .slice(0, 5);
    }

    setFormData((previous) => ({
      ...previous,
      [name]: updatedValue,
    }));

    setMessage("");
    setErrorMessage("");

    if (
      name === "contributionDone" &&
      value === "No"
    ) {
      setFormData((previous) => ({
        ...previous,

        contributionDone: "No",
        contributionType: "",
        contributionTitle: "",
        contributionDate: "",
        contributionFor: "",

        targetGroup: "",
        participantCount: "",
        studentImpact: "",

        departmentTarget: "",
        departmentImpact: "",

        contributionDescription: "",
        impactLevel: "",
        contributionProof: "",
        contributionProofName: "",
      }));

      const contributionInput =
        document.getElementById(
          "patent-contribution-proof"
        );

      if (contributionInput) {
        contributionInput.value = "";
      }
    }

    if (name === "contributionFor") {
      if (value === "Students") {
        setFormData((previous) => ({
          ...previous,
          contributionFor: "Students",

          departmentTarget: "",
          departmentImpact: "",
        }));
      }

      if (value === "Department") {
        setFormData((previous) => ({
          ...previous,
          contributionFor: "Department",

          targetGroup: "",
          participantCount: "",
          studentImpact: "",
        }));
      }
    }
  };

  const validateFile = (file) => {
    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      return "Upload only PDF, JPG, PNG or WEBP files.";
    }

    if (file.size > 2 * 1024 * 1024) {
      return "File must be smaller than 2 MB.";
    }

    return "";
  };

  const handleFileUpload = (
    event,
    fileField,
    fileNameField
  ) => {
    const file = event.target.files?.[0];

    setMessage("");
    setErrorMessage("");

    if (!file) return;

    const fileError =
      validateFile(file);

    if (fileError) {
      setErrorMessage(fileError);
      event.target.value = "";
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      setFormData((previous) => ({
        ...previous,
        [fileField]: reader.result,
        [fileNameField]: file.name,
      }));
    };

    reader.onerror = () => {
      setErrorMessage(
        "Unable to read the selected file."
      );
    };

    reader.readAsDataURL(file);
  };

  const resetForm = () => {
    setFormData({
      title: "",
      applicationNumber: "",
      patentType: "",
      filingDate: "",
      inventors: "",
      country: "",
      patentStatus: "",
      grantDate: "",
      academicYear: "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone: "No",
      contributionType: "",
      contributionTitle: "",
      contributionDate: "",
      contributionFor: "",

      targetGroup: "",
      participantCount: "",
      studentImpact: "",

      departmentTarget: "",
      departmentImpact: "",

      contributionDescription: "",
      impactLevel: "",
      contributionProof: "",
      contributionProofName: "",
    });

    const proofInput =
      document.getElementById(
        "patent-proof"
      );

    const contributionInput =
      document.getElementById(
        "patent-contribution-proof"
      );

    if (proofInput) {
      proofInput.value = "";
    }

    if (contributionInput) {
      contributionInput.value = "";
    }

    setEditingActivityId(
      null
    );

    setEditingMode(
      null
    );
  };

  // =========================================================
  // EDIT / RESUBMIT HELPERS
  // =========================================================

  const populateFormFromActivity = (
    activity
  ) => {
    setFormData({
      title:
        activity.title || "",

      applicationNumber:
        activity.applicationNumber ||
        "",

      patentType:
        activity.patentType || "",

      filingDate:
        activity.filingDate
          ? String(
              activity.filingDate
            ).slice(0, 10)
          : "",

      inventors:
        activity.inventors || "",

      country:
        activity.country || "",

      patentStatus:
        activity.patentStatus ||
        "",

      grantDate:
        activity.grantDate
          ? String(
              activity.grantDate
            ).slice(0, 10)
          : "",

      academicYear:
        activity.academicYear ||
        "2026–2027",

      description:
        activity.description || "",

      proof:
        activity.proof || "",

      proofName:
        activity.proofName ||
        (activity.proof
          ? "Existing Patent / IPR proof"
          : ""),

      contributionDone:
        activity.contributionDone ||
        "No",

      contributionType:
        activity.contributionType ||
        "",

      contributionTitle:
        activity.contributionTitle ||
        "",

      contributionDate:
        activity.contributionDate
          ? String(
              activity.contributionDate
            ).slice(0, 10)
          : "",

      contributionFor:
        activity.contributionFor ||
        "",

      targetGroup:
        activity.targetGroup || "",

      participantCount:
        activity.participantCount
          ? String(
              activity.participantCount
            )
          : "",

      studentImpact:
        activity.studentImpact || "",

      departmentTarget:
        activity.departmentTarget ||
        "",

      departmentImpact:
        activity.departmentImpact ||
        "",

      contributionDescription:
        activity.contributionDescription ||
        "",

      impactLevel:
        activity.impactLevel || "",

      contributionProof:
        activity.contributionProof ||
        "",

      contributionProofName:
        activity.contributionProofName ||
        (activity.contributionProof
          ? "Existing contribution proof"
          : ""),
    });

    const proofInput =
      document.getElementById(
        "patent-proof"
      );

    if (proofInput) {
      proofInput.value = "";
    }

    const contributionInput =
      document.getElementById(
        "patent-contribution-proof"
      );

    if (contributionInput) {
      contributionInput.value =
        "";
    }

    window.setTimeout(
      () => {
        document
          .querySelector(
            ".patent-card"
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      },
      0
    );
  };

  const startEditRejectedActivity = (
    activity
  ) => {
    if (
      (activity.status ||
        "Pending") !==
      "Rejected"
    ) {
      setErrorMessage(
        "Only rejected Patent / IPR records can be edited and resubmitted."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "main"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const startEditRejectedContribution = (
    activity
  ) => {
    const mainStatus =
      activity.status ||
      "Pending";

    const contributionStatus =
      activity.contributionDone ===
      "Yes"
        ? activity.contributionStatus ||
          "Pending"
        : "Not Applicable";

    if (
      mainStatus !==
        "Approved" ||
      activity.contributionDone !==
        "Yes" ||
      contributionStatus !==
        "Rejected"
    ) {
      setErrorMessage(
        "Only a rejected contribution from an approved Patent / IPR record can be edited here."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "contribution"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const cancelEdit = () => {
    resetForm();

    setMessage(
      "Edit cancelled."
    );

    setErrorMessage("");
  };

  const validateContribution = () => {
    if (
      formData.contributionDone !== "Yes"
    ) {
      return "";
    }

    if (
      !formData.contributionType ||
      !formData.contributionTitle.trim() ||
      !formData.contributionDate ||
      !formData.contributionFor ||
      !formData.contributionDescription.trim() ||
      !formData.impactLevel
    ) {
      return "Please complete all required contribution details.";
    }

    if (
      formData.contributionFor ===
        "Students" ||
      formData.contributionFor ===
        "Both"
    ) {
      if (
        !formData.targetGroup.trim() ||
        !formData.participantCount ||
        !formData.studentImpact.trim()
      ) {
        return "Please complete all student contribution and impact details.";
      }

      const count =
        Number(
          formData.participantCount
        );

      if (
        Number.isNaN(count) ||
        count < 1
      ) {
        return "Number of students must be at least 1.";
      }
    }

    if (
      formData.contributionFor ===
        "Department" ||
      formData.contributionFor ===
        "Both"
    ) {
      if (
        !formData.departmentTarget.trim() ||
        !formData.departmentImpact.trim()
      ) {
        return "Please complete all department contribution and impact details.";
      }
    }

    if (
      formData.filingDate &&
      new Date(formData.contributionDate) <
        new Date(formData.filingDate)
    ) {
      return "Contribution date cannot be earlier than the filing date.";
    }

    if (!formData.contributionProof) {
      return "Please upload contribution supporting proof.";
    }

    return "";
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setMessage("");
    setErrorMessage("");

    if (
      !formData.title.trim() ||
      !formData.applicationNumber.trim() ||
      !formData.patentType ||
      !formData.filingDate ||
      !formData.inventors.trim() ||
      !formData.country.trim() ||
      !formData.patentStatus ||
      !formData.academicYear
    ) {
      setErrorMessage(
        "Please complete all required patent / IPR fields."
      );

      return;
    }

    if (
      formData.grantDate &&
      new Date(formData.grantDate) <
        new Date(formData.filingDate)
    ) {
      setErrorMessage(
        "Grant or registration date cannot be earlier than filing date."
      );

      return;
    }

    if (!formData.proof) {
      setErrorMessage(
        "Please upload patent / IPR supporting proof."
      );

      return;
    }

    const contributionError =
      validateContribution();

    if (contributionError) {
      setErrorMessage(
        contributionError
      );

      return;
    }

    const token =
      localStorage.getItem("token");

    if (!token) {
      setErrorMessage(
        "Authentication token not found. Please login again."
      );
      return;
    }

    const isStudent = [
      "Students",
      "Both",
    ].includes(
      formData.contributionFor
    );

    const isDepartment = [
      "Department",
      "Both",
    ].includes(
      formData.contributionFor
    );

    const newActivity = {
      type: "Patent / IPR",

      title:
        formData.title.trim(),

      applicationNumber:
        formData.applicationNumber
          .trim()
          .toUpperCase(),

      patentType:
        formData.patentType,

      filingDate:
        formData.filingDate,

      activityDate:
        formData.filingDate,

      inventors:
        formData.inventors.trim(),

      country:
        formData.country.trim(),

      patentStatus:
        formData.patentStatus,

      grantDate:
        formData.grantDate || null,

      academicYear:
        formData.academicYear,

      description:
        formData.description.trim(),

      proof:
        formData.proof,

      proofName:
        formData.proofName,

      contributionDone:
        formData.contributionDone,

      contributionType:
        formData.contributionDone === "Yes"
          ? formData.contributionType
          : "",

      contributionTitle:
        formData.contributionDone === "Yes"
          ? formData.contributionTitle.trim()
          : "",

      contributionDate:
        formData.contributionDone === "Yes"
          ? formData.contributionDate
          : null,

      contributionFor:
        formData.contributionDone === "Yes"
          ? formData.contributionFor
          : "",

      targetGroup:
        formData.contributionDone === "Yes" &&
        isStudent
          ? formData.targetGroup.trim()
          : "",

      participantCount:
        formData.contributionDone === "Yes" &&
        isStudent
          ? Number(
              formData.participantCount
            )
          : 0,

      studentImpact:
        formData.contributionDone === "Yes" &&
        isStudent
          ? formData.studentImpact.trim()
          : "",

      departmentTarget:
        formData.contributionDone === "Yes" &&
        isDepartment
          ? formData.departmentTarget.trim()
          : "",

      departmentImpact:
        formData.contributionDone === "Yes" &&
        isDepartment
          ? formData.departmentImpact.trim()
          : "",

      contributionDescription:
        formData.contributionDone === "Yes"
          ? formData.contributionDescription.trim()
          : "",

      impactLevel:
        formData.contributionDone === "Yes"
          ? formData.impactLevel
          : "",

      contributionProof:
        formData.contributionDone === "Yes"
          ? formData.contributionProof
          : "",

      contributionProofName:
        formData.contributionDone === "Yes"
          ? formData.contributionProofName
          : "",
    };

    try {
      setSubmitting(true);

      const requestUrl =
        isEditing
          ? `${API_URL}/${editingActivityId}`
          : API_URL;

      const response = await fetch(
        requestUrl,
        {
          method:
            isEditing
              ? "PUT"
              : "POST",

          headers: {
            "Content-Type":
              "application/json",

            Authorization:
              `Bearer ${token}`,
          },

          body:
            JSON.stringify(
              newActivity
            ),
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            (isEditing
              ? "Unable to resubmit Patent / IPR record."
              : "Unable to submit Patent / IPR record.")
        );
      }

      const wasEditing =
        isEditing;

      const wasContributionEditing =
        isContributionEditing;

      if (data.activity) {
        setActivities(
          (previous) =>
            wasEditing
              ? previous.map(
                  (item) =>
                    item._id ===
                    data.activity._id
                      ? data.activity
                      : item
                )
              : [
                  data.activity,
                  ...previous,
                ]
        );
      } else {
        await loadActivities();
      }

      resetForm();

      setMessage(
        wasContributionEditing
          ? "Rejected contribution updated and resubmitted successfully. The Patent / IPR record remains approved and the contribution is now waiting for administrator review."
          : wasEditing
          ? "Rejected Patent / IPR record updated and resubmitted successfully. It is now waiting for administrator review."
          : "Patent / IPR record submitted successfully. It is waiting for administrator approval."
      );
    } catch (error) {
      console.error(
        "Patent / IPR submission error:",
        error
      );

      setErrorMessage(
        error.message ||
          (isEditing
            ? "Unable to resubmit Patent / IPR record."
            : "Unable to submit Patent / IPR record.")
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (activity) => {
    const status =
      activity.status || "Pending";

    if (status !== "Pending") {
      alert(
        "Only pending Patent / IPR records can be deleted."
      );

      return;
    }

    if (
      !window.confirm(
        "Are you sure you want to delete this Patent / IPR record?"
      )
    ) {
      return;
    }

    try {
      setMessage("");
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/${activity._id}`,
        {
          method: "DELETE",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to delete Patent / IPR record."
        );
      }

      setActivities(
        (previous) =>
          previous.filter(
            (item) =>
              item._id !== activity._id
          )
      );

      setMessage(
        "Patent / IPR record deleted successfully."
      );
    } catch (error) {
      console.error(
        "Patent / IPR delete error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to delete Patent / IPR record."
      );
    }
  };

  const formatDate = (dateValue) => {
    if (!dateValue) {
      return "-";
    }

    const date =
      new Date(dateValue);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return dateValue;
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  return (
    <div className="patent-page">
      <section className="patent-heading">
        <div>
          <p className="patent-eyebrow">
            INNOVATION AND INTELLECTUAL PROPERTY
          </p>

          <h1>
            Patents / IPR
          </h1>

          <p>
            Submit patent, copyright,
            trademark and other
            intellectual-property records,
            along with any resulting
            student or departmental
            contribution.
          </p>
        </div>

        <div className="patent-total">
          <span>
            Total Records
          </span>

          <strong>
            {records.length}
          </strong>
        </div>
      </section>

      <section className="patent-stats">
        <article>
          <span>
            Total Submitted
          </span>

          <strong>
            {records.length}
          </strong>

          <small>
            All Patent / IPR records
          </small>
        </article>

        <article>
          <span>Pending</span>

          <strong>
            {pendingCount}
          </strong>

          <small>
            Waiting for review
          </small>
        </article>

        <article>
          <span>Approved</span>

          <strong>
            {approvedCount}
          </strong>

          <small>
            Verified records
          </small>
        </article>

        <article>
          <span>
            Contributions
          </span>

          <strong>
            {contributionCount}
          </strong>

          <small>
            Follow-up contributions
          </small>
        </article>
      </section>

      <section className="patent-card">
        <div className="patent-card-header">
          <div>
            <h2>
              {isContributionEditing
                ? "Edit Rejected Contribution"
                : isMainEditing
                ? "Edit Rejected Patent / IPR"
                : "Add Patent / IPR"}
            </h2>

            <p>
              {isContributionEditing
                ? "The approved Patent / IPR details are locked. Correct only the rejected contribution and resubmit it for administrator review."
                : isMainEditing
                ? "Correct the rejected Patent / IPR record and resubmit it for administrator review."
                : "Enter intellectual-property details and upload supporting evidence."}
            </p>
          </div>

          <span>
            {isContributionEditing
              ? "Contribution Resubmission"
              : isMainEditing
              ? "Resubmission"
              : "New Submission"}
          </span>
        </div>

        <form
          className="patent-form"
          onSubmit={handleSubmit}
        >
          <div className="patent-form-grid">
            <div className="patent-field patent-field--full">
              <label>
                Patent / IPR Title
              </label>

              <input
                name="title"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.title
                }
                onChange={
                  handleChange
                }
                placeholder="Enter title"
                required
              />
            </div>

            <div className="patent-field">
              <label>
                Application Number
              </label>

              <input
                name="applicationNumber"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.applicationNumber
                }
                onChange={
                  handleChange
                }
                placeholder="Enter application number"
                required
              />
            </div>

            <div className="patent-field">
              <label>
                Patent / IPR Type
              </label>

              <select
                name="patentType"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.patentType
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Type
                </option>

                <option value="Patent">
                  Patent
                </option>

                <option value="Copyright">
                  Copyright
                </option>

                <option value="Trademark">
                  Trademark
                </option>

                <option value="Design Registration">
                  Design Registration
                </option>

                <option value="Other IPR">
                  Other IPR
                </option>
              </select>
            </div>

            <div className="patent-field">
              <label>
                Filing Date
              </label>

              <input
                type="date"
                name="filingDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.filingDate
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            <div className="patent-field">
              <label>
                Inventors / Owners
              </label>

              <input
                name="inventors"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.inventors
                }
                onChange={
                  handleChange
                }
                placeholder="Enter inventor or owner names"
                required
              />
            </div>

            <div className="patent-field">
              <label>
                Country
              </label>

              <input
                name="country"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.country
                }
                onChange={
                  handleChange
                }
                placeholder="Example: India"
                required
              />
            </div>

            <div className="patent-field">
              <label>
                Patent Status
              </label>

              <select
                name="patentStatus"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.patentStatus
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Status
                </option>

                <option value="Filed">
                  Filed
                </option>

                <option value="Published">
                  Published
                </option>

                <option value="Granted">
                  Granted
                </option>

                <option value="Registered">
                  Registered
                </option>
              </select>
            </div>

            <div className="patent-field">
              <label>
                Grant / Registration Date
              </label>

              <input
                type="date"
                name="grantDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.grantDate
                }
                onChange={
                  handleChange
                }
                min={
                  formData.filingDate
                }
              />
            </div>

            <div className="patent-field">
              <label>
                Academic Year
              </label>

              <select
                name="academicYear"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.academicYear
                }
                onChange={
                  handleChange
                }
              >
                <option value="2024–2025">
                  2024–2025
                </option>

                <option value="2025–2026">
                  2025–2026
                </option>

                <option value="2026–2027">
                  2026–2027
                </option>
              </select>
            </div>

            <div className="patent-field patent-field--full">
              <label>
                Description
              </label>

              <textarea
                name="description"
                disabled={
                  isContributionEditing
                }
                rows={4}
                value={
                  formData.description
                }
                onChange={
                  handleChange
                }
                placeholder="Enter Patent / IPR details"
              />
            </div>

            <div className="patent-field patent-field--full">
              <label>
                Patent / IPR Supporting
                Proof
              </label>

              <div className="patent-upload">
                <input
                  id="patent-proof"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.webp"
                  disabled={
                    isContributionEditing
                  }
                  onChange={(event) =>
                    handleFileUpload(
                      event,
                      "proof",
                      "proofName"
                    )
                  }
                />

                {formData.proofName && (
                  <small>
                    Selected:{" "}
                    {
                      formData.proofName
                    }
                  </small>
                )}
              </div>
            </div>

            {/* CONTRIBUTION */}

            <div className="patent-contribution-section">
              <div className="patent-contribution-heading">
                <h2>
                  Contribution and Impact
                </h2>

                <p>
                  Mention whether this
                  Patent / IPR resulted in
                  a contribution to
                  students or the
                  department.
                </p>
              </div>

              <div className="patent-contribution-grid">
                <div className="patent-field patent-field--full">
                  <label>
                    Did you make any
                    contribution based on
                    this Patent / IPR?
                  </label>

                  <select
                    name="contributionDone"
                    disabled={
                      isContributionEditing
                    }
                    value={
                      formData.contributionDone
                    }
                    onChange={
                      handleChange
                    }
                  >
                    <option value="No">
                      No
                    </option>

                    <option value="Yes">
                      Yes
                    </option>
                  </select>
                </div>

                {formData.contributionDone ===
                  "Yes" && (
                  <>
                    <div className="patent-field">
                      <label>
                        Contribution Type
                      </label>

                      <select
                        name="contributionType"
                        value={
                          formData.contributionType
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select Type
                        </option>

                        <option value="Class Conducted">
                          Class Conducted
                        </option>

                        <option value="Workshop Conducted">
                          Workshop Conducted
                        </option>

                        <option value="Seminar Conducted">
                          Seminar Conducted
                        </option>

                        <option value="Student Mentoring">
                          Student Mentoring
                        </option>

                        <option value="Project Guidance">
                          Project Guidance
                        </option>

                        <option value="Research Guidance">
                          Research Guidance
                        </option>

                        <option value="Lab Improvement">
                          Lab Improvement
                        </option>

                        <option value="Curriculum Improvement">
                          Curriculum Improvement
                        </option>

                        <option value="Department Training">
                          Department Training
                        </option>

                        <option value="Other">
                          Other
                        </option>
                      </select>
                    </div>

                    <div className="patent-field">
                      <label>
                        Contribution Title
                      </label>

                      <input
                        name="contributionTitle"
                        value={
                          formData.contributionTitle
                        }
                        onChange={
                          handleChange
                        }
                        placeholder="Enter contribution title"
                        required
                      />
                    </div>

                    <div className="patent-field">
                      <label>
                        Contribution Date
                      </label>

                      <input
                        type="date"
                        name="contributionDate"
                        value={
                          formData.contributionDate
                        }
                        onChange={
                          handleChange
                        }
                        min={
                          formData.filingDate
                        }
                        required
                      />
                    </div>

                    <div className="patent-field">
                      <label>
                        Contribution For
                      </label>

                      <select
                        name="contributionFor"
                        value={
                          formData.contributionFor
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select
                        </option>

                        <option value="Students">
                          Students
                        </option>

                        <option value="Department">
                          Department
                        </option>

                        <option value="Both">
                          Both
                        </option>
                      </select>
                    </div>

                    {[
                      "Students",
                      "Both",
                    ].includes(
                      formData.contributionFor
                    ) && (
                      <>
                        <div className="patent-field">
                          <label>
                            Target Class /
                            Student Group
                          </label>

                          <input
                            name="targetGroup"
                            value={
                              formData.targetGroup
                            }
                            onChange={
                              handleChange
                            }
                            placeholder="Example: S6 CSE"
                            required
                          />
                        </div>

                        <div className="patent-field">
                          <label>
                            Number of Students
                          </label>

                          <input
                            type="number"
                            min="1"
                            name="participantCount"
                            value={
                              formData.participantCount
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>

                        <div className="patent-field patent-field--full">
                          <label>
                            Impact on Students
                          </label>

                          <textarea
                            name="studentImpact"
                            rows={3}
                            value={
                              formData.studentImpact
                            }
                            onChange={
                              handleChange
                            }
                            placeholder="Explain how students benefited from the patent, innovation or IPR"
                            required
                          />
                        </div>
                      </>
                    )}

                    {[
                      "Department",
                      "Both",
                    ].includes(
                      formData.contributionFor
                    ) && (
                      <>
                        <div className="patent-field patent-field--full">
                          <label>
                            Department /
                            Target Area
                          </label>

                          <input
                            name="departmentTarget"
                            value={
                              formData.departmentTarget
                            }
                            onChange={
                              handleChange
                            }
                            placeholder="Example: CSE Department / Innovation Lab"
                            required
                          />
                        </div>

                        <div className="patent-field patent-field--full">
                          <label>
                            Impact on Department
                          </label>

                          <textarea
                            name="departmentImpact"
                            rows={3}
                            value={
                              formData.departmentImpact
                            }
                            onChange={
                              handleChange
                            }
                            placeholder="Explain how the department benefited"
                            required
                          />
                        </div>
                      </>
                    )}

                    <div className="patent-field patent-field--full">
                      <label>
                        Contribution Details
                      </label>

                      <textarea
                        name="contributionDescription"
                        rows={4}
                        value={
                          formData.contributionDescription
                        }
                        onChange={
                          handleChange
                        }
                        placeholder="Explain the contribution completed"
                        required
                      />
                    </div>

                    <div className="patent-field">
                      <label>
                        Impact Level
                      </label>

                      <select
                        name="impactLevel"
                        value={
                          formData.impactLevel
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select Impact
                        </option>

                        <option value="Low">
                          Low
                        </option>

                        <option value="Moderate">
                          Moderate
                        </option>

                        <option value="High">
                          High
                        </option>

                        <option value="Very High">
                          Very High
                        </option>
                      </select>
                    </div>

                    <div className="patent-field patent-field--full">
                      <label>
                        Contribution Supporting
                        Proof
                      </label>

                      <div className="patent-upload">
                        <input
                          id="patent-contribution-proof"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.webp"
                          onChange={(event) =>
                            handleFileUpload(
                              event,
                              "contributionProof",
                              "contributionProofName"
                            )
                          }
                        />

                        {formData.contributionProofName && (
                          <small>
                            Selected:{" "}
                            {
                              formData.contributionProofName
                            }
                          </small>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {errorMessage && (
            <div className="patent-message patent-message--error">
              {errorMessage}
            </div>
          )}

          {message && (
            <div className="patent-message patent-message--success">
              {message}
            </div>
          )}

          <div className="patent-form-actions">
            <button
              type="submit"
              disabled={submitting}
            >
              {submitting
                ? isEditing
                  ? "Resubmitting..."
                  : "Submitting..."
                : isContributionEditing
                ? "Update & Resubmit Contribution"
                : isMainEditing
                ? "Update & Resubmit Patent / IPR"
                : "Submit Patent / IPR"}
            </button>

            {isEditing && (
              <button
                type="button"
                onClick={
                  cancelEdit
                }
                disabled={
                  submitting
                }
              >
                Cancel Edit
              </button>
            )}
          </div>
        </form>
      </section>

      <section className="patent-card">
        <div className="patent-card-header">
          <div>
            <h2>
              My Patent / IPR Records
            </h2>

            <p>
              Review intellectual-property
              records, contributions and
              approval status.
            </p>
          </div>
        </div>

        <div className="patent-toolbar">
          <input
            type="text"
            placeholder="Search Patent / IPR records"
            value={searchText}
            onChange={(event) =>
              setSearchText(
                event.target.value
              )
            }
          />

          <select
            value={statusFilter}
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>
          </select>
        </div>

        {loading ? (
          <div className="patent-empty">
            Loading Patent / IPR records...
          </div>
        ) : (
          <div className="patent-table-wrapper">
          <table className="patent-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Type</th>
                <th>Application No.</th>
                <th>Filing Date</th>
                <th>Patent Status</th>
                <th>Contribution</th>
                <th>
                  Contribution For
                </th>
                <th>Main Proof</th>
                <th>
                  Contribution Proof
                </th>
                <th>
                  Activity Status
                </th>
                <th>
                  Contribution Status
                </th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {filteredRecords.map(
                (activity) => {
                  const status =
                    activity.status ||
                    "Pending";

                  const contributionStatus =
                    activity.contributionDone ===
                    "Yes"
                      ? activity.contributionStatus ||
                        "Pending"
                      : "Not Applicable";

                  return (
                    <tr
                      key={
                        activity._id
                      }
                    >
                      <td>
                        <strong>
                          {activity.title ||
                            "-"}
                        </strong>

                        <span>
                          {activity.academicYear ||
                            "-"}
                        </span>
                      </td>

                      <td>
                        {activity.patentType ||
                          "-"}
                      </td>

                      <td>
                        {
                          activity.applicationNumber ||
                          "-"
                        }
                      </td>

                      <td>
                        {formatDate(
                          activity.filingDate
                        )}
                      </td>

                      <td>
                        {activity.patentStatus ||
                          "-"}
                      </td>

                      <td>
                        {activity.contributionDone ===
                        "Yes"
                          ? activity.contributionTitle ||
                            activity.contributionType
                          : "No contribution"}
                      </td>

                      <td>
                        {activity.contributionFor ||
                          "-"}
                      </td>

                      <td>
                        {activity.proof ? (
                          <a
                            href={
                              activity.proof
                            }
                            target="_blank"
                            rel="noreferrer"
                          >
                            View Proof
                          </a>
                        ) : (
                          "-"
                        )}
                      </td>

                      <td>
                        {activity.contributionProof ? (
                          <a
                            href={
                              activity.contributionProof
                            }
                            target="_blank"
                            rel="noreferrer"
                          >
                            View Proof
                          </a>
                        ) : (
                          "Not applicable"
                        )}
                      </td>

                      <td>
                        <span
                          className={`patent-status patent-status--${status.toLowerCase()}`}
                        >
                          {status}
                        </span>
                      </td>

                      <td>
                        {
                          contributionStatus
                        }
                      </td>

                      <td>
                        {status ===
                          "Rejected" && (
                          <button
                            type="button"
                            className="patent-delete"
                            onClick={() =>
                              startEditRejectedActivity(
                                activity
                              )
                            }
                          >
                            Edit & Resubmit
                          </button>
                        )}

                        {status ===
                          "Approved" &&
                        contributionStatus ===
                          "Rejected" && (
                          <button
                            type="button"
                            className="patent-delete"
                            onClick={() =>
                              startEditRejectedContribution(
                                activity
                              )
                            }
                          >
                            Edit & Resubmit Contribution
                          </button>
                        )}

                        {status ===
                          "Pending" && (
                          <button
                            type="button"
                            className="patent-delete"
                            onClick={() =>
                              handleDelete(
                                activity
                              )
                            }
                          >
                            Delete
                          </button>
                        )}

                        {status ===
                          "Approved" &&
                          contributionStatus !==
                            "Rejected" && (
                            <span>
                              Locked
                            </span>
                          )}
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>

          {filteredRecords.length ===
            0 && (
            <div className="patent-empty">
              <div>💡</div>

              <h3>
                No Patent / IPR
                records found
              </h3>

              <p>
                Submit your first Patent
                or IPR record using the
                form above.
              </p>
            </div>
          )}
        </div>
        )}
      </section>
    </div>
  );
}

export default PatentsIPR;