
import { useEffect, useMemo, useState } from "react";
import "./FacultyHistoricalAnalytics.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

function countBy(records, field) {
  const counts = {};

  records.forEach((record) => {
    const key = record[field] || "Unknown";
    counts[key] = (counts[key] || 0) + 1;
  });

  return Object.entries(counts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
}

/* Horizontal bar chart */
function AnalyticsBars({ title, data }) {
  const max = Math.max(...data.map((item) => item.count), 1);

  return (
    <section className="fha-card">
      <h3>{title}</h3>

      {data.length === 0 ? (
        <p className="fha-muted">No data available.</p>
      ) : (
        <div className="fha-bars">
          {data.map((item) => (
            <div className="fha-bar-row" key={item.name}>
              <span className="fha-bar-label">{item.name}</span>

              <div className="fha-bar-track">
                <div
                  className="fha-bar-fill"
                  style={{
                    width: `${(item.count / max) * 100}%`,
                  }}
                />
              </div>

              <strong>{item.count}</strong>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* Line chart for academic-year trends */
function AnalyticsLineChart({ title, data }) {
  const width = 640;
  const height = 300;
  const left = 48;
  const right = 24;
  const top = 35;
  const bottom = 65;

  const max = Math.max(...data.map((item) => item.count), 1);
  const chartWidth = width - left - right;
  const chartHeight = height - top - bottom;

  const points = data.map((item, index) => {
    const x =
      data.length === 1
        ? left + chartWidth / 2
        : left + (index / (data.length - 1)) * chartWidth;

    const y = top + chartHeight - (item.count / max) * chartHeight;

    return { ...item, x, y };
  });

  const linePoints = points
    .map((point) => `${point.x},${point.y}`)
    .join(" ");

  return (
    <section className="fha-card fha-line-card">
      <h3>{title}</h3>

      <p className="fha-muted">
        Number of historical activities by academic year
      </p>

      {data.length === 0 ? (
        <p className="fha-muted">No data available.</p>
      ) : (
        <div className="fha-line-chart-wrapper">
          <svg
            className="fha-line-chart"
            viewBox={`0 0 ${width} ${height}`}
            role="img"
            aria-label={title}
          >
            {/* Horizontal grid lines and Y-axis values */}
            {[0, 0.25, 0.5, 0.75, 1].map((fraction) => {
              const y = top + chartHeight * (1 - fraction);

              return (
                <g key={fraction}>
                  <line
                    x1={left}
                    y1={y}
                    x2={width - right}
                    y2={y}
                    stroke="#fed7aa"
                    strokeDasharray="4 5"
                  />

                  <text
                    x={left - 10}
                    y={y + 4}
                    textAnchor="end"
                    fontSize="11"
                    fill="#9a3412"
                  >
                    {Math.round(max * fraction)}
                  </text>
                </g>
              );
            })}

            {/* Line connecting academic-year points */}
            {points.length > 1 && (
              <polyline
                points={linePoints}
                fill="none"
                stroke="#f97316"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}

            {/* Data points and labels */}
            {points.map((point, index) => (
              <g key={`${point.name}-${index}`}>
                <circle
                  cx={point.x}
                  cy={point.y}
                  r="5"
                  fill="#ffffff"
                  stroke="#ea580c"
                  strokeWidth="3"
                >
                  <title>
                    {point.name}: {point.count} activities
                  </title>
                </circle>

                <text
                  x={point.x}
                  y={point.y - 13}
                  textAnchor="middle"
                  fontSize="12"
                  fontWeight="700"
                  fill="#c2410c"
                >
                  {point.count}
                </text>

                <text
                  x={point.x}
                  y={height - 28}
                  textAnchor="middle"
                  fontSize="10"
                  fill="#57534e"
                >
                  {point.name}
                </text>
              </g>
            ))}
          </svg>
        </div>
      )}
    </section>
  );
}

function FacultyHistoricalAnalytics() {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [selectedType, setSelectedType] = useState("All");
  const [selectedYear, setSelectedYear] = useState("All");
  const [search, setSearch] = useState("");

  /* Fetch the logged-in faculty member's historical records */
  useEffect(() => {
    const controller = new AbortController();

    async function loadHistoricalAnalytics() {
      try {
        setLoading(true);
        setError("");

        const token = localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Please log in again to view your analytics."
          );
        }

        const response = await fetch(
          `${BACKEND_URL}/api/historical-analytics/faculty/me`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            signal: controller.signal,
          }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(
            result.message ||
              "Unable to load your historical analytics."
          );
        }

        setActivities(result.activities || []);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(
            err.message || "Unable to load historical analytics."
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    loadHistoricalAnalytics();

    return () => controller.abort();
  }, []);

  /* Academic years available in the records */
  const years = useMemo(
    () =>
      [
        ...new Set(
          activities.map((item) => item.academicYear).filter(Boolean)
        ),
      ].sort(),
    [activities]
  );

  /* Activity categories available in the records */
  const types = useMemo(
    () =>
      [
        ...new Set(
          activities.map((item) => item.type).filter(Boolean)
        ),
      ].sort(),
    [activities]
  );

  /* Apply type, year, and text-search filters */
  const filteredActivities = useMemo(() => {
    const query = search.trim().toLowerCase();

    return activities.filter((item) => {
      const matchesType =
        selectedType === "All" || item.type === selectedType;

      const matchesYear =
        selectedYear === "All" ||
        item.academicYear === selectedYear;

      const matchesSearch =
        !query ||
        [
          item.title,
          item.type,
          item.academicYear,
          item.department,
        ].some((value) =>
          String(value || "").toLowerCase().includes(query)
        );

      return matchesType && matchesYear && matchesSearch;
    });
  }, [activities, selectedType, selectedYear, search]);

  /* Data for charts */
  const typeAnalytics = useMemo(
    () => countBy(filteredActivities, "type"),
    [filteredActivities]
  );

  const yearAnalytics = useMemo(
    () =>
      countBy(filteredActivities, "academicYear").sort((a, b) =>
        a.name.localeCompare(b.name)
      ),
    [filteredActivities]
  );

  function formatDate(value) {
    if (!value) return "—";

    const date = new Date(value);

    return Number.isNaN(date.getTime())
      ? "—"
      : date.toLocaleDateString("en-IN");
  }

  function resetFilters() {
    setSelectedType("All");
    setSelectedYear("All");
    setSearch("");
  }

  /* Loading state */
  if (loading) {
    return (
      <div className="fha-page">
        <p className="fha-message">
          Loading your historical analytics...
        </p>
      </div>
    );
  }

  /* Error state */
  if (error) {
    return (
      <div className="fha-page">
        <h1>My Historical Analytics</h1>

        <div className="fha-error">{error}</div>

        <p className="fha-muted">
          Check your login and ensure the backend is running.
        </p>
      </div>
    );
  }

  return (
    <div className="fha-page">
      {/* Page header */}
      <header className="fha-header">
        <div>
          <p className="fha-eyebrow">FACULTY DASHBOARD</p>

          <h1>My Historical Analytics</h1>

          <p className="fha-subtitle">
            Review your historical activities and academic-year trends.
          </p>
        </div>

        <button
          className="fha-reset-button"
          onClick={resetFilters}
          type="button"
        >
          Reset filters
        </button>
      </header>

      {/* Filters */}
      <section className="fha-filters">
        <div className="fha-filter">
          <label htmlFor="fha-year">Academic year</label>

          <select
            id="fha-year"
            value={selectedYear}
            onChange={(event) => setSelectedYear(event.target.value)}
          >
            <option value="All">All academic years</option>

            {years.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>

        <div className="fha-filter">
          <label htmlFor="fha-type">Activity type</label>

          <select
            id="fha-type"
            value={selectedType}
            onChange={(event) => setSelectedType(event.target.value)}
          >
            <option value="All">All activity types</option>

            {types.map((activityType) => (
              <option key={activityType} value={activityType}>
                {activityType}
              </option>
            ))}
          </select>
        </div>

        <div className="fha-filter fha-search">
          <label htmlFor="fha-search">Search activities</label>

          <input
            id="fha-search"
            type="search"
            placeholder="Search by title or activity..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
      </section>

      {/* Summary cards */}
      <section className="fha-stat-grid">
        <article className="fha-stat-card">
          <span>Total historical activities</span>
          <strong>{filteredActivities.length}</strong>
          <small>Matching selected filters</small>
        </article>

        <article className="fha-stat-card">
          <span>Activity categories</span>
          <strong>{typeAnalytics.length}</strong>
          <small>Categories represented</small>
        </article>

        <article className="fha-stat-card">
          <span>Academic years</span>
          <strong>{yearAnalytics.length}</strong>
          <small>Years represented</small>
        </article>
      </section>

      {/* Charts */}
      <section className="fha-chart-grid">
        <AnalyticsLineChart
          title="Academic Year Activity Trend"
          data={yearAnalytics}
        />

        <AnalyticsBars
          title="Activities by Type"
          data={typeAnalytics}
        />
      </section>

      {/* Historical records table */}
      <section className="fha-card fha-table-card">
        <h3>My Historical Activity Records</h3>

        <p className="fha-muted">
          {filteredActivities.length} matching records
        </p>

        <div className="fha-table-wrapper">
          <table className="fha-table">
            <thead>
              <tr>
                <th>Activity Type</th>
                <th>Title</th>
                <th>Academic Year</th>
                <th>Department</th>
                <th>Date</th>
              </tr>
            </thead>

            <tbody>
              {filteredActivities.length === 0 ? (
                <tr>
                  <td colSpan="5" className="fha-empty">
                    No historical activities match your filters.
                  </td>
                </tr>
              ) : (
                filteredActivities.map((item, index) => (
                  <tr
                    key={item._id || `${item.title}-${index}`}
                  >
                    <td>
                      <span className="fha-type-badge">
                        {item.type || "Unknown"}
                      </span>
                    </td>

                    <td className="fha-title-cell">
                      {item.title || "—"}
                    </td>

                    <td>{item.academicYear || "—"}</td>

                    <td>{item.department || "—"}</td>

                    <td>
                      {formatDate(
                        item.activityDate ||
                          item.publicationDate ||
                          item.startDate
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      <p className="fha-footer-note">
        These are historical records, shown separately from your
        current activity submissions and Faculty Impact Score.
      </p>
    </div>
  );
}

export default FacultyHistoricalAnalytics;
