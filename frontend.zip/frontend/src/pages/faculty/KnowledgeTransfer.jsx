import { useEffect, useMemo, useState } from "react";
import "./KnowledgeTransfer.css";

const API_URL = "http://localhost:5000/api/activities";

const VALID_ACTIVITY_TYPES = [
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
];

function KnowledgeTransfer() {
  const getLoggedInFaculty = () => {
    try {
      const storedFaculty =
        localStorage.getItem("loggedInFaculty");

      return storedFaculty
        ? JSON.parse(storedFaculty)
        : null;
    } catch (error) {
      console.error(
        "Unable to read logged-in faculty:",
        error
      );
      return null;
    }
  };

  const faculty = getLoggedInFaculty();

  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const [searchText, setSearchText] = useState("");
  const [sourceFilter, setSourceFilter] =
    useState("All");
  const [statusFilter, setStatusFilter] =
    useState("All");
  const [targetFilter, setTargetFilter] =
    useState("All");

  const [selectedContribution, setSelectedContribution] =
    useState(null);

  // =========================================================
  // LOAD FACULTY CONTRIBUTIONS FROM MONGODB
  // =========================================================

  const loadActivities = async () => {
    if (!faculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(
          faculty.facultyId
        )}`,
        {
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load knowledge-transfer contributions."
        );
      }

      setActivities(data.activities || []);
    } catch (error) {
      console.error(
        "Knowledge transfer load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  // =========================================================
  // GET ALL CONTRIBUTIONS
  // =========================================================

  const contributionRecords = useMemo(
    () =>
      activities.filter(
        (activity) =>
          VALID_ACTIVITY_TYPES.includes(
            activity.type
          ) &&
          activity.contributionDone ===
            "Yes"
      ),
    [activities]
  );

  const verifiedContributionRecords =
    useMemo(
      () =>
        contributionRecords.filter(
          (activity) =>
            activity.status ===
              "Approved" &&
            activity.contributionStatus ===
              "Approved"
        ),
      [contributionRecords]
    );

  // =========================================================
  // SOURCE TYPES
  // =========================================================

  const sourceTypes = [
    "All",
    ...VALID_ACTIVITY_TYPES,
  ];

  // =========================================================
  // FILTER CONTRIBUTIONS
  // =========================================================

  const filteredRecords = useMemo(() => {
    const value = searchText
      .trim()
      .toLowerCase();

    return contributionRecords.filter(
      (activity) => {
        const contributionStatus =
          activity.contributionStatus ||
          "Pending";

        const searchableValues = [
          activity.title,
          activity.type,
          activity.contributionTitle,
          activity.contributionType,
          activity.contributionFor,
          activity.targetGroup,
          activity.departmentTarget,
          activity.studentImpact,
          activity.departmentImpact,
          activity.contributionDescription,
        ];

        const matchesSearch =
          !value ||
          searchableValues.some((item) =>
            String(item || "")
              .toLowerCase()
              .includes(value)
          );

        const matchesSource =
          sourceFilter === "All" ||
          activity.type === sourceFilter;

        const matchesStatus =
          statusFilter === "All" ||
          contributionStatus === statusFilter;

        const matchesTarget =
          targetFilter === "All" ||
          activity.contributionFor ===
            targetFilter;

        return (
          matchesSearch &&
          matchesSource &&
          matchesStatus &&
          matchesTarget
        );
      }
    );
  }, [
    contributionRecords,
    searchText,
    sourceFilter,
    statusFilter,
    targetFilter,
  ]);

  // =========================================================
  // COUNTS
  // =========================================================

  const pendingCount =
    contributionRecords.filter(
      (activity) =>
        (activity.contributionStatus ||
          "Pending") === "Pending"
    ).length;

  const approvedCount =
    verifiedContributionRecords.length;

  const rejectedCount =
    contributionRecords.filter(
      (activity) =>
        activity.contributionStatus ===
        "Rejected"
    ).length;

  const studentContributionCount =
    contributionRecords.filter(
      (activity) =>
        activity.contributionFor ===
          "Students" ||
        activity.contributionFor === "Both"
    ).length;

  const departmentContributionCount =
    contributionRecords.filter(
      (activity) =>
        activity.contributionFor ===
          "Department" ||
        activity.contributionFor === "Both"
    ).length;

  const totalStudentsReached =
    verifiedContributionRecords.reduce(
      (total, activity) => {
        if (
          activity.contributionFor ===
            "Students" ||
          activity.contributionFor ===
            "Both"
        ) {
          return (
            total +
            Number(
              activity.participantCount ||
                0
            )
          );
        }

        return total;
      },
      0
    );

  if (!faculty) {
    return (
      <div className="knowledge-no-user">
        <h1>Faculty login not found</h1>

        <p>Please log in again.</p>

        <button
          type="button"
          onClick={() => {
            window.location.href = "/";
          }}
        >
          Back to Login
        </button>
      </div>
    );
  }

  // =========================================================
  // CSS-SAFE STATUS / LABEL VALUE
  // =========================================================

  const toClassSuffix = (value, fallback = "unknown") =>
    String(value || fallback)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "-");

  // =========================================================
  // DATE FORMAT
  // =========================================================

  const formatDate = (dateValue) => {
    if (!dateValue) {
      return "-";
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
      return dateValue;
    }

    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // =========================================================
  // JSX
  // =========================================================

  return (
    <div className="knowledge-page">
      {/* PAGE HEADER */}

      <section className="knowledge-heading">
        <div>
          <p className="knowledge-eyebrow">
            CONTRIBUTION REPOSITORY
          </p>

          <h1>Knowledge Transfer</h1>

          <p>
            View all student and departmental
            contributions created from your FDP,
            NPTEL, research, journal and patent
            activities.
          </p>
        </div>

        <div className="knowledge-total">
          <span>
            Total Contributions
          </span>

          <strong>
            {contributionRecords.length}
          </strong>
        </div>
      </section>

      {errorMessage && (
        <div className="knowledge-empty">
          {errorMessage}
        </div>
      )}

      {/* STATS */}

      <section className="knowledge-stats">
        <article>
          <span>
            Total Contributions
          </span>

          <strong>
            {contributionRecords.length}
          </strong>

          <small>
            All uploaded contributions
          </small>
        </article>

        <article>
          <span>Approved</span>

          <strong>
            {approvedCount}
          </strong>

          <small>
            Source + contribution approved
          </small>
        </article>

        <article>
          <span>
            Student Contributions
          </span>

          <strong>
            {studentContributionCount}
          </strong>

          <small>
            Contributions involving students
          </small>
        </article>

        <article>
          <span>
            Department Contributions
          </span>

          <strong>
            {departmentContributionCount}
          </strong>

          <small>
            Department-level contributions
          </small>
        </article>
      </section>

      {/* SECONDARY STATS */}

      <section className="knowledge-mini-stats">
        <article>
          <span>
            Verified Students Reached
          </span>

          <strong>
            {totalStudentsReached}
          </strong>
        </article>

        <article>
          <span>Pending</span>

          <strong>
            {pendingCount}
          </strong>
        </article>

        <article>
          <span>Rejected</span>

          <strong>
            {rejectedCount}
          </strong>
        </article>
      </section>

      {/* CONTRIBUTION TABLE */}

      <section className="knowledge-card">
        <div className="knowledge-card-header">
          <div>
            <h2>
              Contribution Records
            </h2>

            <p>
              Contributions are automatically
              collected from your submitted
              professional activities.
            </p>
          </div>

          <span>
            Auto Generated
          </span>
        </div>

        {/* FILTERS */}

        <div className="knowledge-toolbar">
          <div className="knowledge-search">
            <span>⌕</span>

            <input
              type="text"
              placeholder="Search contribution, activity or impact"
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
            />
          </div>

          <select
            value={sourceFilter}
            onChange={(event) =>
              setSourceFilter(
                event.target.value
              )
            }
          >
            {sourceTypes.map(
              (sourceType) => (
                <option
                  value={sourceType}
                  key={sourceType}
                >
                  {sourceType === "All"
                    ? "All Activity Types"
                    : sourceType}
                </option>
              )
            )}
          </select>

          <select
            value={targetFilter}
            onChange={(event) =>
              setTargetFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Contribution Targets
            </option>

            <option value="Students">
              Students
            </option>

            <option value="Department">
              Department
            </option>

            <option value="Both">
              Both
            </option>
          </select>

          <select
            value={statusFilter}
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>
          </select>
        </div>

        {/* TABLE */}

        {loading ? (
          <div className="knowledge-empty">
            Loading knowledge-transfer contributions...
          </div>
        ) : (
          <div className="knowledge-table-wrapper">
          <table className="knowledge-table">
            <thead>
              <tr>
                <th>Source Activity</th>
                <th>Contribution</th>
                <th>Contribution For</th>
                <th>Date</th>
                <th>Target</th>
                <th>Students</th>
                <th>Impact Level</th>
                <th>Proof</th>
                <th>Status</th>
                <th>Details</th>
              </tr>
            </thead>

            <tbody>
              {filteredRecords.map(
                (activity) => {
                  const contributionStatus =
                    activity.contributionStatus ||
                    "Pending";

                  return (
                    <tr key={activity._id}>
                      {/* SOURCE ACTIVITY */}

                      <td>
                        <div className="knowledge-source-cell">
                          <strong>
                            {activity.type ||
                              "-"}
                          </strong>

                          <span>
                            {activity.title ||
                              "-"}
                          </span>

                          <small>
                            Source:{" "}
                            {activity.status ||
                              "Pending"}
                          </small>
                        </div>
                      </td>

                      {/* CONTRIBUTION */}

                      <td>
                        <div className="knowledge-contribution-cell">
                          <strong>
                            {activity.contributionType ||
                              "-"}
                          </strong>

                          <span>
                            {activity.contributionTitle ||
                              "-"}
                          </span>
                        </div>
                      </td>

                      {/* CONTRIBUTION FOR */}

                      <td>
                        <span
                          className={`knowledge-target knowledge-target--${toClassSuffix(
                            activity.contributionFor
                          )}`}
                        >
                          {activity.contributionFor ||
                            "-"}
                        </span>
                      </td>

                      {/* DATE */}

                      <td>
                        {formatDate(
                          activity.contributionDate
                        )}
                      </td>

                      {/* TARGET */}

                      <td>
                        {activity.contributionFor ===
                          "Students" && (
                          <span>
                            {activity.targetGroup ||
                              "-"}
                          </span>
                        )}

                        {activity.contributionFor ===
                          "Department" && (
                          <span>
                            {activity.departmentTarget ||
                              "-"}
                          </span>
                        )}

                        {activity.contributionFor ===
                          "Both" && (
                          <div className="knowledge-target-details">
                            <span>
                              Students:{" "}
                              {activity.targetGroup ||
                                "-"}
                            </span>

                            <span>
                              Dept:{" "}
                              {activity.departmentTarget ||
                                "-"}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* STUDENT COUNT */}

                      <td>
                        {activity.contributionFor ===
                          "Students" ||
                        activity.contributionFor ===
                          "Both"
                          ? activity.participantCount ||
                            0
                          : "-"}
                      </td>

                      {/* IMPACT LEVEL */}

                      <td>
                        <span
                          className={`knowledge-impact knowledge-impact--${toClassSuffix(
                            activity.impactLevel,
                            "low"
                          )}`}
                        >
                          {activity.impactLevel ||
                            "-"}
                        </span>
                      </td>

                      {/* PROOF */}

                      <td>
                        {activity.contributionProof ? (
                          <a
                            href={
                              activity.contributionProof
                            }
                            target="_blank"
                            rel="noreferrer"
                          >
                            View Proof
                          </a>
                        ) : (
                          "Not uploaded"
                        )}
                      </td>

                      {/* STATUS */}

                      <td>
                        <span
                          className={`knowledge-status knowledge-status--${toClassSuffix(
                            contributionStatus,
                            "pending"
                          )}`}
                        >
                          {
                            contributionStatus
                          }
                        </span>

                        {contributionStatus ===
                          "Rejected" &&
                          activity.contributionReviewComment && (
                            <small className="knowledge-rejection">
                              {
                                activity.contributionReviewComment
                              }
                            </small>
                          )}

                        {activity.status ===
                          "Approved" &&
                        contributionStatus ===
                          "Approved" ? (
                          <small>
                            Impact eligible
                          </small>
                        ) : (
                          <small>
                            Not yet impact eligible
                          </small>
                        )}
                      </td>

                      {/* DETAILS */}

                      <td>
                        <button
                          type="button"
                          className="knowledge-view-button"
                          onClick={() =>
                            setSelectedContribution(
                              activity
                            )
                          }
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  );
                }
              )}
            </tbody>
          </table>

          {filteredRecords.length ===
            0 && (
            <div className="knowledge-empty">
              <div>⇄</div>

              <h3>
                No contribution records found
              </h3>

              <p>
                Contributions will appear here
                automatically when you select
                “Yes” in the Contribution and
                Impact section of an activity.
              </p>
            </div>
          )}
        </div>
        )}
      </section>

      {/* =====================================================
          DETAILS MODAL
      ====================================================== */}

      {selectedContribution && (
        <div
          className="knowledge-modal-backdrop"
          onClick={() =>
            setSelectedContribution(null)
          }
        >
          <div
            className="knowledge-modal"
            onClick={(event) =>
              event.stopPropagation()
            }
          >
            {/* MODAL HEADER */}

            <div className="knowledge-modal-header">
              <div>
                <p>
                  KNOWLEDGE TRANSFER DETAILS
                </p>

                <h2>
                  {selectedContribution.contributionTitle ||
                    "Contribution"}
                </h2>
              </div>

              <button
                type="button"
                onClick={() =>
                  setSelectedContribution(
                    null
                  )
                }
              >
                ×
              </button>
            </div>

            {/* SOURCE */}

            <section className="knowledge-modal-section">
              <h3>
                Source Activity
              </h3>

              <div className="knowledge-detail-grid">
                <div>
                  <span>
                    Activity Type
                  </span>

                  <strong>
                    {selectedContribution.type ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Activity Title
                  </span>

                  <strong>
                    {selectedContribution.title ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Contribution Type
                  </span>

                  <strong>
                    {selectedContribution.contributionType ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Contribution Date
                  </span>

                  <strong>
                    {formatDate(
                      selectedContribution.contributionDate
                    )}
                  </strong>
                </div>

                <div>
                  <span>
                    Contribution For
                  </span>

                  <strong>
                    {selectedContribution.contributionFor ||
                      "-"}
                  </strong>
                </div>

                <div>
                  <span>
                    Impact Level
                  </span>

                  <strong>
                    {selectedContribution.impactLevel ||
                      "-"}
                  </strong>
                </div>
              </div>
            </section>

            {/* CONTRIBUTION DETAILS */}

            <section className="knowledge-modal-section">
              <h3>
                Contribution Description
              </h3>

              <p className="knowledge-modal-text">
                {selectedContribution.contributionDescription ||
                  "No description provided."}
              </p>
            </section>

            {/* STUDENT IMPACT */}

            {(
              selectedContribution.contributionFor ===
                "Students" ||
              selectedContribution.contributionFor ===
                "Both"
            ) && (
              <section className="knowledge-modal-section knowledge-modal-section--students">
                <h3>
                  Student Contribution
                </h3>

                <div className="knowledge-detail-grid">
                  <div>
                    <span>
                      Target Class /
                      Student Group
                    </span>

                    <strong>
                      {selectedContribution.targetGroup ||
                        "-"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Number of Students
                    </span>

                    <strong>
                      {selectedContribution.participantCount ||
                        0}
                    </strong>
                  </div>
                </div>

                <div className="knowledge-impact-box">
                  <span>
                    Impact on Students
                  </span>

                  <p>
                    {selectedContribution.studentImpact ||
                      "No student impact description provided."}
                  </p>
                </div>
              </section>
            )}

            {/* DEPARTMENT IMPACT */}

            {(
              selectedContribution.contributionFor ===
                "Department" ||
              selectedContribution.contributionFor ===
                "Both"
            ) && (
              <section className="knowledge-modal-section knowledge-modal-section--department">
                <h3>
                  Department Contribution
                </h3>

                <div className="knowledge-detail-grid">
                  <div>
                    <span>
                      Department /
                      Target Area
                    </span>

                    <strong>
                      {selectedContribution.departmentTarget ||
                        "-"}
                    </strong>
                  </div>
                </div>

                <div className="knowledge-impact-box">
                  <span>
                    Impact on Department
                  </span>

                  <p>
                    {selectedContribution.departmentImpact ||
                      "No department impact description provided."}
                  </p>
                </div>
              </section>
            )}

            {/* PROOF */}

            <section className="knowledge-modal-section">
              <h3>
                Supporting Evidence
              </h3>

              {selectedContribution.contributionProof ? (
                <a
                  className="knowledge-modal-proof"
                  href={
                    selectedContribution.contributionProof
                  }
                  target="_blank"
                  rel="noreferrer"
                >
                  Open Contribution Proof
                </a>
              ) : (
                <p>
                  No contribution proof
                  uploaded.
                </p>
              )}
            </section>

            {/* APPROVAL */}

            <section className="knowledge-modal-section">
              <h3>
                Verification Status
              </h3>

              <span
                className={`knowledge-status knowledge-status--${toClassSuffix(
                  selectedContribution.contributionStatus,
                  "pending"
                )}`}
              >
                {selectedContribution.contributionStatus ||
                  "Pending"}
              </span>

              {selectedContribution.contributionReviewComment && (
                <div className="knowledge-review-comment">
                  <span>
                    Admin Review Comment
                  </span>

                  <p>
                    {
                      selectedContribution.contributionReviewComment
                    }
                  </p>
                </div>
              )}
            </section>

            <div className="knowledge-modal-footer">
              <button
                type="button"
                onClick={() =>
                  setSelectedContribution(
                    null
                  )
                }
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default KnowledgeTransfer;