import {
  useEffect,
  useMemo,
  useState,
} from "react";

import "./NPTELCourses.css";

const API_URL =
  "http://localhost:5000/api/activities";

function NPTELCourses() {
  const loggedInFaculty =
    JSON.parse(
      localStorage.getItem(
        "loggedInFaculty"
      )
    );

  const [formData, setFormData] =
    useState({
      title: "",
      courseCode: "",
      institution:
        "NPTEL / SWAYAM",
      courseWeeks: "",
      startDate: "",
      endDate: "",
      examDate: "",
      score: "",
      result: "",
      certificateType: "",
      academicYear:
        "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone:
        "No",

      contributionType:
        "",

      contributionTitle:
        "",

      contributionDate:
        "",

      contributionFor:
        "",

      targetGroup: "",

      participantCount:
        "",

      studentImpact: "",

      departmentTarget:
        "",

      departmentImpact:
        "",

      contributionDescription:
        "",

      impactLevel: "",

      contributionProof:
        "",

      contributionProofName:
        "",
    });

  const [
    activities,
    setActivities,
  ] = useState([]);

  const [
    searchText,
    setSearchText,
  ] = useState("");

  const [
    statusFilter,
    setStatusFilter,
  ] = useState("All");

  const [message, setMessage] =
    useState("");

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [loading, setLoading] =
    useState(true);

  const [
    submitting,
    setSubmitting,
  ] = useState(false);

  const [
    editingActivityId,
    setEditingActivityId,
  ] = useState(null);

  const [
    editingMode,
    setEditingMode,
  ] = useState(null);

  const isEditing =
    Boolean(editingActivityId);

  const isContributionEditing =
    editingMode ===
    "contribution";

  const isMainEditing =
    editingMode ===
    "main";

  // ========================================
  // LOAD NPTEL ACTIVITIES FROM MONGODB
  // ========================================

  const loadActivities =
    async () => {
      if (
        !loggedInFaculty?.facultyId
      ) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setErrorMessage("");

        const token =
          localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/faculty/${encodeURIComponent(
              loggedInFaculty.facultyId
            )}`,
            {
              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to load NPTEL activities."
          );
        }

        setActivities(
          data.activities || []
        );
      } catch (error) {
        console.error(
          "NPTEL load error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to connect to the server."
        );
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    loadActivities();
  }, []);

  // ========================================
  // LOGIN CHECK
  // ========================================

  if (!loggedInFaculty) {
    return (
      <div className="nptel-no-user">
        <h1>
          Faculty login not found
        </h1>

        <p>
          Please log in again.
        </p>

        <button
          type="button"
          onClick={() => {
            window.location.href =
              "/";
          }}
        >
          Back to Login
        </button>
      </div>
    );
  }

  // ========================================
  // NPTEL RECORDS
  // ========================================

  const facultyNPTELRecords =
    activities.filter(
      (activity) =>
        activity.type === "NPTEL"
    );

  // ========================================
  // SEARCH + FILTER
  // ========================================

  const filteredRecords =
    useMemo(() => {
      const value =
        searchText
          .trim()
          .toLowerCase();

      return facultyNPTELRecords.filter(
        (activity) => {
          const status =
            activity.status ||
            "Pending";

          const searchableValues =
            [
              activity.title,
              activity.courseCode,
              activity.institution,
              activity.result,
              activity.academicYear,
              activity.contributionTitle,
              activity.contributionType,
              activity.contributionFor,
              activity.targetGroup,
              activity.departmentTarget,
            ];

          const matchesSearch =
            !value ||
            searchableValues.some(
              (item) =>
                String(
                  item || ""
                )
                  .toLowerCase()
                  .includes(value)
            );

          const matchesStatus =
            statusFilter ===
              "All" ||
            status ===
              statusFilter;

          return (
            matchesSearch &&
            matchesStatus
          );
        }
      );
    }, [
      facultyNPTELRecords,
      searchText,
      statusFilter,
    ]);

  // ========================================
  // COUNTS
  // ========================================

  const pendingCount =
    facultyNPTELRecords.filter(
      (activity) =>
        (activity.status ||
          "Pending") ===
        "Pending"
    ).length;

  const approvedCount =
    facultyNPTELRecords.filter(
      (activity) =>
        activity.status ===
        "Approved"
    ).length;

  const contributionCount =
    facultyNPTELRecords.filter(
      (activity) =>
        activity.contributionDone ===
        "Yes"
    ).length;

  // ========================================
  // HANDLE CHANGE
  // ========================================

  const handleChange = (
    event
  ) => {
    const {
      name,
      value,
    } = event.target;

    let updatedValue =
      value;

    if (name === "score") {
      updatedValue =
        value
          .replace(
            /[^0-9.]/g,
            ""
          )
          .slice(0, 6);
    }

    if (
      name ===
      "participantCount"
    ) {
      updatedValue =
        value
          .replace(
            /\D/g,
            ""
          )
          .slice(0, 5);
    }

    setFormData(
      (previous) => ({
        ...previous,
        [name]:
          updatedValue,
      })
    );

    setMessage("");
    setErrorMessage("");

    // Contribution changed to NO
    if (
      name ===
        "contributionDone" &&
      value === "No"
    ) {
      setFormData(
        (previous) => ({
          ...previous,

          contributionDone:
            "No",

          contributionType:
            "",

          contributionTitle:
            "",

          contributionDate:
            "",

          contributionFor:
            "",

          targetGroup:
            "",

          participantCount:
            "",

          studentImpact:
            "",

          departmentTarget:
            "",

          departmentImpact:
            "",

          contributionDescription:
            "",

          impactLevel:
            "",

          contributionProof:
            "",

          contributionProofName:
            "",
        })
      );

      const contributionInput =
        document.getElementById(
          "nptel-contribution-proof"
        );

      if (
        contributionInput
      ) {
        contributionInput.value =
          "";
      }
    }

    // Contribution target changed
    if (
      name ===
      "contributionFor"
    ) {
      if (
        value === "Students"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Students",

            departmentTarget:
              "",

            departmentImpact:
              "",
          })
        );
      }

      if (
        value === "Department"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Department",

            targetGroup:
              "",

            participantCount:
              "",

            studentImpact:
              "",
          })
        );
      }
    }
  };

  // ========================================
  // FILE VALIDATION
  // ========================================

  const validateFile = (
    file
  ) => {
    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (
      !allowedTypes.includes(
        file.type
      )
    ) {
      return "Upload only PDF, JPG, PNG or WEBP files.";
    }

    if (
      file.size >
      2 * 1024 * 1024
    ) {
      return "The selected file must be smaller than 2 MB.";
    }

    return "";
  };

  // ========================================
  // MAIN CERTIFICATE
  // ========================================

  const handleProofUpload =
    (event) => {
      const file =
        event.target
          .files?.[0];

      setMessage("");
      setErrorMessage("");

      if (!file) {
        return;
      }

      const fileError =
        validateFile(file);

      if (fileError) {
        setErrorMessage(
          fileError
        );

        event.target.value =
          "";

        return;
      }

      const reader =
        new FileReader();

      reader.onload = () => {
        setFormData(
          (previous) => ({
            ...previous,

            proof:
              reader.result,

            proofName:
              file.name,
          })
        );
      };

      reader.onerror = () => {
        setErrorMessage(
          "Unable to read the selected NPTEL proof."
        );
      };

      reader.readAsDataURL(
        file
      );
    };

  // ========================================
  // CONTRIBUTION PROOF
  // ========================================

  const handleContributionProofUpload =
    (event) => {
      const file =
        event.target
          .files?.[0];

      setMessage("");
      setErrorMessage("");

      if (!file) {
        return;
      }

      const fileError =
        validateFile(file);

      if (fileError) {
        setErrorMessage(
          fileError
        );

        event.target.value =
          "";

        return;
      }

      const reader =
        new FileReader();

      reader.onload = () => {
        setFormData(
          (previous) => ({
            ...previous,

            contributionProof:
              reader.result,

            contributionProofName:
              file.name,
          })
        );
      };

      reader.onerror = () => {
        setErrorMessage(
          "Unable to read the contribution proof."
        );
      };

      reader.readAsDataURL(
        file
      );
    };

  // ========================================
  // RESET FORM
  // ========================================

  const resetForm = () => {
    setFormData({
      title: "",
      courseCode: "",
      institution:
        "NPTEL / SWAYAM",
      courseWeeks: "",
      startDate: "",
      endDate: "",
      examDate: "",
      score: "",
      result: "",
      certificateType: "",
      academicYear:
        "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone:
        "No",

      contributionType:
        "",

      contributionTitle:
        "",

      contributionDate:
        "",

      contributionFor:
        "",

      targetGroup:
        "",

      participantCount:
        "",

      studentImpact:
        "",

      departmentTarget:
        "",

      departmentImpact:
        "",

      contributionDescription:
        "",

      impactLevel:
        "",

      contributionProof:
        "",

      contributionProofName:
        "",
    });

    const mainInput =
      document.getElementById(
        "nptel-proof"
      );

    if (mainInput) {
      mainInput.value =
        "";
    }

    const contributionInput =
      document.getElementById(
        "nptel-contribution-proof"
      );

    if (
      contributionInput
    ) {
      contributionInput.value =
        "";
    }

    setEditingActivityId(
      null
    );

    setEditingMode(
      null
    );
  };

  // ========================================
  // EDIT / RESUBMIT HELPERS
  // ========================================

  const populateFormFromActivity = (
    activity
  ) => {
    setFormData({
      title:
        activity.title || "",

      courseCode:
        activity.courseCode || "",

      institution:
        activity.institution ||
        "NPTEL / SWAYAM",

      courseWeeks:
        activity.courseWeeks || "",

      startDate:
        activity.startDate
          ? String(
              activity.startDate
            ).slice(0, 10)
          : "",

      endDate:
        activity.endDate
          ? String(
              activity.endDate
            ).slice(0, 10)
          : "",

      examDate:
        activity.examDate
          ? String(
              activity.examDate
            ).slice(0, 10)
          : "",

      score:
        activity.score !==
          undefined &&
        activity.score !== null
          ? String(
              activity.score
            )
          : "",

      result:
        activity.result || "",

      certificateType:
        activity.certificateType ||
        "",

      academicYear:
        activity.academicYear ||
        "2026–2027",

      description:
        activity.description || "",

      proof:
        activity.proof || "",

      proofName:
        activity.proofName ||
        (activity.proof
          ? "Existing NPTEL proof"
          : ""),

      contributionDone:
        activity.contributionDone ||
        "No",

      contributionType:
        activity.contributionType ||
        "",

      contributionTitle:
        activity.contributionTitle ||
        "",

      contributionDate:
        activity.contributionDate
          ? String(
              activity.contributionDate
            ).slice(0, 10)
          : "",

      contributionFor:
        activity.contributionFor ||
        "",

      targetGroup:
        activity.targetGroup || "",

      participantCount:
        activity.participantCount
          ? String(
              activity.participantCount
            )
          : "",

      studentImpact:
        activity.studentImpact || "",

      departmentTarget:
        activity.departmentTarget ||
        "",

      departmentImpact:
        activity.departmentImpact ||
        "",

      contributionDescription:
        activity.contributionDescription ||
        "",

      impactLevel:
        activity.impactLevel || "",

      contributionProof:
        activity.contributionProof ||
        "",

      contributionProofName:
        activity.contributionProofName ||
        (activity.contributionProof
          ? "Existing contribution proof"
          : ""),
    });

    const mainInput =
      document.getElementById(
        "nptel-proof"
      );

    if (mainInput) {
      mainInput.value = "";
    }

    const contributionInput =
      document.getElementById(
        "nptel-contribution-proof"
      );

    if (contributionInput) {
      contributionInput.value =
        "";
    }

    window.setTimeout(
      () => {
        document
          .querySelector(
            ".nptel-form-card"
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      },
      0
    );
  };

  const startEditRejectedActivity = (
    activity
  ) => {
    if (
      (activity.status ||
        "Pending") !==
      "Rejected"
    ) {
      setErrorMessage(
        "Only rejected NPTEL records can be edited and resubmitted."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "main"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const startEditRejectedContribution = (
    activity
  ) => {
    const mainStatus =
      activity.status ||
      "Pending";

    const contributionStatus =
      activity.contributionDone ===
      "Yes"
        ? activity.contributionStatus ||
          "Pending"
        : "Not Applicable";

    if (
      mainStatus !==
        "Approved" ||
      activity.contributionDone !==
        "Yes" ||
      contributionStatus !==
        "Rejected"
    ) {
      setErrorMessage(
        "Only a rejected contribution from an approved NPTEL course can be edited here."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "contribution"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const cancelEdit = () => {
    resetForm();
    setMessage(
      "Edit cancelled."
    );
    setErrorMessage("");
  };

  // ========================================
  // VALIDATE FORM
  // ========================================

  const validateForm = () => {
    if (
      !formData.title.trim() ||
      !formData.courseCode.trim() ||
      !formData.institution.trim() ||
      !formData.courseWeeks ||
      !formData.startDate ||
      !formData.endDate ||
      !formData.result ||
      !formData.academicYear
    ) {
      return "Please complete all required NPTEL fields.";
    }

    if (
      new Date(
        formData.endDate
      ) <
      new Date(
        formData.startDate
      )
    ) {
      return "Course end date cannot be earlier than the start date.";
    }

    if (
      formData.examDate
    ) {
      if (
        new Date(
          formData.examDate
        ) <
        new Date(
          formData.startDate
        )
      ) {
        return "Examination date cannot be earlier than the course start date.";
      }
    }

    if (formData.score) {
      const numericScore =
        Number(
          formData.score
        );

      if (
        Number.isNaN(
          numericScore
        ) ||
        numericScore < 0 ||
        numericScore > 100
      ) {
        return "Final score must be between 0 and 100.";
      }
    }

    if (!formData.proof) {
      return "Please upload the NPTEL certificate or supporting proof.";
    }

    if (
      formData.contributionDone ===
      "Yes"
    ) {
      if (
        !formData.contributionType ||
        !formData.contributionTitle.trim() ||
        !formData.contributionDate ||
        !formData.contributionFor ||
        !formData.impactLevel ||
        !formData.contributionDescription.trim()
      ) {
        return "Please complete all required contribution details.";
      }

      if (
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.targetGroup.trim() ||
          !formData.participantCount ||
          !formData.studentImpact.trim()
        ) {
          return "Please complete all student contribution and impact details.";
        }

        const studentCount =
          Number(
            formData.participantCount
          );

        if (
          Number.isNaN(
            studentCount
          ) ||
          studentCount < 1
        ) {
          return "Number of students must be at least 1.";
        }
      }

      if (
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.departmentTarget.trim() ||
          !formData.departmentImpact.trim()
        ) {
          return "Please complete all department contribution and impact details.";
        }
      }

      if (
        new Date(
          formData.contributionDate
        ) <
        new Date(
          formData.startDate
        )
      ) {
        return "Contribution date cannot be earlier than the NPTEL course start date.";
      }

      if (
        !formData.contributionProof
      ) {
        return "Please upload supporting proof for the contribution.";
      }
    }

    return "";
  };

  // ========================================
  // SUBMIT TO MONGODB
  // ========================================

  const handleSubmit =
    async (event) => {
      event.preventDefault();

      setMessage("");
      setErrorMessage("");

      const validationError =
        validateForm();

      if (
        validationError
      ) {
        setErrorMessage(
          validationError
        );

        return;
      }

      const token =
        localStorage.getItem("token");

      if (!token) {
        setErrorMessage(
          "Authentication token not found. Please login again."
        );
        return;
      }

      const isStudent =
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both";

      const isDepartment =
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both";

      const newActivity = {
        type: "NPTEL",

        title:
          formData.title.trim(),

        courseCode:
          formData.courseCode
            .trim()
            .toUpperCase(),

        institution:
          formData.institution.trim(),

        courseWeeks:
          formData.courseWeeks,

        startDate:
          formData.startDate,

        endDate:
          formData.endDate,

        examDate:
          formData.examDate ||
          null,

        activityDate:
          formData.startDate,

        score:
          formData.score,

        result:
          formData.result,

        certificateType:
          formData.certificateType,

        academicYear:
          formData.academicYear,

        description:
          formData.description.trim(),

        proof:
          formData.proof,

        proofName:
          formData.proofName,

        contributionDone:
          formData.contributionDone,

        contributionType:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionType
            : "",

        contributionTitle:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionTitle.trim()
            : "",

        contributionDate:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDate
            : null,

        contributionFor:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionFor
            : "",

        targetGroup:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.targetGroup.trim()
            : "",

        participantCount:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? Number(
                formData.participantCount
              )
            : 0,

        studentImpact:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.studentImpact.trim()
            : "",

        departmentTarget:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentTarget.trim()
            : "",

        departmentImpact:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentImpact.trim()
            : "",

        contributionDescription:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDescription.trim()
            : "",

        impactLevel:
          formData.contributionDone ===
          "Yes"
            ? formData.impactLevel
            : "",

        contributionProof:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProof
            : "",

        contributionProofName:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProofName
            : "",
      };

      try {
        setSubmitting(true);

        const requestUrl =
          isEditing
            ? `${API_URL}/${editingActivityId}`
            : API_URL;

        const response =
          await fetch(
            requestUrl,
            {
              method:
                isEditing
                  ? "PUT"
                  : "POST",

              headers: {
                "Content-Type":
                  "application/json",

                Authorization:
                  `Bearer ${token}`,
              },

              body:
                JSON.stringify(
                  newActivity
                ),
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              (isEditing
                ? "Unable to resubmit NPTEL course."
                : "Unable to submit NPTEL course.")
          );
        }

        const wasEditing =
          isEditing;

        const wasContributionEditing =
          isContributionEditing;

        if (data.activity) {
          setActivities(
            (previous) =>
              wasEditing
                ? previous.map(
                    (item) =>
                      item._id ===
                      data.activity._id
                        ? data.activity
                        : item
                  )
                : [
                    data.activity,
                    ...previous,
                  ]
          );
        } else {
          await loadActivities();
        }

        resetForm();

        setMessage(
          wasContributionEditing
            ? "Rejected contribution updated and resubmitted successfully. The NPTEL course remains approved and the contribution is now waiting for administrator review."
            : wasEditing
            ? "Rejected NPTEL course updated and resubmitted successfully. It is now waiting for administrator review."
            : "NPTEL course submitted successfully. The activity and contribution details are waiting for administrator approval."
        );
      } catch (error) {
        console.error(
          "NPTEL submission error:",
          error
        );

        setErrorMessage(
          error.message ||
            (isEditing
              ? "Unable to resubmit NPTEL course."
              : "Unable to submit NPTEL course.")
        );
      } finally {
        setSubmitting(false);
      }
    };

  // ========================================
  // DELETE FROM MONGODB
  // ========================================

  const handleDelete =
    async (activity) => {
      const status =
        activity.status ||
        "Pending";

      if (
        status !== "Pending"
      ) {
        alert(
          "Only pending NPTEL records can be deleted."
        );

        return;
      }

      const confirmed =
        window.confirm(
          "Are you sure you want to delete this NPTEL course record?"
        );

      if (!confirmed) {
        return;
      }

      try {
        setErrorMessage("");
        setMessage("");

        const token =
          localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/${activity._id}`,
            {
              method:
                "DELETE",

              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to delete NPTEL course."
          );
        }

        setActivities(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !==
                activity._id
            )
        );

        setMessage(
          "NPTEL course deleted successfully."
        );
      } catch (error) {
        console.error(
          "NPTEL delete error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to delete NPTEL course."
        );
      }
    };

  // ========================================
  // DATE FORMAT
  // ========================================

  const formatDate = (
    dateValue
  ) => {
    if (!dateValue) {
      return "-";
    }

    const date =
      new Date(
        dateValue
      );

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return dateValue;
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  // ========================================
  // JSX
  // ========================================

  return (
    <div className="nptel-page">
      {/* PAGE HEADING */}

      <section className="nptel-heading">
        <div>
          <p className="nptel-eyebrow">
            ONLINE CERTIFICATION
          </p>

          <h1>
            NPTEL Courses
          </h1>

          <p>
            Submit completed NPTEL or
            SWAYAM courses, upload
            certificates, record
            contributions and monitor
            approval status.
          </p>
        </div>

        <div className="nptel-total">
          <span>
            Total NPTEL Records
          </span>

          <strong>
            {
              facultyNPTELRecords.length
            }
          </strong>
        </div>
      </section>

      {/* STATS */}

      <section className="nptel-stats">
        <article>
          <span>
            Total Submitted
          </span>

          <strong>
            {
              facultyNPTELRecords.length
            }
          </strong>

          <small>
            All course records
          </small>
        </article>

        <article>
          <span>
            Pending
          </span>

          <strong>
            {pendingCount}
          </strong>

          <small>
            Waiting for approval
          </small>
        </article>

        <article>
          <span>
            Approved
          </span>

          <strong>
            {approvedCount}
          </strong>

          <small>
            Verified records
          </small>
        </article>

        <article>
          <span>
            Contributions
          </span>

          <strong>
            {contributionCount}
          </strong>

          <small>
            Follow-up contributions
          </small>
        </article>
      </section>

      {/* FORM */}

      <section className="nptel-form-card">
        <div className="nptel-card-header">
          <div>
            <h2>
              {isContributionEditing
                ? "Edit Rejected Contribution"
                : isMainEditing
                ? "Edit Rejected NPTEL Course"
                : "Add New NPTEL Course"}
            </h2>

            <p>
              {isContributionEditing
                ? "The approved NPTEL course details are locked. Correct only the rejected contribution and resubmit it for administrator review."
                : isMainEditing
                ? "Correct the rejected NPTEL record and resubmit it for administrator review."
                : "Enter course details, upload the certificate and provide contribution details when applicable."}
            </p>
          </div>

          <span>
            {isContributionEditing
              ? "Contribution Resubmission"
              : isMainEditing
              ? "Resubmission"
              : "New Submission"}
          </span>
        </div>

        <form
          className="nptel-form"
          onSubmit={handleSubmit}
        >
          <div className="nptel-form-grid">
            {/* COURSE TITLE */}

            <div className="nptel-field nptel-field--full">
              <label htmlFor="title">
                Course Title
              </label>

              <input
                id="title"
                type="text"
                name="title"
                disabled={
                  isContributionEditing
                }
                placeholder="Enter NPTEL course title"
                value={
                  formData.title
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* COURSE CODE */}

            <div className="nptel-field">
              <label htmlFor="courseCode">
                Course Code
              </label>

              <input
                id="courseCode"
                type="text"
                name="courseCode"
                disabled={
                  isContributionEditing
                }
                placeholder="Example: NOC26-CS01"
                value={
                  formData.courseCode
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* INSTITUTION */}

            <div className="nptel-field">
              <label htmlFor="institution">
                Platform / Institution
              </label>

              <input
                id="institution"
                type="text"
                name="institution"
                disabled={
                  isContributionEditing
                }
                placeholder="Example: NPTEL / SWAYAM"
                value={
                  formData.institution
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* COURSE DURATION */}

            <div className="nptel-field">
              <label htmlFor="courseWeeks">
                Course Duration
              </label>

              <select
                id="courseWeeks"
                name="courseWeeks"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.courseWeeks
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Course
                  Duration
                </option>

                <option value="4 Weeks">
                  4 Weeks
                </option>

                <option value="6 Weeks">
                  6 Weeks
                </option>

                <option value="8 Weeks">
                  8 Weeks
                </option>

                <option value="12 Weeks">
                  12 Weeks
                </option>
              </select>
            </div>

            {/* CERTIFICATE TYPE */}

            <div className="nptel-field">
              <label htmlFor="certificateType">
                Certificate Category
              </label>

              <select
                id="certificateType"
                name="certificateType"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.certificateType
                }
                onChange={
                  handleChange
                }
              >
                <option value="">
                  Select Certificate
                  Category
                </option>

                <option value="Successfully Completed">
                  Successfully
                  Completed
                </option>

                <option value="Elite">
                  Elite
                </option>

                <option value="Elite + Silver">
                  Elite + Silver
                </option>

                <option value="Elite + Gold">
                  Elite + Gold
                </option>

                <option value="Topper">
                  Topper
                </option>
              </select>
            </div>

            {/* START DATE */}

            <div className="nptel-field">
              <label htmlFor="startDate">
                Course Start Date
              </label>

              <input
                id="startDate"
                type="date"
                name="startDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.startDate
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* END DATE */}

            <div className="nptel-field">
              <label htmlFor="endDate">
                Course End Date
              </label>

              <input
                id="endDate"
                type="date"
                name="endDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.endDate
                }
                min={
                  formData.startDate
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* EXAM DATE */}

            <div className="nptel-field">
              <label htmlFor="examDate">
                Examination Date
              </label>

              <input
                id="examDate"
                type="date"
                name="examDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.examDate
                }
                onChange={
                  handleChange
                }
              />
            </div>

            {/* SCORE */}

            <div className="nptel-field">
              <label htmlFor="score">
                Final Score (%)
              </label>

              <input
                id="score"
                type="text"
                name="score"
                disabled={
                  isContributionEditing
                }
                inputMode="decimal"
                placeholder="Example: 82"
                value={
                  formData.score
                }
                onChange={
                  handleChange
                }
              />
            </div>

            {/* RESULT */}

            <div className="nptel-field">
              <label htmlFor="result">
                Result
              </label>

              <select
                id="result"
                name="result"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.result
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Result
                </option>

                <option value="Passed">
                  Passed
                </option>

                <option value="Completed">
                  Completed
                </option>

                <option value="Elite">
                  Elite
                </option>

                <option value="Elite + Silver">
                  Elite + Silver
                </option>

                <option value="Elite + Gold">
                  Elite + Gold
                </option>
              </select>
            </div>

            {/* ACADEMIC YEAR */}

            <div className="nptel-field">
              <label htmlFor="academicYear">
                Academic Year
              </label>

              <select
                id="academicYear"
                name="academicYear"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.academicYear
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="2024–2025">
                  2024–2025
                </option>

                <option value="2025–2026">
                  2025–2026
                </option>

                <option value="2026–2027">
                  2026–2027
                </option>
              </select>
            </div>

            {/* DESCRIPTION */}

            <div className="nptel-field nptel-field--full">
              <label htmlFor="description">
                Course Description
              </label>

              <textarea
                id="description"
                name="description"
                disabled={
                  isContributionEditing
                }
                rows={4}
                placeholder="Enter a short description of the course"
                value={
                  formData.description
                }
                onChange={
                  handleChange
                }
              />
            </div>

            {/* CERTIFICATE */}

            <div className="nptel-field nptel-field--full">
              <label htmlFor="nptel-proof">
                NPTEL Certificate /
                Supporting Proof
              </label>

              <div className="nptel-upload-box">
                <input
                  id="nptel-proof"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.webp"
                  disabled={
                    isContributionEditing
                  }
                  onChange={
                    handleProofUpload
                  }
                />

                <div>
                  <strong>
                    Upload NPTEL
                    certificate
                  </strong>

                  <span>
                    PDF, JPG, PNG or
                    WEBP. Maximum size
                    2 MB.
                  </span>

                  {formData.proofName && (
                    <small>
                      Selected:{" "}
                      {
                        formData.proofName
                      }
                    </small>
                  )}
                </div>
              </div>
            </div>

            {/* ========================================
                CONTRIBUTION
            ======================================== */}

            <div className="nptel-contribution-section">
              <div className="nptel-contribution-heading">
                <h2>
                  Contribution and
                  Impact
                </h2>

                <p>
                  Mention whether you
                  applied or shared the
                  knowledge gained from
                  this NPTEL course with
                  students or the
                  department.
                </p>
              </div>

              <div className="nptel-contribution-grid">
                {/* CONTRIBUTION DONE */}

                <div className="nptel-field nptel-field--full">
                  <label htmlFor="contributionDone">
                    Did you make any
                    contribution based
                    on this NPTEL
                    course?
                  </label>

                  <select
                    id="contributionDone"
                    name="contributionDone"
                    disabled={
                      isContributionEditing
                    }
                    value={
                      formData.contributionDone
                    }
                    onChange={
                      handleChange
                    }
                  >
                    <option value="No">
                      No
                    </option>

                    <option value="Yes">
                      Yes
                    </option>
                  </select>
                </div>

                {formData.contributionDone ===
                  "Yes" && (
                  <>
                    {/* TYPE */}

                    <div className="nptel-field">
                      <label htmlFor="contributionType">
                        Contribution
                        Type
                      </label>

                      <select
                        id="contributionType"
                        name="contributionType"
                        value={
                          formData.contributionType
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select
                          Contribution
                          Type
                        </option>

                        <option value="Class Conducted">
                          Class Conducted
                        </option>

                        <option value="Workshop Conducted">
                          Workshop
                          Conducted
                        </option>

                        <option value="Seminar Conducted">
                          Seminar
                          Conducted
                        </option>

                        <option value="Department Training">
                          Department
                          Training
                        </option>

                        <option value="Student Mentoring">
                          Student
                          Mentoring
                        </option>

                        <option value="Curriculum Improvement">
                          Curriculum
                          Improvement
                        </option>

                        <option value="Lab Improvement">
                          Lab Improvement
                        </option>

                        <option value="Project Guidance">
                          Project
                          Guidance
                        </option>

                        <option value="Research Guidance">
                          Research
                          Guidance
                        </option>

                        <option value="Other">
                          Other
                        </option>
                      </select>
                    </div>

                    {/* TITLE */}

                    <div className="nptel-field">
                      <label htmlFor="contributionTitle">
                        Contribution
                        Title
                      </label>

                      <input
                        id="contributionTitle"
                        type="text"
                        name="contributionTitle"
                        placeholder="Enter contribution title"
                        value={
                          formData.contributionTitle
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />
                    </div>

                    {/* DATE */}

                    <div className="nptel-field">
                      <label htmlFor="contributionDate">
                        Contribution
                        Date
                      </label>

                      <input
                        id="contributionDate"
                        type="date"
                        name="contributionDate"
                        value={
                          formData.contributionDate
                        }
                        min={
                          formData.startDate
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />
                    </div>

                    {/* CONTRIBUTION FOR */}

                    <div className="nptel-field">
                      <label htmlFor="contributionFor">
                        Contribution For
                      </label>

                      <select
                        id="contributionFor"
                        name="contributionFor"
                        value={
                          formData.contributionFor
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select
                          Contribution For
                        </option>

                        <option value="Students">
                          Students
                        </option>

                        <option value="Department">
                          Department
                        </option>

                        <option value="Both">
                          Both
                        </option>
                      </select>
                    </div>

                    {/* STUDENT */}

                    {(formData.contributionFor ===
                      "Students" ||
                      formData.contributionFor ===
                        "Both") && (
                      <>
                        <div className="nptel-field">
                          <label htmlFor="targetGroup">
                            Target Class /
                            Student Group
                          </label>

                          <input
                            id="targetGroup"
                            type="text"
                            name="targetGroup"
                            placeholder="Example: S6 CSE Students"
                            value={
                              formData.targetGroup
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>

                        <div className="nptel-field">
                          <label htmlFor="participantCount">
                            Number of
                            Students
                          </label>

                          <input
                            id="participantCount"
                            type="number"
                            name="participantCount"
                            min="1"
                            placeholder="Enter number of students"
                            value={
                              formData.participantCount
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>

                        <div className="nptel-field nptel-field--full">
                          <label htmlFor="studentImpact">
                            Impact on
                            Students
                          </label>

                          <textarea
                            id="studentImpact"
                            name="studentImpact"
                            rows={3}
                            placeholder="Explain improvements in student knowledge, skills, projects or performance"
                            value={
                              formData.studentImpact
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* DEPARTMENT */}

                    {(formData.contributionFor ===
                      "Department" ||
                      formData.contributionFor ===
                        "Both") && (
                      <>
                        <div className="nptel-field nptel-field--full">
                          <label htmlFor="departmentTarget">
                            Department /
                            Target Area
                          </label>

                          <input
                            id="departmentTarget"
                            type="text"
                            name="departmentTarget"
                            placeholder="Example: CSE Department / AI Laboratory"
                            value={
                              formData.departmentTarget
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>

                        <div className="nptel-field nptel-field--full">
                          <label htmlFor="departmentImpact">
                            Impact on
                            Department
                          </label>

                          <textarea
                            id="departmentImpact"
                            name="departmentImpact"
                            rows={3}
                            placeholder="Explain improvements in teaching, curriculum, laboratory, research or department practices"
                            value={
                              formData.departmentImpact
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />
                        </div>
                      </>
                    )}

                    {/* DETAILS */}

                    <div className="nptel-field nptel-field--full">
                      <label htmlFor="contributionDescription">
                        Contribution
                        Details
                      </label>

                      <textarea
                        id="contributionDescription"
                        name="contributionDescription"
                        rows={4}
                        placeholder="Explain the class, workshop, mentoring, training or implementation completed"
                        value={
                          formData.contributionDescription
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />
                    </div>

                    {/* IMPACT */}

                    <div className="nptel-field">
                      <label htmlFor="impactLevel">
                        Impact Level
                      </label>

                      <select
                        id="impactLevel"
                        name="impactLevel"
                        value={
                          formData.impactLevel
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select Impact
                          Level
                        </option>

                        <option value="Low">
                          Low
                        </option>

                        <option value="Moderate">
                          Moderate
                        </option>

                        <option value="High">
                          High
                        </option>

                        <option value="Very High">
                          Very High
                        </option>
                      </select>
                    </div>

                    {/* CONTRIBUTION PROOF */}

                    <div className="nptel-field nptel-field--full">
                      <label htmlFor="nptel-contribution-proof">
                        Contribution
                        Supporting Proof
                      </label>

                      <div className="nptel-upload-box">
                        <input
                          id="nptel-contribution-proof"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.webp"
                          onChange={
                            handleContributionProofUpload
                          }
                        />

                        <div>
                          <strong>
                            Upload
                            attendance
                            sheet,
                            photograph,
                            feedback or
                            contribution
                            report
                          </strong>

                          <span>
                            PDF, JPG, PNG
                            or WEBP.
                            Maximum size
                            2 MB.
                          </span>

                          {formData.contributionProofName && (
                            <small>
                              Selected:{" "}
                              {
                                formData.contributionProofName
                              }
                            </small>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* MESSAGES */}

          {errorMessage && (
            <div className="nptel-message nptel-message--error">
              {errorMessage}
            </div>
          )}

          {message && (
            <div className="nptel-message nptel-message--success">
              {message}
            </div>
          )}

          <div className="nptel-form-actions">
            <button
              type="submit"
              disabled={
                submitting
              }
            >
              {submitting
                ? isEditing
                  ? "Resubmitting..."
                  : "Submitting..."
                : isContributionEditing
                ? "Update & Resubmit Contribution"
                : isMainEditing
                ? "Update & Resubmit NPTEL"
                : "Submit NPTEL Course"}
            </button>

            {isEditing && (
              <button
                type="button"
                onClick={
                  cancelEdit
                }
                disabled={
                  submitting
                }
              >
                Cancel Edit
              </button>
            )}
          </div>
        </form>
      </section>

      {/* RECORDS */}

      <section className="nptel-records-card">
        <div className="nptel-card-header">
          <div>
            <h2>
              My NPTEL Records
            </h2>

            <p>
              Review submitted
              courses, contributions
              and administrator
              approval status.
            </p>
          </div>
        </div>

        <div className="nptel-toolbar">
          <div className="nptel-search">
            <span>
              ⌕
            </span>

            <input
              type="text"
              placeholder="Search course, code, institution or contribution"
              value={
                searchText
              }
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
            />
          </div>

          <select
            value={
              statusFilter
            }
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>
          </select>
        </div>

        {loading ? (
          <div className="nptel-empty">
            <h3>
              Loading NPTEL
              records...
            </h3>
          </div>
        ) : (
          <div className="nptel-table-wrapper">
            <table className="nptel-table">
              <thead>
                <tr>
                  <th>
                    Course
                  </th>

                  <th>
                    Course Code
                  </th>

                  <th>
                    Duration
                  </th>

                  <th>
                    Score
                  </th>

                  <th>
                    Result
                  </th>

                  <th>
                    Contribution
                  </th>

                  <th>
                    Contribution For
                  </th>

                  <th>
                    Beneficiaries
                  </th>

                  <th>
                    Main Proof
                  </th>

                  <th>
                    Contribution
                    Proof
                  </th>

                  <th>
                    Activity Status
                  </th>

                  <th>
                    Contribution
                    Status
                  </th>

                  <th>
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredRecords.map(
                  (activity) => {
                    const status =
                      activity.status ||
                      "Pending";

                    const contributionStatus =
                      activity.contributionDone ===
                      "Yes"
                        ? activity.contributionStatus ||
                          "Pending"
                        : "Not Applicable";

                    return (
                      <tr
                        key={
                          activity._id
                        }
                      >
                        {/* COURSE */}

                        <td>
                          <strong>
                            {activity.title ||
                              "-"}
                          </strong>

                          <span>
                            {activity.institution ||
                              "-"}
                          </span>
                        </td>

                        {/* CODE */}

                        <td>
                          {activity.courseCode ||
                            "-"}
                        </td>

                        {/* DURATION */}

                        <td>
                          {activity.courseWeeks ||
                            "-"}
                        </td>

                        {/* SCORE */}

                        <td>
                          {activity.score !==
                            undefined &&
                          activity.score !==
                            ""
                            ? `${activity.score}%`
                            : "-"}
                        </td>

                        {/* RESULT */}

                        <td>
                          {activity.result ||
                            "-"}
                        </td>

                        {/* CONTRIBUTION */}

                        <td>
                          {activity.contributionDone ===
                          "Yes" ? (
                            <div className="nptel-contribution-cell">
                              <strong>
                                {activity.contributionType ||
                                  "-"}
                              </strong>

                              <span>
                                {activity.contributionTitle ||
                                  "-"}
                              </span>

                              <small>
                                Impact:{" "}
                                {activity.impactLevel ||
                                  "-"}
                              </small>
                            </div>
                          ) : (
                            <span className="nptel-no-contribution">
                              No
                              contribution
                            </span>
                          )}
                        </td>

                        {/* CONTRIBUTION FOR */}

                        <td>
                          {activity.contributionDone ===
                          "Yes"
                            ? activity.contributionFor ||
                              "-"
                            : "-"}
                        </td>

                        {/* BENEFICIARIES */}

                        <td>
                          {activity.contributionDone !==
                          "Yes"
                            ? "-"
                            : activity.contributionFor ===
                                "Students" ||
                              activity.contributionFor ===
                                "Both"
                            ? `${
                                activity.participantCount ||
                                0
                              } Students`
                            : activity.departmentTarget ||
                              "Department"}
                        </td>

                        {/* MAIN PROOF */}

                        <td>
                          {activity.proof ? (
                            <a
                              href={
                                activity.proof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            "Not uploaded"
                          )}
                        </td>

                        {/* CONTRIBUTION PROOF */}

                        <td>
                          {activity.contributionProof ? (
                            <a
                              href={
                                activity.contributionProof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            "Not applicable"
                          )}
                        </td>

                        {/* ACTIVITY STATUS */}

                        <td>
                          <span
                            className={`nptel-status nptel-status--${status.toLowerCase()}`}
                          >
                            {status}
                          </span>

                          {status ===
                            "Rejected" &&
                            activity.rejectionReason && (
                              <small className="nptel-rejection-reason">
                                {
                                  activity.rejectionReason
                                }
                              </small>
                            )}
                        </td>

                        {/* CONTRIBUTION STATUS */}

                        <td>
                          <span
                            className={`nptel-status ${
                              contributionStatus ===
                              "Not Applicable"
                                ? ""
                                : `nptel-status--${contributionStatus.toLowerCase()}`
                            }`}
                          >
                            {
                              contributionStatus
                            }
                          </span>

                          {contributionStatus ===
                            "Rejected" &&
                            activity.contributionReviewComment && (
                              <small className="nptel-rejection-reason">
                                {
                                  activity.contributionReviewComment
                                }
                              </small>
                            )}
                        </td>

                        {/* ACTION */}

                        <td>
                          {status ===
                            "Rejected" && (
                            <button
                              type="button"
                              className="nptel-delete-button"
                              onClick={() =>
                                startEditRejectedActivity(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit
                            </button>
                          )}

                          {status ===
                            "Approved" &&
                          contributionStatus ===
                            "Rejected" && (
                            <button
                              type="button"
                              className="nptel-delete-button"
                              onClick={() =>
                                startEditRejectedContribution(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit Contribution
                            </button>
                          )}

                          {status ===
                            "Pending" && (
                            <button
                              type="button"
                              className="nptel-delete-button"
                              onClick={() =>
                                handleDelete(
                                  activity
                                )
                              }
                            >
                              Delete
                            </button>
                          )}

                          {status ===
                            "Approved" &&
                            contributionStatus !==
                              "Rejected" && (
                              <span>
                                Locked
                              </span>
                            )}
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>

            {filteredRecords.length ===
              0 && (
              <div className="nptel-empty">
                <div>
                  ▶
                </div>

                <h3>
                  No NPTEL records
                  found
                </h3>

                <p>
                  Submit your first
                  NPTEL or SWAYAM
                  course using the
                  form above.
                </p>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

export default NPTELCourses;