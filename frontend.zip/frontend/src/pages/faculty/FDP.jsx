import {
  useEffect,
  useMemo,
  useState,
} from "react";

import "./FDP.css";

const API_URL =
  "http://localhost:5000/api/activities";

const getLoggedInFaculty = () => {
  try {
    const value =
      localStorage.getItem(
        "loggedInFaculty"
      );

    return value
      ? JSON.parse(value)
      : null;
  } catch (error) {
    console.error(
      "Unable to read logged-in faculty:",
      error
    );

    return null;
  }
};

const toClassSuffix = (
  value,
  fallback = "pending"
) =>
  String(value || fallback)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-");

function FDP() {
  const [loggedInFaculty] =
    useState(
      () => getLoggedInFaculty()
    );

  const [formData, setFormData] =
    useState({
      title: "",
      organizer: "",
      mode: "",
      startDate: "",
      endDate: "",
      duration: "",
      academicYear: "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone: "No",
      contributionType: "",
      contributionTitle: "",
      contributionDate: "",
      contributionFor: "",

      targetGroup: "",
      participantCount: "",
      studentImpact: "",

      departmentTarget: "",
      departmentImpact: "",

      contributionDescription: "",
      impactLevel: "",
      contributionProof: "",
      contributionProofName: "",
    });

  const [activities, setActivities] =
    useState([]);

  const [searchText, setSearchText] =
    useState("");

  const [
    statusFilter,
    setStatusFilter,
  ] = useState("All");

  const [message, setMessage] =
    useState("");

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [loading, setLoading] =
    useState(true);

  const [
    submitting,
    setSubmitting,
  ] = useState(false);

  const [
    editingActivityId,
    setEditingActivityId,
  ] = useState(null);

  const [
    editingMode,
    setEditingMode,
  ] = useState(null);

  const isEditing =
    Boolean(editingActivityId);

  const isContributionEditing =
    editingMode ===
    "contribution";

  const isMainEditing =
    editingMode ===
    "main";

  // =====================================================
  // LOAD FDP ACTIVITIES FROM MONGODB
  // =====================================================

  const loadActivities = async () => {
    if (!loggedInFaculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(
          loggedInFaculty.facultyId
        )}`,
        {
          method: "GET",

          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load FDP activities."
        );
      }

      setActivities(
        data.activities || []
      );
    } catch (error) {
      console.error(
        "FDP load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  // =====================================================
  // FDP RECORDS
  // =====================================================

  const facultyFDPRecords =
    useMemo(
      () =>
        activities.filter(
          (activity) =>
            activity.type ===
            "FDP"
        ),
      [activities]
    );

  // =====================================================
  // SEARCH + FILTER
  // =====================================================

  const filteredRecords =
    useMemo(() => {
      const value =
        searchText
          .trim()
          .toLowerCase();

      return facultyFDPRecords.filter(
        (activity) => {
          const status =
            activity.status ||
            "Pending";

          const searchableValues = [
            activity.title,
            activity.organizer,
            activity.mode,
            activity.academicYear,
            activity.contributionTitle,
            activity.contributionType,
            activity.contributionFor,
            activity.targetGroup,
            activity.departmentTarget,
          ];

          const matchesSearch =
            !value ||
            searchableValues.some(
              (item) =>
                String(
                  item || ""
                )
                  .toLowerCase()
                  .includes(value)
            );

          const matchesStatus =
            statusFilter === "All" ||
            status === statusFilter;

          return (
            matchesSearch &&
            matchesStatus
          );
        }
      );
    }, [
      facultyFDPRecords,
      searchText,
      statusFilter,
    ]);

  // =====================================================
  // COUNTS
  // =====================================================

  const pendingCount =
    facultyFDPRecords.filter(
      (activity) =>
        (activity.status ||
          "Pending") === "Pending"
    ).length;

  const approvedCount =
    facultyFDPRecords.filter(
      (activity) =>
        activity.status ===
        "Approved"
    ).length;

  const contributionCount =
    facultyFDPRecords.filter(
      (activity) =>
        activity.contributionDone ===
        "Yes"
    ).length;

  // =====================================================
  // FORM CHANGE
  // =====================================================

  const handleChange = (event) => {
    const {
      name,
      value,
    } = event.target;

    let updatedValue = value;

    if (
      name === "participantCount"
    ) {
      updatedValue = value
        .replace(/\D/g, "")
        .slice(0, 5);
    }

    setFormData(
      (previous) => ({
        ...previous,
        [name]: updatedValue,
      })
    );

    setMessage("");
    setErrorMessage("");

    if (
      name ===
        "contributionDone" &&
      value === "No"
    ) {
      setFormData(
        (previous) => ({
          ...previous,

          contributionDone:
            "No",

          contributionType: "",
          contributionTitle: "",
          contributionDate: "",
          contributionFor: "",

          targetGroup: "",
          participantCount: "",
          studentImpact: "",

          departmentTarget: "",
          departmentImpact: "",

          contributionDescription:
            "",

          impactLevel: "",

          contributionProof: "",
          contributionProofName:
            "",
        })
      );

      const input =
        document.getElementById(
          "fdp-contribution-proof"
        );

      if (input) {
        input.value = "";
      }
    }

    if (
      name === "contributionFor"
    ) {
      if (
        value === "Students"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Students",

            departmentTarget:
              "",

            departmentImpact:
              "",
          })
        );
      }

      if (
        value === "Department"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Department",

            targetGroup: "",

            participantCount:
              "",

            studentImpact:
              "",
          })
        );
      }
    }
  };

  // =====================================================
  // FILE VALIDATION
  // =====================================================

  const validateFile = (file) => {
    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (
      !allowedTypes.includes(
        file.type
      )
    ) {
      return "Upload only PDF, JPG, PNG or WEBP files.";
    }

    const max =
      2 * 1024 * 1024;

    if (file.size > max) {
      return "The selected file must be smaller than 2 MB.";
    }

    return "";
  };

  // =====================================================
  // MAIN PROOF UPLOAD
  // =====================================================

  const handleProofUpload = (
    event
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) {
      return;
    }

    const error =
      validateFile(file);

    if (error) {
      setErrorMessage(error);

      event.target.value = "";

      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      setFormData(
        (previous) => ({
          ...previous,

          proof:
            reader.result,

          proofName:
            file.name,
        })
      );
    };

    reader.onerror = () => {
      setErrorMessage(
        "Unable to read the selected FDP proof."
      );
    };

    reader.readAsDataURL(file);
  };

  // =====================================================
  // CONTRIBUTION PROOF UPLOAD
  // =====================================================

  const handleContributionProofUpload =
    (event) => {
      const file =
        event.target.files?.[0];

      if (!file) {
        return;
      }

      const error =
        validateFile(file);

      if (error) {
        setErrorMessage(error);

        event.target.value = "";

        return;
      }

      const reader =
        new FileReader();

      reader.onload = () => {
        setFormData(
          (previous) => ({
            ...previous,

            contributionProof:
              reader.result,

            contributionProofName:
              file.name,
          })
        );
      };

      reader.onerror = () => {
        setErrorMessage(
          "Unable to read the contribution proof."
        );
      };

      reader.readAsDataURL(
        file
      );
    };

  // =====================================================
  // DURATION
  // =====================================================

  const calculateDuration = () => {
    if (
      !formData.startDate ||
      !formData.endDate
    ) {
      return "";
    }

    const start =
      new Date(
        formData.startDate
      );

    const end =
      new Date(
        formData.endDate
      );

    if (end < start) {
      return "";
    }

    const difference =
      end.getTime() -
      start.getTime();

    const days =
      Math.floor(
        difference /
          (1000 *
            60 *
            60 *
            24)
      ) + 1;

    return `${days} day${
      days > 1 ? "s" : ""
    }`;
  };

  // =====================================================
  // RESET FORM
  // =====================================================

  const resetForm = (
    options = {}
  ) => {
    const {
      keepEditingState = false,
    } = options;

    setFormData({
      title: "",
      organizer: "",
      mode: "",
      startDate: "",
      endDate: "",
      duration: "",
      academicYear:
        "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone:
        "No",

      contributionType:
        "",

      contributionTitle:
        "",

      contributionDate:
        "",

      contributionFor:
        "",

      targetGroup: "",

      participantCount:
        "",

      studentImpact: "",

      departmentTarget:
        "",

      departmentImpact:
        "",

      contributionDescription:
        "",

      impactLevel: "",

      contributionProof:
        "",

      contributionProofName:
        "",
    });

    const proofInput =
      document.getElementById(
        "fdp-proof"
      );

    if (proofInput) {
      proofInput.value = "";
    }

    const contributionInput =
      document.getElementById(
        "fdp-contribution-proof"
      );

    if (contributionInput) {
      contributionInput.value =
        "";
    }

    if (!keepEditingState) {
      setEditingActivityId(
        null
      );

      setEditingMode(
        null
      );
    }
  };

  // =====================================================
  // EDIT / RESUBMIT REJECTED FDP
  // =====================================================

  const startEditRejectedActivity = (
    activity
  ) => {
    if (
      activity.status !==
      "Rejected"
    ) {
      setErrorMessage(
        "Only rejected FDP records can be edited and resubmitted."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "main"
    );

    setMessage("");
    setErrorMessage("");

    setFormData({
      title:
        activity.title || "",

      organizer:
        activity.organizer || "",

      mode:
        activity.mode || "",

      startDate:
        activity.startDate
          ? String(
              activity.startDate
            ).slice(0, 10)
          : "",

      endDate:
        activity.endDate
          ? String(
              activity.endDate
            ).slice(0, 10)
          : "",

      duration:
        activity.duration || "",

      academicYear:
        activity.academicYear ||
        "2026–2027",

      description:
        activity.description || "",

      proof:
        activity.proof || "",

      proofName:
        activity.proofName ||
        (activity.proof
          ? "Existing FDP proof"
          : ""),

      contributionDone:
        activity.contributionDone ===
        "Yes"
          ? "Yes"
          : "No",

      contributionType:
        activity.contributionType ||
        "",

      contributionTitle:
        activity.contributionTitle ||
        "",

      contributionDate:
        activity.contributionDate
          ? String(
              activity.contributionDate
            ).slice(0, 10)
          : "",

      contributionFor:
        activity.contributionFor ||
        "",

      targetGroup:
        activity.targetGroup || "",

      participantCount:
        activity.participantCount
          ? String(
              activity.participantCount
            )
          : "",

      studentImpact:
        activity.studentImpact || "",

      departmentTarget:
        activity.departmentTarget ||
        "",

      departmentImpact:
        activity.departmentImpact ||
        "",

      contributionDescription:
        activity.contributionDescription ||
        "",

      impactLevel:
        activity.impactLevel || "",

      contributionProof:
        activity.contributionProof ||
        "",

      contributionProofName:
        activity.contributionProofName ||
        (activity.contributionProof
          ? "Existing contribution proof"
          : ""),
    });

    const proofInput =
      document.getElementById(
        "fdp-proof"
      );

    if (proofInput) {
      proofInput.value = "";
    }

    const contributionInput =
      document.getElementById(
        "fdp-contribution-proof"
      );

    if (contributionInput) {
      contributionInput.value =
        "";
    }

    window.setTimeout(
      () => {
        document
          .querySelector(
            ".fdp-form-card"
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      },
      0
    );
  };

  // =====================================================
  // EDIT / RESUBMIT REJECTED CONTRIBUTION
  // MAIN FDP REMAINS APPROVED + LOCKED
  // =====================================================

  const startEditRejectedContribution = (
    activity
  ) => {
    const status =
      activity.status ||
      "Pending";

    const contributionStatus =
      activity.contributionDone ===
      "Yes"
        ? activity.contributionStatus ||
          "Pending"
        : "Not Applicable";

    if (
      status !== "Approved" ||
      activity.contributionDone !==
        "Yes" ||
      contributionStatus !==
        "Rejected"
    ) {
      setErrorMessage(
        "Only a rejected contribution from an approved FDP can be edited here."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "contribution"
    );

    setMessage("");
    setErrorMessage("");

    setFormData({
      title:
        activity.title || "",

      organizer:
        activity.organizer || "",

      mode:
        activity.mode || "",

      startDate:
        activity.startDate
          ? String(
              activity.startDate
            ).slice(0, 10)
          : "",

      endDate:
        activity.endDate
          ? String(
              activity.endDate
            ).slice(0, 10)
          : "",

      duration:
        activity.duration || "",

      academicYear:
        activity.academicYear ||
        "2026–2027",

      description:
        activity.description || "",

      proof:
        activity.proof || "",

      proofName:
        activity.proofName ||
        (activity.proof
          ? "Existing FDP proof"
          : ""),

      contributionDone:
        "Yes",

      contributionType:
        activity.contributionType ||
        "",

      contributionTitle:
        activity.contributionTitle ||
        "",

      contributionDate:
        activity.contributionDate
          ? String(
              activity.contributionDate
            ).slice(0, 10)
          : "",

      contributionFor:
        activity.contributionFor ||
        "",

      targetGroup:
        activity.targetGroup || "",

      participantCount:
        activity.participantCount
          ? String(
              activity.participantCount
            )
          : "",

      studentImpact:
        activity.studentImpact || "",

      departmentTarget:
        activity.departmentTarget ||
        "",

      departmentImpact:
        activity.departmentImpact ||
        "",

      contributionDescription:
        activity.contributionDescription ||
        "",

      impactLevel:
        activity.impactLevel || "",

      contributionProof:
        activity.contributionProof ||
        "",

      contributionProofName:
        activity.contributionProofName ||
        (activity.contributionProof
          ? "Existing contribution proof"
          : ""),
    });

    const proofInput =
      document.getElementById(
        "fdp-proof"
      );

    if (proofInput) {
      proofInput.value = "";
    }

    const contributionInput =
      document.getElementById(
        "fdp-contribution-proof"
      );

    if (contributionInput) {
      contributionInput.value =
        "";
    }

    window.setTimeout(
      () => {
        document
          .querySelector(
            ".fdp-form-card"
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      },
      0
    );
  };

  const cancelEdit = () => {
    resetForm();

    setMessage(
      "Edit cancelled."
    );

    setErrorMessage("");
  };

  // =====================================================
  // VALIDATION
  // =====================================================

  const validateForm = () => {
    if (
      !formData.title.trim() ||
      !formData.organizer.trim() ||
      !formData.mode ||
      !formData.startDate ||
      !formData.endDate ||
      !formData.academicYear
    ) {
      return "Please complete all required FDP fields.";
    }

    if (
      new Date(
        formData.endDate
      ) <
      new Date(
        formData.startDate
      )
    ) {
      return "FDP end date cannot be earlier than the start date.";
    }

    if (!formData.proof) {
      return "Please upload the FDP certificate or supporting proof.";
    }

    if (
      formData.contributionDone ===
      "Yes"
    ) {
      if (
        !formData.contributionType ||
        !formData.contributionTitle.trim() ||
        !formData.contributionDate ||
        !formData.contributionFor ||
        !formData.impactLevel ||
        !formData.contributionDescription.trim()
      ) {
        return "Please complete all required contribution details.";
      }

      if (
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.targetGroup.trim() ||
          !formData.participantCount ||
          !formData.studentImpact.trim()
        ) {
          return "Please complete all student contribution and impact details.";
        }

        if (
          Number(
            formData.participantCount
          ) < 1
        ) {
          return "Number of students must be at least 1.";
        }
      }

      if (
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.departmentTarget.trim() ||
          !formData.departmentImpact.trim()
        ) {
          return "Please complete all department contribution and impact details.";
        }
      }

      if (
        new Date(
          formData.contributionDate
        ) <
        new Date(
          formData.startDate
        )
      ) {
        return "Contribution date cannot be earlier than the FDP start date.";
      }

      if (
        !formData.contributionProof
      ) {
        return "Please upload supporting proof for the contribution.";
      }
    }

    return "";
  };

  // =====================================================
  // SUBMIT TO MONGODB
  // =====================================================

  const handleSubmit =
    async (event) => {
      event.preventDefault();

      setMessage("");
      setErrorMessage("");

      const validationError =
        validateForm();

      if (validationError) {
        setErrorMessage(
          validationError
        );

        return;
      }

      const token =
        localStorage.getItem(
          "token"
        );

      if (!token) {
        setErrorMessage(
          "Authentication token not found. Please login again."
        );

        return;
      }

      const isStudent =
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both";

      const isDepartment =
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both";

      /*
        IMPORTANT:
        Faculty identity is NOT sent from the browser.
        The backend should get facultyId, facultyName
        and department from the authenticated JWT/user.
      */

      const newActivity = {
        type: "FDP",

        title:
          formData.title.trim(),

        organizer:
          formData.organizer.trim(),

        mode:
          formData.mode,

        startDate:
          formData.startDate,

        endDate:
          formData.endDate,

        activityDate:
          formData.startDate,

        duration:
          formData.duration.trim() ||
          calculateDuration(),

        academicYear:
          formData.academicYear,

        description:
          formData.description.trim(),

        proof:
          formData.proof,

        proofName:
          formData.proofName,

        contributionDone:
          formData.contributionDone,

        contributionType:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionType
            : "",

        contributionTitle:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionTitle.trim()
            : "",

        contributionDate:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDate
            : null,

        contributionFor:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionFor
            : "",

        targetGroup:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.targetGroup.trim()
            : "",

        participantCount:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? Number(
                formData.participantCount
              )
            : 0,

        studentImpact:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.studentImpact.trim()
            : "",

        departmentTarget:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentTarget.trim()
            : "",

        departmentImpact:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentImpact.trim()
            : "",

        contributionDescription:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDescription.trim()
            : "",

        impactLevel:
          formData.contributionDone ===
          "Yes"
            ? formData.impactLevel
            : "",

        contributionProof:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProof
            : "",

        contributionProofName:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProofName
            : "",
      };

      try {
        setSubmitting(true);

        const requestUrl =
          isEditing
            ? `${API_URL}/${editingActivityId}`
            : API_URL;

        const requestMethod =
          isEditing
            ? "PUT"
            : "POST";

        const response =
          await fetch(
            requestUrl,
            {
              method:
                requestMethod,

              headers: {
                "Content-Type":
                  "application/json",

                Authorization:
                  `Bearer ${token}`,
              },

              body:
                JSON.stringify(
                  newActivity
                ),
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              (isEditing
                ? "Unable to resubmit FDP."
                : "Unable to submit FDP.")
          );
        }

        if (data.activity) {
          setActivities(
            (previous) =>
              isEditing
                ? previous.map(
                    (activity) =>
                      activity._id ===
                      data.activity._id
                        ? data.activity
                        : activity
                  )
                : [
                    data.activity,
                    ...previous,
                  ]
          );
        } else {
          await loadActivities();
        }

        const wasEditing =
          isEditing;

        const wasContributionEditing =
          isContributionEditing;

        resetForm();

        setMessage(
          wasContributionEditing
            ? "Rejected contribution updated and resubmitted successfully. The FDP remains approved and the contribution is now waiting for administrator review."
            : wasEditing
            ? "Rejected FDP updated and resubmitted successfully. It is now waiting for administrator review."
            : "FDP record submitted successfully. The activity is waiting for administrator approval."
        );
      } catch (error) {
        console.error(
          isEditing
            ? "FDP resubmission error:"
            : "FDP submission error:",
          error
        );

        setErrorMessage(
          error.message ||
            (isEditing
              ? "Unable to resubmit FDP."
              : "Unable to submit FDP.")
        );
      } finally {
        setSubmitting(false);
      }
    };

  // =====================================================
  // DELETE FROM MONGODB
  // =====================================================

  const handleDelete =
    async (activity) => {
      const status =
        activity.status ||
        "Pending";

      /*
        Your backend allows faculty deletion
        only for Pending activities.
      */

      if (
        status !== "Pending"
      ) {
        alert(
          "Only pending FDP records can be deleted."
        );

        return;
      }

      if (
        editingActivityId ===
        activity._id
      ) {
        setErrorMessage(
          "Cancel editing before deleting this FDP record."
        );
        return;
      }

      const confirmed =
        window.confirm(
          "Are you sure you want to delete this FDP record?"
        );

      if (!confirmed) {
        return;
      }

      try {
        setMessage("");
        setErrorMessage("");

        const token =
          localStorage.getItem(
            "token"
          );

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/${activity._id}`,
            {
              method:
                "DELETE",

              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to delete FDP."
          );
        }

        setActivities(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !==
                activity._id
            )
        );

        setMessage(
          "FDP record deleted successfully."
        );
      } catch (error) {
        console.error(
          "FDP delete error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to delete FDP."
        );
      }
    };

  // =====================================================
  // DATE FORMATTER
  // =====================================================

  const formatDate = (value) => {
    if (!value) {
      return "-";
    }

    const date =
      new Date(value);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return String(value);
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  // =====================================================
  // NO FACULTY LOGIN
  // =====================================================

  if (!loggedInFaculty) {
    return (
      <div className="fdp-no-user">
        <h1>
          Faculty login not found
        </h1>

        <p>
          Please log in again.
        </p>

        <button
          type="button"
          onClick={() => {
            window.location.href =
              "/";
          }}
        >
          Back to Login
        </button>
      </div>
    );
  }

  // =====================================================
  // JSX
  // =====================================================

  return (
    <div className="fdp-page">

      {/* HEADER */}

      <section className="fdp-heading">
        <div>
          <p className="fdp-eyebrow">
            PROFESSIONAL DEVELOPMENT
          </p>

          <h1>
            Faculty Development
            Programmes
          </h1>

          <p>
            Submit FDP records,
            upload certificates,
            record follow-up
            contributions and monitor
            approval status.
          </p>
        </div>

        <div className="fdp-total">
          <span>
            Total FDP Records
          </span>

          <strong>
            {
              facultyFDPRecords.length
            }
          </strong>
        </div>
      </section>

      {/* STATS */}

      <section className="fdp-stats">

        <article>
          <span>
            Total Submitted
          </span>

          <strong>
            {
              facultyFDPRecords.length
            }
          </strong>

          <small>
            All FDP records
          </small>
        </article>

        <article>
          <span>
            Pending
          </span>

          <strong>
            {pendingCount}
          </strong>

          <small>
            Waiting for approval
          </small>
        </article>

        <article>
          <span>
            Approved
          </span>

          <strong>
            {approvedCount}
          </strong>

          <small>
            Verified records
          </small>
        </article>

        <article>
          <span>
            Contributions
          </span>

          <strong>
            {contributionCount}
          </strong>

          <small>
            Follow-up contributions
          </small>
        </article>

      </section>

      {/* FORM */}

      <section className="fdp-form-card">

        <div className="fdp-card-header">
          <div>
            <h2>
              {isContributionEditing
                ? "Edit Rejected Contribution"
                : isMainEditing
                ? "Edit Rejected FDP Record"
                : "Add New FDP Record"}
            </h2>

            <p>
              {isContributionEditing
                ? "The approved FDP details are locked. Correct only the rejected contribution and resubmit it for administrator review."
                : isMainEditing
                ? "Correct the rejected record and resubmit it for administrator review."
                : "Enter programme details, upload the certificate and provide contribution details when applicable."}
            </p>
          </div>

          <span>
            {isContributionEditing
              ? "Contribution Resubmission"
              : isMainEditing
              ? "Resubmission"
              : "New Submission"}
          </span>
        </div>

        <form
          className="fdp-form"
          onSubmit={handleSubmit}
        >
          <div className="fdp-form-grid">

            <div className="fdp-field fdp-field--full">
              <label>
                FDP Title
              </label>

              <input
                name="title"
                value={
                  formData.title
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                placeholder="Enter faculty development programme title"
                required
              />
            </div>

            <div className="fdp-field">
              <label>
                Organizing Institution
              </label>

              <input
                name="organizer"
                value={
                  formData.organizer
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                placeholder="Enter organizer name"
                required
              />
            </div>

            <div className="fdp-field">
              <label>
                Mode
              </label>

              <select
                name="mode"
                value={
                  formData.mode
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                required
              >
                <option value="">
                  Select Mode
                </option>

                <option value="Online">
                  Online
                </option>

                <option value="Offline">
                  Offline
                </option>

                <option value="Hybrid">
                  Hybrid
                </option>
              </select>
            </div>

            <div className="fdp-field">
              <label>
                Start Date
              </label>

              <input
                type="date"
                name="startDate"
                value={
                  formData.startDate
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                required
              />
            </div>

            <div className="fdp-field">
              <label>
                End Date
              </label>

              <input
                type="date"
                name="endDate"
                value={
                  formData.endDate
                }
                min={
                  formData.startDate
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                required
              />
            </div>

            <div className="fdp-field">
              <label>
                Duration
              </label>

              <input
                name="duration"
                value={
                  formData.duration
                }
                placeholder={
                  calculateDuration() ||
                  "Example: 5 days"
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
              />
            </div>

            <div className="fdp-field">
              <label>
                Academic Year
              </label>

              <select
                name="academicYear"
                value={
                  formData.academicYear
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                required
              >
                <option value="2024–2025">
                  2024–2025
                </option>

                <option value="2025–2026">
                  2025–2026
                </option>

                <option value="2026–2027">
                  2026–2027
                </option>
              </select>
            </div>

            <div className="fdp-field fdp-field--full">
              <label>
                FDP Description
              </label>

              <textarea
                name="description"
                rows={4}
                value={
                  formData.description
                }
                onChange={
                  handleChange
                }
                disabled={
                  isContributionEditing
                }
                placeholder="Enter a short description of the programme"
              />
            </div>

            {/* FDP PROOF */}

            <div className="fdp-field fdp-field--full">

              <label>
                FDP Certificate /
                Supporting Proof
              </label>

              <div className="fdp-upload-box">

                <input
                  id="fdp-proof"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.webp"
                  disabled={
                    isContributionEditing
                  }
                  onChange={
                    handleProofUpload
                  }
                />

                <div>
                  <strong>
                    Upload FDP certificate
                  </strong>

                  <span>
                    PDF, JPG, PNG or WEBP.
                    Maximum 2 MB.
                  </span>

                  {formData.proofName && (
                    <small>
                      {isEditing &&
                      formData.proof
                        ? "Current / selected: "
                        : "Selected: "}
                      {
                        formData.proofName
                      }
                    </small>
                  )}
                </div>

              </div>
            </div>

            {/* CONTRIBUTION */}

            <div className="fdp-contribution-section">

              <div className="fdp-contribution-heading">

                <h2>
                  Contribution and Impact
                </h2>

                <p>
                  Mention whether you
                  applied or shared the
                  knowledge gained from
                  this FDP with students
                  or the department.
                </p>

              </div>

              <div className="fdp-contribution-grid">

                <div className="fdp-field fdp-field--full">

                  <label>
                    Did you make any
                    contribution based
                    on this FDP?
                  </label>

                  <select
                    name="contributionDone"
                    value={
                      formData.contributionDone
                    }
                    onChange={
                      handleChange
                    }
                    disabled={
                      isContributionEditing
                    }
                  >
                    <option value="No">
                      No
                    </option>

                    <option value="Yes">
                      Yes
                    </option>
                  </select>

                </div>

                {formData.contributionDone ===
                  "Yes" && (
                  <>

                    <div className="fdp-field">

                      <label>
                        Contribution Type
                      </label>

                      <select
                        name="contributionType"
                        value={
                          formData.contributionType
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select Type
                        </option>

                        <option value="Class Conducted">
                          Class Conducted
                        </option>

                        <option value="Workshop Conducted">
                          Workshop Conducted
                        </option>

                        <option value="Seminar Conducted">
                          Seminar Conducted
                        </option>

                        <option value="Department Training">
                          Department Training
                        </option>

                        <option value="Student Mentoring">
                          Student Mentoring
                        </option>

                        <option value="Curriculum Improvement">
                          Curriculum Improvement
                        </option>

                        <option value="Lab Improvement">
                          Lab Improvement
                        </option>

                        <option value="Project Guidance">
                          Project Guidance
                        </option>

                        <option value="Research Guidance">
                          Research Guidance
                        </option>

                        <option value="Other">
                          Other
                        </option>
                      </select>

                    </div>

                    <div className="fdp-field">

                      <label>
                        Contribution Title
                      </label>

                      <input
                        name="contributionTitle"
                        value={
                          formData.contributionTitle
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />

                    </div>

                    <div className="fdp-field">

                      <label>
                        Contribution Date
                      </label>

                      <input
                        type="date"
                        name="contributionDate"
                        value={
                          formData.contributionDate
                        }
                        min={
                          formData.startDate
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />

                    </div>

                    <div className="fdp-field">

                      <label>
                        Contribution For
                      </label>

                      <select
                        name="contributionFor"
                        value={
                          formData.contributionFor
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select
                        </option>

                        <option value="Students">
                          Students
                        </option>

                        <option value="Department">
                          Department
                        </option>

                        <option value="Both">
                          Both
                        </option>

                      </select>

                    </div>

                    {(formData.contributionFor ===
                      "Students" ||
                      formData.contributionFor ===
                        "Both") && (
                      <>
                        <div className="fdp-field">

                          <label>
                            Target Class /
                            Student Group
                          </label>

                          <input
                            name="targetGroup"
                            value={
                              formData.targetGroup
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />

                        </div>

                        <div className="fdp-field">

                          <label>
                            Number of Students
                          </label>

                          <input
                            type="number"
                            min="1"
                            name="participantCount"
                            value={
                              formData.participantCount
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />

                        </div>

                        <div className="fdp-field fdp-field--full">

                          <label>
                            Impact on Students
                          </label>

                          <textarea
                            name="studentImpact"
                            rows={3}
                            value={
                              formData.studentImpact
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />

                        </div>
                      </>
                    )}

                    {(formData.contributionFor ===
                      "Department" ||
                      formData.contributionFor ===
                        "Both") && (
                      <>
                        <div className="fdp-field fdp-field--full">

                          <label>
                            Department /
                            Target Area
                          </label>

                          <input
                            name="departmentTarget"
                            value={
                              formData.departmentTarget
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />

                        </div>

                        <div className="fdp-field fdp-field--full">

                          <label>
                            Impact on Department
                          </label>

                          <textarea
                            name="departmentImpact"
                            rows={3}
                            value={
                              formData.departmentImpact
                            }
                            onChange={
                              handleChange
                            }
                            required
                          />

                        </div>
                      </>
                    )}

                    <div className="fdp-field fdp-field--full">

                      <label>
                        Contribution Details
                      </label>

                      <textarea
                        name="contributionDescription"
                        rows={4}
                        value={
                          formData.contributionDescription
                        }
                        onChange={
                          handleChange
                        }
                        required
                      />

                    </div>

                    <div className="fdp-field">

                      <label>
                        Impact Level
                      </label>

                      <select
                        name="impactLevel"
                        value={
                          formData.impactLevel
                        }
                        onChange={
                          handleChange
                        }
                        required
                      >
                        <option value="">
                          Select Impact
                        </option>

                        <option value="Low">
                          Low
                        </option>

                        <option value="Moderate">
                          Moderate
                        </option>

                        <option value="High">
                          High
                        </option>

                        <option value="Very High">
                          Very High
                        </option>
                      </select>

                    </div>

                    <div className="fdp-field fdp-field--full">

                      <label>
                        Contribution
                        Supporting Proof
                      </label>

                      <div className="fdp-upload-box">

                        <input
                          id="fdp-contribution-proof"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.webp"
                          onChange={
                            handleContributionProofUpload
                          }
                        />

                        <div>

                          <strong>
                            Upload contribution
                            evidence
                          </strong>

                          <span>
                            PDF, JPG, PNG or WEBP.
                            Maximum 2 MB.
                          </span>

                          {formData.contributionProofName && (
                            <small>
                              {isEditing &&
                              formData.contributionProof
                                ? "Current / selected: "
                                : "Selected: "}
                              {
                                formData.contributionProofName
                              }
                            </small>
                          )}

                        </div>

                      </div>
                    </div>

                  </>
                )}

              </div>
            </div>

          </div>

          {errorMessage && (
            <div className="fdp-message fdp-message--error">
              {errorMessage}
            </div>
          )}

          {message && (
            <div className="fdp-message fdp-message--success">
              {message}
            </div>
          )}

          <div className="fdp-form-actions">
            <button
              type="submit"
              disabled={submitting}
            >
              {submitting
                ? isEditing
                  ? "Resubmitting..."
                  : "Submitting..."
                : isContributionEditing
                ? "Update & Resubmit Contribution"
                : isMainEditing
                ? "Update & Resubmit FDP"
                : "Submit FDP Record"}
            </button>

            {isEditing && (
              <button
                type="button"
                disabled={submitting}
                onClick={
                  cancelEdit
                }
              >
                Cancel Edit
              </button>
            )}
          </div>

        </form>
      </section>

      {/* RECORDS */}

      <section className="fdp-records-card">

        <div className="fdp-card-header">

          <div>
            <h2>
              My FDP Records
            </h2>

            <p>
              Review submitted
              programmes, contributions
              and approval status.
            </p>
          </div>

        </div>

        <div className="fdp-toolbar">

          <div className="fdp-search">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search FDP title, organizer or contribution"
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
            />

          </div>

          <select
            value={statusFilter}
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>
          </select>

        </div>

        {loading ? (
          <div className="fdp-empty">
            <h3>
              Loading FDP records...
            </h3>
          </div>
        ) : (
          <div className="fdp-table-wrapper">

            <table className="fdp-table">

              <thead>
                <tr>
                  <th>
                    Programme
                  </th>

                  <th>
                    Organizer
                  </th>

                  <th>
                    Mode
                  </th>

                  <th>
                    Period
                  </th>

                  <th>
                    Contribution
                  </th>

                  <th>
                    Contribution For
                  </th>

                  <th>
                    Beneficiaries
                  </th>

                  <th>
                    Main Proof
                  </th>

                  <th>
                    Contribution Proof
                  </th>

                  <th>
                    Activity Status
                  </th>

                  <th>
                    Contribution Status
                  </th>

                  <th>
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>

                {filteredRecords.map(
                  (activity) => {
                    const status =
                      activity.status ||
                      "Pending";

                    const contributionStatus =
                      activity.contributionDone ===
                      "Yes"
                        ? activity.contributionStatus ||
                          "Pending"
                        : "Not Applicable";

                    return (
                      <tr
                        key={
                          activity._id
                        }
                      >

                        <td>
                          <strong>
                            {
                              activity.title
                            }
                          </strong>

                          <span>
                            {
                              activity.academicYear
                            }
                          </span>
                        </td>

                        <td>
                          {
                            activity.organizer ||
                            "-"
                          }
                        </td>

                        <td>
                          {
                            activity.mode ||
                            "-"
                          }
                        </td>

                        <td>
                          {formatDate(
                            activity.startDate
                          )}

                          {" to "}

                          {formatDate(
                            activity.endDate
                          )}
                        </td>

                        <td>

                          {activity.contributionDone ===
                          "Yes" ? (
                            <div className="fdp-contribution-cell">

                              <strong>
                                {
                                  activity.contributionType ||
                                  "-"
                                }
                              </strong>

                              <span>
                                {
                                  activity.contributionTitle ||
                                  "-"
                                }
                              </span>

                              <small>
                                Impact:{" "}
                                {
                                  activity.impactLevel ||
                                  "-"
                                }
                              </small>

                            </div>
                          ) : (
                            <span className="fdp-no-contribution">
                              No contribution
                            </span>
                          )}

                        </td>

                        <td>
                          {
                            activity.contributionFor ||
                            "-"
                          }
                        </td>

                        <td>
                          {activity.contributionDone !==
                          "Yes"
                            ? "-"
                            : activity.contributionFor ===
                                "Students" ||
                              activity.contributionFor ===
                                "Both"
                            ? `${
                                activity.participantCount ||
                                0
                              } Students`
                            : activity.departmentTarget ||
                              "Department"}
                        </td>

                        <td>

                          {activity.proof ? (
                            <a
                              href={
                                activity.proof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            "Not uploaded"
                          )}

                        </td>

                        <td>

                          {activity.contributionProof ? (
                            <a
                              href={
                                activity.contributionProof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            "Not applicable"
                          )}

                        </td>

                        <td>

                          <span
                            className={`fdp-status fdp-status--${toClassSuffix(
                              status
                            )}`}
                          >
                            {status}
                          </span>

                          {status ===
                            "Rejected" &&
                            activity.rejectionReason && (
                              <small className="fdp-rejection-reason">
                                {
                                  activity.rejectionReason
                                }
                              </small>
                            )}

                        </td>

                        <td>

                          <span
                            className={`fdp-status ${
                              contributionStatus ===
                              "Not Applicable"
                                ? ""
                                : `fdp-status--${toClassSuffix(
                                    contributionStatus
                                  )}`
                            }`}
                          >
                            {
                              contributionStatus
                            }
                          </span>

                          {contributionStatus ===
                            "Rejected" &&
                            activity.contributionReviewComment && (
                              <small className="fdp-rejection-reason">
                                {
                                  activity.contributionReviewComment
                                }
                              </small>
                            )}

                        </td>

                        <td>

                          {status ===
                            "Rejected" && (
                            <button
                              type="button"
                              className="fdp-edit-button"
                              onClick={() =>
                                startEditRejectedActivity(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit
                            </button>
                          )}

                          {status ===
                            "Pending" && (
                            <button
                              type="button"
                              className="fdp-delete-button"
                              onClick={() =>
                                handleDelete(
                                  activity
                                )
                              }
                            >
                              Delete
                            </button>
                          )}

                          {status ===
                            "Approved" &&
                          contributionStatus ===
                            "Rejected" ? (
                            <button
                              type="button"
                              className="fdp-edit-button"
                              onClick={() =>
                                startEditRejectedContribution(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit Contribution
                            </button>
                          ) : status ===
                              "Approved" ? (
                            <span>
                              Locked
                            </span>
                          ) : null}

                        </td>

                      </tr>
                    );
                  }
                )}

              </tbody>

            </table>

            {filteredRecords.length ===
              0 && (
              <div className="fdp-empty">

                <div>
                  🎓
                </div>

                <h3>
                  No FDP records found
                </h3>

                <p>
                  Submit your first
                  faculty development
                  programme using the
                  form above.
                </p>

              </div>
            )}

          </div>
        )}

      </section>

    </div>
  );
}

export default FDP;