import { useEffect, useMemo, useState } from "react";
import "./FacultyImpactScore.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

const API_URL = `${BACKEND_URL}/api/activities`;

/*
  FINAL FIS STRUCTURE = 100 MARKS

  FDP                 = 12
  NPTEL               = 18
  Research Paper      = 15
  Journal Publication = 14
  Patent / IPR        = 15
  Knowledge Transfer  = 26
  --------------------------------
  TOTAL               = 100
*/
const activityConfig = {
  FDP: {
    pointsPerActivity: 2,
    maxScore: 12,
    targetCount: 6,
  },
  NPTEL: {
    pointsPerActivity: 3,
    maxScore: 18,
    targetCount: 6,
  },
  "Research Paper": {
    pointsPerActivity: 5,
    maxScore: 15,
    targetCount: 3,
  },
  "Journal Publication": {
    pointsPerActivity: 7,
    maxScore: 14,
    targetCount: 2,
  },
  "Patent / IPR": {
    pointsPerActivity: 5,
    maxScore: 15,
    targetCount: 3,
  },
};

const contributionWeights = {
  Students: 4,
  Department: 5,
  Both: 8,
};

const KNOWLEDGE_TRANSFER_MAX = 26;
const VALID_ACTIVITY_TYPES = Object.keys(activityConfig);

function getLoggedInFaculty() {
  try {
    const value = localStorage.getItem("loggedInFaculty");
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.error("Unable to read logged-in faculty:", error);
    return null;
  }
}

function FacultyImpactScore() {
  const [faculty] = useState(() => getLoggedInFaculty());
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const loadActivities = async () => {
    if (!faculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token = localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(faculty.facultyId)}`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Unable to load faculty impact score data."
        );
      }

      setActivities(Array.isArray(data.activities) ? data.activities : []);
    } catch (error) {
      console.error("Faculty impact score load error:", error);
      setErrorMessage(
        error.message || "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* Only the five official source activities are eligible. */
  const validActivities = useMemo(
    () =>
      activities.filter((activity) =>
        VALID_ACTIVITY_TYPES.includes(activity.type)
      ),
    [activities]
  );

  const approvedActivities = useMemo(
    () =>
      validActivities.filter(
        (activity) => activity.status === "Approved"
      ),
    [validActivities]
  );

  const pendingActivities = useMemo(
    () =>
      validActivities.filter(
        (activity) => (activity.status || "Pending") === "Pending"
      ),
    [validActivities]
  );

  const rejectedActivities = useMemo(
    () =>
      validActivities.filter(
        (activity) => activity.status === "Rejected"
      ),
    [validActivities]
  );

  /*
    Knowledge Transfer is not a separate activity type.
    It is counted only when:
      1. Main source activity is Approved
      2. contributionDone === "Yes"
      3. contributionStatus === "Approved"
  */
  const approvedContributions = useMemo(
    () =>
      approvedActivities.filter(
        (activity) =>
          activity.contributionDone === "Yes" &&
          activity.contributionStatus === "Approved"
      ),
    [approvedActivities]
  );

  const pendingContributions = useMemo(
    () =>
      validActivities.filter(
        (activity) =>
          activity.status === "Approved" &&
          activity.contributionDone === "Yes" &&
          (activity.contributionStatus || "Pending") === "Pending"
      ),
    [validActivities]
  );

  const rejectedContributions = useMemo(
    () =>
      validActivities.filter(
        (activity) =>
          activity.status === "Approved" &&
          activity.contributionDone === "Yes" &&
          activity.contributionStatus === "Rejected"
      ),
    [validActivities]
  );

  /*
    Category scoring:

    score = approvedCount × pointsPerActivity
    final category score = min(score, category maxScore)
  */
  const categoryData = useMemo(
    () =>
      Object.entries(activityConfig).map(([type, config]) => {
        const approvedCount = approvedActivities.filter(
          (activity) => activity.type === type
        ).length;

        const pendingCount = pendingActivities.filter(
          (activity) => activity.type === type
        ).length;

        const rejectedCount = rejectedActivities.filter(
          (activity) => activity.type === type
        ).length;

        const rawActivityScore =
          approvedCount * config.pointsPerActivity;

        const activityScore = Math.min(
          rawActivityScore,
          config.maxScore
        );

        return {
          type,
          pointsPerActivity: config.pointsPerActivity,
          maxScore: config.maxScore,
          targetCount: config.targetCount,
          approvedCount,
          pendingCount,
          rejectedCount,
          rawActivityScore,
          activityScore,
        };
      }),
    [approvedActivities, pendingActivities, rejectedActivities]
  );

  /* Activity part of FIS: maximum 74 marks. */
  const activityScore = useMemo(
    () =>
      categoryData.reduce(
        (total, category) => total + category.activityScore,
        0
      ),
    [categoryData]
  );

  /* Raw activity points are kept only for transparency. */
  const rawActivityPoints = useMemo(
    () =>
      categoryData.reduce(
        (total, category) => total + category.rawActivityScore,
        0
      ),
    [categoryData]
  );

  /*
    Knowledge Transfer raw points:
      Students   = 4
      Department = 5
      Both       = 8

    Knowledge Transfer contribution to final FIS is capped at 26.
  */
  const rawKnowledgeTransferPoints = useMemo(
    () =>
      approvedContributions.reduce(
        (total, activity) =>
          total +
          (contributionWeights[activity.contributionFor] || 0),
        0
      ),
    [approvedContributions]
  );

  const knowledgeTransferScore = Math.min(
    rawKnowledgeTransferPoints,
    KNOWLEDGE_TRANSFER_MAX
  );

  /*
    Final FIS = Category Activity Score + Knowledge Transfer Score

    Maximum:
      Activities          = 74
      Knowledge Transfer  = 26
      Total               = 100
  */
  const impactScore = Math.min(
    activityScore + knowledgeTransferScore,
    100
  );

  const rawScore =
    rawActivityPoints + rawKnowledgeTransferPoints;

  const studentContributionCount = approvedContributions.filter(
    (activity) =>
      activity.contributionFor === "Students" ||
      activity.contributionFor === "Both"
  ).length;

  const departmentContributionCount = approvedContributions.filter(
    (activity) =>
      activity.contributionFor === "Department" ||
      activity.contributionFor === "Both"
  ).length;

  const bothContributionCount = approvedContributions.filter(
    (activity) => activity.contributionFor === "Both"
  ).length;

  const totalStudentsReached = approvedContributions.reduce(
    (total, activity) => {
      if (
        activity.contributionFor === "Students" ||
        activity.contributionFor === "Both"
      ) {
        return total + Number(activity.participantCount || 0);
      }

      return total;
    },
    0
  );

  const performanceLabel =
    impactScore >= 80
      ? "Excellent"
      : impactScore >= 60
      ? "Very Good"
      : impactScore >= 40
      ? "Good"
      : "Developing";

  if (!faculty) {
    return (
      <div className="impact-score-no-user">
        <h1>Faculty login not found</h1>
        <p>Please log in again.</p>
        <button
          type="button"
          onClick={() => {
            window.location.href = "/";
          }}
        >
          Back to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="impact-score-no-user">
        <p>Loading impact score...</p>
      </div>
    );
  }

  return (
    <div className="impact-score-page">
      <section className="impact-score-heading">
        <div>
          <p>PERFORMANCE ANALYSIS</p>
          <h1>Faculty Impact Score</h1>
          <span>
            Review how administrator-approved academic activities and
            verified knowledge-transfer contributions build your overall
            Faculty Impact Score.
          </span>
        </div>

        <div className="impact-score-label">
          <small>Performance</small>
          <strong>{performanceLabel}</strong>
        </div>
      </section>

      {errorMessage && (
        <div className="impact-score-no-user">
          <p>{errorMessage}</p>
          <button type="button" onClick={loadActivities}>
            Try Again
          </button>
        </div>
      )}

      <section className="impact-score-hero">
        <div className="impact-score-main">
          <span>Current Impact Score</span>

          <div className="impact-score-number">
            <strong>{impactScore}</strong>
            <small>/100</small>
          </div>

          <div className="impact-score-progress">
            <div style={{ width: `${impactScore}%` }} />
          </div>

          <p>
            FIS uses category-wise limits. Approved source activities
            contribute up to 74 points and approved Knowledge Transfer
            contributes up to 26 points, giving a maximum score of 100.
          </p>
        </div>

        <div className="impact-score-summary">
          <article>
            <span>Approved Activities</span>
            <strong>{approvedActivities.length}</strong>
          </article>

          <article>
            <span>Approved Contributions</span>
            <strong>{approvedContributions.length}</strong>
          </article>

          <article>
            <span>Activity Score</span>
            <strong>{activityScore}/74</strong>
          </article>

          <article>
            <span>Knowledge Transfer</span>
            <strong>{knowledgeTransferScore}/26</strong>
          </article>

          <article>
            <span>Verified Students Reached</span>
            <strong>{totalStudentsReached}</strong>
          </article>

          <article>
            <span>Raw Points</span>
            <strong>{rawScore}</strong>
          </article>
        </div>
      </section>

      <section className="impact-score-card">
        <div className="impact-score-card-header">
          <div>
            <h2>Activity Score Breakdown</h2>
            <p>
              Each category has its own points per approved activity and
              maximum contribution to the 100-point FIS.
            </p>
          </div>
        </div>

        <div className="impact-score-table-wrapper">
          <table className="impact-score-table">
            <thead>
              <tr>
                <th>Activity</th>
                <th>Points / Activity</th>
                <th>Approved</th>
                <th>Target</th>
                <th>Raw Points</th>
                <th>FIS Score</th>
                <th>Maximum</th>
                <th>Progress</th>
              </tr>
            </thead>

            <tbody>
              {categoryData.map((category) => {
                const progress =
                  category.maxScore > 0
                    ? Math.min(
                        (category.activityScore / category.maxScore) * 100,
                        100
                      )
                    : 0;

                return (
                  <tr key={category.type}>
                    <td>
                      <strong>{category.type}</strong>
                    </td>
                    <td>{category.pointsPerActivity}</td>
                    <td>{category.approvedCount}</td>
                    <td>{category.targetCount}</td>
                    <td>{category.rawActivityScore}</td>
                    <td>
                      <strong>{category.activityScore}</strong>
                    </td>
                    <td>{category.maxScore}</td>
                    <td>
                      <div className="impact-score-mini-progress">
                        <div style={{ width: `${progress}%` }} />
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <section className="impact-score-card">
        <div className="impact-score-card-header">
          <div>
            <h2>Knowledge Transfer Impact</h2>
            <p>
              Only approved contributions attached to approved source
              activities are counted. Knowledge Transfer is capped at 26
              points.
            </p>
          </div>
        </div>

        <div className="impact-score-contribution-grid">
          <article>
            <span>Student Contributions</span>
            <strong>{studentContributionCount}</strong>
            <small>Students = +4 points</small>
          </article>

          <article>
            <span>Department Contributions</span>
            <strong>{departmentContributionCount}</strong>
            <small>Department = +5 points</small>
          </article>

          <article>
            <span>Student + Department</span>
            <strong>{bothContributionCount}</strong>
            <small>Both = +8 points</small>
          </article>

          <article>
            <span>Knowledge Transfer Score</span>
            <strong>{knowledgeTransferScore}/26</strong>
            <small>
              Raw contribution points: {rawKnowledgeTransferPoints}
            </small>
          </article>
        </div>
      </section>

      <section className="impact-score-card">
        <div className="impact-score-card-header">
          <div>
            <h2>Activity Scoring Rules</h2>
            <p>
              Activity points are awarded only after administrator approval.
            </p>
          </div>
        </div>

        <div className="impact-score-rules">
          {Object.entries(activityConfig).map(([type, config]) => (
            <div key={type}>
              <span>{type}</span>
              <strong>
                +{config.pointsPerActivity} each · Max {config.maxScore}
              </strong>
            </div>
          ))}
        </div>
      </section>

      <section className="impact-score-card">
        <div className="impact-score-card-header">
          <div>
            <h2>Knowledge Transfer Scoring</h2>
            <p>
              These points are added only when both the source activity and
              its contribution are approved.
            </p>
          </div>
        </div>

        <div className="impact-score-rules">
          <div>
            <span>Students</span>
            <strong>+4 points</strong>
          </div>

          <div>
            <span>Department</span>
            <strong>+5 points</strong>
          </div>

          <div>
            <span>Both</span>
            <strong>+8 points</strong>
          </div>

          <div>
            <span>Maximum Knowledge Transfer</span>
            <strong>26 points</strong>
          </div>
        </div>
      </section>

      <section className="impact-score-card">
        <div className="impact-score-card-header">
          <div>
            <h2>Review Status</h2>
            <p>Current activity and contribution review status.</p>
          </div>
        </div>

        <div className="impact-score-contribution-grid">
          <article>
            <span>Pending Activities</span>
            <strong>{pendingActivities.length}</strong>
          </article>

          <article>
            <span>Rejected Activities</span>
            <strong>{rejectedActivities.length}</strong>
          </article>

          <article>
            <span>Pending Contributions</span>
            <strong>{pendingContributions.length}</strong>
          </article>

          <article>
            <span>Rejected Contributions</span>
            <strong>{rejectedContributions.length}</strong>
          </article>
        </div>
      </section>
    </div>
  );
}

export default FacultyImpactScore;
