import {
  useEffect,
  useMemo,
  useState,
} from "react";

import "./ResearchPapers.css";

const API_URL =
  "http://localhost:5000/api/activities";

function ResearchPapers() {
  const loggedInFaculty =
    JSON.parse(
      localStorage.getItem(
        "loggedInFaculty"
      )
    );

  const [formData, setFormData] =
    useState({
      title: "",
      authors: "",
      conferenceName: "",
      publicationDate: "",
      doi: "",
      indexing: "",
      publicationType: "",
      academicYear:
        "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone:
        "No",

      contributionType:
        "",

      contributionTitle:
        "",

      contributionDate:
        "",

      contributionFor:
        "",

      targetGroup:
        "",

      participantCount:
        "",

      studentImpact:
        "",

      departmentTarget:
        "",

      departmentImpact:
        "",

      contributionDescription:
        "",

      impactLevel:
        "",

      contributionProof:
        "",

      contributionProofName:
        "",
    });

  const [
    activities,
    setActivities,
  ] = useState([]);

  const [
    searchText,
    setSearchText,
  ] = useState("");

  const [
    statusFilter,
    setStatusFilter,
  ] = useState("All");

  const [message, setMessage] =
    useState("");

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [loading, setLoading] =
    useState(true);

  const [
    submitting,
    setSubmitting,
  ] = useState(false);

  const [
    editingActivityId,
    setEditingActivityId,
  ] = useState(null);

  const [
    editingMode,
    setEditingMode,
  ] = useState(null);

  const isEditing =
    Boolean(editingActivityId);

  const isContributionEditing =
    editingMode ===
    "contribution";

  const isMainEditing =
    editingMode ===
    "main";

  // ========================================
  // LOAD RESEARCH PAPERS FROM MONGODB
  // ========================================

  const loadActivities =
    async () => {
      if (
        !loggedInFaculty?.facultyId
      ) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setErrorMessage("");

        const token =
          localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/faculty/${encodeURIComponent(
              loggedInFaculty.facultyId
            )}`,
            {
              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to load research papers."
          );
        }

        setActivities(
          data.activities || []
        );
      } catch (error) {
        console.error(
          "Research paper load error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to connect to the server."
        );
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    loadActivities();
  }, []);

  // ========================================
  // LOGIN CHECK
  // ========================================

  if (!loggedInFaculty) {
    return (
      <div className="research-no-user">
        <h1>
          Faculty login not found
        </h1>

        <p>
          Please log in again.
        </p>

        <button
          onClick={() =>
            (window.location.href =
              "/")
          }
        >
          Back to Login
        </button>
      </div>
    );
  }

  // ========================================
  // RECORDS
  // ========================================

  const records =
    activities.filter(
      (activity) =>
        activity.type ===
        "Research Paper"
    );

  const filteredRecords =
    useMemo(() => {
      const value =
        searchText
          .trim()
          .toLowerCase();

      return records.filter(
        (activity) => {
          const status =
            activity.status ||
            "Pending";

          const values = [
            activity.title,
            activity.authors,
            activity.conferenceName,
            activity.publicationType,
            activity.indexing,
            activity.contributionTitle,
            activity.contributionFor,
          ];

          const matchesSearch =
            !value ||
            values.some(
              (item) =>
                String(
                  item || ""
                )
                  .toLowerCase()
                  .includes(value)
            );

          const matchesStatus =
            statusFilter ===
              "All" ||
            status ===
              statusFilter;

          return (
            matchesSearch &&
            matchesStatus
          );
        }
      );
    }, [
      records,
      searchText,
      statusFilter,
    ]);

  // ========================================
  // COUNTS
  // ========================================

  const pendingCount =
    records.filter(
      (activity) =>
        (activity.status ||
          "Pending") ===
        "Pending"
    ).length;

  const approvedCount =
    records.filter(
      (activity) =>
        activity.status ===
        "Approved"
    ).length;

  const contributionCount =
    records.filter(
      (activity) =>
        activity.contributionDone ===
        "Yes"
    ).length;

  // ========================================
  // HANDLE CHANGE
  // ========================================

  const handleChange = (
    event
  ) => {
    const {
      name,
      value,
    } = event.target;

    let updatedValue =
      value;

    if (
      name ===
      "participantCount"
    ) {
      updatedValue =
        value
          .replace(
            /\D/g,
            ""
          )
          .slice(0, 5);
    }

    setFormData(
      (previous) => ({
        ...previous,
        [name]:
          updatedValue,
      })
    );

    setMessage("");
    setErrorMessage("");

    if (
      name ===
        "contributionDone" &&
      value === "No"
    ) {
      setFormData(
        (previous) => ({
          ...previous,

          contributionDone:
            "No",

          contributionType:
            "",

          contributionTitle:
            "",

          contributionDate:
            "",

          contributionFor:
            "",

          targetGroup:
            "",

          participantCount:
            "",

          studentImpact:
            "",

          departmentTarget:
            "",

          departmentImpact:
            "",

          contributionDescription:
            "",

          impactLevel:
            "",

          contributionProof:
            "",

          contributionProofName:
            "",
        })
      );

      const contributionInput =
        document.getElementById(
          "research-contribution-proof"
        );

      if (
        contributionInput
      ) {
        contributionInput.value =
          "";
      }
    }

    if (
      name ===
      "contributionFor"
    ) {
      if (
        value === "Students"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Students",

            departmentTarget:
              "",

            departmentImpact:
              "",
          })
        );
      }

      if (
        value === "Department"
      ) {
        setFormData(
          (previous) => ({
            ...previous,

            contributionFor:
              "Department",

            targetGroup:
              "",

            participantCount:
              "",

            studentImpact:
              "",
          })
        );
      }
    }
  };

  // ========================================
  // FILE VALIDATION
  // ========================================

  const validateFile = (
    file
  ) => {
    const types = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (
      !types.includes(
        file.type
      )
    ) {
      return "Upload only PDF, JPG, PNG or WEBP files.";
    }

    if (
      file.size >
      2 * 1024 * 1024
    ) {
      return "File must be smaller than 2 MB.";
    }

    return "";
  };

  // ========================================
  // READ FILE
  // ========================================

  const readFile = (
    event,
    proofKey,
    proofNameKey
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) {
      return;
    }

    const error =
      validateFile(file);

    if (error) {
      setErrorMessage(
        error
      );

      event.target.value =
        "";

      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      setFormData(
        (previous) => ({
          ...previous,
          [proofKey]:
            reader.result,
          [proofNameKey]:
            file.name,
        })
      );
    };

    reader.onerror = () => {
      setErrorMessage(
        "Unable to read the selected file."
      );
    };

    reader.readAsDataURL(
      file
    );
  };

  // ========================================
  // RESET
  // ========================================

  const resetForm = () => {
    setFormData({
      title: "",
      authors: "",
      conferenceName: "",
      publicationDate: "",
      doi: "",
      indexing: "",
      publicationType: "",
      academicYear:
        "2026–2027",
      description: "",
      proof: "",
      proofName: "",

      contributionDone:
        "No",

      contributionType:
        "",

      contributionTitle:
        "",

      contributionDate:
        "",

      contributionFor:
        "",

      targetGroup:
        "",

      participantCount:
        "",

      studentImpact:
        "",

      departmentTarget:
        "",

      departmentImpact:
        "",

      contributionDescription:
        "",

      impactLevel:
        "",

      contributionProof:
        "",

      contributionProofName:
        "",
    });

    const proof =
      document.getElementById(
        "research-proof"
      );

    const contribution =
      document.getElementById(
        "research-contribution-proof"
      );

    if (proof) {
      proof.value = "";
    }

    if (contribution) {
      contribution.value =
        "";
    }

    setEditingActivityId(
      null
    );

    setEditingMode(
      null
    );
  };

  // ========================================
  // EDIT / RESUBMIT HELPERS
  // ========================================

  const populateFormFromActivity = (
    activity
  ) => {
    setFormData({
      title:
        activity.title || "",

      authors:
        activity.authors || "",

      conferenceName:
        activity.conferenceName || "",

      publicationDate:
        activity.publicationDate
          ? String(
              activity.publicationDate
            ).slice(0, 10)
          : "",

      doi:
        activity.doi || "",

      indexing:
        activity.indexing || "",

      publicationType:
        activity.publicationType || "",

      academicYear:
        activity.academicYear ||
        "2026–2027",

      description:
        activity.description || "",

      proof:
        activity.proof || "",

      proofName:
        activity.proofName ||
        (activity.proof
          ? "Existing research proof"
          : ""),

      contributionDone:
        activity.contributionDone ||
        "No",

      contributionType:
        activity.contributionType ||
        "",

      contributionTitle:
        activity.contributionTitle ||
        "",

      contributionDate:
        activity.contributionDate
          ? String(
              activity.contributionDate
            ).slice(0, 10)
          : "",

      contributionFor:
        activity.contributionFor ||
        "",

      targetGroup:
        activity.targetGroup || "",

      participantCount:
        activity.participantCount
          ? String(
              activity.participantCount
            )
          : "",

      studentImpact:
        activity.studentImpact || "",

      departmentTarget:
        activity.departmentTarget ||
        "",

      departmentImpact:
        activity.departmentImpact ||
        "",

      contributionDescription:
        activity.contributionDescription ||
        "",

      impactLevel:
        activity.impactLevel || "",

      contributionProof:
        activity.contributionProof ||
        "",

      contributionProofName:
        activity.contributionProofName ||
        (activity.contributionProof
          ? "Existing contribution proof"
          : ""),
    });

    const proof =
      document.getElementById(
        "research-proof"
      );

    if (proof) {
      proof.value = "";
    }

    const contribution =
      document.getElementById(
        "research-contribution-proof"
      );

    if (contribution) {
      contribution.value =
        "";
    }

    window.setTimeout(
      () => {
        document
          .querySelector(
            ".research-form"
          )
          ?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
      },
      0
    );
  };

  const startEditRejectedActivity = (
    activity
  ) => {
    if (
      (activity.status ||
        "Pending") !==
      "Rejected"
    ) {
      setErrorMessage(
        "Only rejected research paper records can be edited and resubmitted."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "main"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const startEditRejectedContribution = (
    activity
  ) => {
    const mainStatus =
      activity.status ||
      "Pending";

    const contributionStatus =
      activity.contributionDone ===
      "Yes"
        ? activity.contributionStatus ||
          "Pending"
        : "Not Applicable";

    if (
      mainStatus !==
        "Approved" ||
      activity.contributionDone !==
        "Yes" ||
      contributionStatus !==
        "Rejected"
    ) {
      setErrorMessage(
        "Only a rejected contribution from an approved research paper can be edited here."
      );
      return;
    }

    setEditingActivityId(
      activity._id
    );

    setEditingMode(
      "contribution"
    );

    setMessage("");
    setErrorMessage("");

    populateFormFromActivity(
      activity
    );
  };

  const cancelEdit = () => {
    resetForm();
    setMessage(
      "Edit cancelled."
    );
    setErrorMessage("");
  };

  // ========================================
  // CONTRIBUTION VALIDATION
  // ========================================

  const validateContribution =
    () => {
      if (
        formData.contributionDone !==
        "Yes"
      ) {
        return "";
      }

      if (
        !formData.contributionType ||
        !formData.contributionTitle.trim() ||
        !formData.contributionDate ||
        !formData.contributionFor ||
        !formData.contributionDescription.trim() ||
        !formData.impactLevel
      ) {
        return "Please complete all contribution details.";
      }

      if (
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.targetGroup.trim() ||
          !formData.participantCount ||
          !formData.studentImpact.trim()
        ) {
          return "Please complete all student impact details.";
        }

        const count =
          Number(
            formData.participantCount
          );

        if (
          Number.isNaN(
            count
          ) ||
          count < 1
        ) {
          return "Number of students must be at least 1.";
        }
      }

      if (
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both"
      ) {
        if (
          !formData.departmentTarget.trim() ||
          !formData.departmentImpact.trim()
        ) {
          return "Please complete all department impact details.";
        }
      }

      if (
        formData.publicationDate &&
        new Date(
          formData.contributionDate
        ) <
          new Date(
            formData.publicationDate
          )
      ) {
        return "Contribution date cannot be earlier than the publication date.";
      }

      if (
        !formData.contributionProof
      ) {
        return "Please upload contribution supporting proof.";
      }

      return "";
    };

  // ========================================
  // SUBMIT TO MONGODB
  // ========================================

  const handleSubmit =
    async (event) => {
      event.preventDefault();

      setErrorMessage("");
      setMessage("");

      if (
        !formData.title.trim() ||
        !formData.authors.trim() ||
        !formData.conferenceName.trim() ||
        !formData.publicationDate ||
        !formData.publicationType
      ) {
        setErrorMessage(
          "Please complete all required research paper fields."
        );

        return;
      }

      if (!formData.proof) {
        setErrorMessage(
          "Please upload the research paper supporting proof."
        );

        return;
      }

      const contributionError =
        validateContribution();

      if (
        contributionError
      ) {
        setErrorMessage(
          contributionError
        );

        return;
      }

      const token =
        localStorage.getItem("token");

      if (!token) {
        setErrorMessage(
          "Authentication token not found. Please login again."
        );
        return;
      }

      const isStudent =
        formData.contributionFor ===
          "Students" ||
        formData.contributionFor ===
          "Both";

      const isDepartment =
        formData.contributionFor ===
          "Department" ||
        formData.contributionFor ===
          "Both";

      const newActivity = {
        type:
          "Research Paper",

        title:
          formData.title.trim(),

        authors:
          formData.authors.trim(),

        conferenceName:
          formData.conferenceName.trim(),

        publicationDate:
          formData.publicationDate,

        activityDate:
          formData.publicationDate,

        doi:
          formData.doi.trim(),

        indexing:
          formData.indexing,

        publicationType:
          formData.publicationType,

        academicYear:
          formData.academicYear,

        description:
          formData.description.trim(),

        proof:
          formData.proof,

        proofName:
          formData.proofName,

        contributionDone:
          formData.contributionDone,

        contributionType:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionType
            : "",

        contributionTitle:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionTitle.trim()
            : "",

        contributionDate:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDate
            : null,

        contributionFor:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionFor
            : "",

        targetGroup:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.targetGroup.trim()
            : "",

        participantCount:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? Number(
                formData.participantCount
              )
            : 0,

        studentImpact:
          formData.contributionDone ===
            "Yes" &&
          isStudent
            ? formData.studentImpact.trim()
            : "",

        departmentTarget:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentTarget.trim()
            : "",

        departmentImpact:
          formData.contributionDone ===
            "Yes" &&
          isDepartment
            ? formData.departmentImpact.trim()
            : "",

        contributionDescription:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionDescription.trim()
            : "",

        impactLevel:
          formData.contributionDone ===
          "Yes"
            ? formData.impactLevel
            : "",

        contributionProof:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProof
            : "",

        contributionProofName:
          formData.contributionDone ===
          "Yes"
            ? formData.contributionProofName
            : "",
      };

      try {
        setSubmitting(true);

        const requestUrl =
          isEditing
            ? `${API_URL}/${editingActivityId}`
            : API_URL;

        const response =
          await fetch(
            requestUrl,
            {
              method:
                isEditing
                  ? "PUT"
                  : "POST",

              headers: {
                "Content-Type":
                  "application/json",

                Authorization:
                  `Bearer ${token}`,
              },

              body:
                JSON.stringify(
                  newActivity
                ),
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              (isEditing
                ? "Unable to resubmit research paper."
                : "Unable to submit research paper.")
          );
        }

        const wasEditing =
          isEditing;

        const wasContributionEditing =
          isContributionEditing;

        if (data.activity) {
          setActivities(
            (previous) =>
              wasEditing
                ? previous.map(
                    (item) =>
                      item._id ===
                      data.activity._id
                        ? data.activity
                        : item
                  )
                : [
                    data.activity,
                    ...previous,
                  ]
          );
        } else {
          await loadActivities();
        }

        resetForm();

        setMessage(
          wasContributionEditing
            ? "Rejected contribution updated and resubmitted successfully. The research paper remains approved and the contribution is now waiting for administrator review."
            : wasEditing
            ? "Rejected research paper updated and resubmitted successfully. It is now waiting for administrator review."
            : "Research paper submitted successfully. It is waiting for administrator approval."
        );
      } catch (error) {
        console.error(
          "Research submission error:",
          error
        );

        setErrorMessage(
          error.message ||
            (isEditing
              ? "Unable to resubmit research paper."
              : "Unable to submit research paper.")
        );
      } finally {
        setSubmitting(false);
      }
    };

  // ========================================
  // DELETE FROM MONGODB
  // ========================================

  const handleDelete =
    async (activity) => {
      const status =
        activity.status ||
        "Pending";

      if (
        status !== "Pending"
      ) {
        alert(
          "Only pending research paper records can be deleted."
        );

        return;
      }

      if (
        !window.confirm(
          "Delete this research paper record?"
        )
      ) {
        return;
      }

      try {
        setErrorMessage("");
        setMessage("");

        const token =
          localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Authentication token not found. Please login again."
          );
        }

        const response =
          await fetch(
            `${API_URL}/${activity._id}`,
            {
              method:
                "DELETE",

              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Unable to delete research paper."
          );
        }

        setActivities(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !==
                activity._id
            )
        );

        setMessage(
          "Research paper deleted successfully."
        );
      } catch (error) {
        console.error(
          "Research delete error:",
          error
        );

        setErrorMessage(
          error.message ||
            "Unable to delete research paper."
        );
      }
    };

  // ========================================
  // CONTRIBUTION SECTION
  // ========================================

  const renderContributionSection =
    () => (
      <div className="research-contribution-section">
        <div className="research-contribution-heading">
          <h2>
            Contribution and Impact
          </h2>

          <p>
            Mention whether the
            knowledge or findings from
            this research were
            transferred to students or
            the department.
          </p>
        </div>

        <div className="research-contribution-grid">
          <div className="research-field research-field--full">
            <label>
              Did you make any
              contribution based on
              this research?
            </label>

            <select
              name="contributionDone"
              disabled={
                isContributionEditing
              }
              value={
                formData.contributionDone
              }
              onChange={
                handleChange
              }
            >
              <option value="No">
                No
              </option>

              <option value="Yes">
                Yes
              </option>
            </select>
          </div>

          {formData.contributionDone ===
            "Yes" && (
            <>
              <div className="research-field">
                <label>
                  Contribution Type
                </label>

                <select
                  name="contributionType"
                  value={
                    formData.contributionType
                  }
                  onChange={
                    handleChange
                  }
                  required
                >
                  <option value="">
                    Select Type
                  </option>

                  <option value="Class Conducted">
                    Class Conducted
                  </option>

                  <option value="Workshop Conducted">
                    Workshop Conducted
                  </option>

                  <option value="Seminar Conducted">
                    Seminar Conducted
                  </option>

                  <option value="Student Mentoring">
                    Student Mentoring
                  </option>

                  <option value="Research Guidance">
                    Research Guidance
                  </option>

                  <option value="Curriculum Improvement">
                    Curriculum
                    Improvement
                  </option>

                  <option value="Department Training">
                    Department Training
                  </option>

                  <option value="Other">
                    Other
                  </option>
                </select>
              </div>

              <div className="research-field">
                <label>
                  Contribution Title
                </label>

                <input
                  name="contributionTitle"
                  value={
                    formData.contributionTitle
                  }
                  onChange={
                    handleChange
                  }
                  placeholder="Enter contribution title"
                  required
                />
              </div>

              <div className="research-field">
                <label>
                  Contribution Date
                </label>

                <input
                  type="date"
                  name="contributionDate"
                  value={
                    formData.contributionDate
                  }
                  onChange={
                    handleChange
                  }
                  min={
                    formData.publicationDate
                  }
                  required
                />
              </div>

              <div className="research-field">
                <label>
                  Contribution For
                </label>

                <select
                  name="contributionFor"
                  value={
                    formData.contributionFor
                  }
                  onChange={
                    handleChange
                  }
                  required
                >
                  <option value="">
                    Select
                  </option>

                  <option value="Students">
                    Students
                  </option>

                  <option value="Department">
                    Department
                  </option>

                  <option value="Both">
                    Both
                  </option>
                </select>
              </div>

              {[
                "Students",
                "Both",
              ].includes(
                formData.contributionFor
              ) && (
                <>
                  <div className="research-field">
                    <label>
                      Target Class /
                      Students
                    </label>

                    <input
                      name="targetGroup"
                      value={
                        formData.targetGroup
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="Example: S6 CSE"
                      required
                    />
                  </div>

                  <div className="research-field">
                    <label>
                      Number of Students
                    </label>

                    <input
                      type="number"
                      min="1"
                      name="participantCount"
                      value={
                        formData.participantCount
                      }
                      onChange={
                        handleChange
                      }
                      required
                    />
                  </div>

                  <div className="research-field research-field--full">
                    <label>
                      Impact on Students
                    </label>

                    <textarea
                      name="studentImpact"
                      rows={3}
                      value={
                        formData.studentImpact
                      }
                      onChange={
                        handleChange
                      }
                      required
                    />
                  </div>
                </>
              )}

              {[
                "Department",
                "Both",
              ].includes(
                formData.contributionFor
              ) && (
                <>
                  <div className="research-field research-field--full">
                    <label>
                      Department /
                      Target Area
                    </label>

                    <input
                      name="departmentTarget"
                      value={
                        formData.departmentTarget
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="Example: CSE Department"
                      required
                    />
                  </div>

                  <div className="research-field research-field--full">
                    <label>
                      Impact on
                      Department
                    </label>

                    <textarea
                      name="departmentImpact"
                      rows={3}
                      value={
                        formData.departmentImpact
                      }
                      onChange={
                        handleChange
                      }
                      required
                    />
                  </div>
                </>
              )}

              <div className="research-field research-field--full">
                <label>
                  Contribution Details
                </label>

                <textarea
                  name="contributionDescription"
                  rows={4}
                  value={
                    formData.contributionDescription
                  }
                  onChange={
                    handleChange
                  }
                  required
                />
              </div>

              <div className="research-field">
                <label>
                  Impact Level
                </label>

                <select
                  name="impactLevel"
                  value={
                    formData.impactLevel
                  }
                  onChange={
                    handleChange
                  }
                  required
                >
                  <option value="">
                    Select Impact
                  </option>

                  <option value="Low">
                    Low
                  </option>

                  <option value="Moderate">
                    Moderate
                  </option>

                  <option value="High">
                    High
                  </option>

                  <option value="Very High">
                    Very High
                  </option>
                </select>
              </div>

              <div className="research-field research-field--full">
                <label>
                  Contribution
                  Supporting Proof
                </label>

                <div className="research-upload">
                  <input
                    id="research-contribution-proof"
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png,.webp"
                    onChange={(event) =>
                      readFile(
                        event,
                        "contributionProof",
                        "contributionProofName"
                      )
                    }
                  />

                  {formData.contributionProofName && (
                    <small>
                      Selected:{" "}
                      {
                        formData.contributionProofName
                      }
                    </small>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    );

  // ========================================
  // DATE FORMAT
  // ========================================

  const formatDate = (
    value
  ) => {
    if (!value) {
      return "-";
    }

    const date =
      new Date(value);

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return value;
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  // ========================================
  // JSX
  // ========================================

  return (
    <div className="research-page">
      <section className="research-heading">
        <div>
          <p className="research-eyebrow">
            RESEARCH CONTRIBUTION
          </p>

          <h1>
            Research Papers
          </h1>

          <p>
            Submit research
            publications, supporting
            evidence and resulting
            contributions.
          </p>
        </div>

        <div className="research-total">
          <span>
            Total Records
          </span>

          <strong>
            {records.length}
          </strong>
        </div>
      </section>

      <section className="research-stats">
        <article>
          <span>
            Total
          </span>

          <strong>
            {records.length}
          </strong>
        </article>

        <article>
          <span>
            Pending
          </span>

          <strong>
            {pendingCount}
          </strong>
        </article>

        <article>
          <span>
            Approved
          </span>

          <strong>
            {approvedCount}
          </strong>
        </article>

        <article>
          <span>
            Contributions
          </span>

          <strong>
            {contributionCount}
          </strong>
        </article>
      </section>

      <section className="research-card">
        <div className="research-card-header">
          <div>
            <h2>
              {isContributionEditing
                ? "Edit Rejected Contribution"
                : isMainEditing
                ? "Edit Rejected Research Paper"
                : "Add Research Paper"}
            </h2>

            <p>
              {isContributionEditing
                ? "The approved research paper details are locked. Correct only the rejected contribution and resubmit it for administrator review."
                : isMainEditing
                ? "Correct the rejected research paper and resubmit it for administrator review."
                : "Enter publication details and supporting proof."}
            </p>
          </div>
        </div>

        <form
          className="research-form"
          onSubmit={handleSubmit}
        >
          <div className="research-form-grid">
            <div className="research-field research-field--full">
              <label>
                Paper Title
              </label>

              <input
                name="title"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.title
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            <div className="research-field">
              <label>
                Authors
              </label>

              <input
                name="authors"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.authors
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            <div className="research-field">
              <label>
                Conference /
                Publication
              </label>

              <input
                name="conferenceName"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.conferenceName
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            <div className="research-field">
              <label>
                Publication Date
              </label>

              <input
                type="date"
                name="publicationDate"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.publicationDate
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            <div className="research-field">
              <label>
                DOI / Paper ID
              </label>

              <input
                name="doi"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.doi
                }
                onChange={
                  handleChange
                }
              />
            </div>

            <div className="research-field">
              <label>
                Indexing
              </label>

              <select
                name="indexing"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.indexing
                }
                onChange={
                  handleChange
                }
              >
                <option value="">
                  Select Indexing
                </option>

                <option value="Scopus">
                  Scopus
                </option>

                <option value="Web of Science">
                  Web of Science
                </option>

                <option value="UGC CARE">
                  UGC CARE
                </option>

                <option value="IEEE">
                  IEEE
                </option>

                <option value="Other">
                  Other
                </option>
              </select>
            </div>

            <div className="research-field">
              <label>
                Publication Type
              </label>

              <select
                name="publicationType"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.publicationType
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Type
                </option>

                <option value="Conference Paper">
                  Conference Paper
                </option>

                <option value="Research Article">
                  Research Article
                </option>

                <option value="Review Paper">
                  Review Paper
                </option>

                <option value="Book Chapter">
                  Book Chapter
                </option>
              </select>
            </div>

            <div className="research-field">
              <label>
                Academic Year
              </label>

              <select
                name="academicYear"
                disabled={
                  isContributionEditing
                }
                value={
                  formData.academicYear
                }
                onChange={
                  handleChange
                }
              >
                <option value="2024–2025">
                  2024–2025
                </option>

                <option value="2025–2026">
                  2025–2026
                </option>

                <option value="2026–2027">
                  2026–2027
                </option>
              </select>
            </div>

            <div className="research-field research-field--full">
              <label>
                Description
              </label>

              <textarea
                name="description"
                disabled={
                  isContributionEditing
                }
                rows={4}
                value={
                  formData.description
                }
                onChange={
                  handleChange
                }
              />
            </div>

            <div className="research-field research-field--full">
              <label>
                Supporting Proof
              </label>

              <div className="research-upload">
                <input
                  id="research-proof"
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.webp"
                  disabled={
                    isContributionEditing
                  }
                  onChange={(event) =>
                    readFile(
                      event,
                      "proof",
                      "proofName"
                    )
                  }
                />

                {formData.proofName && (
                  <small>
                    Selected:{" "}
                    {
                      formData.proofName
                    }
                  </small>
                )}
              </div>
            </div>

            {renderContributionSection()}
          </div>

          {errorMessage && (
            <div className="research-message research-message--error">
              {errorMessage}
            </div>
          )}

          {message && (
            <div className="research-message research-message--success">
              {message}
            </div>
          )}

          <div className="research-form-actions">
            <button
              type="submit"
              disabled={
                submitting
              }
            >
              {submitting
                ? isEditing
                  ? "Resubmitting..."
                  : "Submitting..."
                : isContributionEditing
                ? "Update & Resubmit Contribution"
                : isMainEditing
                ? "Update & Resubmit Research Paper"
                : "Submit Research Paper"}
            </button>

            {isEditing && (
              <button
                type="button"
                onClick={
                  cancelEdit
                }
                disabled={
                  submitting
                }
              >
                Cancel Edit
              </button>
            )}
          </div>
        </form>
      </section>

      <section className="research-card">
        <div className="research-card-header">
          <h2>
            My Research Papers
          </h2>
        </div>

        <div className="research-toolbar">
          <input
            placeholder="Search records"
            value={
              searchText
            }
            onChange={(event) =>
              setSearchText(
                event.target.value
              )
            }
          />

          <select
            value={
              statusFilter
            }
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>
          </select>
        </div>

        {loading ? (
          <div className="research-empty">
            Loading research
            papers...
          </div>
        ) : (
          <div className="research-table-wrapper">
            <table className="research-table">
              <thead>
                <tr>
                  <th>
                    Title
                  </th>

                  <th>
                    Publication
                  </th>

                  <th>
                    Date
                  </th>

                  <th>
                    Contribution
                  </th>

                  <th>
                    Contribution For
                  </th>

                  <th>
                    Proof
                  </th>

                  <th>
                    Status
                  </th>

                  <th>
                    Contribution Status
                  </th>

                  <th>
                    Action
                  </th>
                </tr>
              </thead>

              <tbody>
                {filteredRecords.map(
                  (activity) => {
                    const status =
                      activity.status ||
                      "Pending";

                    const contributionStatus =
                      activity.contributionDone ===
                      "Yes"
                        ? activity.contributionStatus ||
                          "Pending"
                        : "Not Applicable";

                    return (
                      <tr
                        key={
                          activity._id
                        }
                      >
                        <td>
                          {activity.title ||
                            "-"}
                        </td>

                        <td>
                          {activity.conferenceName ||
                            "-"}
                        </td>

                        <td>
                          {formatDate(
                            activity.publicationDate
                          )}
                        </td>

                        <td>
                          {activity.contributionDone ===
                          "Yes"
                            ? activity.contributionTitle ||
                              "-"
                            : "No contribution"}
                        </td>

                        <td>
                          {activity.contributionFor ||
                            "-"}
                        </td>

                        <td>
                          {activity.proof ? (
                            <a
                              href={
                                activity.proof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View
                            </a>
                          ) : (
                            "-"
                          )}
                        </td>

                        <td>
                          <span
                            className={`research-status research-status--${status.toLowerCase()}`}
                          >
                            {status}
                          </span>

                          {status ===
                            "Rejected" &&
                            activity.rejectionReason && (
                              <small className="research-rejection-reason">
                                {
                                  activity.rejectionReason
                                }
                              </small>
                            )}
                        </td>

                        <td>
                          {
                            contributionStatus
                          }

                          {contributionStatus ===
                            "Rejected" &&
                            activity.contributionReviewComment && (
                              <small className="research-rejection-reason">
                                {
                                  activity.contributionReviewComment
                                }
                              </small>
                            )}
                        </td>

                        <td>
                          {status ===
                            "Rejected" && (
                            <button
                              type="button"
                              className="research-delete"
                              onClick={() =>
                                startEditRejectedActivity(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit
                            </button>
                          )}

                          {status ===
                            "Approved" &&
                          contributionStatus ===
                            "Rejected" && (
                            <button
                              type="button"
                              className="research-delete"
                              onClick={() =>
                                startEditRejectedContribution(
                                  activity
                                )
                              }
                            >
                              Edit & Resubmit Contribution
                            </button>
                          )}

                          {status ===
                            "Pending" && (
                            <button
                              type="button"
                              className="research-delete"
                              onClick={() =>
                                handleDelete(
                                  activity
                                )
                              }
                            >
                              Delete
                            </button>
                          )}

                          {status ===
                            "Approved" &&
                            contributionStatus !==
                              "Rejected" && (
                              <span>
                                Locked
                              </span>
                            )}
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>

            {filteredRecords.length ===
              0 && (
              <div className="research-empty">
                No research papers
                found.
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

export default ResearchPapers;