import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FacultyOverview.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "http://localhost:5000";

const API_URL =
  `${BACKEND_URL}/api/activities`;

const BACKEND_ORIGIN = BACKEND_URL;

const activityTypes = [
  {
    type: "FDP",
    label: "FDP",
    description: "Faculty development programmes",
    icon: "🎓",
    route: "/faculty/fdp",
  },
  {
    type: "NPTEL",
    label: "NPTEL",
    description: "Completed online courses",
    icon: "▶",
    route: "/faculty/nptel",
  },
  {
    type: "Research Paper",
    label: "Research Papers",
    description: "Research contributions",
    icon: "🔬",
    route: "/faculty/research",
  },
  {
    type: "Journal Publication",
    label: "Journal Publications",
    description: "Published journal articles",
    icon: "📘",
    route: "/faculty/journals",
  },
  {
    type: "Patent / IPR",
    label: "Patents / IPR",
    description: "Innovation and intellectual property",
    icon: "💡",
    route: "/faculty/patents",
  },
];

const activityConfig = {
  FDP: {
    pointsPerActivity: 2,
    maxScore: 12,
  },
  NPTEL: {
    pointsPerActivity: 3,
    maxScore: 18,
  },
  "Research Paper": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
  "Journal Publication": {
    pointsPerActivity: 7,
    maxScore: 14,
  },
  "Patent / IPR": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
};

const contributionWeights = {
  Students: 4,
  Department: 5,
  Both: 8,
};

const KNOWLEDGE_TRANSFER_MAX = 26;
const ACTIVITY_SCORE_MAX = 74;

const VALID_ACTIVITY_TYPES =
  new Set(
    Object.keys(activityConfig)
  );

const getProfileImageSrc = (
  imageValue
) => {
  const value =
    String(imageValue || "").trim();

  if (!value) {
    return "";
  }

  if (
    value.startsWith("http://") ||
    value.startsWith("https://") ||
    value.startsWith("data:") ||
    value.startsWith("blob:")
  ) {
    return value;
  }

  return `${BACKEND_ORIGIN}${
    value.startsWith("/")
      ? value
      : `/${value}`
  }`;
};

function FacultyOverview() {
  const navigate = useNavigate();

  const faculty = useMemo(() => {
    try {
      return JSON.parse(
        localStorage.getItem("loggedInFaculty")
      );
    } catch (error) {
      console.error("Unable to load faculty details:", error);
      return null;
    }
  }, []);

  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  // Loaded from the saved MongoDB faculty record, not just the login snapshot.
  const [savedProfile, setSavedProfile] = useState(faculty);
  const [profileLoading, setProfileLoading] = useState(true);

  const loadSavedProfile = async () => {
    if (!faculty?._id) {
      setProfileLoading(false);
      return;
    }

    try {
      const token = localStorage.getItem("token");

      if (!token) {
        throw new Error("Authentication token not found. Please log in again.");
      }

      const response = await fetch(
        `${BACKEND_URL}/api/faculty/${encodeURIComponent(faculty._id)}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Unable to load your saved profile."
        );
      }

      const profile = data.faculty || faculty;
      setSavedProfile(profile);

      // Keep the dashboard's local session snapshot aligned with MongoDB.
      localStorage.setItem("loggedInFaculty", JSON.stringify(profile));
    } catch (error) {
      console.error("Faculty profile completion load error:", error);
      // Use the last authenticated snapshot if the profile endpoint is temporarily unavailable.
      setSavedProfile(faculty);
    } finally {
      setProfileLoading(false);
    }
  };

  const loadActivities = async () => {
    if (!faculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token =
        localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(
          faculty.facultyId
        )}`,
        {
          headers: {
            Authorization:
              `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Unable to load faculty dashboard activities."
        );
      }

      setActivities(data.activities || []);
    } catch (error) {
      console.error(
        "Faculty overview load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
    loadSavedProfile();
  }, []);

  /*
    Only the five official source activity
    types are used by the dashboard and
    impact-score calculation.
  */
  const facultyActivities =
    useMemo(
      () =>
        activities.filter(
          (activity) =>
            VALID_ACTIVITY_TYPES.has(
              activity.type
            )
        ),
      [activities]
    );

  const approvedActivities = useMemo(
    () =>
      facultyActivities.filter(
        (activity) =>
          activity.status === "Approved"
      ),
    [facultyActivities]
  );

  const pendingActivities = useMemo(
    () =>
      facultyActivities.filter(
        (activity) =>
          (activity.status || "Pending") ===
          "Pending"
      ),
    [facultyActivities]
  );

  const rejectedActivities = useMemo(
    () =>
      facultyActivities.filter(
        (activity) =>
          activity.status === "Rejected"
      ),
    [facultyActivities]
  );

  const scoreData = useMemo(() => {
    const categoryScores =
      Object.entries(
        activityConfig
      ).map(
        ([type, config]) => {
          const approvedCount =
            approvedActivities.filter(
              (activity) =>
                activity.type === type
            ).length;

          const rawCategoryScore =
            approvedCount *
            config.pointsPerActivity;

          const cappedCategoryScore =
            Math.min(
              rawCategoryScore,
              config.maxScore
            );

          return {
            type,
            approvedCount,
            rawCategoryScore,
            cappedCategoryScore,
          };
        }
      );

    const rawActivityScore =
      categoryScores.reduce(
        (total, category) =>
          total +
          category.rawCategoryScore,
        0
      );

    const activityScore =
      categoryScores.reduce(
        (total, category) =>
          total +
          category.cappedCategoryScore,
        0
      );

    const rawKnowledgeTransferScore =
      approvedActivities.reduce(
        (total, activity) => {
          if (
            activity.contributionDone !==
              "Yes" ||
            activity.contributionStatus !==
              "Approved"
          ) {
            return total;
          }

          return (
            total +
            (contributionWeights[
              activity.contributionFor
            ] || 0)
          );
        },
        0
      );

    const knowledgeTransferScore =
      Math.min(
        rawKnowledgeTransferScore,
        KNOWLEDGE_TRANSFER_MAX
      );

    const rawScore =
      rawActivityScore +
      rawKnowledgeTransferScore;

    const impactScore =
      Math.min(
        activityScore +
          knowledgeTransferScore,
        100
      );

    return {
      categoryScores,
      rawActivityScore,
      activityScore,
      rawKnowledgeTransferScore,
      knowledgeTransferScore,
      rawScore,
      impactScore,
    };
  }, [approvedActivities]);

  const {
    activityScore,
    knowledgeTransferScore,
    rawScore,
    impactScore,
  } = scoreData;

  const approvedContributions =
    useMemo(
      () =>
        facultyActivities.filter(
          (activity) =>
            activity.status ===
              "Approved" &&
            activity.contributionDone ===
              "Yes" &&
            activity.contributionStatus ===
              "Approved"
        ),
      [facultyActivities]
    );

  const pendingContributions =
    useMemo(
      () =>
        facultyActivities.filter(
          (activity) =>
            activity.contributionDone ===
              "Yes" &&
            (activity.contributionStatus ||
              "Pending") ===
              "Pending"
        ),
      [facultyActivities]
    );

  const rejectedContributions =
    useMemo(
      () =>
        facultyActivities.filter(
          (activity) =>
            activity.status ===
              "Approved" &&
            activity.contributionDone ===
              "Yes" &&
            activity.contributionStatus ===
              "Rejected"
        ),
      [facultyActivities]
    );

  const categoryData = useMemo(
    () =>
      activityTypes.map((item) => ({
        ...item,
        count: facultyActivities.filter(
          (activity) =>
            activity.type === item.type
        ).length,
      })),
    [facultyActivities]
  );

  const maximumCategoryCount = Math.max(
    1,
    ...categoryData.map((item) => item.count)
  );

  const recentActivities = useMemo(
    () =>
      [...facultyActivities]
        .sort((first, second) => {
          const firstDate = new Date(
            first.submissionDate ||
              first.createdAt ||
              first.activityDate ||
              first.startDate ||
              first.publicationDate ||
              first.filingDate ||
              0
          );

          const secondDate = new Date(
            second.submissionDate ||
              second.createdAt ||
              second.activityDate ||
              second.startDate ||
              second.publicationDate ||
              second.filingDate ||
              0
          );

          return secondDate - firstDate;
        })
        .slice(0, 5),
    [facultyActivities]
  );

  // Profile completion is calculated from the fields saved on the faculty record.
  // Login identifiers are excluded because they are not editable profile details.
  const profileCompletionFields = [
    { key: "name", label: "Full name" },
    { key: "facultyId", label: "Faculty ID" },
    { key: "department", label: "Department" },
    { key: "designation", label: "Designation" },
    { key: "email", label: "Email address" },
    { key: "phone", label: "Phone number" },
    { key: "qualification", label: "Qualification" },
    { key: "dateOfJoining", label: "Date of joining" },
    { key: "address", label: "Address" },
    { key: "profileImage", label: "Profile photo" },
  ];

  const profileCompletion = useMemo(() => {
    const profile = savedProfile || {};
    const completedFields = profileCompletionFields.filter((field) => {
      const value = profile[field.key];
      return value !== null &&
        value !== undefined &&
        String(value).trim() !== "";
    });

    const missingFields = profileCompletionFields.filter((field) => {
      const value = profile[field.key];
      return value === null ||
        value === undefined ||
        String(value).trim() === "";
    });

    return {
      completed: completedFields.length,
      total: profileCompletionFields.length,
      percentage: Math.round(
        (completedFields.length / profileCompletionFields.length) * 100
      ),
      missingFields,
    };
  }, [savedProfile]);

  const approvalRate =
    facultyActivities.length > 0
      ? Math.round(
          (approvedActivities.length /
            facultyActivities.length) *
            100
        )
      : 0;

  const toClassSuffix = (
    value,
    fallback = "pending"
  ) =>
    String(value || fallback)
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "-");

  const formatDate = (dateValue) => {
    if (!dateValue) {
      return "Not available";
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
      return dateValue;
    }

    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // All hooks must run before any conditional return.
  if (!faculty) {
    return (
      <div className="faculty-overview__no-user">
        <h1>Faculty session not found</h1>

        <p>Please log in again to access your dashboard.</p>

        <button
          type="button"
          onClick={() => navigate("/")}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="faculty-overview__no-user">
        <p>Loading dashboard activities...</p>
      </div>
    );
  }

  return (
    <div className="faculty-overview">
      <section className="faculty-overview__hero">
        <div className="faculty-overview__hero-content">
          <p className="faculty-overview__eyebrow">
            FACULTY DASHBOARD
          </p>

          <h1>
            Welcome back,{" "}
            <span>{faculty.name || "Faculty Member"}</span>
          </h1>

          <p>
            Track your academic activities,
            contribution reviews and approved-only
            faculty impact score.
          </p>

          <div className="faculty-overview__hero-actions">
            <button
              type="button"
              onClick={() => navigate("/faculty/profile")}
            >
              View Profile
            </button>

            <button
              type="button"
              className="faculty-overview__secondary-button"
              onClick={() => navigate("/faculty/fdp")}
            >
              Add New Activity
            </button>
          </div>
        </div>

        <div className="faculty-overview__profile-card">
          <div className="faculty-overview__profile-photo">
            {faculty.profileImage ? (
              <img
                src={getProfileImageSrc(
                  faculty.profileImage
                )}
                alt={`${faculty.name} profile`}
              />
            ) : (
              <span>
                {faculty.name
                  ?.charAt(0)
                  .toUpperCase() || "F"}
              </span>
            )}
          </div>

          <div className="faculty-overview__profile-details">
            <strong>{faculty.name || "-"}</strong>
            <span>{faculty.designation || "-"}</span>

            <div>
              <small>{faculty.department || "-"}</small>
              <small>{faculty.facultyId || "-"}</small>
            </div>
          </div>
        </div>
      </section>

      {/* PROFILE COMPLETION — based on the saved MongoDB profile */}
      <section
        className="faculty-profile-completion"
        aria-labelledby="faculty-profile-completion-title"
      >
        <div className="faculty-profile-completion__icon" aria-hidden="true">
          <span>✓</span>
        </div>

        <div className="faculty-profile-completion__content">
          <div className="faculty-profile-completion__heading">
            <div>
              <p className="faculty-profile-completion__eyebrow">
                YOUR PROFILE
              </p>
              <h2 id="faculty-profile-completion-title">
                Profile completion
              </h2>
              <p>
                {profileLoading
                  ? "Checking your saved profile details..."
                  : profileCompletion.percentage === 100
                  ? "Your profile is complete. Great work!"
                  : "Complete your details to keep your faculty profile up to date."}
              </p>
            </div>

            <div className="faculty-profile-completion__percentage">
              <strong>
                {profileLoading ? "—" : `${profileCompletion.percentage}%`}
              </strong>
              <span>
                {profileLoading
                  ? "Loading"
                  : `${profileCompletion.completed} of ${profileCompletion.total} fields`}
              </span>
            </div>
          </div>

          <div
            className="faculty-profile-completion__track"
            role="progressbar"
            aria-label="Faculty profile completion"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={profileLoading ? 0 : profileCompletion.percentage}
          >
            <div
              className="faculty-profile-completion__fill"
              style={{
                width: `${profileLoading ? 0 : profileCompletion.percentage}%`,
              }}
            />
          </div>

          <div className="faculty-profile-completion__footer">
            <div className="faculty-profile-completion__missing">
              {profileLoading ? (
                <span>Loading saved fields…</span>
              ) : profileCompletion.missingFields.length > 0 ? (
                <>
                  <strong>Still needed:</strong>{" "}
                  {profileCompletion.missingFields
                    .slice(0, 4)
                    .map((field) => field.label)
                    .join(", ")}
                  {profileCompletion.missingFields.length > 4
                    ? ` +${profileCompletion.missingFields.length - 4} more`
                    : ""}
                </>
              ) : (
                <span className="faculty-profile-completion__complete">
                  ✓ All profile fields are filled in
                </span>
              )}
            </div>

            <button
              type="button"
              className="faculty-profile-completion__edit"
              onClick={() => navigate("/faculty/profile")}
            >
              Edit Profile <span aria-hidden="true">→</span>
            </button>
          </div>
        </div>
      </section>

      {errorMessage && (
        <div className="faculty-overview__empty">
          <p>{errorMessage}</p>

          <button
            type="button"
            onClick={loadActivities}
          >
            Try Again
          </button>
        </div>
      )}

      <section className="faculty-overview__summary-grid">
        <article className="faculty-summary-card">
          <div className="faculty-summary-card__icon">
            📚
          </div>

          <div>
            <span>Total Activities</span>
            <strong>{facultyActivities.length}</strong>
            <small>All submitted records</small>
          </div>
        </article>

        <article className="faculty-summary-card">
          <div className="faculty-summary-card__icon">
            ✓
          </div>

          <div>
            <span>Approved</span>
            <strong>{approvedActivities.length}</strong>
            <small>Verified by administrator</small>
          </div>
        </article>

        <article className="faculty-summary-card">
          <div className="faculty-summary-card__icon">
            ⏳
          </div>

          <div>
            <span>Pending</span>
            <strong>{pendingActivities.length}</strong>
            <small>
              Awaiting verification ·{" "}
              {rejectedActivities.length} rejected
            </small>
          </div>
        </article>

        <article className="faculty-summary-card">
          <div className="faculty-summary-card__icon">
            🎯
          </div>

          <div>
            <span>Impact Score</span>
            <strong>{impactScore}</strong>
            <small>Balanced approved-only FIS out of 100</small>
          </div>
        </article>
      </section>

      <section className="faculty-overview__main-grid">
        <article className="faculty-overview__panel faculty-overview__panel--wide">
          <div className="faculty-overview__panel-header">
            <div>
              <h2>Activity Portfolio</h2>

              <p>
                Distribution of your academic and
                professional activities.
              </p>
            </div>

            <span className="faculty-overview__panel-badge">
              {facultyActivities.length} Records
            </span>
          </div>

          <div className="faculty-overview__category-chart">
            {categoryData.map((item) => {
              const height =
                item.count === 0
                  ? 5
                  : (item.count /
                      maximumCategoryCount) *
                    100;

              return (
                <button
                  type="button"
                  className="faculty-overview__category-item"
                  key={item.type}
                  onClick={() => navigate(item.route)}
                >
                  <strong>{item.count}</strong>

                  <div className="faculty-overview__category-track">
                    <div
                      className="faculty-overview__category-fill"
                      style={{
                        height: `${height}%`,
                      }}
                    />
                  </div>

                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </article>

        <article className="faculty-overview__panel">
          <div className="faculty-overview__panel-header">
            <div>
              <h2>Approval Overview</h2>

              <p>
                Current status of your submitted records.
              </p>
            </div>
          </div>

          <div className="faculty-overview__approval-ring">
            <div
              className="faculty-overview__approval-donut"
              style={{
                background: `conic-gradient(
                  #22a06b 0deg ${approvalRate * 3.6}deg,
                  #edf1f5 ${approvalRate * 3.6}deg 360deg
                )`,
              }}
            >
              <div>
                <strong>{approvalRate}%</strong>
                <span>Approved</span>
              </div>
            </div>
          </div>

          <div className="faculty-overview__approval-list">
            <div>
              <span className="faculty-status-dot faculty-status-dot--approved" />
              <p>Approved</p>
              <strong>{approvedActivities.length}</strong>
            </div>

            <div>
              <span className="faculty-status-dot faculty-status-dot--pending" />
              <p>Pending</p>
              <strong>{pendingActivities.length}</strong>
            </div>

            <div>
              <span className="faculty-status-dot faculty-status-dot--rejected" />
              <p>Rejected</p>
              <strong>{rejectedActivities.length}</strong>
            </div>

            <div>
              <span className="faculty-status-dot faculty-status-dot--approved" />
              <p>Approved Contributions</p>
              <strong>
                {
                  approvedContributions.length
                }
              </strong>
            </div>

            <div>
              <span className="faculty-status-dot faculty-status-dot--pending" />
              <p>Pending Contributions</p>
              <strong>
                {
                  pendingContributions.length
                }
              </strong>
            </div>

            <div>
              <span className="faculty-status-dot faculty-status-dot--rejected" />
              <p>Rejected Contributions</p>
              <strong>
                {
                  rejectedContributions.length
                }
              </strong>
            </div>
          </div>
        </article>
      </section>

      <section className="faculty-overview__main-grid">
        <article className="faculty-overview__panel">
          <div className="faculty-overview__panel-header">
            <div>
              <h2>Faculty Impact Score</h2>

              <p>
                Academic activity points are capped
                category-wise at 74 marks. Approved
                knowledge-transfer contributions add
                up to 26 marks, giving a total FIS
                of 100.
              </p>
            </div>
          </div>

          <div className="faculty-overview__score-block">
            <div>
              <strong>{impactScore}</strong>
              <span>/100</span>
            </div>

            <p>
              {impactScore >= 80
                ? "Excellent performance"
                : impactScore >= 60
                ? "Very good progress"
                : impactScore >= 40
                ? "Good progress"
                : "Add more approved activities"}
            </p>
          </div>

          <div className="faculty-overview__fis-breakdown">

  <div className="faculty-overview__fis-item">
    <span>
      Academic Activity
    </span>

    <strong>
      {activityScore}
      <small>
        /{ACTIVITY_SCORE_MAX}
      </small>
    </strong>
  </div>

  <div className="faculty-overview__fis-item">
    <span>
      Knowledge Transfer
    </span>

    <strong>
      {knowledgeTransferScore}
      <small>
        /{KNOWLEDGE_TRANSFER_MAX}
      </small>
    </strong>
  </div>

  <div className="faculty-overview__fis-item">
    <span>
      Raw Points
    </span>

    <strong>
      {rawScore}
    </strong>
  </div>

</div>

          <div className="faculty-overview__score-progress">
            <div
              style={{
                width: `${impactScore}%`,
              }}
            />
          </div>

          <button
            type="button"
            className="faculty-overview__panel-link"
            onClick={() =>
              navigate("/faculty/impact-score")
            }
          >
            View detailed score analysis
          </button>
        </article>

        <article className="faculty-overview__panel">
          <div className="faculty-overview__panel-header">
            <div>
              <h2>Quick Actions</h2>

              <p>
                Frequently used faculty tools.
              </p>
            </div>
          </div>

          <div className="faculty-overview__quick-actions">
            <button
              type="button"
              onClick={() => navigate("/faculty/fdp")}
            >
              <span>＋</span>

              <div>
                <strong>Add Activity</strong>
                <small>Submit a new academic record</small>
              </div>
            </button>

            <button
              type="button"
              onClick={() =>
                navigate("/faculty/profile")
              }
            >
              <span>♙</span>

              <div>
                <strong>Update Profile</strong>
                <small>
                  Edit personal and professional details
                </small>
              </div>
            </button>

            <button
              type="button"
              onClick={() =>
                navigate("/faculty/reports")
              }
            >
              <span>▧</span>

              <div>
                <strong>My Reports</strong>
                <small>
                  Review your academic records
                </small>
              </div>
            </button>
          </div>
        </article>
      </section>

      <section className="faculty-overview__panel faculty-overview__recent-panel">
        <div className="faculty-overview__panel-header">
          <div>
            <h2>Recent Activities</h2>

            <p>
              Your most recently submitted academic
              records.
            </p>
          </div>

          <button
            type="button"
            className="faculty-overview__panel-link"
            onClick={() => navigate("/faculty/reports")}
          >
            View all
          </button>
        </div>

        {recentActivities.length === 0 ? (
          <div className="faculty-overview__empty">
            <div>＋</div>

            <h3>No activities submitted yet</h3>

            <p>
              Add your first academic or professional
              activity to begin building your portfolio.
            </p>

            <button
              type="button"
              onClick={() => navigate("/faculty/fdp")}
            >
              Add First Activity
            </button>
          </div>
        ) : (
          <div className="faculty-overview__recent-table-wrapper">
            <table className="faculty-overview__recent-table">
              <thead>
                <tr>
                  <th>Activity</th>
                  <th>Category</th>
                  <th>Submission Date</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {recentActivities.map((activity) => {
                  const status =
                    activity.status || "Pending";

                  return (
                    <tr key={activity._id}>
                      <td>
                        <strong>
                          {activity.title || "-"}
                        </strong>

                        <span>
                          {activity.organizer ||
                            activity.publisher ||
                            "No additional details"}
                        </span>
                      </td>

                      <td>{activity.type || "-"}</td>

                      <td>
                        {formatDate(
                          activity.submissionDate ||
                            activity.createdAt
                        )}
                      </td>

                      <td>
                        <span
                          className={`faculty-overview__status faculty-overview__status--${toClassSuffix(
                            status
                          )}`}
                        >
                          {status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

export default FacultyOverview;