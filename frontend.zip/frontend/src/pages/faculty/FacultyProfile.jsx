import {

  useEffect,

  useState,

} from "react";

import "./FacultyProfile.css";

const FACULTY_API =

  "http://localhost:5000/api/faculty";

const BACKEND_ORIGIN =

  "http://localhost:5000";

const getProfileImageSrc = (value) => {

  const image = String(value || "").trim();

  if (!image) {

    return "";

  }

  if (

    image.startsWith("data:") ||

    image.startsWith("blob:") ||

    image.startsWith("http://") ||

    image.startsWith("https://")

  ) {

    return image;

  }

  return `${BACKEND_ORIGIN}${

    image.startsWith("/")

      ? image

      : `/${image}`

  }`;

};

// Calculate completed years of service from the date of joining.
const calculateExperience = (dateOfJoining) => {
  if (!dateOfJoining) return "";

  // Parse YYYY-MM-DD as a local date to avoid timezone shifts.
  const parts = String(dateOfJoining).split("-").map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) return "";

  const [year, month, day] = parts;
  const joiningDate = new Date(year, month - 1, day);
  if (Number.isNaN(joiningDate.getTime())) return "";

  const today = new Date();
  if (joiningDate > today) return "";

  let years = today.getFullYear() - joiningDate.getFullYear();
  const anniversaryThisYear = new Date(
    today.getFullYear(),
    joiningDate.getMonth(),
    joiningDate.getDate()
  );
  if (today < anniversaryThisYear) years -= 1;

  return `${years} ${years === 1 ? "year" : "years"}`;
};

function FacultyProfile() {

  const getLoggedInFaculty = () => {

    try {

      const storedFaculty =

        localStorage.getItem(

          "loggedInFaculty"

        );

      return storedFaculty

        ? JSON.parse(storedFaculty)

        : null;

    } catch (error) {

      console.error(

        "Unable to read logged-in faculty:",

        error

      );

      return null;

    }

  };

  const loggedInFaculty =

    getLoggedInFaculty();

  const [formData, setFormData] =

    useState({

      name: "",

      facultyId: "",

      department: "",

      designation: "",

      email: "",

      phone: "",

      qualification: "",

      experience: "",

      dateOfJoining: "",

      aadhaarNumber: "",

      panNumber: "",

      address: "",

      profileImage: "",

    });

  const [loading, setLoading] =

    useState(true);

  const [

    submitting,

    setSubmitting,

  ] = useState(false);

  const [

    uploadingImage,

    setUploadingImage,

  ] = useState(false);

  const [message, setMessage] =

    useState("");

  const [

    errorMessage,

    setErrorMessage,

  ] = useState("");

  // ========================================

  // HISTORICAL ACTIVITIES

  // ========================================

  const [

    historicalActivities,

    setHistoricalActivities,

  ] = useState([]);

  const [

    historicalLoading,

    setHistoricalLoading,

  ] = useState(false);

  const [

    historicalError,

    setHistoricalError,

  ] = useState("");

// ========================================

  // FORMAT DATE FOR INPUT

  // ========================================

  const formatDateForInput = (

    value

  ) => {

    if (!value) {

      return "";

    }

    const date =

      new Date(value);

    if (

      Number.isNaN(

        date.getTime()

      )

    ) {

      return "";

    }

    return date

      .toISOString()

      .split("T")[0];

  };

  // ========================================

  // LOAD CURRENT FACULTY FROM MONGODB

  // ========================================

  const loadFaculty = async () => {

    if (!loggedInFaculty?._id) {

      setLoading(false);

      return;

    }

    try {

      setLoading(true);

      setErrorMessage("");

      const token =

        localStorage.getItem("token");

      if (!token) {

        throw new Error(

          "Authentication token not found. Please login again."

        );

      }

      const response =

        await fetch(

          `${FACULTY_API}/${loggedInFaculty._id}`,

          {

            headers: {

              Authorization:

                `Bearer ${token}`,

            },

          }

        );

      const data =

        await response.json();

      if (!response.ok) {

        throw new Error(

          data.message ||

            "Unable to load faculty profile."

        );

      }

      const faculty =

        data.faculty;

      setFormData({

        name:

          faculty.name || "",

        facultyId:

          faculty.facultyId || "",

        department:

          faculty.department || "",

        designation:

          faculty.designation || "",

        email:

          faculty.email || "",

        phone:

          faculty.phone || "",

        qualification:

          faculty.qualification || "",

        experience:

          calculateExperience(formatDateForInput(faculty.dateOfJoining)),

        dateOfJoining:

          formatDateForInput(

            faculty.dateOfJoining

          ),

        aadhaarNumber:

          faculty.aadhaarNumber || "",

        panNumber:

          faculty.panNumber || "",

        address:

          faculty.address || "",

        profileImage:

          faculty.profileImage || "",

      });

      // Keep login session synchronized

      localStorage.setItem(

        "loggedInFaculty",

        JSON.stringify(

          faculty

        )

      );

    } catch (error) {

      console.error(

        "Faculty profile load error:",

        error

      );

      setErrorMessage(

        error.message ||

          "Unable to connect to the server."

      );

    } finally {

      setLoading(false);

    }

  };

  // ========================================

  // LOAD HISTORICAL ACTIVITIES

  // ========================================

  const loadHistoricalActivities = async () => {

    if (!loggedInFaculty?.facultyId) {

      return;

    }

    try {

      setHistoricalLoading(true);

      setHistoricalError("");

      const token =

        localStorage.getItem("token");

      if (!token) {

        throw new Error(

          "Authentication token not found. Please login again."

        );

      }

      const response =

        await fetch(

          `${BACKEND_ORIGIN}/api/historical-activities/faculty/${loggedInFaculty.facultyId}`,

          {

            headers: {

              Authorization:

                `Bearer ${token}`,

            },

          }

        );

      const data =

        await response.json();

      if (!response.ok) {

        throw new Error(

          data.message ||

            "Unable to load historical activities."

        );

      }

      setHistoricalActivities(

        data.activities || []

      );

    } catch (error) {

      console.error(

        "Historical activities loading error:",

        error

      );

      setHistoricalError(

        error.message ||

          "Unable to load historical activities."

      );

    } finally {

      setHistoricalLoading(false);

    }

  };

  useEffect(() => {

    loadFaculty();

    loadHistoricalActivities();

  }, []);

  // ========================================

  // LOGIN CHECK

  // ========================================

  if (!loggedInFaculty) {

    return (

      <div className="faculty-profile__no-user">

        <h1>

          No faculty login found

        </h1>

        <p>

          Please log in again.

        </p>

        <button

          type="button"

          onClick={() => {

            window.location.href =

              "/";

          }}

        >

          Back to Login

        </button>

      </div>

    );

  }

  // ========================================

  // HANDLE CHANGE

  // ========================================

  const handleChange = (

    event

  ) => {

    const {

      name,

      value,

    } = event.target;

    let updatedValue =

      value;

    if (name === "phone") {

      updatedValue =

        value

          .replace(/\D/g, "")

          .slice(0, 10);

    }

    if (

      name === "aadhaarNumber"

    ) {

      updatedValue =

        value

          .replace(/\D/g, "")

          .slice(0, 12);

    }

    if (

      name === "panNumber"

    ) {

      updatedValue =

        value

          .toUpperCase()

          .replace(

            /[^A-Z0-9]/g,

            ""

          )

          .slice(0, 10);

    }

    setFormData(

      (previousData) => ({

        ...previousData,

        [name]:

          updatedValue,

      })

    );

    setMessage("");

    setErrorMessage("");

  };

  // ========================================

  // PROFILE IMAGE UPLOAD

  // SAVES DIRECTLY TO MONGODB

  // ========================================

  const handleImageUpload =

    async (event) => {

      const file =

        event.target.files?.[0];

      setMessage("");

      setErrorMessage("");

      if (!file) {

        return;

      }

      if (!loggedInFaculty?._id) {

        setErrorMessage(

          "Faculty account information is missing. Please login again."

        );

        event.target.value = "";

        return;

      }

      const allowedTypes = [

        "image/jpeg",

        "image/jpg",

        "image/png",

        "image/webp",

      ];

      if (

        !allowedTypes.includes(

          file.type

        )

      ) {

        setErrorMessage(

          "Please upload a JPG, JPEG, PNG or WEBP image."

        );

        event.target.value = "";

        return;

      }

      const maximumSize =

        1024 * 1024;

      if (

        file.size >

        maximumSize

      ) {

        setErrorMessage(

          "Profile image must be smaller than 1 MB."

        );

        event.target.value = "";

        return;

      }

      try {

        setUploadingImage(true);

        const token =

          localStorage.getItem(

            "token"

          );

        if (!token) {

          throw new Error(

            "Authentication token not found. Please login again."

          );

        }

        const uploadData =

          new FormData();

        uploadData.append(

          "image",

          file

        );

        const response =

          await fetch(

            `${FACULTY_API}/${loggedInFaculty._id}/upload-profile-image`,

            {

              method: "POST",

              headers: {

                Authorization:

                  `Bearer ${token}`,

              },

              body: uploadData,

            }

          );

        const data =

          await response.json();

        if (!response.ok) {

          throw new Error(

            data.message ||

              "Unable to upload profile photograph."

          );

        }

        const updatedFaculty =

          data.faculty;

        if (!updatedFaculty) {

          throw new Error(

            "The server did not return the updated faculty profile."

          );

        }

        setFormData(

          (previousData) => ({

            ...previousData,

            profileImage:

              updatedFaculty.profileImage ||

              "",

          })

        );

        localStorage.setItem(

          "loggedInFaculty",

          JSON.stringify(

            updatedFaculty

          )

        );

        setMessage(

          "Profile photograph uploaded successfully."

        );

      } catch (error) {

        console.error(

          "Profile image upload error:",

          error

        );

        setErrorMessage(

          error.message ||

            "Unable to upload profile photograph."

        );

      } finally {

        setUploadingImage(false);

        event.target.value = "";

      }

    };

  // ========================================

  // REMOVE PROFILE IMAGE

  // ========================================

  const handleRemoveImage =

    async () => {

      if (!loggedInFaculty?._id) {

        setErrorMessage(

          "Faculty account information is missing. Please login again."

        );

        return;

      }

      const confirmed =

        window.confirm(

          "Remove your profile photograph?"

        );

      if (!confirmed) {

        return;

      }

      try {

        setUploadingImage(true);

        setMessage("");

        setErrorMessage("");

        const token =

          localStorage.getItem(

            "token"

          );

        if (!token) {

          throw new Error(

            "Authentication token not found. Please login again."

          );

        }

        const response =

          await fetch(

            `${FACULTY_API}/${loggedInFaculty._id}`,

            {

              method: "PUT",

              headers: {

                "Content-Type":

                  "application/json",

                Authorization:

                  `Bearer ${token}`,

              },

              body: JSON.stringify({

                profileImage: "",

              }),

            }

          );

        const data =

          await response.json();

        if (!response.ok) {

          throw new Error(

            data.message ||

              "Unable to remove profile photograph."

          );

        }

        const updatedFaculty =

          data.faculty;

        setFormData(

          (previousData) => ({

            ...previousData,

            profileImage: "",

          })

        );

        if (updatedFaculty) {

          localStorage.setItem(

            "loggedInFaculty",

            JSON.stringify(

              updatedFaculty

            )

          );

        }

        setMessage(

          "Profile photograph removed successfully."

        );

      } catch (error) {

        console.error(

          "Profile image remove error:",

          error

        );

        setErrorMessage(

          error.message ||

            "Unable to remove profile photograph."

        );

      } finally {

        setUploadingImage(false);

      }

    };

  // ========================================

  // VALIDATE + SAVE TO MONGODB

  // ========================================

  const handleSubmit =

    async (event) => {

      event.preventDefault();

      setMessage("");

      setErrorMessage("");

      if (!loggedInFaculty?._id) {

        setErrorMessage(

          "Faculty account information is missing. Please login again."

        );

        return;

      }

      const cleanName =

        formData.name.trim();

      const cleanEmail =

        formData.email

          .trim()

          .toLowerCase();

      const cleanAadhaar =

        formData.aadhaarNumber.trim();

      const cleanPan =

        formData.panNumber

          .trim()

          .toUpperCase();

      const emailPattern =

        /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/i;

      const panPattern =

        /^[A-Z]{5}[0-9]{4}[A-Z]$/;

      if (!cleanName) {

        setErrorMessage(

          "Please enter your full name."

        );

        return;

      }

      if (!formData.department) {

        setErrorMessage(

          "Please select your department."

        );

        return;

      }

      if (!formData.designation) {

        setErrorMessage(

          "Please select your designation."

        );

        return;

      }

      if (

        !emailPattern.test(

          cleanEmail

        )

      ) {

        setErrorMessage(

          "Please enter a valid email address."

        );

        return;

      }

      if (

        formData.phone &&

        !/^[0-9]{10}$/.test(

          formData.phone

        )

      ) {

        setErrorMessage(

          "Phone number must contain exactly 10 digits."

        );

        return;

      }

      if (

        !/^[0-9]{12}$/.test(

          cleanAadhaar

        )

      ) {

        setErrorMessage(

          "Aadhaar number must contain exactly 12 digits."

        );

        return;

      }

      if (

        !panPattern.test(

          cleanPan

        )

      ) {

        setErrorMessage(

          "Enter a valid PAN number, for example ABCDE1234F."

        );

        return;

      }

      if (

        formData.dateOfJoining &&

        new Date(formData.dateOfJoining) >

          new Date()

      ) {

        setErrorMessage(

          "Date of joining cannot be in the future."

        );

        return;

      }

      const updateData = {

        name:

          cleanName,

        department:

          formData.department,

        designation:

          formData.designation,

        email:

          cleanEmail,

        phone:

          formData.phone,

        qualification:

          formData.qualification.trim(),

        experience:

          calculateExperience(formData.dateOfJoining),

        dateOfJoining:

          formData.dateOfJoining ||

          null,

        aadhaarNumber:

          cleanAadhaar,

        panNumber:

          cleanPan,

        address:

          formData.address.trim(),

      };

      try {

        setSubmitting(true);

        const token =

          localStorage.getItem(

            "token"

          );

        if (!token) {

          throw new Error(

            "Authentication token not found. Please login again."

          );

        }

        const response =

          await fetch(

            `${FACULTY_API}/${loggedInFaculty._id}`,

            {

              method:

                "PUT",

              headers: {

                "Content-Type":

                  "application/json",

                Authorization:

                  `Bearer ${token}`,

              },

              body:

                JSON.stringify(

                  updateData

                ),

            }

          );

        const data =

          await response.json();

        if (!response.ok) {

          throw new Error(

            data.message ||

              "Unable to update faculty profile."

          );

        }

        const updatedFaculty =

          data.faculty;

        // Keep only current login session locally

        localStorage.setItem(

          "loggedInFaculty",

          JSON.stringify(

            updatedFaculty

          )

        );

        setFormData({

          name:

            updatedFaculty.name ||

            "",

          facultyId:

            updatedFaculty.facultyId ||

            "",

          department:

            updatedFaculty.department ||

            "",

          designation:

            updatedFaculty.designation ||

            "",

          email:

            updatedFaculty.email ||

            "",

          phone:

            updatedFaculty.phone ||

            "",

          qualification:

            updatedFaculty.qualification ||

            "",

          experience:

            calculateExperience(formatDateForInput(updatedFaculty.dateOfJoining)),

          dateOfJoining:

            formatDateForInput(

              updatedFaculty.dateOfJoining

            ),

          aadhaarNumber:

            updatedFaculty.aadhaarNumber ||

            "",

          panNumber:

            updatedFaculty.panNumber ||

            "",

          address:

            updatedFaculty.address ||

            "",

          profileImage:

            updatedFaculty.profileImage ||

            "",

        });

        setMessage(

          "Profile updated successfully."

        );

      } catch (error) {

        console.error(

          "Faculty profile update error:",

          error

        );

        setErrorMessage(

          error.message ||

            "Unable to update profile."

        );

      } finally {

        setSubmitting(false);

      }

    };

  // ========================================

  // LOADING

  // ========================================

  if (loading) {

    return (

      <div className="faculty-profile__no-user">

        <p>

          Loading faculty profile...

        </p>

      </div>

    );

  }

  // ========================================

  // JSX

  // ========================================

  return (

    <div className="faculty-profile">

      <section className="faculty-profile__heading">

        <div>

          <p className="faculty-profile__eyebrow">

            FACULTY ACCOUNT

          </p>

          <h1>

            My Profile

          </h1>

          <p>

            View and update your

            personal and professional

            information.

          </p>

        </div>

      </section>

      <section className="faculty-profile__card">

        <form

          className="faculty-profile__form"

          onSubmit={

            handleSubmit

          }

        >

          {/* PROFILE PHOTO */}

          <div className="faculty-profile__photo-section">

            <div className="faculty-profile__photo-preview">

              {formData.profileImage ? (

                <img

                  src={getProfileImageSrc(

                    formData.profileImage

                  )}

                  alt={`${

                    formData.name ||

                    "Faculty"

                  } profile`}

                />

              ) : (

                <span>

                  {formData.name

                    ? formData.name

                        .charAt(0)

                        .toUpperCase()

                    : "F"}

                </span>

              )}

            </div>

            <div className="faculty-profile__photo-content">

              <h2>

                Profile Photograph

              </h2>

              <p>

                Upload a clear JPG,

                PNG or WEBP image.

                Maximum file size is

                1 MB. The photograph

                is saved immediately.

              </p>

              <div className="faculty-profile__photo-actions">

                <label className="faculty-profile__upload-button">

                  {uploadingImage

                    ? "Uploading..."

                    : "Upload Image"}

                  <input

                    type="file"

                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"

                    disabled={

                      uploadingImage

                    }

                    onChange={

                      handleImageUpload

                    }

                  />

                </label>

                {formData.profileImage && (

                  <button

                    type="button"

                    className="faculty-profile__remove-image"

                    disabled={

                      uploadingImage

                    }

                    onClick={

                      handleRemoveImage

                    }

                  >

                    Remove Image

                  </button>

                )}

              </div>

            </div>

          </div>

          {/* BASIC INFORMATION */}

          <div className="faculty-profile__section-heading">

            <h2>

              Basic Information

            </h2>

            <p>

              Faculty identity and

              contact details

            </p>

          </div>

          <div className="faculty-profile__grid">

            <div className="faculty-profile__field">

              <label htmlFor="name">

                Full Name

              </label>

              <input

                id="name"

                type="text"

                name="name"

                value={

                  formData.name

                }

                onChange={

                  handleChange

                }

                required

              />

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="facultyId">

                Faculty ID

              </label>

              <input

                id="facultyId"

                type="text"

                name="facultyId"

                value={

                  formData.facultyId

                }

                disabled

              />

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="department">

                Department

              </label>

              <select

                id="department"

                name="department"

                value={

                  formData.department

                }

                onChange={

                  handleChange

                }

                required

              >

                <option value="">

                  Select Department

                </option>

                <option value="CSE">

                  Computer Science

                  &amp; Engineering

                </option>

                <option value="ECE">

                  Electronics &amp;

                  Communication

                  Engineering

                </option>

                <option value="EEE">

                  Electrical &amp;

                  Electronics

                  Engineering

                </option>

                <option value="ME">

                  Mechanical

                  Engineering

                </option>

                <option value="CE">

                  Civil Engineering

                </option>

              </select>

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="designation">

                Designation

              </label>

              <select

                id="designation"

                name="designation"

                value={

                  formData.designation

                }

                onChange={

                  handleChange

                }

                required

              >

                <option value="">

                  Select Designation

                </option>

                <option value="Professor">

                  Professor

                </option>

                <option value="Associate Professor">

                  Associate Professor

                </option>

                <option value="Assistant Professor">

                  Assistant Professor

                </option>

              </select>

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="email">

                Email Address

              </label>

              <input

                id="email"

                type="email"

                name="email"

                value={

                  formData.email

                }

                onChange={

                  handleChange

                }

                required

              />

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="phone">

                Phone Number

              </label>

              <input

                id="phone"

                type="tel"

                name="phone"

                inputMode="numeric"

                placeholder="Enter 10-digit phone number"

                value={

                  formData.phone

                }

                onChange={

                  handleChange

                }

                maxLength={10}

              />

            </div>

          </div>

          {/* IDENTITY */}

          <div className="faculty-profile__section-heading">

            <h2>

              Identity Details

            </h2>

            <p>

              Aadhaar and PAN numbers

              must be unique for every

              faculty account.

            </p>

          </div>

          <div className="faculty-profile__grid">

            <div className="faculty-profile__field">

              <label htmlFor="aadhaarNumber">

                Aadhaar Number

              </label>

              <input

                id="aadhaarNumber"

                type="text"

                name="aadhaarNumber"

                inputMode="numeric"

                placeholder="Enter 12-digit Aadhaar number"

                value={

                  formData.aadhaarNumber

                }

                onChange={

                  handleChange

                }

                maxLength={12}

                required

              />

              <small>

                Must contain exactly

                12 digits.

              </small>

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="panNumber">

                PAN Number

              </label>

              <input

                id="panNumber"

                type="text"

                name="panNumber"

                placeholder="Example: ABCDE1234F"

                value={

                  formData.panNumber

                }

                onChange={

                  handleChange

                }

                maxLength={10}

                required

              />

              <small>

                Format: five letters,

                four numbers and one

                letter.

              </small>

            </div>

          </div>

          {/* PROFESSIONAL */}

          <div className="faculty-profile__section-heading">

            <h2>

              Professional

              Information

            </h2>

            <p>

              Qualification and

              employment details

            </p>

          </div>

          <div className="faculty-profile__grid">

            <div className="faculty-profile__field">

              <label htmlFor="qualification">

                Qualification

              </label>

              <input

                id="qualification"

                type="text"

                name="qualification"

                placeholder="Example: M.Tech, PhD"

                value={

                  formData.qualification

                }

                onChange={

                  handleChange

                }

              />

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="experience">

                Experience

              </label>

              <input
                id="experience"
                type="text"
                name="experience"
                placeholder="Calculated from date of joining"
                value={calculateExperience(formData.dateOfJoining)}
                readOnly
                aria-readonly="true"
              />
              <small>Automatically calculated from your date of joining.</small>

            </div>

            <div className="faculty-profile__field">

              <label htmlFor="dateOfJoining">

                Date of Joining

              </label>

              <input

                id="dateOfJoining"

                type="date"

                name="dateOfJoining"

                value={

                  formData.dateOfJoining

                }

                onChange={

                  handleChange

                }

                max={

                  new Date()

                    .toISOString()

                    .split("T")[0]

                }

              />

            </div>

            <div className="faculty-profile__field faculty-profile__field--full">

              <label htmlFor="address">

                Address

              </label>

              <textarea

                id="address"

                name="address"

                rows={4}

                value={

                  formData.address

                }

                onChange={

                  handleChange

                }

                placeholder="Enter residential address"

              />

            </div>

          </div>

                    {/* HISTORICAL ACTIVITIES */}

          <div className="faculty-profile__section-heading">

            <h2>

              Activities

            </h2>

            <p>

              Historical academic activity records

            </p>

          </div>

          <div className="faculty-profile__activities">

            {historicalLoading && (

              <div className="faculty-profile__message">

                Loading historical activities...

              </div>

            )}

            {historicalError && (

              <div className="faculty-profile__message faculty-profile__message--error">

                {historicalError}

              </div>

            )}

            {!historicalLoading &&

              !historicalError &&

              historicalActivities.length === 0 && (

                <div className="faculty-profile__message">

                  No historical activities found.

                </div>

              )}

            {!historicalLoading &&

              historicalActivities.length > 0 && (

                <div className="faculty-profile__activities-list">

                  {historicalActivities.map((activity) => {

                    const activityDate =

                      activity.activityDate ||

                      activity.publicationDate ||

                      activity.startDate;

                    return (

                      <article

                        key={activity._id}

                        className="faculty-profile__activity-card"

                      >

                        <div className="faculty-profile__activity-card-top">

                          <span className="faculty-profile__activity-type">

                            {activity.type}

                          </span>

                          {activity.academicYear && (

                            <span className="faculty-profile__activity-year">

                              {activity.academicYear}

                            </span>

                          )}

                        </div>

                        <h3>

                          {activity.title ||

                            "Untitled activity"}

                        </h3>

                        {activityDate && (

                          <p>

                            <strong>Date:</strong>{" "}

                            {new Date(

                              activityDate

                            ).toLocaleDateString("en-IN")}

                          </p>

                        )}

                        {activity.type === "FDP" ? (

  <>

    {activity.duration && (

      <p>

        <strong>Duration:</strong>{" "}

        {activity.duration}

      </p>

    )}

    {activity.organizer && (

      <p>

        <strong>Conducted by:</strong>{" "}

        {activity.organizer}

      </p>

    )}

  </>

) : activity.type === "Journal Publication" ? (

  <>

    {activity.journalName && (

      <p>

        <strong>Journal:</strong>{" "}

        {activity.journalName}

      </p>

    )}

    {activity.publicationStatus && (

      <p>

        <strong>Status:</strong>{" "}

        {activity.publicationStatus}

      </p>

    )}

    {activity.publicationType && (

      <p>

        <strong>Publication Type:</strong>{" "}

        {activity.publicationType}

      </p>

    )}

    {activity.indexing && (

      <p>

        <strong>Indexing:</strong>{" "}

        {activity.indexing}

      </p>

    )}

    {activity.doi && (

      <p>

        <strong>DOI:</strong>{" "}

        {activity.doi}

      </p>

    )}

    {(activity.publicationLink || activity.doi) && (

      <p>

        <strong>Publication:</strong>{" "}

        <a

          href={

            activity.doi

              ? `https://doi.org/${activity.doi.replace(

                  /^https?:\/\/doi\.org\//i,

                  ""

                )}`

              : activity.publicationLink

          }

          target="_blank"

          rel="noopener noreferrer"

        >

          View publication

        </a>

      </p>

    )}

  </>

) : activity.type === "Conference" ? (

  <>

    {activity.conferenceName && (

      <p>

        <strong>Conference:</strong>{" "}

        {activity.conferenceName}

      </p>

    )}

    {activity.publicationStatus && (

      <p>

        <strong>Status:</strong>{" "}

        {activity.publicationStatus}

      </p>

    )}

    {activity.indexing && (

      <p>

        <strong>Indexing:</strong>{" "}

        {activity.indexing}

      </p>

    )}

    {activity.doi && (

      <p>

        <strong>DOI:</strong>{" "}

        {activity.doi}

      </p>

    )}

    {(activity.publicationLink || activity.doi) && (

      <p>

        <strong>Publication:</strong>{" "}

        <a

          href={

            activity.doi

              ? `https://doi.org/${activity.doi.replace(

                  /^https?:\/\/doi\.org\//i,

                  ""

                )}`

              : activity.publicationLink

          }

          target="_blank"

          rel="noopener noreferrer"

        >

          View publication

        </a>

      </p>

    )}

  </>

) : activity.type === "Book Chapter" ? (

  <>

    {activity.conferenceName && (

      <p>

        <strong>Conference / Event:</strong>{" "}

        {activity.conferenceName}

      </p>

    )}

    {activity.publicationStatus && (

      <p>

        <strong>Status:</strong>{" "}

        {activity.publicationStatus}

      </p>

    )}

    {activity.publicationType && (

      <p>

        <strong>Publication Type:</strong>{" "}

        {activity.publicationType}

      </p>

    )}

    {activity.indexing && (

      <p>

        <strong>Indexing:</strong>{" "}

        {activity.indexing}

      </p>

    )}

    {activity.doi && (

      <p>

        <strong>DOI:</strong>{" "}

        {activity.doi}

      </p>

    )}

    {(activity.publicationLink || activity.doi) && (

      <p>

        <strong>Publication:</strong>{" "}

        <a

          href={

            activity.doi

              ? `https://doi.org/${activity.doi.replace(

                  /^https?:\/\/doi\.org\//i,

                  ""

                )}`

              : activity.publicationLink

          }

          target="_blank"

          rel="noopener noreferrer"

        >

          View publication

        </a>

      </p>

    )}

  </>

) : null}

</article>

                    );

                  })}

                </div>

              )}

          </div>

{errorMessage && (

            <div className="faculty-profile__message faculty-profile__message--error">

              {errorMessage}

            </div>

          )}

          {message && (

            <div className="faculty-profile__message faculty-profile__message--success">

              {message}

            </div>

          )}

          <div className="faculty-profile__actions">

            <button

              type="submit"

              disabled={

                submitting ||

                uploadingImage

              }

            >

              {submitting

                ? "Saving..."

                : "Save Profile Changes"}

            </button>

          </div>

        </form>

      </section>

    </div>

  );

}

export default FacultyProfile;