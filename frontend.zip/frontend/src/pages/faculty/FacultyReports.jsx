import { useEffect, useState } from "react";
import "./FacultyReports.css";

const BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  "http://localhost:5000";

const API_URL =
  `${BACKEND_URL}/api/activities`;

const ACTIVITY_TYPES = [
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
];

const ACTIVITY_CONFIG = {
  FDP: {
    pointsPerActivity: 2,
    maxScore: 12,
  },
  NPTEL: {
    pointsPerActivity: 3,
    maxScore: 18,
  },
  "Research Paper": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
  "Journal Publication": {
    pointsPerActivity: 7,
    maxScore: 14,
  },
  "Patent / IPR": {
    pointsPerActivity: 5,
    maxScore: 15,
  },
};

const CONTRIBUTION_WEIGHTS = {
  Students: 4,
  Department: 5,
  Both: 8,
};

const ACTIVITY_SCORE_MAX = 74;
const KNOWLEDGE_TRANSFER_MAX = 26;

function getLoggedInFaculty() {
  try {
    const value = localStorage.getItem("loggedInFaculty");
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.error("Unable to read logged-in faculty:", error);
    return null;
  }
}

function FacultyReports() {
  const [faculty] = useState(() => getLoggedInFaculty());

  const [typeFilter, setTypeFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [
    contributionStatusFilter,
    setContributionStatusFilter,
  ] = useState("All");
  const [searchText, setSearchText] = useState("");
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  const loadActivities = async () => {
    if (!faculty?.facultyId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const token = localStorage.getItem("token");

      if (!token) {
        throw new Error(
          "Authentication token not found. Please login again."
        );
      }

      const response = await fetch(
        `${API_URL}/faculty/${encodeURIComponent(
          faculty.facultyId
        )}`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Unable to load faculty reports."
        );
      }

      setActivities(data.activities || []);
    } catch (error) {
      console.error(
        "Faculty reports load error:",
        error
      );

      setErrorMessage(
        error.message ||
          "Unable to connect to the server."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivities();
  }, []);

  const facultyActivities = activities.filter(
    (activity) =>
      ACTIVITY_TYPES.includes(activity.type)
  );

  const activityTypes = [
    "All",
    ...ACTIVITY_TYPES,
  ];

  const filteredActivities =
    facultyActivities.filter((activity) => {
      const status =
        activity.status || "Pending";

      const value =
        searchText.trim().toLowerCase();

      const matchesType =
        typeFilter === "All" ||
        activity.type === typeFilter;

      const contributionStatus =
        activity.contributionDone ===
        "Yes"
          ? activity.contributionStatus ||
            "Pending"
          : "Not Applicable";

      const matchesStatus =
        statusFilter === "All" ||
        status === statusFilter;

      const matchesContributionStatus =
        contributionStatusFilter ===
          "All" ||
        contributionStatus ===
          contributionStatusFilter;

      const searchableValues = [
        activity.title,
        activity.type,
        activity.academicYear,
        activity.contributionTitle,
        activity.contributionType,
        activity.contributionFor,
      ];

      const matchesSearch =
        !value ||
        searchableValues.some(
          (item) =>
            String(item || "")
              .toLowerCase()
              .includes(value)
        );

      return (
        matchesType &&
        matchesStatus &&
        matchesContributionStatus &&
        matchesSearch
      );
    });

  const handlePrint = () => {
    if (loading) {
      alert("Please wait until the faculty activity records finish loading.");
      return;
    }
    if (errorMessage) {
      alert("The report could not be fully loaded. Please resolve the loading error before printing.");
      return;
    }
    window.print();
  };

  const handleExport = () => {
    if (filteredActivities.length === 0) {
      alert("No records available to export.");
      return;
    }

    const rows = filteredActivities.map(
      (activity) => ({
        "Faculty ID":
          faculty?.facultyId || "",
        Faculty:
          faculty?.name || "",
        Department:
          faculty?.department || "",
        "Activity Type":
          activity.type || "",
        Title:
          activity.title || "",
        "Academic Year":
          activity.academicYear || "",
        "Submission Date":
          activity.submissionDate ||
          activity.createdAt ||
          "",
        Status:
          activity.status || "Pending",

        "Contribution Done":
          activity.contributionDone || "No",

        "Contribution For":
          activity.contributionFor || "",

        "Contribution Status":
          activity.contributionDone ===
          "Yes"
            ? activity.contributionStatus ||
              "Pending"
            : "Not Applicable",

        "Raw Activity Points":
          activity.status ===
          "Approved"
            ? ACTIVITY_CONFIG[
                activity.type
              ]?.pointsPerActivity || 0
            : 0,

        "Raw Knowledge Transfer Points":
          activity.status ===
            "Approved" &&
          activity.contributionDone ===
            "Yes" &&
          activity.contributionStatus ===
            "Approved"
            ? CONTRIBUTION_WEIGHTS[
                activity.contributionFor
              ] || 0
            : 0,

        "Impact Eligible":
          activity.status ===
            "Approved"
            ? "Yes"
            : "No",
      })
    );

    const headers = Object.keys(rows[0]);

    const escapeValue = (value) => {
      const text = String(value ?? "");

      if (
        text.includes(",") ||
        text.includes('"') ||
        text.includes("\n")
      ) {
        return `"${text.replaceAll(
          '"',
          '""'
        )}"`;
      }

      return text;
    };

    const csv = [
      headers
        .map(escapeValue)
        .join(","),
      ...rows.map((row) =>
        headers
          .map((header) =>
            escapeValue(row[header])
          )
          .join(",")
      ),
    ].join("\n");

    const blob = new Blob(
      [csv],
      {
        type: "text/csv;charset=utf-8;",
      }
    );

    const url =
      URL.createObjectURL(blob);

    const link =
      document.createElement("a");

    link.href = url;

    link.download = `${
      faculty?.facultyId || "faculty"
    }-activity-report.csv`;

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  };

  const formatDate = (value) => {
    if (!value) {
      return "-";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return String(value);
    }

    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }
    );
  };

  const approved =
    facultyActivities.filter(
      (item) =>
        item.status === "Approved"
    ).length;

  const pending =
    facultyActivities.filter(
      (item) =>
        (item.status || "Pending") ===
        "Pending"
    ).length;

  const rejected =
    facultyActivities.filter(
      (item) =>
        item.status === "Rejected"
    ).length;


  const approvedContributions =
    facultyActivities.filter(
      (item) =>
        item.status ===
          "Approved" &&
        item.contributionDone ===
          "Yes" &&
        item.contributionStatus ===
          "Approved"
    );

  const pendingContributions =
    facultyActivities.filter(
      (item) =>
        item.contributionDone ===
          "Yes" &&
        (item.contributionStatus ||
          "Pending") ===
          "Pending"
    );

  const rejectedContributions =
    facultyActivities.filter(
      (item) =>
        item.status ===
          "Approved" &&
        item.contributionDone ===
          "Yes" &&
        item.contributionStatus ===
          "Rejected"
    );

  const approvedActivityList =
    facultyActivities.filter(
      (activity) =>
        activity.status === "Approved"
    );

  const categoryScores =
    Object.entries(
      ACTIVITY_CONFIG
    ).map(
      ([type, config]) => {
        const approvedCount =
          approvedActivityList.filter(
            (activity) =>
              activity.type === type
          ).length;

        const rawCategoryScore =
          approvedCount *
          config.pointsPerActivity;

        const cappedCategoryScore =
          Math.min(
            rawCategoryScore,
            config.maxScore
          );

        return {
          type,
          approvedCount,
          rawCategoryScore,
          cappedCategoryScore,
          maxScore: config.maxScore,
        };
      }
    );

  const rawActivityScore =
    categoryScores.reduce(
      (total, category) =>
        total +
        category.rawCategoryScore,
      0
    );

  const activityScore =
    categoryScores.reduce(
      (total, category) =>
        total +
        category.cappedCategoryScore,
      0
    );

  const rawKnowledgeTransferScore =
    facultyActivities.reduce(
      (total, activity) => {
        if (
          activity.status !==
            "Approved" ||
          activity.contributionDone !==
            "Yes" ||
          activity.contributionStatus !==
            "Approved"
        ) {
          return total;
        }

        return (
          total +
          (CONTRIBUTION_WEIGHTS[
            activity.contributionFor
          ] || 0)
        );
      },
      0
    );

  const knowledgeTransferScore =
    Math.min(
      rawKnowledgeTransferScore,
      KNOWLEDGE_TRANSFER_MAX
    );

  const rawScore =
    rawActivityScore +
    rawKnowledgeTransferScore;

  const impactScore =
    Math.min(
      activityScore +
        knowledgeTransferScore,
      100
    );

  const academicYearSummary = Object.values(
    facultyActivities.reduce((summary, activity) => {
      const year = activity.academicYear || "Not specified";
      if (!summary[year]) {
        summary[year] = { year, total: 0, approved: 0, pending: 0, rejected: 0 };
      }
      summary[year].total += 1;
      const status = activity.status || "Pending";
      if (status === "Approved") summary[year].approved += 1;
      else if (status === "Rejected") summary[year].rejected += 1;
      else summary[year].pending += 1;
      return summary;
    }, {})
  ).sort((a, b) => String(a.year).localeCompare(String(b.year)));

  const getActivityPoints = (activity) => {
    const status = activity.status || "Pending";
    const activityPoints =
      status === "Approved"
        ? ACTIVITY_CONFIG[activity.type]?.pointsPerActivity || 0
        : 0;
    const contributionPoints =
      status === "Approved" &&
      activity.contributionDone === "Yes" &&
      activity.contributionStatus === "Approved"
        ? CONTRIBUTION_WEIGHTS[activity.contributionFor] || 0
        : 0;
    return { activityPoints, contributionPoints };
  };

  if (!faculty) {
    return (
      <div className="faculty-reports">
        <div className="faculty-reports-empty">
          Faculty login not found. Please log in again.
        </div>
      </div>
    );
  }

  return (
    <div className="faculty-reports">

      {/* Dedicated report document: shown only when printing / saving as PDF */}
      <div className="faculty-report-print-document">
        <header className="faculty-report-print-header">
          <div className="faculty-report-print-brand">FACULTY MANAGEMENT SYSTEM</div>
          <h1>Individual Faculty Activity Report</h1>
          <p>Academic performance, activity records and knowledge-transfer summary</p>
        </header>

        <section className="faculty-report-print-section">
          <h2>1. Faculty Profile</h2>
          <div className="faculty-report-print-profile-grid">
            <div><span>Faculty Name</span><strong>{faculty.name || "Not provided"}</strong></div>
            <div><span>Faculty ID</span><strong>{faculty.facultyId || "Not provided"}</strong></div>
            <div><span>Department</span><strong>{faculty.department || "Not provided"}</strong></div>
            <div><span>Designation</span><strong>{faculty.designation || "Not provided"}</strong></div>
            <div><span>Email</span><strong>{faculty.email || "Not provided"}</strong></div>
            <div><span>Phone</span><strong>{faculty.phone || "Not provided"}</strong></div>
            <div><span>Qualification</span><strong>{faculty.qualification || "Not provided"}</strong></div>
            <div><span>Experience</span><strong>{faculty.experience || "Not provided"}</strong></div>
            <div><span>Date of Joining</span><strong>{formatDate(faculty.dateOfJoining)}</strong></div>
          </div>
        </section>

        <section className="faculty-report-print-section">
          <h2>2. Performance Summary</h2>
          <div className="faculty-report-print-stat-grid">
            <div><span>Total Activity Records</span><strong>{facultyActivities.length}</strong></div>
            <div><span>Approved</span><strong>{approved}</strong></div>
            <div><span>Pending</span><strong>{pending}</strong></div>
            <div><span>Rejected</span><strong>{rejected}</strong></div>
            <div><span>Approved Contributions</span><strong>{approvedContributions.length}</strong></div>
            <div><span>Pending Contributions</span><strong>{pendingContributions.length}</strong></div>
            <div><span>Rejected Contributions</span><strong>{rejectedContributions.length}</strong></div>
            <div><span>Impact Score</span><strong>{impactScore}/100</strong></div>
          </div>
        </section>

        <section className="faculty-report-print-section">
          <h2>3. Faculty Impact Score (FIS) Breakdown</h2>
          <p className="faculty-report-print-note">
            Scores below use the existing approved-only scoring rules in the Faculty Reports page.
            Pending and rejected activities do not earn activity points.
          </p>
          <table className="faculty-report-print-table">
            <thead><tr><th>Activity Category</th><th>Approved Records</th><th>Raw Points</th><th>Applied Points</th><th>Category Maximum</th></tr></thead>
            <tbody>
              {categoryScores.map((category) => (
                <tr key={category.type}>
                  <td>{category.type}</td>
                  <td>{category.approvedCount}</td>
                  <td>{category.rawCategoryScore}</td>
                  <td>{category.cappedCategoryScore}</td>
                  <td>{category.maxScore}</td>
                </tr>
              ))}
              <tr><th>Activity Score Total</th><td>—</td><td>{rawActivityScore}</td><td>{activityScore}</td><td>{ACTIVITY_SCORE_MAX}</td></tr>
            </tbody>
          </table>
          <table className="faculty-report-print-table faculty-report-print-table--compact">
            <thead><tr><th>Knowledge Transfer</th><th>Raw Points</th><th>Applied Points</th><th>Maximum</th></tr></thead>
            <tbody>
              <tr><td>Approved contributions only</td><td>{rawKnowledgeTransferScore}</td><td>{knowledgeTransferScore}</td><td>{KNOWLEDGE_TRANSFER_MAX}</td></tr>
              <tr><th>Overall Impact Score</th><td>{rawScore} raw combined points</td><td>{impactScore}</td><td>100</td></tr>
            </tbody>
          </table>
          <p className="faculty-report-print-note">
            Activity category weights: FDP 2 points (max 12); NPTEL 3 (max 18); Research Paper 5 (max 15);
            Journal Publication 7 (max 14); Patent / IPR 5 (max 15). Knowledge-transfer weights:
            Students 4, Department 5, Both 8, capped at 26.
          </p>
        </section>

        <section className="faculty-report-print-section">
          <h2>4. Academic-Year Summary</h2>
          {academicYearSummary.length > 0 ? (
            <table className="faculty-report-print-table">
              <thead><tr><th>Academic Year</th><th>Total Records</th><th>Approved</th><th>Pending</th><th>Rejected</th></tr></thead>
              <tbody>
                {academicYearSummary.map((year) => (
                  <tr key={year.year}><td>{year.year}</td><td>{year.total}</td><td>{year.approved}</td><td>{year.pending}</td><td>{year.rejected}</td></tr>
                ))}
              </tbody>
            </table>
          ) : <p>No activity records are available.</p>}
        </section>

        <section className="faculty-report-print-section">
          <h2>5. Detailed Activity and Contribution Register</h2>
          <p className="faculty-report-print-note">
            This register includes all reportable activity records for this faculty member, not only the rows currently visible after page filters.
          </p>
          {facultyActivities.length > 0 ? (
            <table className="faculty-report-print-table faculty-report-print-activity-table">
              <thead>
                <tr>
                  <th>#</th><th>Activity Type</th><th>Title / Details</th><th>Academic Year</th>
                  <th>Submission Date</th><th>Activity Status</th><th>Contribution Details</th>
                  <th>Points (Activity + Transfer)</th>
                </tr>
              </thead>
              <tbody>
                {facultyActivities.map((activity, index) => {
                  const { activityPoints, contributionPoints } = getActivityPoints(activity);
                  return (
                    <tr key={activity._id || `${activity.type}-${index}`}>
                      <td>{index + 1}</td>
                      <td>{activity.type || "—"}</td>
                      <td>
                        <strong>{activity.title || "Untitled activity"}</strong>
                        {activity.contributionTitle && <div>Contribution title: {activity.contributionTitle}</div>}
                        {activity.contributionType && <div>Contribution type: {activity.contributionType}</div>}
                        {activity.contributionReviewComment && <div>Review note: {activity.contributionReviewComment}</div>}
                      </td>
                      <td>{activity.academicYear || "—"}</td>
                      <td>{formatDate(activity.submissionDate || activity.createdAt)}</td>
                      <td>{activity.status || "Pending"}</td>
                      <td>
                        {activity.contributionDone === "Yes" ? (
                          <>
                            <div>{activity.contributionTitle || activity.contributionType || "Contribution"}</div>
                            <div>For: {activity.contributionFor || "—"}</div>
                            <div>Status: {activity.contributionStatus || "Pending"}</div>
                          </>
                        ) : "No contribution"}
                      </td>
                      <td>{activityPoints} + {contributionPoints}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : <p>No activity records are available for this faculty member.</p>}
        </section>

        <footer className="faculty-report-print-footer">
          <p>Report generated on {new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })}</p>
          <p>This report reflects records currently available in the Faculty Management System. Supporting proof documents remain accessible through the system.</p>
          <div className="faculty-report-print-signatures">
            <span>Faculty Signature</span><span>Head of Department</span><span>Authorized Signatory</span>
          </div>
        </footer>
      </div>

      <section className="faculty-reports-heading">
        <div>
          <p className="faculty-reports-eyebrow">
            FACULTY REPORT CENTRE
          </p>

          <h1>My Reports</h1>

          <p>
            Review, filter, print and export
            your activity, knowledge transfer and
            balanced approved-only impact records.
          </p>
        </div>

        <div className="faculty-reports-actions">

          <button
            type="button"
            onClick={handlePrint}
          >
            Print / PDF
          </button>

          <button
            type="button"
            onClick={handleExport}
          >
            Export CSV
          </button>

        </div>
      </section>

      {errorMessage && (
        <div className="faculty-reports-empty">
          {errorMessage}

          <br />

          <button
            type="button"
            onClick={loadActivities}
          >
            Try Again
          </button>
        </div>
      )}

      <section className="faculty-reports-stats">

        <article>
          <span>Total Records</span>
          <strong>
            {facultyActivities.length}
          </strong>
        </article>

        <article>
          <span>Approved</span>
          <strong>{approved}</strong>
        </article>

        <article>
          <span>Pending</span>
          <strong>{pending}</strong>
        </article>

        <article>
          <span>Rejected</span>
          <strong>{rejected}</strong>
        </article>

        <article>
          <span>
            Approved Contributions
          </span>
          <strong>
            {
              approvedContributions.length
            }
          </strong>
        </article>

        <article>
          <span>
            Pending Contributions
          </span>
          <strong>
            {
              pendingContributions.length
            }
          </strong>
        </article>

        <article>
          <span>
            Rejected Contributions
          </span>
          <strong>
            {
              rejectedContributions.length
            }
          </strong>
        </article>

        <article>
          <span>
            Impact Score
          </span>
          <strong>
            {impactScore}/100
          </strong>
          <small>
            Activity: {activityScore}/{ACTIVITY_SCORE_MAX} · Knowledge Transfer:
            {" "}{knowledgeTransferScore}/{KNOWLEDGE_TRANSFER_MAX} · Raw:
            {" "}{rawScore}
          </small>
        </article>

      </section>

      <section className="faculty-reports-card">

        <div className="faculty-reports-card-header">
          <div>
            <h2>Activity Report</h2>

            <p>
              Approved activities earn
              category-based points up to
              74 marks. Approved knowledge
              transfer contributes up to
              26 marks. Raw points are kept
              separately for transparency.
            </p>
          </div>
        </div>

        <div className="faculty-reports-toolbar">

          <div className="faculty-reports-search">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search activity, contribution or academic year"
              value={searchText}
              onChange={(event) =>
                setSearchText(
                  event.target.value
                )
              }
            />

          </div>

          <select
            value={typeFilter}
            onChange={(event) =>
              setTypeFilter(
                event.target.value
              )
            }
          >

            {activityTypes.map((type) => (
              <option
                value={type}
                key={type}
              >
                {type === "All"
                  ? "All Activity Types"
                  : type}
              </option>
            ))}

          </select>

          <select
            value={statusFilter}
            onChange={(event) =>
              setStatusFilter(
                event.target.value
              )
            }
          >

            <option value="All">
              All Statuses
            </option>

            <option value="Pending">
              Pending
            </option>

            <option value="Approved">
              Approved
            </option>

            <option value="Rejected">
              Rejected
            </option>

          </select>


          <select
            value={
              contributionStatusFilter
            }
            onChange={(event) =>
              setContributionStatusFilter(
                event.target.value
              )
            }
          >
            <option value="All">
              All Contribution Statuses
            </option>

            <option value="Pending">
              Contribution Pending
            </option>

            <option value="Approved">
              Contribution Approved
            </option>

            <option value="Rejected">
              Contribution Rejected
            </option>

            <option value="Not Applicable">
              No Contribution
            </option>
          </select>

        </div>

        {loading ? (
          <div className="faculty-reports-empty">
            Loading activity records...
          </div>
        ) : (
          <div className="faculty-reports-table-wrapper">

            <table className="faculty-reports-table">

              <thead>
                <tr>
                  <th>
                    Activity Type
                  </th>

                  <th>
                    Title
                  </th>

                  <th>
                    Academic Year
                  </th>

                  <th>
                    Submission Date
                  </th>

                  <th>
                    Proof
                  </th>

                  <th>
                    Status
                  </th>

                  <th>
                    Contribution
                  </th>

                  <th>
                    Contribution Status
                  </th>

                  <th>
                    Raw Points
                  </th>
                </tr>
              </thead>

              <tbody>

                {filteredActivities.map(
                  (activity) => {
                    const status =
                      activity.status ||
                      "Pending";

                    return (
                      <tr
                        key={
                          activity._id
                        }
                      >

                        <td>
                          {activity.type ||
                            "-"}
                        </td>

                        <td>
                          <strong>
                            {activity.title ||
                              "-"}
                          </strong>
                        </td>

                        <td>
                          {activity.academicYear ||
                            "-"}
                        </td>

                        <td>
                          {formatDate(
                            activity.submissionDate ||
                              activity.createdAt
                          )}
                        </td>

                        <td>

                          {activity.proof ? (
                            <a
                              href={
                                activity.proof
                              }
                              target="_blank"
                              rel="noreferrer"
                            >
                              View Proof
                            </a>
                          ) : (
                            "Not uploaded"
                          )}

                        </td>

                        <td>

                          <span
                            className={`faculty-report-status faculty-report-status--${status.toLowerCase()}`}
                          >
                            {status}
                          </span>

                        </td>

                        <td>
                          {activity.contributionDone ===
                          "Yes"
                            ? activity.contributionTitle ||
                              activity.contributionType ||
                              activity.contributionFor ||
                              "Contribution"
                            : "No contribution"}
                        </td>

                        <td>
                          {activity.contributionDone ===
                          "Yes"
                            ? activity.contributionStatus ||
                              "Pending"
                            : "Not Applicable"}

                          {activity.contributionStatus ===
                            "Rejected" &&
                            activity.contributionReviewComment && (
                              <small>
                                {" "}
                                {
                                  activity.contributionReviewComment
                                }
                              </small>
                            )}
                        </td>

                        <td>
                          {status ===
                          "Approved"
                            ? ACTIVITY_CONFIG[
                                activity.type
                              ]?.pointsPerActivity || 0
                            : 0}
                          {" + "}
                          {status ===
                            "Approved" &&
                          activity.contributionDone ===
                            "Yes" &&
                          activity.contributionStatus ===
                            "Approved"
                            ? CONTRIBUTION_WEIGHTS[
                                activity.contributionFor
                              ] || 0
                            : 0}
                        </td>

                      </tr>
                    );
                  }
                )}

              </tbody>

            </table>

            {filteredActivities.length ===
              0 &&
              !errorMessage && (
                <div className="faculty-reports-empty">
                  No activity records found.
                </div>
              )}

          </div>
        )}

      </section>

    </div>
  );
}

export default FacultyReports;