import { useState } from "react";
import "./Register.css";

function Register() {
  const [formData, setFormData] =
    useState({
      fullName: "",
      facultyId: "",
      department: "",
      designation: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
    });

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [
    successMessage,
    setSuccessMessage,
  ] = useState("");

  const [
    showPassword,
    setShowPassword,
  ] = useState(false);

  const [
    isSubmitting,
    setIsSubmitting,
  ] = useState(false);

  const emailPattern =
    /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.(com|org)$/i;

  const passwordPattern =
    /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?])[A-Za-z0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]{6,}$/;

  const handleChange = (e) => {
    const {
      name,
      value,
    } = e.target;

    let updatedValue = value;

    if (name === "phone") {
      updatedValue = value
        .replace(/\D/g, "")
        .slice(0, 10);
    }

    if (name === "facultyId") {
      updatedValue =
        value.toUpperCase();
    }

    setFormData(
      (previous) => ({
        ...previous,
        [name]: updatedValue,
      })
    );

    setErrorMessage("");
    setSuccessMessage("");
  };

  const handleSubmit =
    async (e) => {
      e.preventDefault();

      setErrorMessage("");
      setSuccessMessage("");

      // =========================
      // FRONTEND VALIDATION
      // =========================

      if (
        !formData.fullName.trim()
      ) {
        setErrorMessage(
          "Please enter your full name."
        );

        return;
      }

      if (
        !formData.facultyId.trim()
      ) {
        setErrorMessage(
          "Please enter your faculty ID."
        );

        return;
      }

      if (!formData.department) {
        setErrorMessage(
          "Please select your department."
        );

        return;
      }

      if (!formData.designation) {
        setErrorMessage(
          "Please select your designation."
        );

        return;
      }

      if (
        !emailPattern.test(
          formData.email.trim()
        )
      ) {
        setErrorMessage(
          "Please enter a valid email address."
        );

        return;
      }

      if (
        !/^[0-9]{10}$/.test(
          formData.phone
        )
      ) {
        setErrorMessage(
          "Phone number must contain exactly 10 digits."
        );

        return;
      }

      if (
        !passwordPattern.test(
          formData.password
        )
      ) {
        setErrorMessage(
          "Password must have at least 6 characters, one uppercase letter, one number and one special character."
        );

        return;
      }

      if (
        formData.password !==
        formData.confirmPassword
      ) {
        setErrorMessage(
          "Passwords do not match."
        );

        return;
      }

      // =========================
      // SEND TO BACKEND
      // =========================

      try {
        setIsSubmitting(true);

        const response =
          await fetch(
            "http://localhost:5000/api/auth/faculty/register",
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json",
              },

              body: JSON.stringify({
                facultyId:
                  formData.facultyId.trim(),

                name:
                  formData.fullName.trim(),

                department:
                  formData.department,

                designation:
                  formData.designation,

                email:
                  formData.email
                    .trim()
                    .toLowerCase(),

                phone:
                  formData.phone,

                password:
                  formData.password,
              }),
            }
          );

        const data =
          await response.json();

        if (!response.ok) {
          setErrorMessage(
            data.message ||
              "Registration failed."
          );

          return;
        }

        setSuccessMessage(
          data.message ||
            "Registration submitted successfully. Your account is waiting for administrator approval."
        );

        setFormData({
          fullName: "",
          facultyId: "",
          department: "",
          designation: "",
          email: "",
          phone: "",
          password: "",
          confirmPassword: "",
        });

        setTimeout(() => {
          window.location.href =
            "/";
        }, 1800);
      } catch (error) {
        console.error(
          "Registration error:",
          error
        );

        setErrorMessage(
          "Unable to connect to the server. Please make sure the backend is running."
        );
      } finally {
        setIsSubmitting(false);
      }
    };

  return (
    <div className="register-page">
      <div className="register-card">
        {/* HEADER */}

        <div className="register-header">
          <p>
            SCMS
          </p>

          <h1>
            Create Faculty Account
          </h1>

          <p>
            Register your details to
            access the Faculty Management
            System
          </p>

          <div className="register-header__rule" />
        </div>

        {/* FORM */}

        <form
          className="register-form"
          onSubmit={handleSubmit}
        >
          <div className="register-grid">
            {/* NAME */}

            <div className="register-field">
              <label>
                Full Name
              </label>

              <input
                type="text"
                name="fullName"
                placeholder="Enter full name"
                value={
                  formData.fullName
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* FACULTY ID */}

            <div className="register-field">
              <label>
                Faculty ID
              </label>

              <input
                type="text"
                name="facultyId"
                placeholder="Enter faculty ID"
                value={
                  formData.facultyId
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* DEPARTMENT */}

            <div className="register-field">
              <label>
                Department
              </label>

              <select
                name="department"
                value={
                  formData.department
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Department
                </option>

                <option value="CSE">
                  Computer Science &
                  Engineering
                </option>

                <option value="ECE">
                  Electronics &
                  Communication Engineering
                </option>

                <option value="EEE">
                  Electrical &
                  Electronics Engineering
                </option>

                <option value="ME">
                  Mechanical Engineering
                </option>

                <option value="CE">
                  Civil Engineering
                </option>
              </select>
            </div>

            {/* DESIGNATION */}

            <div className="register-field">
              <label>
                Designation
              </label>

              <select
                name="designation"
                value={
                  formData.designation
                }
                onChange={
                  handleChange
                }
                required
              >
                <option value="">
                  Select Designation
                </option>

                <option value="Professor">
                  Professor
                </option>

                <option value="Associate Professor">
                  Associate Professor
                </option>

                <option value="Assistant Professor">
                  Assistant Professor
                </option>
              </select>
            </div>

            {/* EMAIL */}

            <div className="register-field">
              <label>
                Email Address
              </label>

              <input
                type="email"
                name="email"
                placeholder="name@scmsgroup.org"
                value={
                  formData.email
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* PHONE */}

            <div className="register-field">
              <label>
                Phone Number
              </label>

              <input
                type="tel"
                name="phone"
                placeholder="Enter 10 digit phone number"
                maxLength="10"
                value={
                  formData.phone
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>

            {/* PASSWORD */}

            <div className="register-field">
              <label>
                Password
              </label>

              <div className="register-password">
                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  name="password"
                  placeholder="Create password"
                  value={
                    formData.password
                  }
                  onChange={
                    handleChange
                  }
                  required
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowPassword(
                      (previous) =>
                        !previous
                    )
                  }
                >
                  {showPassword
                    ? "Hide"
                    : "Show"}
                </button>
              </div>
            </div>

            {/* CONFIRM PASSWORD */}

            <div className="register-field">
              <label>
                Confirm Password
              </label>

              <input
                type={
                  showPassword
                    ? "text"
                    : "password"
                }
                name="confirmPassword"
                placeholder="Confirm password"
                value={
                  formData.confirmPassword
                }
                onChange={
                  handleChange
                }
                required
              />
            </div>
          </div>

          {/* ERROR */}

          {errorMessage && (
            <div className="register-message register-message--error">
              {errorMessage}
            </div>
          )}

          {/* SUCCESS */}

          {successMessage && (
            <div className="register-message register-message--success">
              {successMessage}
            </div>
          )}

          {/* SUBMIT */}

          <button
            type="submit"
            className="register-submit"
            disabled={
              isSubmitting
            }
          >
            {isSubmitting
              ? "SUBMITTING..."
              : "CREATE ACCOUNT"}
          </button>
        </form>

        {/* LOGIN */}

        <p className="register-login">
          Already have an account?{" "}

          <button
            type="button"
            onClick={() => {
              window.location.href =
                "/";
            }}
          >
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
}

export default Register;