const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadDir =
  path.join(
    __dirname,
    "../uploads/certificates"
  );

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(
    uploadDir,
    {
      recursive: true,
    }
  );
}

const storage =
  multer.diskStorage({
    destination: (
      req,
      file,
      callback
    ) => {
      callback(
        null,
        uploadDir
      );
    },

    filename: (
      req,
      file,
      callback
    ) => {
      const extension =
        path
          .extname(
            file.originalname || ""
          )
          .toLowerCase();

      const uniqueName =
        `document-${Date.now()}-${Math.round(
          Math.random() * 1e9
        )}${extension}`;

      callback(
        null,
        uniqueName
      );
    },
  });

const allowedMimeTypes =
  new Set([
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/jpg",
    "image/webp",
  ]);

const allowedExtensions =
  new Set([
    ".pdf",
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
  ]);

const fileFilter = (
  req,
  file,
  callback
) => {
  const extension =
    path
      .extname(
        file.originalname || ""
      )
      .toLowerCase();

  const mimeType =
    String(
      file.mimetype || ""
    ).toLowerCase();

  if (
    !allowedExtensions.has(
      extension
    ) ||
    !allowedMimeTypes.has(
      mimeType
    )
  ) {
    return callback(
      new Error(
        "Invalid file type. Only PDF, JPG, PNG, and WEBP files are allowed."
      ),
      false
    );
  }

  return callback(
    null,
    true
  );
};

const uploadDocument =
  multer({
    storage,
    fileFilter,
    limits: {
      fileSize:
        5 * 1024 * 1024,
      files: 1,
    },
  });

module.exports = {
  uploadDocument,
};
