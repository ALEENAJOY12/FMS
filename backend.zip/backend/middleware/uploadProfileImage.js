const multer = require("multer");
const path = require("path");
const fs = require("fs");

const uploadDir =
  path.join(
    __dirname,
    "../uploads/profile-images"
  );

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(
    uploadDir,
    {
      recursive: true,
    }
  );
}

const storage =
  multer.diskStorage({
    destination: (
      req,
      file,
      callback
    ) => {
      callback(
        null,
        uploadDir
      );
    },

    filename: (
      req,
      file,
      callback
    ) => {
      const extension =
        path
          .extname(
            file.originalname || ""
          )
          .toLowerCase();

      const uniqueName =
        `profile-${Date.now()}-${Math.round(
          Math.random() * 1e9
        )}${extension}`;

      callback(
        null,
        uniqueName
      );
    },
  });

const allowedMimeTypes =
  new Set([
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/webp",
  ]);

const allowedExtensions =
  new Set([
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
  ]);

const fileFilter = (
  req,
  file,
  callback
) => {
  const extension =
    path
      .extname(
        file.originalname || ""
      )
      .toLowerCase();

  const mimeType =
    String(
      file.mimetype || ""
    ).toLowerCase();

  if (
    !allowedExtensions.has(
      extension
    ) ||
    !allowedMimeTypes.has(
      mimeType
    )
  ) {
    return callback(
      new Error(
        "Invalid profile image. Only JPG, JPEG, PNG and WEBP files are allowed."
      ),
      false
    );
  }

  return callback(
    null,
    true
  );
};

const uploadProfileImage =
  multer({
    storage,
    fileFilter,
    limits: {
      fileSize:
        1024 * 1024,
      files: 1,
    },
  });

const uploadProfileImageFile = (
  req,
  res,
  next
) => {
  uploadProfileImage.single(
    "image"
  )(
    req,
    res,
    (error) => {
      if (!error) {
        return next();
      }

      if (
        error instanceof
        multer.MulterError
      ) {
        if (
          error.code ===
          "LIMIT_FILE_SIZE"
        ) {
          return res
            .status(400)
            .json({
              success: false,
              message:
                "Profile image must be smaller than 1 MB.",
            });
        }

        return res
          .status(400)
          .json({
            success: false,
            message:
              error.message ||
              "Unable to upload profile image.",
          });
      }

      return res
        .status(400)
        .json({
          success: false,
          message:
            error.message ||
            "Invalid profile image.",
        });
    }
  );
};

module.exports = {
  uploadProfileImage,
  uploadProfileImageFile,
};
