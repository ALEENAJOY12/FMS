const jwt = require("jsonwebtoken");

const Faculty = require("../models/Faculty");
const Admin = require("../models/Admin");

// ========================================
// GET TOKEN FROM HEADER
// ========================================

const getToken = (req) => {
  const authHeader =
    req.headers.authorization;

  if (
    !authHeader ||
    !authHeader.startsWith("Bearer ")
  ) {
    return null;
  }

  return authHeader.split(" ")[1];
};

// ========================================
// VERIFY JWT
// FACULTY OR ADMIN
// ========================================

const protect = async (req, res, next) => {
  try {
    const token = getToken(req);

    if (!token) {
      return res.status(401).json({
        success: false,
        message:
          "Authentication required. Please login.",
      });
    }

    // Verify JWT
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    // ========================================
    // FACULTY TOKEN
    // ========================================

    if (decoded.role === "faculty") {
      const faculty =
        await Faculty.findById(
          decoded.id
        ).select("-password");

      if (!faculty) {
        return res.status(401).json({
          success: false,
          message:
            "Faculty account no longer exists.",
        });
      }

      if (
        faculty.registrationStatus !==
        "Approved"
      ) {
        return res.status(403).json({
          success: false,
          message:
            "Faculty account is not approved.",
        });
      }

      if (
        faculty.accountStatus !==
        "Active"
      ) {
        return res.status(403).json({
          success: false,
          message:
            "Faculty account is not active.",
        });
      }

      req.user = {
        id: faculty._id,
        facultyId:
          faculty.facultyId,
        role: "faculty",
        faculty,
      };

      return next();
    }

    // ========================================
    // ADMIN TOKEN
    // ========================================

    if (decoded.role === "admin") {
      const admin =
        await Admin.findById(
          decoded.id
        ).select("-password");

      if (!admin) {
        return res.status(401).json({
          success: false,
          message:
            "Administrator account no longer exists.",
        });
      }

      if (
        admin.accountStatus !==
        "Active"
      ) {
        return res.status(403).json({
          success: false,
          message:
            "Administrator account is inactive.",
        });
      }

      req.user = {
        id: admin._id,
        role: "admin",
        admin,
      };

      return next();
    }

    // ========================================
    // UNKNOWN ROLE
    // ========================================

    return res.status(403).json({
      success: false,
      message:
        "You are not authorized to access this resource.",
    });
  } catch (error) {
    console.error(
      "JWT verification error:",
      error.message
    );

    if (
      error.name ===
      "TokenExpiredError"
    ) {
      return res.status(401).json({
        success: false,
        message:
          "Your login session has expired. Please login again.",
      });
    }

    if (
      error.name ===
      "JsonWebTokenError"
    ) {
      return res.status(401).json({
        success: false,
        message:
          "Invalid authentication token. Please login again.",
      });
    }

    return res.status(401).json({
      success: false,
      message:
        "Authentication failed. Please login again.",
    });
  }
};

// ========================================
// FACULTY ONLY
// ========================================

const facultyOnly = (
  req,
  res,
  next
) => {
  if (
    !req.user ||
    req.user.role !== "faculty"
  ) {
    return res.status(403).json({
      success: false,
      message:
        "Faculty access only.",
    });
  }

  next();
};

// ========================================
// ADMIN ONLY
// ========================================

const adminOnly = (
  req,
  res,
  next
) => {
  if (
    !req.user ||
    req.user.role !== "admin"
  ) {
    return res.status(403).json({
      success: false,
      message:
        "Administrator access only.",
    });
  }

  next();
};

// ========================================
// EXPORTS
// ========================================

module.exports = {
  protect,
  facultyOnly,
  adminOnly,
};