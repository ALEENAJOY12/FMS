const multer = require("multer");
const path = require("path");

const MAX_FILE_SIZE =
  5 * 1024 * 1024;

const storage =
  multer.memoryStorage();

const allowedExtensions =
  new Set([
    ".xlsx",
    ".xls",
    ".csv",
  ]);

const allowedMimeTypes =
  new Set([
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel",
    "text/csv",
    "application/csv",
    "text/plain",
    "application/octet-stream",
  ]);

const excelFilter = (
  req,
  file,
  callback
) => {
  const extension =
    path
      .extname(
        file.originalname || ""
      )
      .toLowerCase();

  const mimeType =
    String(
      file.mimetype || ""
    ).toLowerCase();

  if (
    !allowedExtensions.has(
      extension
    )
  ) {
    return callback(
      new Error(
        "Invalid file extension. Only .xlsx, .xls, and .csv files are allowed."
      ),
      false
    );
  }

  if (
    mimeType &&
    !allowedMimeTypes.has(
      mimeType
    )
  ) {
    return callback(
      new Error(
        "Invalid spreadsheet MIME type."
      ),
      false
    );
  }

  return callback(
    null,
    true
  );
};

const uploadExcel = multer({
  storage,

  fileFilter:
    excelFilter,

  limits: {
    fileSize:
      MAX_FILE_SIZE,

    files: 1,
  },
});

const uploadExcelFile = (
  req,
  res,
  next
) => {
  uploadExcel.single("file")(
    req,
    res,
    (error) => {
      if (!error) {
        return next();
      }

      if (
        error instanceof
        multer.MulterError
      ) {
        if (
          error.code ===
          "LIMIT_FILE_SIZE"
        ) {
          return res
            .status(400)
            .json({
              success: false,
              message:
                "The selected file is larger than 5 MB.",
            });
        }

        return res
          .status(400)
          .json({
            success: false,
            message:
              error.message ||
              "Unable to upload the spreadsheet.",
          });
      }

      return res
        .status(400)
        .json({
          success: false,
          message:
            error.message ||
            "Invalid spreadsheet file.",
        });
    }
  );
};

module.exports = {
  uploadExcel,
  uploadExcelFile,
};