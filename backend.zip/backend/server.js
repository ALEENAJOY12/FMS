
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");

// ========================================
// LOAD ENVIRONMENT VARIABLES FIRST
// ========================================

dotenv.config();

// ========================================
// DATABASE CONNECTION
// ========================================

const connectDB = require("./config/db");

// ========================================
// ROUTES
// ========================================

const facultyRoutes = require("./routes/facultyRoutes");
const authRoutes = require("./routes/authRoutes");
const activityRoutes = require("./routes/activityRoutes");

const historicalActivityRoutes = require(
  "./routes/historicalActivityRoutes"
);

const historicalAnalyticsRoutes = require(
  "./routes/historicalAnalyticsRoutes"
);

const aiRoutes = require("./routes/aiRoutes");
const growthForecastRoutes = require("./routes/growthForecastRoutes");

// ========================================
// APP
// ========================================

const app = express();

// ========================================
// CORS
// ========================================

app.use(cors());

// ========================================
// BODY PARSING
// ========================================

app.use(
  express.json({
    limit: "15mb",
  })
);

app.use(
  express.urlencoded({
    extended: true,
    limit: "15mb",
  })
);

// ========================================
// STATIC FILE SERVING
// ========================================

app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"))
);

// ========================================
// BASIC TEST ROUTE
// ========================================

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Faculty Management System API is running.",
  });
});

// ========================================
// HEALTH ROUTE
// ========================================

app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    status: "ok",
  });
});

// ========================================
// ACTIVITY TEST ROUTE
// ========================================

app.get("/api/activities-test", (req, res) => {
  res.json({
    success: true,
    message: "Activity test route working",
  });
});

// ========================================
// FACULTY ROUTES
// ========================================

app.use("/api/faculty", facultyRoutes);

// ========================================
// AUTH ROUTES
// ========================================

app.use("/api/auth", authRoutes);

// ========================================
// ACTIVITY ROUTES
// ========================================

app.use("/api/activities", activityRoutes);

// ========================================
// HISTORICAL ACTIVITY ROUTES
// ========================================

app.use(
  "/api/historical-activities",
  historicalActivityRoutes
);

// ========================================
// HISTORICAL ANALYTICS ROUTES
// ========================================

app.use(
  "/api/historical-analytics",
  historicalAnalyticsRoutes
);

// ========================================
// AI ROUTES
// ========================================

app.use("/api/ai", aiRoutes);
app.use("/api/growth-forecast", growthForecastRoutes);

// ========================================
// 404 HANDLER
// ========================================

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API route not found",
  });
});

// ========================================
// GLOBAL ERROR HANDLER
// ========================================

app.use((error, req, res, next) => {
  console.error("Server error:", error);

  res.status(error.status || 500).json({
    success: false,
    message: error.message || "Internal server error",
  });
});

// ========================================
// PORT
// ========================================

const PORT = process.env.PORT || 5000;

// ========================================
// START SERVER
// ========================================

const startServer = async () => {
  try {
    await connectDB();

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error.message);
    process.exit(1);
  }
};

startServer();
