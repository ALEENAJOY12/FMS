const mongoose = require("mongoose");
const dns = require("node:dns");

dns.setServers([
  "8.8.8.8",
  "8.8.4.4",
]);

const connectDB = async () => {
  try {
    const connection =
      await mongoose.connect(
        process.env.MONGO_URI,
        {
          family: 4,
        }
      );

    console.log(
      `MongoDB connected successfully: ${connection.connection.host}`
    );

    return connection;
  } catch (error) {
    console.error(
      "MongoDB connection failed:",
      error.message
    );

    throw error;
  }
};

module.exports = connectDB;