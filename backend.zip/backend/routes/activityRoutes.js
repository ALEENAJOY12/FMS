const express = require("express");

const {
  getAllActivities,
  getFacultyActivities,
  getActivityById,
  createActivity,
  updateActivity,
  deleteActivity,
} = require(
  "../controllers/activityController"
);

const {
  protect,
  facultyOnly,
  adminOnly,
} = require(
  "../middleware/authMiddleware"
);

const router =
  express.Router();

// ========================================
// GET ALL ACTIVITIES
// ADMIN ONLY
// GET /api/activities
// ========================================

router.get(
  "/",
  protect,
  adminOnly,
  getAllActivities
);

// ========================================
// GET FACULTY ACTIVITIES
//
// FACULTY:
// - may request only own facultyId
//   (controller enforces ownership)
//
// ADMIN:
// - may request any facultyId
//
// GET /api/activities/faculty/:facultyId
// ========================================

router.get(
  "/faculty/:facultyId",
  protect,
  getFacultyActivities
);

// ========================================
// CREATE ACTIVITY
// FACULTY ONLY
// POST /api/activities
// ========================================

router.post(
  "/",
  protect,
  facultyOnly,
  createActivity
);

// ========================================
// GET ONE ACTIVITY
//
// FACULTY:
// - own record only
//
// ADMIN:
// - any record
//
// GET /api/activities/:id
// ========================================

router.get(
  "/:id",
  protect,
  getActivityById
);

// ========================================
// UPDATE / REVIEW ACTIVITY
//
// FACULTY:
// - own Pending/Rejected activity
// - rejected contribution resubmission
//
// ADMIN:
// - review fields only
//
// Controller enforces the role-specific
// ownership and workflow rules.
//
// PUT /api/activities/:id
// ========================================

router.put(
  "/:id",
  protect,
  updateActivity
);

// ========================================
// DELETE ACTIVITY
//
// FACULTY:
// - own Pending record only
//
// ADMIN:
// - any activity
//
// Controller enforces ownership/status.
//
// DELETE /api/activities/:id
// ========================================

router.delete(
  "/:id",
  protect,
  deleteActivity
);

module.exports = router;
