
const express = require("express");
const router = express.Router();

const {
  getFDPForecast,
} = require("../controllers/growthForecastController");

router.get("/fdp", getFDPForecast);

module.exports = router;
