const express = require("express");

const {
  getAllFaculty,
  getFacultyById,
  createFaculty,
  updateFaculty,
  deleteFaculty,
  bulkImportFaculty,
  uploadCertificate,
  uploadProfileImage,
} = require(
  "../controllers/facultyController"
);

const {
  protect,
  adminOnly,
} = require(
  "../middleware/authMiddleware"
);

const {
  uploadExcelFile,
} = require(
  "../middleware/uploadExcel"
);

const {
  uploadDocument,
} = require(
  "../middleware/uploadDocument"
);

const {
  uploadProfileImageFile,
} = require(
  "../middleware/uploadProfileImage"
);

const router =
  express.Router();

// ========================================
// GET ALL FACULTY
// GET /api/faculty
// ADMIN ONLY
// ========================================

router.get(
  "/",
  protect,
  adminOnly,
  getAllFaculty
);

// ========================================
// BULK IMPORT FACULTY
// POST /api/faculty/bulk-import
// ADMIN ONLY
// ========================================

router.post(
  "/bulk-import",
  protect,
  adminOnly,
  uploadExcelFile,
  bulkImportFaculty
);

// ========================================
// UPLOAD FACULTY PROFILE IMAGE
// POST /api/faculty/:id/upload-profile-image
// ADMIN OR OWN FACULTY PROFILE
// ========================================

router.post(
  "/:id/upload-profile-image",
  protect,
  uploadProfileImageFile,
  uploadProfileImage
);

// ========================================
// UPLOAD FACULTY CERTIFICATE
// POST /api/faculty/:id/upload-certificate
// ADMIN OR OWN FACULTY PROFILE
//
// Ownership is enforced in the controller.
// ========================================

router.post(
  "/:id/upload-certificate",
  protect,
  uploadDocument.single(
    "document"
  ),
  uploadCertificate
);

// ========================================
// GET ONE FACULTY
// GET /api/faculty/:id
// ADMIN OR OWN FACULTY PROFILE
// ========================================

router.get(
  "/:id",
  protect,
  getFacultyById
);

// ========================================
// ADD FACULTY
// POST /api/faculty
// ADMIN ONLY
// ========================================

router.post(
  "/",
  protect,
  adminOnly,
  createFaculty
);

// ========================================
// UPDATE FACULTY
// PUT /api/faculty/:id
// ADMIN OR OWN FACULTY PROFILE
// ========================================

router.put(
  "/:id",
  protect,
  updateFaculty
);

// ========================================
// DELETE FACULTY
// DELETE /api/faculty/:id
// ADMIN ONLY
// ========================================

router.delete(
  "/:id",
  protect,
  adminOnly,
  deleteFaculty
);

module.exports = router;
