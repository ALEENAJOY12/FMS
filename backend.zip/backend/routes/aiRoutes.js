const express = require("express");

const {
  generateReportSummary,
  generateDashboardInsight,
} = require("../controllers/aiController");

const {
  protect,
  adminOnly,
} = require("../middleware/authMiddleware");

const router = express.Router();

// ========================================
// AI REPORT SUMMARY
// POST /api/ai/report-summary
// ========================================

router.post(
  "/report-summary",
  protect,
  adminOnly,
  generateReportSummary
);

// ========================================
// AI DASHBOARD INSIGHT
// POST /api/ai/dashboard-insight
// ========================================

router.post(
  "/dashboard-insight",
  protect,
  adminOnly,
  generateDashboardInsight
);

// ========================================
// AI EVIDENCE ANALYSIS
// POST /api/ai/evidence-analysis
// ========================================


module.exports = router;