const express = require("express");

const {
  registerFaculty,
  loginFaculty,
  loginAdmin,
} = require("../controllers/authController");

const router = express.Router();

// ========================================
// FACULTY REGISTRATION
// POST /api/auth/faculty/register
// ========================================

router.post(
  "/faculty/register",
  registerFaculty
);

// ========================================
// FACULTY LOGIN
// POST /api/auth/faculty/login
// ========================================

router.post(
  "/faculty/login",
  loginFaculty
);

// ========================================
// ADMIN LOGIN
// POST /api/auth/admin/login
// ========================================   

router.post(
  "/admin/login",
  loginAdmin
);

module.exports = router;