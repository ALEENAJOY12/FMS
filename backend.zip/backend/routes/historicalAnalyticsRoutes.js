
const express = require("express");

const {
  getCollegeHistoricalAnalytics,
  getPersonalHistoricalAnalytics,
} = require("../controllers/historicalAnalyticsController");

const {
  protect,
  adminOnly,
  facultyOnly,
} = require("../middleware/authMiddleware");

const router = express.Router();

// College-wide analytics: admin only
router.get(
  "/admin",
  protect,
  adminOnly,
  getCollegeHistoricalAnalytics
);

// Personal historical analytics: faculty only
router.get(
  "/faculty/me",
  protect,
  facultyOnly,
  getPersonalHistoricalAnalytics
);

module.exports = router;
