const express = require("express");

const {
  getFacultyHistoricalActivities,
} = require(
  "../controllers/historicalActivityController"
);

const {
  protect,
} = require(
  "../middleware/authMiddleware"
);

const router = express.Router();

router.get(
  "/faculty/:facultyId",
  protect,
  getFacultyHistoricalActivities
);

module.exports = router;