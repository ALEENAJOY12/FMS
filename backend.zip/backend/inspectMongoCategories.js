
require("dotenv").config();

const mongoose = require("mongoose");
const HistoricalActivity = require("./models/HistoricalActivity");

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    const results = await HistoricalActivity.aggregate([
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    console.log("\nHistorical activity types in MongoDB:");
    console.table(results);
  } catch (error) {
    console.error("Inspection failed:", error.message);
  } finally {
    await mongoose.disconnect();
  }
}

main();
