
require("dotenv").config();

const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");

const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");

async function main() {
  try {
    await connectDB();

    const records = await HistoricalActivity.find({}).lean();

    const backupFolder = path.resolve(__dirname, "../../backups");
    fs.mkdirSync(backupFolder, { recursive: true });

    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, "-");

    const backupPath = path.join(
      backupFolder,
      `historical-activities-${timestamp}.json`
    );

    fs.writeFileSync(
      backupPath,
      JSON.stringify(records, null, 2),
      "utf8"
    );

    console.log("Backup completed successfully.");
    console.log("Records backed up:", records.length);
    console.log("Backup file:", backupPath);
  } catch (error) {
    console.error("Backup failed:", error.message);
    process.exitCode = 1;
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
  }
}

main();
