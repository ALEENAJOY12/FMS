
require("dotenv").config();

const mongoose = require("mongoose");
const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");

async function main() {
  try {
    await connectDB();

    const total = await HistoricalActivity.countDocuments();

    const byType = await HistoricalActivity.aggregate([
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    console.log("\nTotal historical records:", total);
    console.log("Records by type:");
    console.table(byType);
  } catch (error) {
    console.error("Count failed:", error.message);
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
  }
}

main();
