
require("dotenv").config();

const mongoose = require("mongoose");
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");
const Faculty = require("../models/Faculty");

const projectRoot = path.resolve(__dirname, "../..");

const workbookCandidates = [
  path.join(
    projectRoot,
    "FMS_Historical_Activities_With_FDP_2023-26.xlsx"
  ),
  path.join(
    projectRoot,
    "FMS_Historical_Activities_With_FDP_2023-26 (1).xlsx"
  ),
];

const inputPath = workbookCandidates.find((file) =>
  fs.existsSync(file)
);

// Default is preview-only. Import requires an explicit --apply flag.
const APPLY_CHANGES = process.argv.includes("--apply");

const text = (value) => String(value ?? "").trim();

const normalizeHeader = (value) =>
  String(value ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

const normalizeText = (value) =>
  text(value)
    .toLowerCase()
    .replace(/[“”‘’]/g, "'")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");

function getValue(row, headers) {
  const accepted = new Set(headers.map(normalizeHeader));

  for (const [key, value] of Object.entries(row)) {
    if (accepted.has(normalizeHeader(key))) {
      return value;
    }
  }

  return "";
}

function excelDate(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value;
  }

  if (typeof value === "number") {
    const parsed = xlsx.SSF.parse_date_code(value);

    if (!parsed) return null;

    return new Date(
      Date.UTC(parsed.y, parsed.m - 1, parsed.d)
    );
  }

  const raw = text(value);

  // Handle DD/MM/YYYY and DD-MM-YYYY explicitly.
  const match = raw.match(
    /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/
  );

  if (match) {
    const [, day, month, year] = match;

    const date = new Date(
      Date.UTC(
        Number(year),
        Number(month) - 1,
        Number(day)
      )
    );

    // Reject impossible dates.
    if (
      date.getUTCFullYear() !== Number(year) ||
      date.getUTCMonth() !== Number(month) - 1 ||
      date.getUTCDate() !== Number(day)
    ) {
      return null;
    }

    return date;
  }

  const date = new Date(raw);

  return Number.isNaN(date.getTime()) ? null : date;
}

function dateKey(value) {
  if (!value) return "";

  const date =
    value instanceof Date ? value : new Date(value);

  return Number.isNaN(date.getTime())
    ? ""
    : date.toISOString().slice(0, 10);
}

function readSheet(workbook, sheetName) {
  const sheet = workbook.Sheets[sheetName];

  if (!sheet) {
    throw new Error(
      `Required Excel sheet not found: "${sheetName}"`
    );
  }

  return xlsx.utils.sheet_to_json(sheet, {
    defval: "",
  });
}

/*
 * Duplicate detection:
 * - Faculty ID, type and normalized title must match.
 * - Publications use faculty + type + title.
 * - FDPs also compare academic year and start date.
 * - If a date is missing, a matching academic year can
 *   identify a likely duplicate.
 * - Different academic years remain separate records.
 */
function sameIdentity(a, b) {
  const sameFaculty =
    text(a.facultyId).toUpperCase() ===
    text(b.facultyId).toUpperCase();

  const sameType = text(a.type) === text(b.type);

  const sameTitle =
    normalizeText(a.title) === normalizeText(b.title);

  if (!sameFaculty || !sameType || !sameTitle) {
    return false;
  }

  // Publication duplicate rule.
  if (a.type !== "FDP") {
    return true;
  }

  const yearA = text(a.academicYear);
  const yearB = text(b.academicYear);

  // A matching title in a different academic year
  // is not automatically considered a duplicate.
  if (yearA && yearB && yearA !== yearB) {
    return false;
  }

  const dateA = dateKey(a.startDate || a.activityDate);
  const dateB = dateKey(b.startDate || b.activityDate);

  // When both dates exist, require the same start date.
  if (dateA && dateB) {
    return dateA === dateB;
  }

  // When one or both dates are missing, use the year
  // if both records have a matching academic year.
  if (yearA && yearB) {
    return yearA === yearB;
  }

  // Insufficient information for a reliable match.
  return false;
}

async function getFacultyMap() {
  const faculties = await Faculty.find({})
    .select("facultyId name department")
    .lean();

  return new Map(
    faculties
      .filter((faculty) => text(faculty.facultyId))
      .map((faculty) => [
        text(faculty.facultyId).toUpperCase(),
        faculty,
      ])
  );
}

async function prepareFdpRecords(workbook, facultyMap) {
  const rows = readSheet(
    workbook,
    "FDP Historical Combined"
  );

  const docs = [];
  const warnings = [];
  let ignored = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];

    const facultyId = text(
      getValue(row, ["Faculty ID"])
    ).toUpperCase();

    const title = text(getValue(row, ["Title"]));

    const type = text(
      getValue(row, ["Activity Type"])
    );

    if (
      !facultyId ||
      !title ||
      type.toUpperCase() !== "FDP"
    ) {
      ignored++;
      continue;
    }

    const faculty = facultyMap.get(facultyId);

    if (!faculty) {
      warnings.push(
        `FDP Excel row ${i + 2}: faculty "${facultyId}" not found; skipped.`
      );
      continue;
    }

    const startDate = excelDate(
      getValue(row, ["Start Date"])
    );

    const endDate = excelDate(
      getValue(row, ["End Date"])
    );

    const dateCheck = text(
      getValue(row, ["Date Check"])
    );

    if (dateCheck && dateCheck.toLowerCase() !== "ok") {
      warnings.push(
        `FDP Excel row ${i + 2} (${facultyId} - ${title}): ${dateCheck}`
      );
    }

    if (startDate && endDate && endDate < startDate) {
      warnings.push(
        `FDP Excel row ${i + 2} (${facultyId} - ${title}): end date precedes start date.`
      );
    }

    if (!startDate) {
      warnings.push(
        `FDP Excel row ${i + 2} (${facultyId} - ${title}): missing or invalid start date.`
      );
    }

    docs.push({
      facultyId,
      facultyName:
        text(faculty.name) ||
        text(getValue(row, ["Faculty Name"])),

      department:
        text(faculty.department) ||
        text(getValue(row, ["Department"])),

      type: "FDP",
      title,

      academicYear: text(
        getValue(row, ["Academic Year"])
      ),

      startDate,
      endDate,
      activityDate: startDate,

      duration: text(
        getValue(row, ["Duration"])
      ),

      organizer: text(
        getValue(row, ["Organizer"])
      ),

      sourceFile:
        text(getValue(row, ["Source File"])) ||
        path.basename(inputPath),

      sourceRow:
        Number(getValue(row, ["Source Row"])) ||
        i + 2,
    });
  }

  return {
    docs,
    rowCount: rows.length,
    ignored,
    warnings,
  };
}

async function preparePublicationRecords(
  workbook,
  facultyMap
) {
  const rows = readSheet(
    workbook,
    "All Matched Publications"
  );

  const docs = [];
  const warnings = [];
  let ignored = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];

    const facultyId = text(
      getValue(row, ["Faculty ID"])
    ).toUpperCase();

    const title = text(
      getValue(row, [
        "TITLE OF THE ARTICLE / ARTICLE IN PREPARATION",
        "Title",
      ])
    );

    const rawType = text(
      getValue(row, [
        "JOURNAL / CONFERENCE / BOOK CHAPTER",
      ])
    ).toLowerCase();

    if (!facultyId || !title || !rawType) {
      ignored++;
      continue;
    }

    let type;

    if (
      rawType === "journal" ||
      rawType === "journal publication"
    ) {
      type = "Journal Publication";
    } else if (rawType === "conference") {
      type = "Conference";
    } else if (rawType === "book chapter") {
      type = "Book Chapter";
    } else {
      warnings.push(
        `Publication Excel row ${i + 2}: unsupported type "${rawType}"; skipped.`
      );
      continue;
    }

    const faculty = facultyMap.get(facultyId);

    if (!faculty) {
      warnings.push(
        `Publication Excel row ${i + 2}: faculty "${facultyId}" not found; skipped.`
      );
      continue;
    }

    const publicationDate = excelDate(
      getValue(row, ["PUBLICATION DATE"])
    );

    const status = text(
      getValue(row, [
        "CURRENT STATUS IN PREPARATION / PUBLISHED / ACCEPTED / SUBMITTED / IN REVISION",
        "CURRENT STATUS",
      ])
    );

    if (!publicationDate) {
      warnings.push(
        `Publication Excel row ${i + 2} (${facultyId} - ${title}): publication date missing or invalid.`
      );
    }

    docs.push({
      facultyId,

      facultyName:
        text(faculty.name) ||
        text(
          getValue(row, [
            "Canonical Faculty Name",
            "NAME OF FACULTY",
          ])
        ),

      department:
        text(faculty.department) ||
        text(getValue(row, ["AFFILIATION"])),

      type,
      title,

      // Do not invent a year when the source doesn't provide one.
      academicYear: text(
        getValue(row, ["Academic Year"])
      ),

      activityDate: publicationDate,
      publicationDate,

      publicationStatus: status,

      publicationType: text(
        getValue(row, [
          "Type Unpaid journal / Paid journal",
          "Type",
        ])
      ),

      journalName: text(
        getValue(row, ["JOURNAL NAME"])
      ),

      conferenceName: text(
        getValue(row, ["CONFERENCE NAME"])
      ),

      doi: text(getValue(row, ["DOI"])),

      publicationLink: text(
        getValue(row, ["LINK TO PUBLICATION"])
      ),

      indexing: text(
        getValue(row, ["INDEXING"])
      ),

      sourceFile: "Faculty Publications 2025-26.xlsx",

      sourceRow:
        Number(
          getValue(row, ["Sl No:", "Sl No", "Sl. No."])
        ) || i + 2,
    });
  }

  return {
    docs,
    rowCount: rows.length,
    ignored,
    warnings,
  };
}

function countByType(records) {
  return records.reduce((counts, record) => {
    counts[record.type] =
      (counts[record.type] || 0) + 1;

    return counts;
  }, {});
}

async function main() {
  try {
    console.log("\n=== Historical Activities Import ===");

    console.log(
      `Mode: ${
        APPLY_CHANGES
          ? "APPLY - inserts eligible records"
          : "PREVIEW ONLY - no database writes"
      }`
    );

    if (!inputPath) {
      throw new Error(
        "Excel workbook not found in D:\\FMS. Check the workbook filename."
      );
    }

    console.log(`Workbook: ${inputPath}`);

    const workbook = xlsx.readFile(inputPath, {
      cellDates: true,
    });

    await connectDB();

    const facultyMap = await getFacultyMap();

    console.log(
      `Faculty records loaded: ${facultyMap.size}`
    );

    const fdp = await prepareFdpRecords(
      workbook,
      facultyMap
    );

    const publications = await preparePublicationRecords(
      workbook,
      facultyMap
    );

    const prepared = [
      ...fdp.docs,
      ...publications.docs,
    ];

    const existing = await HistoricalActivity.find({})
      .lean();

    const accepted = [];
    const skippedExisting = [];
    const skippedWorkbookDuplicate = [];

    for (const doc of prepared) {
      if (
        existing.some((record) =>
          sameIdentity(record, doc)
        )
      ) {
        skippedExisting.push(doc);
      } else if (
        accepted.some((record) =>
          sameIdentity(record, doc)
        )
      ) {
        skippedWorkbookDuplicate.push(doc);
      } else {
        accepted.push(doc);
      }
    }

    console.log("\n--- Preview summary ---");

    console.log(
      `Existing database records: ${existing.length}`
    );

    console.log(
      `FDP rows in Excel: ${fdp.rowCount}`
    );

    console.log(
      `FDP records prepared: ${fdp.docs.length}`
    );

    console.log(
      `FDP rows ignored: ${fdp.ignored}`
    );

    console.log(
      `Publication rows in Excel: ${publications.rowCount}`
    );

    console.log(
      `Publication records prepared: ${publications.docs.length}`
    );

    console.log(
      `Publication rows ignored: ${publications.ignored}`
    );

    console.log(
      `Likely duplicates skipped: ${skippedExisting.length}`
    );

    console.log(
      `Duplicate workbook rows skipped: ${skippedWorkbookDuplicate.length}`
    );

    console.log(
      `Eligible new records: ${accepted.length}`
    );

    console.log(
      "Eligible records by type:",
      countByType(accepted)
    );

    if (accepted.length) {
      console.log("\n--- Proposed new records (first 30) ---");

      console.table(
        accepted.slice(0, 30).map((record) => ({
          facultyId: record.facultyId,
          type: record.type,
          title: record.title,
          academicYear: record.academicYear,
          startDate: dateKey(record.startDate),
          publicationDate: dateKey(record.publicationDate),
        }))
      );

      if (accepted.length > 30) {
        console.log(
          `...and ${accepted.length - 30} more proposed records.`
        );
      }
    }

    const warnings = [
      ...fdp.warnings,
      ...publications.warnings,
    ];

    if (warnings.length) {
      console.log(
        `\nWarnings (${warnings.length}; first 30 shown):`
      );

      warnings
        .slice(0, 30)
        .forEach((warning) =>
          console.log("-", warning)
        );

      if (warnings.length > 30) {
        console.log(
          `...and ${warnings.length - 30} more warnings.`
        );
      }
    }

    if (!APPLY_CHANGES) {
      console.log(
        "\nPREVIEW ONLY: no records were inserted, updated, or deleted."
      );

      console.log(
        "Review the proposed records and warnings before importing."
      );

      return;
    }

    // Do not silently proceed if the preview has no new records.
    if (!accepted.length) {
      console.log(
        "\nNo eligible new records. Database unchanged."
      );
      return;
    }

    // Insert only; never delete or overwrite existing records.
    const inserted = await HistoricalActivity.insertMany(
      accepted,
      { ordered: false }
    );

    console.log(
      `\nInserted ${inserted.length} historical records.`
    );

    console.log(
      `Total historical records now: ${
        await HistoricalActivity.countDocuments()
      }`
    );
  } catch (error) {
    console.error(
      "\nHistorical import failed:",
      error.message || error
    );

    process.exitCode = 1;
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
  }
}

main();
