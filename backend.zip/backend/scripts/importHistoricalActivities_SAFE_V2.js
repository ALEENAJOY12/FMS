
require("dotenv").config();

const mongoose = require("mongoose");
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");
const Faculty = require("../models/Faculty");

const projectRoot = path.resolve(__dirname, "../..");

const workbookCandidates = [
  path.join(
    projectRoot,
    "FMS_Historical_Activities_With_FDP_2023-26.xlsx"
  ),
  path.join(
    projectRoot,
    "FMS_Historical_Activities_With_FDP_2023-26 (1).xlsx"
  ),
];

const inputPath = workbookCandidates.find((file) =>
  fs.existsSync(file)
);

const APPLY_CHANGES = process.argv.includes("--apply");

const reportPath = path.join(
  projectRoot,
  "FDP_Import_Review_Report.xlsx"
);

const text = (value) => String(value ?? "").trim();

function normalizeHeader(value) {
  return String(value ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function normalizeText(value) {
  return text(value)
    .toLowerCase()
    .replace(/[“”‘’]/g, "'")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function getValue(row, acceptedHeaders) {
  const accepted = new Set(
    acceptedHeaders.map(normalizeHeader)
  );

  for (const [key, value] of Object.entries(row)) {
    if (accepted.has(normalizeHeader(key))) {
      return value;
    }
  }

  return "";
}

// Preserve the calendar date from Excel without a timezone shift.
function excelDate(value) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return null;
  }

  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) return null;

    return new Date(
      Date.UTC(
        value.getFullYear(),
        value.getMonth(),
        value.getDate()
      )
    );
  }

  if (typeof value === "number") {
    const parsed = xlsx.SSF.parse_date_code(value);

    if (!parsed) return null;

    return new Date(
      Date.UTC(parsed.y, parsed.m - 1, parsed.d)
    );
  }

  const raw = text(value);

  // Interpret DD/MM/YYYY and DD-MM-YYYY explicitly.
  const match = raw.match(
    /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/
  );

  if (match) {
    const [, d, m, y] = match;

    const day = Number(d);
    const month = Number(m);
    const year = Number(y);

    const date = new Date(
      Date.UTC(year, month - 1, day)
    );

    if (
      date.getUTCFullYear() !== year ||
      date.getUTCMonth() !== month - 1 ||
      date.getUTCDate() !== day
    ) {
      return null;
    }

    return date;
  }

  const parsed = new Date(raw);

  if (Number.isNaN(parsed.getTime())) {
    return null;
  }

  return new Date(
    Date.UTC(
      parsed.getFullYear(),
      parsed.getMonth(),
      parsed.getDate()
    )
  );
}

function dateKey(value) {
  if (!value) return "";

  const date =
    value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) return "";

  return [
    date.getUTCFullYear(),
    String(date.getUTCMonth() + 1).padStart(2, "0"),
    String(date.getUTCDate()).padStart(2, "0"),
  ].join("-");
}

function readSheet(workbook, sheetName) {
  const sheet = workbook.Sheets[sheetName];

  if (!sheet) {
    throw new Error(
      `Required Excel sheet not found: "${sheetName}"`
    );
  }

  return xlsx.utils.sheet_to_json(sheet, {
    defval: "",
  });
}

function sameIdentity(a, b) {
  const sameFaculty =
    text(a.facultyId).toUpperCase() ===
    text(b.facultyId).toUpperCase();

  const sameType = text(a.type) === text(b.type);

  const sameTitle =
    normalizeText(a.title) === normalizeText(b.title);

  if (!sameFaculty || !sameType || !sameTitle) {
    return false;
  }

  // Publication duplicate rule.
  if (a.type !== "FDP") {
    return true;
  }

  const yearA = text(a.academicYear);
  const yearB = text(b.academicYear);

  if (yearA && yearB && yearA !== yearB) {
    return false;
  }

  const dateA = dateKey(a.startDate || a.activityDate);
  const dateB = dateKey(b.startDate || b.activityDate);

  if (dateA && dateB) {
    return dateA === dateB;
  }

  if (yearA && yearB) {
    return yearA === yearB;
  }

  // Not enough information to confidently match.
  return false;
}

async function getFacultyMap() {
  const faculties = await Faculty.find({})
    .select("facultyId name department")
    .lean();

  return new Map(
    faculties
      .filter((faculty) => text(faculty.facultyId))
      .map((faculty) => [
        text(faculty.facultyId).toUpperCase(),
        faculty,
      ])
  );
}

async function prepareFdpRecords(workbook, facultyMap) {
  const rows = readSheet(
    workbook,
    "FDP Historical Combined"
  );

  const docs = [];
  const reviewRows = [];
  const warnings = [];
  let ignored = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const excelRow = i + 2;

    const facultyId = text(
      getValue(row, ["Faculty ID"])
    ).toUpperCase();

    const title = text(getValue(row, ["Title"]));

    const type = text(
      getValue(row, ["Activity Type"])
    );

    if (
      !facultyId ||
      !title ||
      type.toUpperCase() !== "FDP"
    ) {
      ignored++;
      continue;
    }

    const academicYear = text(
      getValue(row, ["Academic Year"])
    );

    const startDate = excelDate(
      getValue(row, ["Start Date"])
    );

    const endDate = excelDate(
      getValue(row, ["End Date"])
    );

    const dateCheck = text(
      getValue(row, ["Date Check"])
    );

    const reasons = [];

    if (dateCheck && dateCheck.toLowerCase() !== "ok") {
      reasons.push(`Source warning: ${dateCheck}`);

      warnings.push(
        `FDP row ${excelRow} (${facultyId} - ${title}): ${dateCheck}`
      );
    }

    if (!startDate) {
      reasons.push("Missing or invalid start date");
    }

    if (!endDate) {
      reasons.push("Missing or invalid end date");
    }

    // Never guess which date is correct.
    // Exclude records whose end date precedes the start date.
    if (
      startDate &&
      endDate &&
      endDate < startDate
    ) {
      reasons.push(
        "End date before start date; excluded from import"
      );

      reviewRows.push({
        ExcelRow: excelRow,
        FacultyID: facultyId,
        AcademicYear: academicYear,
        Title: title,
        StartDate: dateKey(startDate),
        EndDate: dateKey(endDate),
        SourceDateCheck: dateCheck,
        Reason: reasons.join("; "),
      });

      warnings.push(
        `FDP row ${excelRow} (${facultyId} - ${title}): skipped due to reversed dates.`
      );

      ignored++;
      continue;
    }

    const faculty = facultyMap.get(facultyId);

    if (!faculty) {
      reasons.push("Faculty ID not found in database");

      reviewRows.push({
        ExcelRow: excelRow,
        FacultyID: facultyId,
        AcademicYear: academicYear,
        Title: title,
        StartDate: dateKey(startDate),
        EndDate: dateKey(endDate),
        SourceDateCheck: dateCheck,
        Reason: reasons.join("; "),
      });

      warnings.push(
        `FDP row ${excelRow}: faculty ${facultyId} not found; skipped.`
      );

      ignored++;
      continue;
    }

    // Missing dates are allowed by the current schema.
    // They are reported rather than invented.
    if (!startDate || !endDate) {
      reviewRows.push({
        ExcelRow: excelRow,
        FacultyID: facultyId,
        AcademicYear: academicYear,
        Title: title,
        StartDate: dateKey(startDate),
        EndDate: dateKey(endDate),
        SourceDateCheck: dateCheck,
        Reason: reasons.join("; "),
      });
    }

    docs.push({
      facultyId,
      facultyName:
        text(faculty.name) ||
        text(getValue(row, ["Faculty Name"])),

      department:
        text(faculty.department) ||
        text(getValue(row, ["Department"])),

      type: "FDP",
      title,
      academicYear,
      startDate,
      endDate,
      activityDate: startDate,

      duration: text(
        getValue(row, ["Duration"])
      ),

      organizer: text(
        getValue(row, ["Organizer"])
      ),

      sourceFile:
        text(getValue(row, ["Source File"])) ||
        path.basename(inputPath),

      sourceRow:
        Number(getValue(row, ["Source Row"])) ||
        excelRow,
    });
  }

  return {
    docs,
    rowCount: rows.length,
    ignored,
    warnings,
    reviewRows,
  };
}

async function preparePublicationRecords(
  workbook,
  facultyMap
) {
  const rows = readSheet(
    workbook,
    "All Matched Publications"
  );

  const docs = [];
  const warnings = [];
  let ignored = 0;

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const excelRow = i + 2;

    const facultyId = text(
      getValue(row, ["Faculty ID"])
    ).toUpperCase();

    const title = text(
      getValue(row, [
        "TITLE OF THE ARTICLE / ARTICLE IN PREPARATION",
        "Title",
      ])
    );

    const rawType = text(
      getValue(row, [
        "JOURNAL / CONFERENCE / BOOK CHAPTER",
      ])
    ).toLowerCase();

    if (!facultyId || !title || !rawType) {
      ignored++;
      continue;
    }

    let type;

    if (
      rawType === "journal" ||
      rawType === "journal publication"
    ) {
      type = "Journal Publication";
    } else if (rawType === "conference") {
      type = "Conference";
    } else if (rawType === "book chapter") {
      type = "Book Chapter";
    } else {
      warnings.push(
        `Publication row ${excelRow}: unsupported type "${rawType}"; skipped.`
      );

      ignored++;
      continue;
    }

    const faculty = facultyMap.get(facultyId);

    if (!faculty) {
      warnings.push(
        `Publication row ${excelRow}: faculty ${facultyId} not found; skipped.`
      );

      ignored++;
      continue;
    }

    const publicationDate = excelDate(
      getValue(row, ["PUBLICATION DATE"])
    );

    if (!publicationDate) {
      warnings.push(
        `Publication row ${excelRow} (${facultyId} - ${title}): publication date missing or invalid.`
      );
    }

    docs.push({
      facultyId,

      facultyName:
        text(faculty.name) ||
        text(
          getValue(row, [
            "Canonical Faculty Name",
            "NAME OF FACULTY",
          ])
        ),

      department:
        text(faculty.department) ||
        text(getValue(row, ["AFFILIATION"])),

      type,
      title,

      academicYear: text(
        getValue(row, ["Academic Year"])
      ),

      activityDate: publicationDate,
      publicationDate,

      publicationStatus: text(
        getValue(row, [
          "CURRENT STATUS IN PREPARATION / PUBLISHED / ACCEPTED / SUBMITTED / IN REVISION",
          "CURRENT STATUS",
        ])
      ),

      publicationType: text(
        getValue(row, [
          "Type Unpaid journal / Paid journal",
          "Type",
        ])
      ),

      journalName: text(
        getValue(row, ["JOURNAL NAME"])
      ),

      conferenceName: text(
        getValue(row, ["CONFERENCE NAME"])
      ),

      doi: text(getValue(row, ["DOI"])),

      publicationLink: text(
        getValue(row, ["LINK TO PUBLICATION"])
      ),

      indexing: text(
        getValue(row, ["INDEXING"])
      ),

      sourceFile: "Faculty Publications 2025-26.xlsx",

      sourceRow:
        Number(
          getValue(row, ["Sl No:", "Sl No", "Sl. No."])
        ) || excelRow,
    });
  }

  return {
    docs,
    rowCount: rows.length,
    ignored,
    warnings,
  };
}

function countByType(records) {
  return records.reduce((counts, record) => {
    counts[record.type] =
      (counts[record.type] || 0) + 1;

    return counts;
  }, {});
}

function writeReviewWorkbook(
  summary,
  reviewRows,
  accepted,
  warnings
) {
  const workbook = xlsx.utils.book_new();

  const summarySheet = xlsx.utils.aoa_to_sheet([
    ["Historical Activity Import Review"],
    ["Mode", APPLY_CHANGES ? "APPLY" : "PREVIEW ONLY"],
    ["Workbook", path.basename(inputPath || "")],
    ["Existing database records", summary.existing],
    ["FDP source rows", summary.fdpRows],
    ["FDP records prepared", summary.fdpPrepared],
    ["FDP rows ignored or excluded", summary.fdpIgnored],
    ["Publication source rows", summary.pubRows],
    ["Publication records prepared", summary.pubPrepared],
    ["Publication rows ignored", summary.pubIgnored],
    ["Likely duplicates skipped", summary.duplicates],
    ["Duplicate workbook rows skipped", summary.workbookDuplicates],
    ["Eligible new records", summary.eligible],
    ["Eligible records by type", JSON.stringify(summary.byType)],
    [],
    [
      "Safety",
      "Reversed-date FDP records are excluded. Dates are never automatically corrected.",
    ],
    [
      "Safety",
      "Existing records are never deleted or updated by this script.",
    ],
  ]);

  xlsx.utils.book_append_sheet(
    workbook,
    summarySheet,
    "Summary"
  );

  const reviewSheet = xlsx.utils.json_to_sheet(
    reviewRows.length
      ? reviewRows
      : [{ Result: "No FDP date-review rows." }]
  );

  xlsx.utils.book_append_sheet(
    workbook,
    reviewSheet,
    "FDP Rows To Review"
  );

  const proposedRows = accepted.map((record) => ({
    FacultyID: record.facultyId,
    Type: record.type,
    Title: record.title,
    AcademicYear: record.academicYear,
    StartDate: dateKey(record.startDate),
    EndDate: dateKey(record.endDate),
    PublicationDate: dateKey(record.publicationDate),
    SourceRow: record.sourceRow,
  }));

  xlsx.utils.book_append_sheet(
    workbook,
    xlsx.utils.json_to_sheet(
      proposedRows.length
        ? proposedRows
        : [{ Result: "No eligible records." }]
    ),
    "Eligible New Records"
  );

  xlsx.utils.book_append_sheet(
    workbook,
    xlsx.utils.json_to_sheet(
      warnings.length
        ? warnings.map((warning) => ({ Warning: warning }))
        : [{ Result: "No warnings." }]
    ),
    "Warnings"
  );

  for (const name of workbook.SheetNames) {
    const sheet = workbook.Sheets[name];

    sheet["!cols"] = Array.from(
      { length: sheet["!ref"] ? 8 : 1 },
      () => ({ wch: 28 })
    );

    sheet["!freeze"] = {
      xSplit: 0,
      ySplit: 1,
    };
  }

  xlsx.writeFile(workbook, reportPath);
}

async function main() {
  try {
    console.log(
      "\n=== Historical Activities SAFE Import V2 ==="
    );

    console.log(
      `Mode: ${
        APPLY_CHANGES
          ? "APPLY - inserts eligible records only"
          : "PREVIEW ONLY - no database writes"
      }`
    );

    if (!inputPath) {
      throw new Error(
        "Excel workbook not found in D:\\FMS. Check the filename."
      );
    }

    console.log("Workbook:", inputPath);

    const workbook = xlsx.readFile(inputPath, {
      cellDates: true,
    });

    await connectDB();

    const facultyMap = await getFacultyMap();

    console.log(
      "Faculty records loaded:",
      facultyMap.size
    );

    const fdp = await prepareFdpRecords(
      workbook,
      facultyMap
    );

    const publications = await preparePublicationRecords(
      workbook,
      facultyMap
    );

    const prepared = [
      ...fdp.docs,
      ...publications.docs,
    ];

    const existing = await HistoricalActivity.find({})
      .lean();

    const accepted = [];
    const skippedExisting = [];
    const skippedWorkbookDuplicate = [];

    for (const doc of prepared) {
      if (
        existing.some((record) =>
          sameIdentity(record, doc)
        )
      ) {
        skippedExisting.push(doc);
      } else if (
        accepted.some((record) =>
          sameIdentity(record, doc)
        )
      ) {
        skippedWorkbookDuplicate.push(doc);
      } else {
        accepted.push(doc);
      }
    }

    const warnings = [
      ...fdp.warnings,
      ...publications.warnings,
    ];

    const summary = {
      existing: existing.length,
      fdpRows: fdp.rowCount,
      fdpPrepared: fdp.docs.length,
      fdpIgnored: fdp.ignored,
      pubRows: publications.rowCount,
      pubPrepared: publications.docs.length,
      pubIgnored: publications.ignored,
      duplicates: skippedExisting.length,
      workbookDuplicates:
        skippedWorkbookDuplicate.length,
      eligible: accepted.length,
      byType: countByType(accepted),
    };

    console.log("\n--- Preview summary ---");
    console.table(summary);

    console.log(
      "Eligible new records by type:",
      countByType(accepted)
    );

    console.log("Warnings:", warnings.length);

    writeReviewWorkbook(
      summary,
      fdp.reviewRows,
      accepted,
      warnings
    );

    console.log(
      "\nReview report created:",
      reportPath
    );

    if (!APPLY_CHANGES) {
      console.log(
        "\nPREVIEW ONLY: no records were inserted, updated, or deleted."
      );

      console.log(
        "Review the Excel report before importing."
      );

      return;
    }

    if (!accepted.length) {
      console.log(
        "\nNo eligible new records. Database unchanged."
      );

      return;
    }

    // Validate every document before starting the import.
    for (const doc of accepted) {
      const instance = new HistoricalActivity(doc);
      await instance.validate();
    }

    // Insert only. Never delete or overwrite existing records.
    const inserted = await HistoricalActivity.insertMany(
      accepted,
      { ordered: true }
    );

    console.log(
      `\nInserted ${inserted.length} historical records.`
    );

    console.log(
      "Total historical records now:",
      await HistoricalActivity.countDocuments()
    );
  } catch (error) {
    console.error(
      "\nHistorical import failed:",
      error.message || error
    );

    process.exitCode = 1;
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
  }
}

main();
