
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const root = path.resolve(__dirname, "../..");

const files = [
  path.join(root, "FMS_Historical_Activities_With_FDP_2023-26.xlsx"),
  path.join(root, "FMS_Historical_Activities_With_FDP_2023-26 (1).xlsx"),
];

const workbookPath = files.find((file) => fs.existsSync(file));

if (!workbookPath) {
  console.error("Excel workbook not found in D:\\FMS");
  process.exit(1);
}

const workbook = xlsx.readFile(workbookPath, {
  cellDates: true,
});

const sheet = workbook.Sheets["FDP Historical Combined"];

if (!sheet) {
  console.error('Sheet "FDP Historical Combined" not found.');
  process.exit(1);
}

const rows = xlsx.utils.sheet_to_json(sheet, {
  defval: "",
});

function parseDate(value) {
  if (value === "" || value == null) return null;

  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value;
  }

  if (typeof value === "number") {
    const parsed = xlsx.SSF.parse_date_code(value);
    if (!parsed) return null;

    return new Date(Date.UTC(
      parsed.y,
      parsed.m - 1,
      parsed.d
    ));
  }

  const raw = String(value).trim();
  const match = raw.match(
    /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/
  );

  if (match) {
    const [, day, month, year] = match;
    const date = new Date(Date.UTC(
      Number(year),
      Number(month) - 1,
      Number(day)
    ));

    if (
      date.getUTCFullYear() !== Number(year) ||
      date.getUTCMonth() !== Number(month) - 1 ||
      date.getUTCDate() !== Number(day)
    ) {
      return null;
    }

    return date;
  }

  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? null : date;
}

function value(row, key) {
  const target = key.toLowerCase().replace(/[^a-z0-9]/g, "");

  for (const [header, item] of Object.entries(row)) {
    if (
      header.toLowerCase().replace(/[^a-z0-9]/g, "") === target
    ) {
      return item;
    }
  }

  return "";
}

function dateString(date) {
  return date ? date.toISOString().slice(0, 10) : "";
}

const problems = [];

rows.forEach((row, index) => {
  const facultyId = String(value(row, "Faculty ID") || "").trim();
  const title = String(value(row, "Title") || "").trim();
  const year = String(value(row, "Academic Year") || "").trim();

  const start = parseDate(value(row, "Start Date"));
  const end = parseDate(value(row, "End Date"));
  const sourceCheck = String(value(row, "Date Check") || "").trim();

  const reasons = [];

  if (!start) {
    reasons.push("Missing or invalid start date");
  }

  if (!end) {
    reasons.push("Missing or invalid end date");
  }

  if (start && end && end < start) {
    reasons.push("End date is before start date");
  }

  if (sourceCheck && sourceCheck.toLowerCase() !== "ok") {
    reasons.push(sourceCheck);
  }

  if (reasons.length) {
    problems.push({
      ExcelRow: index + 2,
      FacultyID: facultyId,
      AcademicYear: year,
      Title: title,
      StartDate: dateString(start),
      EndDate: dateString(end),
      Problem: reasons.join("; "),
    });
  }
});

console.log("\n=== FDP DATE VALIDATION REPORT ===");
console.log("Workbook:", workbookPath);
console.log("Total FDP rows:", rows.length);
console.log("Rows needing review:", problems.length);

console.table(problems);

const outputPath = path.join(
  root,
  "FDP_Date_Validation_Report.xlsx"
);

const outputWorkbook = xlsx.utils.book_new();

const outputSheet = xlsx.utils.json_to_sheet(problems);

xlsx.utils.book_append_sheet(
  outputWorkbook,
  outputSheet,
  "Date Problems"
);

xlsx.writeFile(outputWorkbook, outputPath);

console.log("\nReport saved to:", outputPath);
console.log("Original Excel workbook was not modified.");
console.log("MongoDB was not accessed or changed.");
