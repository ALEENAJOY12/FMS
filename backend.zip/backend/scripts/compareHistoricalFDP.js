
require("dotenv").config();

const mongoose = require("mongoose");
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");

const root = path.resolve(__dirname, "../..");

const candidates = [
  path.join(root, "FMS_Historical_Activities_With_FDP_2023-26.xlsx"),
  path.join(root, "FMS_Historical_Activities_With_FDP_2023-26 (1).xlsx"),
];

const workbookPath = candidates.find((file) => fs.existsSync(file));

const clean = (value) =>
  String(value ?? "")
    .toLowerCase()
    .replace(/[“”‘’]/g, "'")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");

function getValue(row, names) {
  const accepted = new Set(
    names.map((name) => name.toLowerCase().replace(/[^a-z0-9]/g, ""))
  );

  for (const [key, value] of Object.entries(row)) {
    const normalized = key.toLowerCase().replace(/[^a-z0-9]/g, "");

    if (accepted.has(normalized)) return value;
  }

  return "";
}

function parseDate(value) {
  if (value === "" || value == null) return "";

  if (value instanceof Date) {
    return Number.isNaN(value.getTime())
      ? ""
      : value.toISOString().slice(0, 10);
  }

  if (typeof value === "number") {
    const parsed = xlsx.SSF.parse_date_code(value);

    if (!parsed) return "";

    return [
      parsed.y,
      String(parsed.m).padStart(2, "0"),
      String(parsed.d).padStart(2, "0"),
    ].join("-");
  }

  const raw = String(value).trim();
  const match = raw.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);

  if (match) {
    const [, day, month, year] = match;

    return [
      year,
      String(month).padStart(2, "0"),
      String(day).padStart(2, "0"),
    ].join("-");
  }

  const date = new Date(raw);

  return Number.isNaN(date.getTime())
    ? ""
    : date.toISOString().slice(0, 10);
}

async function main() {
  try {
    if (!workbookPath) {
      throw new Error("Excel workbook not found in D:\\FMS.");
    }

    const workbook = xlsx.readFile(workbookPath, {
      cellDates: true,
    });

    const sheet = workbook.Sheets["FDP Historical Combined"];

    if (!sheet) {
      throw new Error('Sheet "FDP Historical Combined" not found.');
    }

    const excelRows = xlsx.utils.sheet_to_json(sheet, {
      defval: "",
    });

    await connectDB();

    const existing = await HistoricalActivity.find({
      type: "FDP",
    })
      .select(
        "facultyId title academicYear startDate endDate activityDate sourceRow"
      )
      .lean();

    console.log("\n=== READ-ONLY FDP COMPARISON ===");
    console.log("Existing FDP records:", existing.length);
    console.log("Excel FDP rows:", excelRows.length);

    for (const record of existing) {
      const facultyId = String(record.facultyId || "")
        .trim()
        .toUpperCase();

      const title = clean(record.title);

      const matches = excelRows
        .map((row, index) => ({
          row,
          excelRow: index + 2,
        }))
        .filter(({ row }) => {
          const excelFacultyId = String(
            getValue(row, ["Faculty ID"]) || ""
          )
            .trim()
            .toUpperCase();

          return (
            excelFacultyId === facultyId &&
            clean(getValue(row, ["Title"])) === title &&
            String(getValue(row, ["Activity Type"]))
              .trim()
              .toUpperCase() === "FDP"
          );
        });

      const existingStart = parseDate(
        record.startDate || record.activityDate
      );

      const existingEnd = parseDate(record.endDate);

      console.log("\n----------------------------------------");
      console.log("Faculty ID:", facultyId);
      console.log("Title:", record.title);
      console.log("Stored academic year:", record.academicYear);
      console.log("Stored dates:", existingStart, "to", existingEnd);

      if (!matches.length) {
        console.log("RESULT: NO EXACT FACULTY-ID + TITLE MATCH");
        continue;
      }

      console.log("Matching Excel rows:", matches.length);

      for (const { row, excelRow } of matches) {
        console.log({
          excelRow,
          academicYear: getValue(row, ["Academic Year"]),
          startDate: parseDate(getValue(row, ["Start Date"])),
          endDate: parseDate(getValue(row, ["End Date"])),
          dateCheck: getValue(row, ["Date Check"]),
          matchStatus: getValue(row, ["Match Status"]),
        });
      }
    }

    console.log("\nComparison finished. No records were modified.");
  } catch (error) {
    console.error("Comparison failed:", error.message);
  } finally {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close().catch(() => {});
    }
  }
}

main();
