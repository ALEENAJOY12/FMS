require("dotenv").config();

const mongoose = require("mongoose");
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const connectDB = require("../config/db");
const HistoricalActivity = require("../models/HistoricalActivity");
const Faculty = require("../models/Faculty");

const inputPath = path.resolve(
  __dirname,
  "../../FMS_Historical_Activities_With_FDP_2023-26.xlsx"
);

const text = (value) => String(value ?? "").trim();

const normalizeHeader = (value) =>
  String(value ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");

const getValue = (row, headers) => {
  for (const [key, value] of Object.entries(row)) {
    if (headers.map(normalizeHeader).includes(normalizeHeader(key))) {
      return value;
    }
  }
  return "";
};

const excelDate = (value) => {
  if (!value) return null;

  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : value;
  }

  if (typeof value === "number") {
    const date = xlsx.SSF.parse_date_code(value);

    return date
      ? new Date(Date.UTC(date.y, date.m - 1, date.d))
      : null;
  }

  const raw = text(value);
  const match = raw.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);

  if (match) {
    const [, day, month, year] = match;

    return new Date(
      Date.UTC(Number(year), Number(month) - 1, Number(day))
    );
  }

  const date = new Date(raw);

  return Number.isNaN(date.getTime()) ? null : date;
};

const academicYearFromDate = (date) => {
  if (!date) return "";

  const year = date.getUTCFullYear();
  const month = date.getUTCMonth();

  // June–May academic year
  const startYear = month >= 5 ? year : year - 1;

  return `${startYear}-${String((startYear + 1) % 100).padStart(2, "0")}`;
};

const readSheet = (workbook, name) => {
  const sheet = workbook.Sheets[name];

  if (!sheet) {
    throw new Error(`Missing Excel sheet: ${name}`);
  }

  return xlsx.utils.sheet_to_json(sheet, { defval: "" });
};

const findFaculty = async (facultyId) => {
  return Faculty.findOne({
    facultyId: text(facultyId).toUpperCase(),
  }).select("facultyId name department");
};

async function importFDP(workbook) {
  const rows = readSheet(workbook, "FDP Historical Combined");
  const docs = [];

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];

    const facultyId = text(getValue(row, ["Faculty ID"])).toUpperCase();
    const title = text(getValue(row, ["Title"]));
    const type = text(getValue(row, ["Activity Type"]));

    if (!facultyId || !title || type !== "FDP") {
      continue;
    }

    const faculty = await findFaculty(facultyId);

    if (!faculty) {
      console.warn(`Faculty not found: ${facultyId}. Skipping FDP row ${i + 2}.`);
      continue;
    }

    const startDate = excelDate(getValue(row, ["Start Date"]));
    const endDate = excelDate(getValue(row, ["End Date"]));

    docs.push({
      facultyId: faculty.facultyId,
      facultyName: faculty.name,
      department: faculty.department || "",
      type: "FDP",
      title,
      academicYear: text(getValue(row, ["Academic Year"])),
      startDate,
      endDate,
      activityDate: startDate,
      duration: text(getValue(row, ["Duration"])),
      organizer: text(getValue(row, ["Organizer"])),
      sourceFile:
        text(getValue(row, ["Source File"])) ||
        "FMS_Historical_Activities_With_FDP_2023-26.xlsx",
      sourceRow: Number(getValue(row, ["Source Row"])) || i + 2,
    });
  }

  return docs;
}

async function importPublications(workbook) {
  const rows = readSheet(workbook, "All Matched Publications");
  const docs = [];

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];

    const facultyId = text(getValue(row, ["Faculty ID"])).toUpperCase();

    const title = text(
      getValue(row, [
        "TITLE OF THE ARTICLE / ARTICLE IN PREPARATION",
        "Title",
      ])
    );

    const rawType = text(
      getValue(row, ["JOURNAL / CONFERENCE / BOOK CHAPTER"])
    ).toLowerCase();

    if (!facultyId || !title || !rawType) {
      continue;
    }

    let type;

    if (rawType === "journal" || rawType === "journal publication") {
      type = "Journal Publication";
    } else if (rawType === "conference") {
      type = "Conference";
    } else if (rawType === "book chapter") {
      type = "Book Chapter";
    } else {
      console.warn(`Unknown publication type: ${rawType}`);
      continue;
    }

    const faculty = await findFaculty(facultyId);

    if (!faculty) {
      console.warn(`Faculty not found: ${facultyId}. Skipping publication row ${i + 2}.`);
      continue;
    }

    const publicationDate = excelDate(
      getValue(row, ["PUBLICATION DATE"])
    );

    docs.push({
      facultyId: faculty.facultyId,
      facultyName: faculty.name,
      department: faculty.department || "",
      type,
      title,
      academicYear: academicYearFromDate(publicationDate) || "2025-26",
      activityDate: publicationDate,
      publicationDate,
      publicationStatus: text(
        getValue(row, [
          "CURRENT STATUS IN PREPARATION / PUBLISHED / ACCEPTED / SUBMITTED / IN REVISION",
        ])
      ),
      publicationType: text(
        getValue(row, ["Type Unpaid journal / Paid journal"])
      ),
      journalName: text(getValue(row, ["JOURNAL NAME"])),
      conferenceName: text(getValue(row, ["CONFERENCE NAME"])),
      doi: text(getValue(row, ["DOI"])),
      publicationLink: text(getValue(row, ["LINK TO PUBLICATION"])),
      indexing: text(getValue(row, ["INDEXING"])),
      sourceFile: "Faculty Publications 2025-26.xlsx",
      sourceRow: Number(getValue(row, ["Sl No:"])) || i + 2,
    });
  }

  return docs;
}

(async () => {
  try {
    console.log("Preparing historical activity import...");
    console.log(`Excel file: ${inputPath}`);

    if (!fs.existsSync(inputPath)) {
      throw new Error(
        "Excel file not found. Place FMS_Historical_Activities_With_FDP_2023-26.xlsx in the project root."
      );
    }

    const workbook = xlsx.readFile(inputPath, { cellDates: true });

    // Prepare records first. Do not delete anything yet.
    const [fdpDocs, publicationDocs] = await Promise.all([
      Promise.resolve(importFDP(workbook)),
      Promise.resolve(importPublications(workbook)),
    ]);

    const docs = [
      ...(await fdpDocs),
      ...(await publicationDocs),
    ];

    console.log(`FDP records prepared: ${fdpDocs.length}`);
    console.log(`Publication records prepared: ${publicationDocs.length}`);
    console.log(`Total records prepared: ${docs.length}`);

    if (!docs.length) {
      throw new Error("No records were prepared. No database records were changed.");
    }

    // Connect only after checking the workbook and preparing records.
    await connectDB();

    /*
     * Safety-first behavior:
     * This version does not delete existing records automatically.
     * Run it only after checking whether these historical records
     * have already been imported, otherwise duplicates may be created.
     */
    console.log(
      "Preview completed. Existing records were not deleted or modified."
    );
    console.log(
      "Automatic insertion is paused to prevent duplicate historical records."
    );
    console.log(
      "Next, we will verify existing records before choosing a safe import method."
    );
  } catch (error) {
    console.error("Historical import check failed:");
    console.error(error.message || error);
    process.exitCode = 1;
  } finally {
    await mongoose.connection.close().catch(() => {});
  }
})();