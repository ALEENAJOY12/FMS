
from pathlib import Path
import pandas as pd

folder = Path(__file__).parent
input_file = folder / "faculty_year_activity_counts.csv"
output_file = folder / "next_year_fdp_forecast.csv"

# Academic years included in this experiment.
YEARS = ["2023-24", "2024-25", "2025-26"]
LATEST_YEAR = "2025-26"
FORECAST_YEAR = "2026-27"

# Greater weight for more recent years.
YEAR_WEIGHTS = {
    "2023-24": 0.20,
    "2024-25": 0.30,
    "2025-26": 0.50,
}

df = pd.read_csv(input_file)

required_columns = {"facultyId", "academicYear", "fDPCount"}
missing_columns = required_columns - set(df.columns)

if missing_columns:
    raise SystemExit(
        f"Missing required CSV columns: {sorted(missing_columns)}"
    )

# Normalize academic-year labels.
df["academicYear"] = (
    df["academicYear"]
    .astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

df["facultyId"] = df["facultyId"].astype(str).str.strip()
df["fDPCount"] = pd.to_numeric(df["fDPCount"], errors="coerce")

# Keep only valid historical rows for the three completed years.
history = df[
    df["academicYear"].isin(YEARS)
    & df["facultyId"].notna()
    & (df["facultyId"] != "")
    & (df["facultyId"].str.lower() != "nan")
].copy()

if history.empty:
    raise SystemExit("No historical FDP data found.")

if history["fDPCount"].isna().any():
    print("Warning: Some rows have missing FDP counts and will be ignored.")

history = history.dropna(subset=["fDPCount"])

if (history["fDPCount"] < 0).any():
    raise SystemExit("FDP counts cannot be negative.")

# Each faculty should have at most one row per academic year.
duplicates = history.duplicated(
    subset=["facultyId", "academicYear"], keep=False
)

if duplicates.any():
    print(
        "Warning: Duplicate faculty-year rows found. "
        "Their FDP counts will be summed."
    )

history = (
    history.groupby(["facultyId", "academicYear"], as_index=False)
    ["fDPCount"].sum()
)

latest = history[
    history["academicYear"] == LATEST_YEAR
].copy()

if latest.empty:
    raise SystemExit(f"No records found for {LATEST_YEAR}.")

# Only faculty with a recorded row in the latest year are forecast.
# Missing rows in earlier years are NOT assumed to mean zero.
latest_faculty = set(latest["facultyId"])

history = history[
    history["facultyId"].isin(latest_faculty)
].copy()

forecast_rows = []

for faculty_id in sorted(latest_faculty):
    faculty_history = history[
        history["facultyId"] == faculty_id
    ].copy()

    faculty_history["weight"] = faculty_history[
        "academicYear"
    ].map(YEAR_WEIGHTS)

    # Weighted average over the years actually observed for this faculty.
    # Weights are normalized so missing years are not treated as zero.
    usable = faculty_history.dropna(
        subset=["fDPCount", "weight"]
    )

    total_weight = usable["weight"].sum()

    if total_weight <= 0:
        continue

    prediction = (
        (usable["fDPCount"] * usable["weight"]).sum()
        / total_weight
    )

    latest_count = float(
        faculty_history.loc[
            faculty_history["academicYear"] == LATEST_YEAR,
            "fDPCount",
        ].iloc[0]
    )

    observed_years = sorted(
        faculty_history["academicYear"].unique(),
        key=YEARS.index,
    )

    # Report how much historical evidence supports the estimate.
    if len(observed_years) >= 3:
        status = "Experimental estimate - 3 years of recorded history"
    elif len(observed_years) == 2:
        status = "Limited estimate - 2 years of recorded history"
    else:
        status = "Low confidence - only 1 year of recorded history"

    forecast_rows.append({
        "facultyId": faculty_id,
        "basedOnAcademicYear": LATEST_YEAR,
        "actualFDPCount": latest_count,
        "forecastAcademicYear": FORECAST_YEAR,
        "predictedFDPCount": round(float(prediction), 2),
        "predictedFDPCountRounded": int(round(float(prediction))),
        "method": "Faculty-wise recency-weighted historical average",
        "status": status,
        "historyYearsAvailable": len(observed_years),
        "historyYears": ", ".join(observed_years),
    })

output = pd.DataFrame(forecast_rows)

if output.empty:
    raise SystemExit("No forecasts could be generated.")

output.to_csv(output_file, index=False)

print("\nIndividualized FDP forecasts generated.")
print(f"Faculty included: {len(output)}")
print(f"Forecast year: {FORECAST_YEAR}")
print("Method: Faculty-wise recency-weighted historical average")
print(f"Output: {output_file}")

print("\nForecast summary:")
print(
    output[
        [
            "facultyId",
            "actualFDPCount",
            "predictedFDPCount",
            "predictedFDPCountRounded",
            "historyYearsAvailable",
            "status",
        ]
    ].to_string(index=False)
)

print("\nNo MongoDB records were modified.")
