
from pathlib import Path
import pandas as pd

DATA_FILE = Path(__file__).parent / "faculty_year_activity_counts.csv"

if not DATA_FILE.exists():
    raise FileNotFoundError(f"Dataset not found: {DATA_FILE}")

df = pd.read_csv(DATA_FILE)

print("=" * 60)
print("FMS FACULTY GROWTH — ML DATASET INSPECTION")
print("=" * 60)

print(f"\nDataset shape: {df.shape[0]} rows, {df.shape[1]} columns")
print("\nColumns:")
for column in df.columns:
    print(f"  - {column}")

print("\nFirst 10 rows:")
print(df.head(10).to_string(index=False))

required = {"facultyId", "academicYear", "totalActivities"}
missing = required - set(df.columns)

if missing:
    print("\nRequired columns not found:", sorted(missing))
    print("Review the column names above before training.")
    raise SystemExit(1)

df["academicYear"] = (
    df["academicYear"]
    .astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

print("\nRecords per academic year:")
print(df.groupby("academicYear").size().to_string())

print("\nFaculty coverage per academic year:")
print(
    df.groupby("academicYear")["facultyId"]
    .nunique()
    .to_string()
)

print("\nTotal activity count summary:")
print(df["totalActivities"].describe().to_string())

print("\nMissing values in key columns:")
print(
    df[["facultyId", "academicYear", "totalActivities"]]
    .isna()
    .sum()
    .to_string()
)

print("\nDuplicate faculty-year combinations:")
duplicates = df.duplicated(
    subset=["facultyId", "academicYear"],
    keep=False
)
print(int(duplicates.sum()))

print("\nYear-to-year faculty overlap:")
years = sorted(df["academicYear"].dropna().unique())

for previous_year, current_year in zip(years, years[1:]):
    previous_faculty = set(
        df.loc[df["academicYear"] == previous_year, "facultyId"].dropna()
    )
    current_faculty = set(
        df.loc[df["academicYear"] == current_year, "facultyId"].dropna()
    )

    overlap = previous_faculty & current_faculty

    print(
        f"  {previous_year} -> {current_year}: "
        f"{len(overlap)} faculty present in both years"
    )

print("\nInspection complete.")
print("No database records were modified.")
