
from pathlib import Path
import pandas as pd

file_path = Path(__file__).parent / "faculty_year_activity_counts.csv"
df = pd.read_csv(file_path)

df["academicYear"] = (
    df["academicYear"]
    .astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

categories = [
    "fDPCount",
    "nPTELCount",
    "researchPaperCount",
    "journalPublicationCount",
    "patentIPRCount",
    "conferenceCount",
    "bookChapterCount",
]

print("\nCATEGORY COUNTS BY ACADEMIC YEAR\n")
print(
    df.groupby("academicYear")[categories]
    .sum()
    .to_string()
)

print("\nFACULTY WITH NONZERO COUNTS BY CATEGORY\n")
for category in categories:
    nonzero = (df[category].fillna(0) > 0).sum()
    print(f"{category}: {nonzero} faculty-year rows with activity")

print("\nDATASET TOTALS\n")
print(df[categories].sum().to_string())

print("\nInspection only. No data was modified.")
