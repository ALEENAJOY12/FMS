
from pathlib import Path
import pandas as pd
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

DATA_FILE = Path(__file__).parent / "faculty_year_activity_counts.csv"

df = pd.read_csv(DATA_FILE)
df["academicYear"] = (
    df["academicYear"].astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

df = df[df["academicYear"].isin(
    ["2023-24", "2024-25", "2025-26"]
)].copy()

df["fDPCount"] = pd.to_numeric(df["fDPCount"], errors="coerce")
df = df.dropna(subset=["facultyId", "academicYear", "fDPCount"])

if df.duplicated(["facultyId", "academicYear"]).any():
    raise ValueError("Duplicate faculty-year rows found.")

year_pairs = [
    ("2023-24", "2024-25"),
    ("2024-25", "2025-26"),
]

for previous_year, target_year in year_pairs:
    previous = df[df["academicYear"] == previous_year][
        ["facultyId", "fDPCount"]
    ]
    target = df[df["academicYear"] == target_year][
        ["facultyId", "fDPCount"]
    ]

    pairs = previous.merge(
        target,
        on="facultyId",
        how="inner",
        suffixes=("_previous", "_actual"),
    )

    if pairs.empty:
        print(f"No matching faculty: {previous_year} -> {target_year}")
        continue

    X_train = previous[["fDPCount"]].rename(
    columns={"fDPCount": "fDPCount_previous"}
)
    y_train = previous["fDPCount"]

    # Only faculty with a previous-year record are evaluated.
    X_test = pairs[["fDPCount_previous"]]
    y_test = pairs["fDPCount_actual"]

    baseline = DummyRegressor(strategy="mean")
    forest = RandomForestRegressor(
        n_estimators=100,
        max_depth=3,
        random_state=42,
    )

    baseline.fit(X_train, y_train)
    forest.fit(X_train, y_train)

    baseline_predictions = baseline.predict(X_test)
    forest_predictions = forest.predict(X_test)

    print(f"\n{previous_year} -> {target_year}")
    print(f"Matched faculty: {len(pairs)}")

    for name, predictions in [
        ("Average baseline", baseline_predictions),
        ("Random Forest", forest_predictions),
    ]:
        mae = mean_absolute_error(y_test, predictions)
        rmse = mean_squared_error(y_test, predictions) ** 0.5
        print(f"{name}: MAE={mae:.3f}, RMSE={rmse:.3f}")

print("\nHeld-out chronological evaluation complete.")
print("Only previous-year FDP counts were used as input.")
print("This is exploratory; sparse data limits reliability.")
print("No MongoDB records or FMS features were modified.")
