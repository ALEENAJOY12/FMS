
from pathlib import Path
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error

DATA_FILE = Path(__file__).parent / "faculty_year_activity_counts.csv"
OUTPUT_FILE = Path(__file__).parent / "growth_evaluation_results.csv"

df = pd.read_csv(DATA_FILE)

df["academicYear"] = (
    df["academicYear"]
    .astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

# Only use the three main historical years for this experiment.
valid_years = ["2023-24", "2024-25", "2025-26"]
df = df[df["academicYear"].isin(valid_years)].copy()

df["totalActivities"] = pd.to_numeric(
    df["totalActivities"], errors="coerce"
)
df = df.dropna(subset=["facultyId", "academicYear", "totalActivities"])

if df.duplicated(["facultyId", "academicYear"]).any():
    raise ValueError("Duplicate faculty-year rows found.")

year_pairs = [
    ("2023-24", "2024-25"),
    ("2024-25", "2025-26"),
]

results = []

for train_year, test_year in year_pairs:
    train = df[df["academicYear"] == train_year].copy()
    test = df[df["academicYear"] == test_year].copy()

    # Evaluate only faculty observed in both years.
    merged = test[["facultyId", "totalActivities"]].merge(
        train[["facultyId", "totalActivities"]],
        on="facultyId",
        how="inner",
        suffixes=("_actual", "_previous"),
    )

    if merged.empty:
        print(f"\nNo overlapping faculty for {train_year} -> {test_year}")
        continue

    actual = merged["totalActivities_actual"]
    previous = merged["totalActivities_previous"]

    # Baseline 1: predict that each faculty repeats their previous count.
    previous_year_prediction = previous

    # Baseline 2: predict the average count in the training year.
    average_prediction = pd.Series(
        train["totalActivities"].mean(),
        index=merged.index,
    )

    print(f"\n{'=' * 55}")
    print(f"Evaluation: {train_year} -> {test_year}")
    print(f"Matched faculty: {len(merged)}")
    print(f"Training-year mean: {train['totalActivities'].mean():.3f}")

    for name, prediction in [
        ("Previous-year count", previous_year_prediction),
        ("Training-year mean", average_prediction),
    ]:
        mae = mean_absolute_error(actual, prediction)
        rmse = mean_squared_error(actual, prediction) ** 0.5

        print(f"\n{name}")
        print(f"  MAE:  {mae:.3f} activities")
        print(f"  RMSE: {rmse:.3f} activities")

        for index, row in merged.iterrows():
            results.append({
                "trainYear": train_year,
                "testYear": test_year,
                "facultyId": row["facultyId"],
                "actualActivities": row["totalActivities_actual"],
                "previousYearPrediction": row["totalActivities_previous"],
                "trainingMeanPrediction": train["totalActivities"].mean(),
                "model": name,
            })

if results:
    pd.DataFrame(results).to_csv(OUTPUT_FILE, index=False)
    print(f"\nDetailed results saved to: {OUTPUT_FILE}")
else:
    print("\nNo evaluation results generated.")

print("\nThis experiment evaluates baselines, not a trained ML model.")
print("It does not modify MongoDB or existing FMS features.")
