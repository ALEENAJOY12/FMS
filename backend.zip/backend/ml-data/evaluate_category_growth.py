
from pathlib import Path
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error

DATA_FILE = Path(__file__).parent / "faculty_year_activity_counts.csv"
OUTPUT_FILE = Path(__file__).parent / "category_evaluation_results.csv"

CATEGORIES = [
    "fDPCount",
    "nPTELCount",
    "researchPaperCount",
    "journalPublicationCount",
    "patentIPRCount",
    "conferenceCount",
    "bookChapterCount",
]

YEAR_PAIRS = [
    ("2023-24", "2024-25"),
    ("2024-25", "2025-26"),
]

df = pd.read_csv(DATA_FILE)

df["academicYear"] = (
    df["academicYear"]
    .astype(str)
    .str.replace("–", "-", regex=False)
    .str.replace("—", "-", regex=False)
    .str.strip()
)

required = ["facultyId", "academicYear", *CATEGORIES]
missing = set(required) - set(df.columns)

if missing:
    raise ValueError(f"Missing required columns: {sorted(missing)}")

df = df[df["academicYear"].isin(
    ["2023-24", "2024-25", "2025-26"]
)].copy()

for category in CATEGORIES:
    df[category] = pd.to_numeric(df[category], errors="coerce")

if df.duplicated(["facultyId", "academicYear"]).any():
    raise ValueError("Duplicate faculty-year combinations found.")

all_results = []

for train_year, test_year in YEAR_PAIRS:
    train = df[df["academicYear"] == train_year].copy()
    test = df[df["academicYear"] == test_year].copy()

    # Compare only faculty with records in both academic years.
    merged = test[["facultyId", *CATEGORIES]].merge(
        train[["facultyId", *CATEGORIES]],
        on="facultyId",
        how="inner",
        suffixes=("_actual", "_previous"),
    )

    if merged.empty:
        print(f"\nSkipping {train_year} -> {test_year}: no overlap.")
        continue

    print(f"\n{'=' * 65}")
    print(f"{train_year} -> {test_year}")
    print(f"Matched faculty: {len(merged)}")

    for category in CATEGORIES:
        actual = merged[f"{category}_actual"]
        previous = merged[f"{category}_previous"]

        # Baseline A: each faculty repeats their previous count.
        previous_prediction = previous

        # Baseline B: use the category average from the training year.
        training_mean = train[category].mean()
        mean_prediction = pd.Series(
            training_mean, index=merged.index
        )

        print(f"\n{category} (training-year mean: {training_mean:.3f})")

        for model_name, prediction in [
            ("Previous-year count", previous_prediction),
            ("Training-year category mean", mean_prediction),
        ]:
            mae = mean_absolute_error(actual, prediction)
            rmse = mean_squared_error(actual, prediction) ** 0.5

            print(
                f"  {model_name}: "
                f"MAE={mae:.3f}, RMSE={rmse:.3f}"
            )

            all_results.append({
                "trainYear": train_year,
                "testYear": test_year,
                "category": category,
                "model": model_name,
                "matchedFaculty": len(merged),
                "MAE": mae,
                "RMSE": rmse,
            })

if not all_results:
    raise RuntimeError("No evaluation results were generated.")

results = pd.DataFrame(all_results)
results.to_csv(OUTPUT_FILE, index=False)

print("\n" + "=" * 65)
print("Evaluation complete.")
print(f"Results saved to: {OUTPUT_FILE}")
print("These are baseline comparisons, not trained-ML results.")
print("No MongoDB records or FMS features were modified.")
