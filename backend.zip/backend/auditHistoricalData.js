
require("dotenv").config();

const mongoose = require("mongoose");
const connectDB = require("./config/db");
const HistoricalActivity = require("./models/HistoricalActivity");

async function auditHistoricalData() {
  try {
    await connectDB();

    console.log(
      "\nTotal historical records:",
      await HistoricalActivity.countDocuments()
    );

    console.log("\nRecords by activity type:");
    console.table(
      await HistoricalActivity.aggregate([
        {
          $group: {
            _id: "$type",
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ])
    );

    console.log("\nRecords by academic year:");
    console.table(
      await HistoricalActivity.aggregate([
        {
          $group: {
            _id: {
              $cond: [
                { $eq: ["$academicYear", ""] },
                "(Missing)",
                "$academicYear",
              ],
            },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ])
    );

    console.log(
      "\nUnique faculty:",
      (await HistoricalActivity.distinct("facultyId")).length
    );
  } catch (error) {
    console.error("Audit failed:", error.message);
  } finally {
    await mongoose.disconnect();
  }
}

auditHistoricalData();
