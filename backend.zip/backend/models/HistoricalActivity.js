
const mongoose = require("mongoose");

const historicalActivitySchema = new mongoose.Schema(
  {
    facultyId: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true,
    },

    facultyName: {
      type: String,
      required: true,
      trim: true,
    },

    department: {
      type: String,
      trim: true,
      default: "",
    },

    // Supports both imported historical activities
    // and newly approved activities.
    type: {
      type: String,
      required: true,
      enum: [
        "FDP",
        "NPTEL",
        "Research Paper",
        "Journal Publication",
        "Patent / IPR",
        "Conference",
        "Book Chapter",
      ],
    },

    title: {
      type: String,
      required: true,
      trim: true,
    },

    academicYear: {
      type: String,
      trim: true,
      default: "",
    },

    startDate: {
      type: Date,
      default: null,
    },

    endDate: {
      type: Date,
      default: null,
    },

    activityDate: {
      type: Date,
      default: null,
    },

    duration: {
      type: String,
      trim: true,
      default: "",
    },

    organizer: {
      type: String,
      trim: true,
      default: "",
    },

    journalName: {
      type: String,
      trim: true,
      default: "",
    },

    publicationDate: {
      type: Date,
      default: null,
    },

    publicationStatus: {
      type: String,
      trim: true,
      default: "",
    },

    publicationType: {
      type: String,
      trim: true,
      default: "",
    },

    indexing: {
      type: String,
      trim: true,
      default: "",
    },

    doi: {
      type: String,
      trim: true,
      default: "",
    },

    publicationLink: {
      type: String,
      trim: true,
      default: "",
    },

    conferenceName: {
      type: String,
      trim: true,
      default: "",
    },

    // Links a historical record to its current Activity.
    // Imported historical records can leave this field empty.
    sourceActivityId: {
      type: String,
      trim: true,
      default: undefined,
      unique: true,
      sparse: true,
    },

    sourceFile: {
      type: String,
      trim: true,
      default: "",
    },

    sourceRow: {
      type: Number,
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// Keep the existing faculty/type/date index.
historicalActivitySchema.index({
  facultyId: 1,
  type: 1,
  startDate: 1,
});

module.exports = mongoose.model(
  "HistoricalActivity",
  historicalActivitySchema
);
