const mongoose = require("mongoose");

const activitySchema = new mongoose.Schema(
  {
    facultyId: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true,
    },

    facultyName: {
      type: String,
      required: true,
      trim: true,
    },

    department: {
      type: String,
      trim: true,
      default: "",
    },

    type: {
      type: String,
      required: true,
      enum: [
        "FDP",
        "NPTEL",
        "Research Paper",
        "Journal Publication",
        "Patent / IPR",
      ],
    },

    title: {
      type: String,
      required: true,
      trim: true,
    },

    // =========================
    // COMMON ACTIVITY FIELDS
    // =========================

    organizer: {
      type: String,
      trim: true,
      default: "",
    },

    institution: {
      type: String,
      trim: true,
      default: "",
    },

    publisher: {
      type: String,
      trim: true,
      default: "",
    },

    conferenceName: {
      type: String,
      trim: true,
      default: "",
    },

    mode: {
      type: String,
      trim: true,
      default: "",
    },

    startDate: {
      type: Date,
      default: null,
    },

    endDate: {
      type: Date,
      default: null,
    },

    activityDate: {
      type: Date,
      default: null,
    },

    duration: {
      type: String,
      trim: true,
      default: "",
    },

    academicYear: {
      type: String,
      trim: true,
      default: "",
    },

    description: {
      type: String,
      trim: true,
      default: "",
    },

    // =========================
    // NPTEL
    // =========================

    courseCode: {
      type: String,
      trim: true,
      default: "",
    },

    courseWeeks: {
      type: String,
      trim: true,
      default: "",
    },

    examDate: {
      type: Date,
      default: null,
    },

    score: {
      type: String,
      default: "",
    },

    result: {
      type: String,
      trim: true,
      default: "",
    },

    certificateType: {
      type: String,
      trim: true,
      default: "",
    },

    // =========================
    // RESEARCH / JOURNAL
    // =========================

    authors: {
      type: String,
      trim: true,
      default: "",
    },

    publicationDate: {
      type: Date,
      default: null,
    },

    doi: {
      type: String,
      trim: true,
      default: "",
    },

    indexing: {
      type: String,
      trim: true,
      default: "",
    },

    publicationType: {
      type: String,
      trim: true,
      default: "",
    },

    journalName: {
      type: String,
      trim: true,
      default: "",
    },

    issn: {
      type: String,
      trim: true,
      default: "",
    },

    volumeIssue: {
      type: String,
      trim: true,
      default: "",
    },

    // =========================
    // PATENT / IPR
    // =========================

    applicationNumber: {
      type: String,
      trim: true,
      default: "",
    },

    patentType: {
      type: String,
      trim: true,
      default: "",
    },

    filingDate: {
      type: Date,
      default: null,
    },

    inventors: {
      type: String,
      trim: true,
      default: "",
    },

    country: {
      type: String,
      trim: true,
      default: "",
    },

    patentStatus: {
      type: String,
      trim: true,
      default: "",
    },

    grantDate: {
      type: Date,
      default: null,
    },

    // =========================
    // MAIN PROOF
    // =========================

    proof: {
      type: String,
      default: "",
    },

    proofName: {
      type: String,
      default: "",
    },

    // =========================
    // CONTRIBUTION
    // =========================

    contributionDone: {
      type: String,
      enum: ["Yes", "No"],
      default: "No",
    },

    contributionType: {
      type: String,
      trim: true,
      default: "",
    },

    contributionTitle: {
      type: String,
      trim: true,
      default: "",
    },

    contributionDate: {
      type: Date,
      default: null,
    },

    contributionFor: {
      type: String,
      enum: ["", "Students", "Department", "Both"],
      default: "",
    },

    // STUDENT IMPACT

    targetGroup: {
      type: String,
      trim: true,
      default: "",
    },

    participantCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    studentImpact: {
      type: String,
      trim: true,
      default: "",
    },

    // DEPARTMENT IMPACT

    departmentTarget: {
      type: String,
      trim: true,
      default: "",
    },

    departmentImpact: {
      type: String,
      trim: true,
      default: "",
    },

    // COMMON CONTRIBUTION

    contributionDescription: {
      type: String,
      trim: true,
      default: "",
    },

    impactLevel: {
      type: String,
      enum: ["", "Low", "Moderate", "High", "Very High"],
      default: "",
    },

    contributionProof: {
      type: String,
      default: "",
    },

    contributionProofName: {
      type: String,
      default: "",
    },

    // =========================
    // APPROVAL
    // =========================

    status: {
      type: String,
      enum: ["Pending", "Approved", "Rejected"],
      default: "Pending",
    },

    rejectionReason: {
      type: String,
      trim: true,
      default: "",
    },

    reviewedAt: {
      type: Date,
      default: null,
    },

    contributionStatus: {
      type: String,
      enum: [
        "Pending",
        "Approved",
        "Rejected",
        "Not Applicable",
      ],
      default: "Not Applicable",
    },

    contributionReviewComment: {
      type: String,
      trim: true,
      default: "",
    },

    contributionReviewedAt: {
      type: Date,
      default: null,
    },

    submissionDate: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

const Activity = mongoose.model(
  "Activity",
  activitySchema
);

module.exports = Activity;