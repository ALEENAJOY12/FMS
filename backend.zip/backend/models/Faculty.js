const mongoose = require("mongoose");

const normalizeDepartment = (department) => {
  const value = String(department || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");

  const aliases = {
    cse: "CSE",
    "computer science": "CSE",
    "computer science engineering": "CSE",
    "computer science and engineering": "CSE",
    "computer science & engineering": "CSE",
  };

  return (
    aliases[value] ||
    String(department || "").trim()
  );
};

const emptyToUndefined = (value) => {
  const cleaned = String(value ?? "").trim();

  return cleaned ? cleaned : undefined;
};

const facultySchema = new mongoose.Schema(
  {
    facultyId: {
      type: String,
      required: [
        true,
        "Faculty ID is required",
      ],
      unique: true,
      trim: true,
      uppercase: true,
    },

    name: {
      type: String,
      required: [
        true,
        "Faculty name is required",
      ],
      trim: true,
    },

    email: {
      type: String,
      required: [
        true,
        "Email is required",
      ],
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        "Please provide a valid email address",
      ],
    },

    phone: {
      type: String,
      trim: true,
      default: "",
    },

    department: {
      type: String,
      required: [
        true,
        "Department is required",
      ],
      trim: true,
      set: normalizeDepartment,
    },

    designation: {
      type: String,
      required: [
        true,
        "Designation is required",
      ],
      trim: true,
    },

    qualification: {
      type: String,
      trim: true,
      default: "",
    },

    experience: {
      type: String,
      trim: true,
      default: "",
    },

    dateOfJoining: {
      type: Date,
      default: null,
    },

    aadhaarNumber: {
      type: String,
      trim: true,
      unique: true,
      sparse: true,
      default: undefined,
      set: emptyToUndefined,
    },

    panNumber: {
      type: String,
      trim: true,
      uppercase: true,
      unique: true,
      sparse: true,
      default: undefined,
      set: emptyToUndefined,
    },

    address: {
      type: String,
      trim: true,
      default: "",
    },

    // Faculty profile photograph only
    profileImage: {
      type: String,
      trim: true,
      default: "",
    },

    // Faculty proof / certificate only
    certificateUrl: {
      type: String,
      trim: true,
      default: "",
    },

    certificateName: {
      type: String,
      trim: true,
      default: "",
    },

    certificateMimeType: {
      type: String,
      trim: true,
      default: "",
    },

    source: {
      type: String,
      enum: [
        "Excel Import",
        "Manual Entry",
        "System",
      ],
      default: "System",
    },

    registrationStatus: {
      type: String,
      enum: [
        "Not Registered",
        "Pending",
        "Approved",
        "Rejected",
      ],
      default: "Not Registered",
    },

    accountStatus: {
      type: String,
      enum: [
        "Inactive",
        "Active",
        "Suspended",
      ],
      default: "Inactive",
    },

    isRegistered: {
      type: Boolean,
      default: false,
    },

    password: {
      type: String,
      default: "",
      select: false,
    },

    lastLogin: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// Helpful indexes for admin filters
facultySchema.index({
  department: 1,
});

facultySchema.index({
  registrationStatus: 1,
});

facultySchema.index({
  accountStatus: 1,
});

const Faculty = mongoose.model(
  "Faculty",
  facultySchema
);

module.exports = Faculty; 