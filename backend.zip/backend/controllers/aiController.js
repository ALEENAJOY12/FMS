const OpenAIModule = require("openai");
const OpenAI = OpenAIModule.default || OpenAIModule;

const ALLOWED_REPORTS = new Set([
  "Faculty Directory",
  "Registration Status",
  "Activity Submission",
  "Pending Activities",
  "Department Performance",
  "Faculty Impact Score",
]);

const MAX_CONTEXT_BYTES = 20 * 1024;

function getOpenAIClient() {
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

function handleOpenAIError(res, error, message) {
  console.error(message, error);
  const status = Number(error?.status) || 500;

  if (status === 401) {
    return res.status(503).json({
      success: false,
      message: "The server AI key is invalid or unavailable.",
    });
  }

  if (status === 429) {
    return res.status(429).json({
      success: false,
      message: "AI usage limit reached. Please try again later.",
    });
  }

  return res.status(500).json({
    success: false,
    message:
      process.env.NODE_ENV === "production"
        ? message
        : error.message || message,
  });
}

// ========================================
// AI REPORT SUMMARY
// Requires OpenAI API credits.
// ========================================
const generateReportSummary = async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({
        success: false,
        message: "AI is not configured on the server yet.",
      });
    }

    const { selectedReport, context } = req.body || {};

    if (!ALLOWED_REPORTS.has(selectedReport)) {
      return res.status(400).json({
        success: false,
        message: "Invalid report type.",
      });
    }

    if (!context || typeof context !== "object" || Array.isArray(context)) {
      return res.status(400).json({
        success: false,
        message: "Report context is required.",
      });
    }

    const serializedContext = JSON.stringify(context);
    if (Buffer.byteLength(serializedContext, "utf8") > MAX_CONTEXT_BYTES) {
      return res.status(413).json({
        success: false,
        message: "Report context is too large.",
      });
    }

    const response = await getOpenAIClient().responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: [
        "You are the AI analytics assistant for a university Faculty Management System.",
        "Use only the supplied report statistics.",
        "Never invent counts, causes, trends, names, or conclusions.",
        "Do not ask for or mention personal information.",
        "Write in clear professional English.",
        "Return 4 concise bullet points followed by one short Recommended focus sentence.",
        "When a value is zero, state that plainly.",
        "Do not use markdown headings.",
      ].join(" "),
      input: [
        `Selected report: ${selectedReport}`,
        "",
        "Current report statistics:",
        serializedContext,
      ].join("\n"),
      reasoning: { effort: "none" },
      text: { verbosity: "low" },
      max_output_tokens: 450,
      store: false,
    });

    const summary = String(response.output_text || "").trim();
    if (!summary) {
      return res.status(502).json({
        success: false,
        message: "AI returned an empty response. Please try again.",
      });
    }

    return res.status(200).json({
      success: true,
      summary,
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    });
  } catch (error) {
    return handleOpenAIError(
      res,
      error,
      "Unable to generate the AI report summary."
    );
  }
};

// ========================================
// RULE-BASED DASHBOARD INSIGHT
// Does not call OpenAI.
// ========================================
const generateDashboardInsight = async (req, res) => {
  try {
    const { context } = req.body || {};

    if (!context || typeof context !== "object" || Array.isArray(context)) {
      return res.status(400).json({
        success: false,
        message: "Dashboard context is required.",
      });
    }

    const serializedContext = JSON.stringify(context);
    if (Buffer.byteLength(serializedContext, "utf8") > MAX_CONTEXT_BYTES) {
      return res.status(413).json({
        success: false,
        message: "Dashboard context is too large.",
      });
    }

    const statistics = [];

    function collectStatistics(value, path = "") {
      if (value === null || value === undefined) return;

      if (typeof value === "number" && Number.isFinite(value)) {
        statistics.push({ label: path || "Value", value });
        return;
      }

      if (typeof value === "string") {
        const trimmed = value.trim();
        if (trimmed !== "" && Number.isFinite(Number(trimmed))) {
          statistics.push({ label: path || "Value", value: Number(trimmed) });
        }
        return;
      }

      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          collectStatistics(
            item,
            path ? `${path} ${index + 1}` : `Item ${index + 1}`
          );
        });
        return;
      }

      if (typeof value === "object") {
        for (const [key, child] of Object.entries(value)) {
          collectStatistics(child, path ? `${path} ${key}` : key);
        }
      }
    }

    collectStatistics(context);

    function findStatistic(keywords) {
      return statistics.find((item) => {
        const label = item.label.toLowerCase();
        return keywords.some((keyword) => label.includes(keyword));
      });
    }

    const faculty = findStatistic([
      "total faculty",
      "faculty count",
      "faculties",
    ]);
    const pending = findStatistic(["pending"]);
    const approved = findStatistic(["approved"]);
    const rejected = findStatistic(["rejected"]);
    const submissions = findStatistic([
      "submission",
      "submitted",
      "activities",
    ]);
    const departments = findStatistic(["department"]);
    const bullets = [];

    if (faculty) {
      bullets.push(
        `• Faculty overview: ${faculty.label} is ${faculty.value}.`
      );
    }

    if (pending) {
      bullets.push(
        pending.value > 0
          ? `• Review workload: ${pending.value} pending item(s) may need administrator review.`
          : "• Review workload: no pending items are reported by this statistic."
      );
    }

    if (approved && bullets.length < 3) {
      bullets.push(`• Approvals: ${approved.label} is ${approved.value}.`);
    }

    if (rejected && bullets.length < 3) {
      bullets.push(`• Rejections: ${rejected.label} is ${rejected.value}.`);
    }

    if (submissions && bullets.length < 3) {
      bullets.push(`• Activity: ${submissions.label} is ${submissions.value}.`);
    }

    if (departments && bullets.length < 3) {
      bullets.push(
        `• Department information: ${departments.label} is ${departments.value}.`
      );
    }

    if (bullets.length === 0) {
      bullets.push(
        "• No clearly labelled numeric dashboard statistics were found."
      );
      bullets.push("• Check that the dashboard request includes its statistics.");
      bullets.push(
        "• A trend or cause cannot be confirmed from the supplied data alone."
      );
    }

    while (bullets.length < 3) {
      bullets.push(
        "• No additional conclusion can be confirmed from the supplied statistics."
      );
    }

    const recommendedAction =
      pending && pending.value > 0
        ? "Recommended action: review pending items and prioritize those waiting the longest."
        : "Recommended action: continue monitoring submissions and review statuses.";

    const insight = `${bullets.slice(0, 3).join("\n")}\n${recommendedAction}`;

    return res.status(200).json({
      success: true,
      insight,
      model: "rule-based",
    });
  } catch (error) {
    console.error("Rule-based dashboard insight error:", error);

    return res.status(500).json({
      success: false,
      message:
        process.env.NODE_ENV === "production"
          ? "Unable to generate the dashboard insight."
          : error.message || "Unable to generate the dashboard insight.",
    });
  }
};

// ========================================
// EXPORT CONTROLLERS
// Evidence analysis has been removed.
// ========================================
module.exports = {
  generateReportSummary,
  generateDashboardInsight,
};