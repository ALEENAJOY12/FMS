
const Activity = require("../models/Activity");
const HistoricalActivity = require("../models/HistoricalActivity");

const VALID_ACTIVITY_TYPES = new Set([
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
]);

const VALID_MAIN_STATUSES = new Set([
  "Pending",
  "Approved",
  "Rejected",
]);

const VALID_CONTRIBUTION_STATUSES = new Set([
  "Pending",
  "Approved",
  "Rejected",
  "Not Applicable",
]);

// ========================================
// HELPERS
// ========================================

const normalizeFacultyId = (value) =>
  String(value || "").trim().toUpperCase();

/*
 * Synchronize approved activities into HistoricalActivity.
 * sourceActivityId prevents duplicate linked records.
 * Imported historical records are left untouched.
 */
const syncApprovedActivityToHistorical = async (activity) => {
  if (!activity?._id) return;

  const sourceActivityId = String(activity._id);
  const status = activity.status || "Pending";

  // Remove only the linked mirror if the activity is no longer approved.
  if (status !== "Approved") {
    await HistoricalActivity.deleteOne({ sourceActivityId });
    return;
  }

  if (!VALID_ACTIVITY_TYPES.has(activity.type)) {
    throw new Error(
      `Unsupported historical activity type: ${activity.type}`
    );
  }

  const historicalData = {
    sourceActivityId,
    facultyId: normalizeFacultyId(activity.facultyId),
    facultyName: String(activity.facultyName || "").trim(),
    department: activity.department || "",
    type: activity.type,
    title: activity.title,
    academicYear: activity.academicYear || "",

    startDate: activity.startDate || null,
    endDate: activity.endDate || null,

    activityDate:
      activity.activityDate ||
      activity.examDate ||
      activity.filingDate ||
      activity.publicationDate ||
      null,

    duration: activity.duration || activity.courseWeeks || "",

    organizer:
      activity.organizer ||
      activity.institution ||
      activity.publisher ||
      activity.conferenceName ||
      "",

    journalName: activity.journalName || "",
    publicationDate: activity.publicationDate || null,

    publicationStatus:
      activity.result || activity.patentStatus || "",

    publicationType:
      activity.publicationType || activity.patentType || "",

    indexing: activity.indexing || "",
    doi: activity.doi || "",
    publicationLink: activity.proof || "",
    conferenceName: activity.conferenceName || "",

    sourceFile: "FMS approved activity",
  };

  await HistoricalActivity.findOneAndUpdate(
    { sourceActivityId },
    { $set: historicalData },
    {
      upsert: true,
      new: true,
      runValidators: true,
      setDefaultsOnInsert: true,
    }
  );
};

const isKnownRole = (req) =>
  req.user?.role === "faculty" ||
  req.user?.role === "admin";

const rejectUnknownRole = (req, res) => {
  if (isKnownRole(req)) return false;

  res.status(403).json({
    success: false,
    message: "You are not authorized to access this resource.",
  });

  return true;
};

const isFacultyOwner = (activity, req) => {
  if (
    !activity ||
    !req.user ||
    req.user.role !== "faculty"
  ) {
    return false;
  }

  return (
    normalizeFacultyId(activity.facultyId) ===
    normalizeFacultyId(req.user.facultyId)
  );
};

const handleControllerError = (res, error, fallbackMessage) => {
  if (error.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: "Invalid activity ID.",
    });
  }

  const payload = {
    success: false,
    message: fallbackMessage,
  };

  if (process.env.NODE_ENV !== "production") {
    payload.error = error.message;
  }

  return res.status(500).json(payload);
};

// ========================================
// GET ALL ACTIVITIES
// ADMIN ONLY
// ========================================

const getAllActivities = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    if (req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Administrator access is required.",
      });
    }

    const activities = await Activity.find().sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      count: activities.length,
      activities,
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to retrieve activities."
    );
  }
};

// ========================================
// GET ACTIVITIES BY FACULTY ID
// FACULTY: OWN RECORDS ONLY
// ADMIN: ANY FACULTY
// ========================================

const getFacultyActivities = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    const facultyId = normalizeFacultyId(req.params.facultyId);

    if (!facultyId) {
      return res.status(400).json({
        success: false,
        message: "Faculty ID is required.",
      });
    }

    if (
      req.user.role === "faculty" &&
      facultyId !== normalizeFacultyId(req.user.facultyId)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only view your own activities.",
      });
    }

    const activities = await Activity.find({ facultyId }).sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      count: activities.length,
      activities,
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to retrieve faculty activities."
    );
  }
};

// ========================================
// GET SINGLE ACTIVITY
// ========================================

const getActivityById = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    const activity = await Activity.findById(req.params.id);

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: "Activity not found.",
      });
    }

    if (
      req.user.role === "faculty" &&
      !isFacultyOwner(activity, req)
    ) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to view this activity.",
      });
    }

    return res.status(200).json({
      success: true,
      activity,
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to retrieve activity."
    );
  }
};

// ========================================
// CREATE ACTIVITY
// FACULTY ONLY
// New activities start as Pending.
// ========================================

const createActivity = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    if (req.user.role !== "faculty") {
      return res.status(403).json({
        success: false,
        message: "Only faculty members can submit activities.",
      });
    }

    const faculty = req.user.faculty;

    if (!faculty) {
      return res.status(401).json({
        success: false,
        message: "Faculty authentication data not found.",
      });
    }

    const type = String(req.body.type || "").trim();
    const title = String(req.body.title || "").trim();

    if (!type || !title) {
      return res.status(400).json({
        success: false,
        message: "Activity type and title are required.",
      });
    }

    if (!VALID_ACTIVITY_TYPES.has(type)) {
      return res.status(400).json({
        success: false,
        message: "Invalid activity type.",
      });
    }

    const contributionDone =
      req.body.contributionDone === "Yes" ? "Yes" : "No";

    const activityData = { ...req.body };

    // Do not trust identity, status, or review fields from the client.
    [
      "_id",
      "__v",
      "facultyId",
      "facultyName",
      "department",
      "status",
      "rejectionReason",
      "reviewedAt",
      "contributionStatus",
      "contributionReviewComment",
      "contributionReviewedAt",
      "submissionDate",
      "createdAt",
      "updatedAt",
    ].forEach((field) => delete activityData[field]);

    const activity = await Activity.create({
      ...activityData,
      facultyId: normalizeFacultyId(faculty.facultyId),
      facultyName: String(faculty.name || "").trim(),
      department: faculty.department || "",
      type,
      title,
      status: "Pending",
      rejectionReason: "",
      reviewedAt: null,
      contributionDone,
      contributionStatus:
        contributionDone === "Yes" ? "Pending" : "Not Applicable",
      contributionReviewComment: "",
      contributionReviewedAt: null,
      submissionDate: new Date(),
    });

    return res.status(201).json({
      success: true,
      message: "Activity submitted successfully.",
      activity,
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to create activity."
    );
  }
};

// ========================================
// UPDATE ACTIVITY
//
// ADMIN: review/update workflow fields.
// FACULTY: update own Pending/Rejected activity.
// Approved activities remain locked, except
// for resubmitting a rejected contribution.
// ========================================

const updateActivity = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    const existingActivity = await Activity.findById(req.params.id);

    if (!existingActivity) {
      return res.status(404).json({
        success: false,
        message: "Activity not found.",
      });
    }

    const updateData = { ...req.body };

    // Never allow direct editing of identity/system fields.
    [
      "_id",
      "__v",
      "createdAt",
      "updatedAt",
      "facultyId",
      "facultyName",
      "department",
      "type",
    ].forEach((field) => delete updateData[field]);

    // ====================================
    // FACULTY UPDATE
    // ====================================

    if (req.user.role === "faculty") {
      if (!isFacultyOwner(existingActivity, req)) {
        return res.status(403).json({
          success: false,
          message: "You can only update your own activities.",
        });
      }

      const mainStatus = existingActivity.status || "Pending";

      const contributionStatus =
        existingActivity.contributionStatus ||
        (existingActivity.contributionDone === "Yes"
          ? "Pending"
          : "Not Applicable");

      [
        "status",
        "rejectionReason",
        "reviewedAt",
        "contributionStatus",
        "contributionReviewComment",
        "contributionReviewedAt",
        "submissionDate",
      ].forEach((field) => delete updateData[field]);

      // Approved activity with a rejected contribution:
      // only contribution fields can be corrected.
      if (
        mainStatus === "Approved" &&
        contributionStatus === "Rejected"
      ) {
        const allowedContributionFields = new Set([
          "contributionType",
          "contributionTitle",
          "contributionDate",
          "contributionFor",
          "targetGroup",
          "participantCount",
          "studentImpact",
          "departmentTarget",
          "departmentImpact",
          "contributionDescription",
          "impactLevel",
          "contributionProof",
          "contributionProofName",
        ]);

        const contributionUpdate = {};

        for (const [key, value] of Object.entries(updateData)) {
          if (allowedContributionFields.has(key)) {
            contributionUpdate[key] = value;
          }
        }

        contributionUpdate.contributionDone = "Yes";
        contributionUpdate.status = "Approved";
        contributionUpdate.contributionStatus = "Pending";
        contributionUpdate.contributionReviewComment = "";
        contributionUpdate.contributionReviewedAt = null;

        const activity = await Activity.findByIdAndUpdate(
          req.params.id,
          contributionUpdate,
          {
            returnDocument: "after",
            runValidators: true,
          }
        );

        return res.status(200).json({
          success: true,
          message:
            "Contribution resubmitted successfully. The approved activity remains locked.",
          activity,
        });
      }

      if (mainStatus === "Approved") {
        return res.status(403).json({
          success: false,
          message:
            "Approved activities are locked. Only a rejected contribution can be edited and resubmitted.",
        });
      }

      // Pending or Rejected activity resubmission.
      updateData.status = "Pending";
      updateData.rejectionReason = "";
      updateData.reviewedAt = null;
      updateData.submissionDate = new Date();

      const contributionDone =
        updateData.contributionDone === "Yes"
          ? "Yes"
          : updateData.contributionDone === "No"
          ? "No"
          : existingActivity.contributionDone === "Yes"
          ? "Yes"
          : "No";

      updateData.contributionDone = contributionDone;
      updateData.contributionStatus =
        contributionDone === "Yes" ? "Pending" : "Not Applicable";
      updateData.contributionReviewComment = "";
      updateData.contributionReviewedAt = null;
    }

    // ====================================
    // ADMIN REVIEW UPDATE
    // Admin can update review/workflow fields only.
    // ====================================

    let finalUpdateData = updateData;

    if (req.user.role === "admin") {
      const adminUpdate = {};
      const requestedMainStatus = req.body.status;

      if (requestedMainStatus !== undefined) {
        if (!VALID_MAIN_STATUSES.has(requestedMainStatus)) {
          return res.status(400).json({
            success: false,
            message: "Invalid activity status.",
          });
        }

        adminUpdate.status = requestedMainStatus;

        if (requestedMainStatus === "Rejected") {
          const rejectionReason = String(
            req.body.rejectionReason || ""
          ).trim();

          if (!rejectionReason) {
            return res.status(400).json({
              success: false,
              message:
                "A rejection reason is required when rejecting an activity.",
            });
          }

          adminUpdate.rejectionReason = rejectionReason;
          adminUpdate.reviewedAt = new Date();
        } else if (requestedMainStatus === "Approved") {
          adminUpdate.rejectionReason = "";
          adminUpdate.reviewedAt = new Date();
        } else {
          adminUpdate.rejectionReason = "";
          adminUpdate.reviewedAt = null;
        }
      }

      const finalMainStatus =
        adminUpdate.status || existingActivity.status || "Pending";

      const contributionExists =
        existingActivity.contributionDone === "Yes";

      // If the main activity is not approved, reset its contribution review.
      if (contributionExists && finalMainStatus !== "Approved") {
        adminUpdate.contributionStatus = "Pending";
        adminUpdate.contributionReviewComment = "";
        adminUpdate.contributionReviewedAt = null;
      }

      if (!contributionExists) {
        adminUpdate.contributionStatus = "Not Applicable";
        adminUpdate.contributionReviewComment = "";
        adminUpdate.contributionReviewedAt = null;
      }

      const requestedContributionStatus =
        req.body.contributionStatus;

      if (
        requestedContributionStatus !== undefined &&
        finalMainStatus === "Approved"
      ) {
        if (!contributionExists) {
          return res.status(400).json({
            success: false,
            message:
              "This activity does not contain a contribution.",
          });
        }

        if (
          !VALID_CONTRIBUTION_STATUSES.has(
            requestedContributionStatus
          ) ||
          requestedContributionStatus === "Not Applicable"
        ) {
          return res.status(400).json({
            success: false,
            message: "Invalid contribution status.",
          });
        }

        adminUpdate.contributionStatus =
          requestedContributionStatus;

        if (requestedContributionStatus === "Rejected") {
          const contributionComment = String(
            req.body.contributionReviewComment || ""
          ).trim();

          if (!contributionComment) {
            return res.status(400).json({
              success: false,
              message:
                "A review comment is required when rejecting a contribution.",
            });
          }

          adminUpdate.contributionReviewComment =
            contributionComment;
          adminUpdate.contributionReviewedAt = new Date();
        } else if (requestedContributionStatus === "Approved") {
          adminUpdate.contributionReviewComment = "";
          adminUpdate.contributionReviewedAt = new Date();
        } else {
          adminUpdate.contributionReviewComment = "";
          adminUpdate.contributionReviewedAt = null;
        }
      } else if (
        requestedContributionStatus !== undefined &&
        finalMainStatus !== "Approved"
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Approve the main activity before reviewing its contribution.",
        });
      }

      finalUpdateData = adminUpdate;
    }

    const activity = await Activity.findByIdAndUpdate(
      req.params.id,
      finalUpdateData,
      {
        returnDocument: "after",
        runValidators: true,
      }
    );

    // Synchronize only after an admin review.
    if (req.user.role === "admin" && activity) {
      try {
        await syncApprovedActivityToHistorical(activity);
      } catch (syncError) {
        console.error(
          "Historical activity sync failed:",
          syncError
        );

        return res.status(500).json({
          success: false,
          message:
            "The activity review was saved, but Historical Analytics could not be synchronized. Please retry the review action.",
        });
      }
    }

    return res.status(200).json({
      success: true,
      message: "Activity updated successfully.",
      activity,
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to update activity."
    );
  }
};

// ========================================
// DELETE ACTIVITY
//
// ADMIN: can delete any activity.
// FACULTY: can delete own Pending activity.
// ========================================

const deleteActivity = async (req, res) => {
  try {
    if (rejectUnknownRole(req, res)) return;

    const activity = await Activity.findById(req.params.id);

    if (!activity) {
      return res.status(404).json({
        success: false,
        message: "Activity not found.",
      });
    }

    if (req.user.role === "faculty") {
      if (!isFacultyOwner(activity, req)) {
        return res.status(403).json({
          success: false,
          message: "You can only delete your own activities.",
        });
      }

      if ((activity.status || "Pending") !== "Pending") {
        return res.status(403).json({
          success: false,
          message: "Only Pending activities can be deleted by faculty.",
        });
      }
    }

    // Remove the linked mirror, if one exists, before deleting.
    // This does not affect imported historical records.
    await HistoricalActivity.deleteOne({
      sourceActivityId: String(activity._id),
    });

    await Activity.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: "Activity deleted successfully.",
    });
  } catch (error) {
    return handleControllerError(
      res,
      error,
      "Unable to delete activity."
    );
  }
};

module.exports = {
  getAllActivities,
  getFacultyActivities,
  getActivityById,
  createActivity,
  updateActivity,
  deleteActivity,
};
