
const HistoricalActivity = require("../models/HistoricalActivity");

const getFacultyHistoricalActivities = async (req, res) => {
  try {
    const { facultyId } = req.params;

    if (!facultyId || !facultyId.trim()) {
      return res.status(400).json({
        success: false,
        message: "Faculty ID is required.",
      });
    }

    // Faculty can access only their own records.
    // Admin can access records for any faculty.
    if (req.user.role === "faculty") {
      const loggedInFacultyId = String(
        req.user.facultyId || ""
      ).trim().toUpperCase();

      const requestedFacultyId = facultyId
        .trim()
        .toUpperCase();

      if (loggedInFacultyId !== requestedFacultyId) {
        return res.status(403).json({
          success: false,
          message:
            "You are not authorized to view this faculty's historical activities.",
        });
      }
    } else if (req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to access these records.",
      });
    }

    const activities = await HistoricalActivity.find({
      facultyId: facultyId.trim().toUpperCase(),
    }).sort({
      startDate: -1,
      publicationDate: -1,
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      count: activities.length,
      activities,
    });
  } catch (error) {
    console.error("Get historical activities error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to load historical activities.",
    });
  }
};

module.exports = {
  getFacultyHistoricalActivities,
};
