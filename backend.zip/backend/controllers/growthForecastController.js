
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");

exports.getFDPForecast = async (req, res) => {
  const csvPath = path.join(
    __dirname,
    "..",
    "ml-data",
    "next_year_fdp_forecast.csv"
  );

  if (!fs.existsSync(csvPath)) {
    return res.status(404).json({
      success: false,
      message: "Forecast file not found. Generate the forecast first.",
    });
  }

  const results = [];

  const stream = fs.createReadStream(csvPath).pipe(csv());

  stream.on("data", (row) => {
    // Convert numeric CSV fields into numbers for the React frontend.
    results.push({
      ...row,
      actualFDPCount: Number(row.actualFDPCount) || 0,
      predictedFDPCount: Number(row.predictedFDPCount) || 0,
      predictedFDPCountRounded:
        Number(row.predictedFDPCountRounded) || 0,
      historyYearsAvailable:
        Number(row.historyYearsAvailable) || 0,
      historyYears: row.historyYears || "",
    });
  });

  stream.on("end", () => {
    return res.status(200).json({
      success: true,
      count: results.length,
      forecastYear: results[0]?.forecastAcademicYear || "2026-27",
      method:
        results[0]?.method ||
        "Faculty-wise recency-weighted historical average",
      disclaimer:
        "Experimental estimates based on available historical FDP counts. " +
        "They are not validated individual predictions and should not be " +
        "used as faculty performance evaluations.",
      data: results,
    });
  });

  stream.on("error", (error) => {
    console.error("Forecast CSV read error:", error);

    if (!res.headersSent) {
      return res.status(500).json({
        success: false,
        message: "Failed to read forecast data.",
      });
    }
  });
};
