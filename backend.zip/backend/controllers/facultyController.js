const Faculty = require("../models/Faculty");
const xlsx = require("xlsx");

const normalizeFacultyId = (value) =>
  String(value || "")
    .trim()
    .toUpperCase();

const normalizeEmail = (value) =>
  String(value || "")
    .trim()
    .toLowerCase();

const normalizeDepartment = (department) => {
  const value = String(department || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");

  const aliases = {
    cse: "CSE",
    "computer science": "CSE",
    "computer science engineering": "CSE",
    "computer science and engineering": "CSE",
    "computer science & engineering": "CSE",
  };

  return (
    aliases[value] ||
    String(department || "Other").trim() ||
    "Other"
  );
};

const isValidEmail = (email) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

const getRowValue = (row, aliases) => {
  const normalizedEntries = Object.entries(row).reduce(
    (result, [key, value]) => {
      const normalizedKey = String(key || "")
        .trim()
        .toLowerCase()
        .replace(/[\s_-]+/g, "");

      result[normalizedKey] = value;
      return result;
    },
    {}
  );

  for (const alias of aliases) {
    const normalizedAlias = alias
      .trim()
      .toLowerCase()
      .replace(/[\s_-]+/g, "");

    const value = normalizedEntries[normalizedAlias];

    if (
      value !== undefined &&
      value !== null &&
      String(value).trim() !== ""
    ) {
      return value;
    }
  }

  return "";
};

// ========================================
// GET ALL FACULTY
// ADMIN ONLY
// ========================================

const getAllFaculty = async (req, res) => {
  try {
    const faculty = await Faculty.find()
      .select("-password")
      .sort({ name: 1 });

    return res.status(200).json({
      success: true,
      count: faculty.length,
      faculty,
    });
  } catch (error) {
    console.error("Get all faculty error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve faculty",
      error: error.message,
    });
  }
};

// ========================================
// GET ONE FACULTY
// ADMIN = ANY FACULTY
// FACULTY = OWN PROFILE ONLY
// ========================================

const getFacultyById = async (req, res) => {
  try {
    const requestedFacultyId = req.params.id;

    // ========================================
    // FACULTY OWNERSHIP CHECK
    // ========================================

    if (
      req.user?.role === "faculty" &&
      String(req.user.id) !== String(requestedFacultyId)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only access your own faculty profile.",
      });
    }

    const faculty = await Faculty.findById(requestedFacultyId).select(
      "-password"
    );

    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: "Faculty not found",
      });
    }

    return res.status(200).json({
      success: true,
      faculty,
    });
  } catch (error) {
    console.error("Get faculty error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve faculty",
      error: error.message,
    });
  }
};

// ========================================
// ADD FACULTY
// ADMIN ONLY
// ========================================

const createFaculty = async (req, res) => {
  try {
    const {
      facultyId,
      name,
      email,
      phone,
      department,
      designation,
      qualification,
      experience,
      dateOfJoining,
      aadhaarNumber,
      panNumber,
      address,
      profileImage,
    } = req.body;

    // ========================================
    // REQUIRED FIELDS
    // ========================================

    if (!facultyId || !name || !email || !department || !designation) {
      return res.status(400).json({
        success: false,
        message: "Please provide all required faculty details.",
      });
    }

    const cleanFacultyId = facultyId.trim().toUpperCase();
    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone?.trim() || "";
    const cleanAadhaar = aadhaarNumber?.trim() || "";
    const cleanPan = panNumber?.trim().toUpperCase() || "";

    // ========================================
    // CHECK FACULTY ID
    // ========================================

    const existingFacultyId = await Faculty.findOne({
      facultyId: cleanFacultyId,
    });

    if (existingFacultyId) {
      return res.status(400).json({
        success: false,
        message: "Faculty ID already exists",
      });
    }

    // ========================================
    // CHECK EMAIL
    // ========================================

    const existingEmail = await Faculty.findOne({
      email: cleanEmail,
    });

    if (existingEmail) {
      return res.status(400).json({
        success: false,
        message: "Email already exists",
      });
    }

    // ========================================
    // CHECK AADHAAR
    // ========================================

    if (cleanAadhaar) {
      const existingAadhaar = await Faculty.findOne({
        aadhaarNumber: cleanAadhaar,
      });

      if (existingAadhaar) {
        return res.status(400).json({
          success: false,
          message: "Aadhaar number already exists",
        });
      }
    }

    // ========================================
    // CHECK PAN
    // ========================================

    if (cleanPan) {
      const existingPAN = await Faculty.findOne({
        panNumber: cleanPan,
      });

      if (existingPAN) {
        return res.status(400).json({
          success: false,
          message: "PAN number already exists",
        });
      }
    }

    // ========================================
    // CREATE FACULTY
    // ========================================

    const faculty = await Faculty.create({
      facultyId: cleanFacultyId,
      name: cleanName,
      email: cleanEmail,
      phone: cleanPhone,
      department:
        normalizeDepartment(
          department
        ),
      designation:
        designation.trim(),
      qualification: qualification?.trim() || "",
      experience: experience?.trim() || "",
      dateOfJoining: dateOfJoining || null,
      aadhaarNumber: cleanAadhaar || undefined,
      panNumber: cleanPan || undefined,
      address: address?.trim() || "",
      profileImage: profileImage || "",
      source: "Manual Entry",
      registrationStatus: "Not Registered",
      accountStatus: "Inactive",
      isRegistered: false,
    });

    const safeFaculty = faculty.toObject();
    delete safeFaculty.password;

    return res.status(201).json({
      success: true,
      message: "Faculty added successfully",
      faculty: safeFaculty,
    });
  } catch (error) {
    console.error("Create faculty error:", error);

    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern || {})[0] || "field";
      return res.status(400).json({
        success: false,
        message: `${field} already exists.`,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Unable to add faculty",
      error: error.message,
    });
  }
};

// ========================================
// UPDATE FACULTY
// ADMIN = ANY FACULTY
// FACULTY = OWN PROFILE ONLY
// ========================================

const updateFaculty = async (req, res) => {
  try {
    const requestedFacultyId = req.params.id;

    // ========================================
    // FACULTY OWNERSHIP CHECK
    // ========================================

    if (
      req.user?.role === "faculty" &&
      String(req.user.id) !== String(requestedFacultyId)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only update your own faculty profile.",
      });
    }

    // ========================================
    // FIND FACULTY
    // ========================================

    const currentFaculty = await Faculty.findById(requestedFacultyId);

    if (!currentFaculty) {
      return res.status(404).json({
        success: false,
        message: "Faculty not found",
      });
    }

    // Create safe copy
    const updateData = { ...req.body };

    // ========================================
    // ALWAYS PROTECTED
    // ========================================

    delete updateData.password;
    delete updateData.facultyId;
    delete updateData.source;
    delete updateData._id;
    delete updateData.__v;

    // ========================================
    // FACULTY CANNOT MODIFY ACCOUNT CONTROLS
    // ADMIN MAY MODIFY THEM
    // ========================================

    if (req.user?.role === "faculty") {
      delete updateData.registrationStatus;
      delete updateData.accountStatus;
      delete updateData.isRegistered;
      delete updateData.lastLogin;
    }

    // ========================================
    // EMAIL DUPLICATE CHECK
    // ========================================

    if (updateData.email) {
      const cleanEmail = updateData.email.trim().toLowerCase();
      const existingEmail = await Faculty.findOne({
        email: cleanEmail,
        _id: { $ne: requestedFacultyId },
      });

      if (existingEmail) {
        return res.status(400).json({
          success: false,
          message:
            "This email address is already registered to another faculty account.",
        });
      }
      updateData.email = cleanEmail;
    }

    // ========================================
    // AADHAAR DUPLICATE CHECK
    // ========================================

    if (updateData.aadhaarNumber) {
      const cleanAadhaar = updateData.aadhaarNumber.trim();
      const existingAadhaar = await Faculty.findOne({
        aadhaarNumber: cleanAadhaar,
        _id: { $ne: requestedFacultyId },
      });

      if (existingAadhaar) {
        return res.status(400).json({
          success: false,
          message:
            "This Aadhaar number is already registered to another faculty account.",
        });
      }
      updateData.aadhaarNumber = cleanAadhaar;
    }

    // ========================================
    // PAN DUPLICATE CHECK
    // ========================================

    if (updateData.panNumber) {
      const cleanPan = updateData.panNumber.trim().toUpperCase();
      const existingPAN = await Faculty.findOne({
        panNumber: cleanPan,
        _id: { $ne: requestedFacultyId },
      });

      if (existingPAN) {
        return res.status(400).json({
          success: false,
          message:
            "This PAN number is already registered to another faculty account.",
        });
      }
      updateData.panNumber = cleanPan;
    }

    // ========================================
    // NORMALIZE VALUES
    // ========================================

    if (updateData.name) {
      updateData.name = updateData.name.trim();
    }

    if (updateData.department !== undefined) {
      updateData.department =
        normalizeDepartment(
          updateData.department
        );
    }

    if (updateData.designation !== undefined) {
      updateData.designation =
        String(
          updateData.designation
        ).trim();
    }
    if (updateData.phone !== undefined) {
      updateData.phone = String(updateData.phone).trim();
    }
    if (updateData.qualification !== undefined) {
      updateData.qualification = String(updateData.qualification).trim();
    }
    if (updateData.experience !== undefined) {
      updateData.experience = String(updateData.experience).trim();
    }
    if (updateData.address !== undefined) {
      updateData.address = String(updateData.address).trim();
    }
    if (updateData.dateOfJoining === "") {
      updateData.dateOfJoining = null;
    }

    // ========================================
    // UPDATE FACULTY
    // ========================================

    const faculty = await Faculty.findByIdAndUpdate(
      requestedFacultyId,
      updateData,
      { returnDocument: "after", runValidators: true }
    ).select("-password");

    return res.status(200).json({
      success: true,
      message: "Faculty updated successfully",
      faculty,
    });
  } catch (error) {
    console.error("Faculty update error:", error);

    // ========================================
    // DUPLICATE INDEX ERROR
    // ========================================
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern || {})[0] || "field";
      return res.status(400).json({
        success: false,
        message: `${field} already exists.`,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Unable to update faculty",
      error: error.message,
    });
  }
};

// ========================================
// DELETE FACULTY
// ADMIN ONLY
// ========================================

const deleteFaculty = async (req, res) => {
  try {
    const faculty = await Faculty.findByIdAndDelete(req.params.id);

    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: "Faculty not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Faculty deleted successfully",
    });
  } catch (error) {
    console.error("Delete faculty error:", error);

    return res.status(500).json({
      success: false,
      message: "Unable to delete faculty",
      error: error.message,
    });
  }
};

// ========================================
// BULK IMPORT FACULTY (EXCEL)
// ADMIN ONLY
// ========================================

const bulkImportFaculty = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message:
          "Please upload an Excel or CSV file.",
      });
    }

    let workbook;

    try {
      workbook = xlsx.read(
        req.file.buffer,
        {
          type: "buffer",
        }
      );
    } catch (error) {
      return res.status(400).json({
        success: false,
        message:
          "The uploaded file could not be read. Please verify that it is a valid .xlsx, .xls, or .csv file.",
      });
    }

    const sheetName =
      workbook.SheetNames?.[0];

    if (!sheetName) {
      return res.status(400).json({
        success: false,
        message:
          "The uploaded file does not contain a worksheet.",
      });
    }

    const rawData =
      xlsx.utils.sheet_to_json(
        workbook.Sheets[sheetName],
        {
          defval: "",
          raw: false,
        }
      );

    if (rawData.length === 0) {
      return res.status(400).json({
        success: false,
        message:
          "The uploaded spreadsheet is empty.",
      });
    }

    // ----------------------------------------
    // Read and normalize rows first
    // ----------------------------------------

    const parsedRows =
      rawData.map(
        (row, index) => {
          const rowNumber =
            index + 2;

          const facultyId =
            normalizeFacultyId(
              getRowValue(
                row,
                [
                  "Faculty ID",
                  "FacultyID",
                  "facultyId",
                  "ID",
                ]
              )
            );

          const name =
            String(
              getRowValue(
                row,
                [
                  "Name",
                  "Full Name",
                  "FullName",
                ]
              ) || ""
            ).trim();

          const email =
            normalizeEmail(
              getRowValue(
                row,
                ["Email"]
              )
            );

          const department =
            normalizeDepartment(
              getRowValue(
                row,
                ["Department"]
              )
            );

          const designation =
            String(
              getRowValue(
                row,
                ["Designation"]
              ) || ""
            ).trim();

          const phone =
            String(
              getRowValue(
                row,
                [
                  "Phone",
                  "Mobile",
                  "Phone Number",
                ]
              ) || ""
            ).trim();

          const qualification =
            String(
              getRowValue(
                row,
                ["Qualification"]
              ) || ""
            ).trim();

          const experience =
            String(
              getRowValue(
                row,
                ["Experience"]
              ) || ""
            ).trim();

          return {
            rowNumber,
            facultyId,
            name,
            email,
            department,
            designation,
            phone,
            qualification,
            experience,
          };
        }
      );

    // ----------------------------------------
    // Load existing Faculty IDs and emails
    // ----------------------------------------

    const facultyIds =
      parsedRows
        .map(
          (row) =>
            row.facultyId
        )
        .filter(Boolean);

    const emails =
      parsedRows
        .map(
          (row) =>
            row.email
        )
        .filter(Boolean);

    const existingFaculty =
      await Faculty.find(
        {
          $or: [
            {
              facultyId: {
                $in: facultyIds,
              },
            },
            {
              email: {
                $in: emails,
              },
            },
          ],
        },
        {
          facultyId: 1,
          email: 1,
        }
      ).lean();

    const existingFacultyIds =
      new Set(
        existingFaculty.map(
          (faculty) =>
            normalizeFacultyId(
              faculty.facultyId
            )
        )
      );

    const existingEmails =
      new Set(
        existingFaculty.map(
          (faculty) =>
            normalizeEmail(
              faculty.email
            )
        )
      );

    const seenFacultyIds =
      new Set();

    const seenEmails =
      new Set();

    const validRecords =
      [];

    const skippedRecords =
      [];

    // ----------------------------------------
    // Validate each spreadsheet row
    // ----------------------------------------

    for (const row of parsedRows) {
      const {
        rowNumber,
        facultyId,
        name,
        email,
        department,
        designation,
        phone,
        qualification,
        experience,
      } = row;

      if (
        !facultyId ||
        !name ||
        !email ||
        !department ||
        !designation
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Missing required field. Faculty ID, Name, Email, Department and Designation are required.",
        });

        continue;
      }

      if (
        !isValidEmail(email)
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Invalid email address.",
        });

        continue;
      }

      if (
        existingFacultyIds.has(
          facultyId
        )
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Faculty ID already exists.",
        });

        continue;
      }

      if (
        existingEmails.has(email)
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Email already exists.",
        });

        continue;
      }

      if (
        seenFacultyIds.has(
          facultyId
        )
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Duplicate Faculty ID in the uploaded file.",
        });

        continue;
      }

      if (
        seenEmails.has(email)
      ) {
        skippedRecords.push({
          row: rowNumber,
          facultyId,
          email,
          reason:
            "Duplicate email in the uploaded file.",
        });

        continue;
      }

      seenFacultyIds.add(
        facultyId
      );

      seenEmails.add(
        email
      );

      validRecords.push({
        rowNumber,

        document: {
          facultyId,
          name,
          email,
          department,
          designation,
          phone,
          qualification,
          experience,

          role: "faculty",

          source:
            "Excel Import",

          // Excel import creates the official
          // faculty master record only.
          // Registration and account activation
          // remain separate admin workflows.
          registrationStatus:
            "Not Registered",

          accountStatus:
            "Inactive",

          isRegistered:
            false,
        },
      });
    }

    // ----------------------------------------
    // Insert valid rows
    // ----------------------------------------

    let importedCount = 0;

    if (
      validRecords.length > 0
    ) {
      const operations =
        validRecords.map(
          (record) => ({
            insertOne: {
              document:
                record.document,
            },
          })
        );

      try {
        const result =
          await Faculty.bulkWrite(
            operations,
            {
              ordered: false,
            }
          );

        importedCount =
          result.insertedCount ||
          0;
      } catch (error) {
        const writeErrors =
          error.writeErrors || [];

        const failedIndexes =
          new Set(
            writeErrors.map(
              (writeError) =>
                writeError.index
            )
          );

        importedCount =
          validRecords.length -
          failedIndexes.size;

        writeErrors.forEach(
          (writeError) => {
            const failedRecord =
              validRecords[
                writeError.index
              ];

            if (
              !failedRecord
            ) {
              return;
            }

            skippedRecords.push({
              row:
                failedRecord.rowNumber,

              facultyId:
                failedRecord
                  .document
                  .facultyId,

              email:
                failedRecord
                  .document
                  .email,

              reason:
                writeError.code ===
                11000
                  ? "Duplicate value detected while saving to MongoDB."
                  : writeError.errmsg ||
                    writeError.message ||
                    "MongoDB rejected this row.",
            });
          }
        );

        // If MongoDB failed for a reason other than
        // individual row write errors, stop the import.
        if (
          writeErrors.length === 0
        ) {
          throw error;
        }
      }
    }

    return res.status(200).json({
      success: true,

      message:
        importedCount > 0
          ? `Successfully imported ${importedCount} faculty record${importedCount === 1 ? "" : "s"}.`
          : "No new faculty records were imported.",

      summary: {
        totalRows:
          rawData.length,

        importedCount,

        skippedCount:
          skippedRecords.length,

        skippedDetails:
          skippedRecords,
      },
    });
  } catch (error) {
    console.error(
      "Bulk import error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to process the faculty import file.",
    });
  }
};

// ========================================
// UPLOAD FACULTY PROFILE IMAGE
// POST /api/faculty/:id/upload-profile-image
//
// ADMIN:
// - Can upload for any faculty.
//
// FACULTY:
// - Can upload only their own photo.
// ========================================

const uploadProfileImage = async (
  req,
  res
) => {
  try {
    const facultyId =
      req.params.id;

    if (
      req.user?.role ===
        "faculty" &&
      String(req.user.id) !==
        String(facultyId)
    ) {
      return res
        .status(403)
        .json({
          success: false,
          message:
            "You can only upload your own profile photograph.",
        });
    }

    if (!req.file) {
      return res
        .status(400)
        .json({
          success: false,
          message:
            "Please select a valid profile image.",
        });
    }

    const profileImageUrl =
      `/uploads/profile-images/${req.file.filename}`;

    const updatedFaculty =
      await Faculty
        .findByIdAndUpdate(
          facultyId,
          {
            profileImage:
              profileImageUrl,
          },
          {
            returnDocument:
              "after",
            runValidators:
              true,
          }
        )
        .select(
          "-password"
        );

    if (!updatedFaculty) {
      return res
        .status(404)
        .json({
          success: false,
          message:
            "Faculty not found.",
        });
    }

    return res
      .status(200)
      .json({
        success: true,
        message:
          "Profile photograph uploaded successfully.",
        profileImage:
          profileImageUrl,
        faculty:
          updatedFaculty,
      });
  } catch (error) {
    console.error(
      "Profile image upload error:",
      error
    );

    return res
      .status(500)
      .json({
        success: false,
        message:
          "Unable to upload profile photograph.",
        error:
          error.message,
      });
  }
};

// ========================================
// UPLOAD FACULTY CERTIFICATE / DOCUMENT
// ========================================

const uploadCertificate = async (req, res) => {
  try {
    const facultyId = req.params.id;

    if (
      req.user?.role === "faculty" &&
      String(req.user.id) !==
        String(facultyId)
    ) {
      return res.status(403).json({
        success: false,
        message:
          "You can only upload documents to your own faculty profile.",
      });
    }

    // 1. Check if Multer successfully processed a file
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded or invalid file format.",
      });
    }

    // 2. Create the public URL path for the uploaded proof document
    const fileUrl = `/uploads/certificates/${req.file.filename}`;

    // 3. Save certificate metadata separately from the faculty profile photo
    const updatedFaculty = await Faculty.findByIdAndUpdate(
      facultyId,
      {
        certificateUrl: fileUrl,
        certificateName:
          req.file.originalname || "",
        certificateMimeType:
          req.file.mimetype || "",
      },
      {
        returnDocument: "after",
        runValidators: true,
      }
    ).select("-password");

    if (!updatedFaculty) {
      return res.status(404).json({
        success: false,
        message: "Faculty not found.",
      });
    }

    return res.status(200).json({
      success: true,
      message: "File uploaded successfully.",
      fileUrl: fileUrl,
      faculty: updatedFaculty
    });

  } catch (error) {
    console.error("Upload error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to upload file.",
      error: error.message
    });
  }
};

// ========================================
// EXPORTS
// ========================================

module.exports = {
  getAllFaculty,
  getFacultyById,
  createFaculty,
  updateFaculty,
  deleteFaculty,
  bulkImportFaculty,
  uploadCertificate,
  uploadProfileImage,
};