const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Faculty = require("../models/Faculty");
const Admin = require("../models/Admin");

// ========================================
// GENERATE FACULTY JWT TOKEN
// ========================================

const generateFacultyToken = (faculty) => {
  return jwt.sign(
    {
      id: faculty._id,
      facultyId: faculty.facultyId,
      role: "faculty",
    },
    process.env.JWT_SECRET,
    {
      expiresIn:
        process.env.JWT_EXPIRES_IN || "1d",
    }
  );
};

// ========================================
// GENERATE ADMIN JWT TOKEN
// ========================================

const generateAdminToken = (admin) => {
  return jwt.sign(
    {
      id: admin._id,
      role: "admin",
    },
    process.env.JWT_SECRET,
    {
      expiresIn:
        process.env.JWT_EXPIRES_IN || "1d",
    }
  );
};

// ========================================
// FACULTY REGISTER
// ========================================

const registerFaculty = async (req, res) => {
  try {
    const {
      facultyId,
      name,
      email,
      phone,
      department,
      designation,
      password,
    } = req.body;

    // ========================================
    // VALIDATION
    // ========================================

    if (
      !facultyId ||
      !name ||
      !email ||
      !department ||
      !designation ||
      !password
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Please provide all required registration details.",
      });
    }

    const cleanFacultyId =
      facultyId.trim().toUpperCase();

    const cleanEmail =
      email.trim().toLowerCase();

    // ========================================
    // FIND OFFICIAL FACULTY MASTER RECORD
    // ========================================

    const faculty =
      await Faculty.findOne({
        facultyId: cleanFacultyId,
        email: cleanEmail,
      }).select("+password");

    if (!faculty) {
      return res.status(404).json({
        success: false,
        message:
          "Faculty ID and email do not match any official faculty record.",
      });
    }

    // ========================================
    // ALREADY REGISTERED
    // ========================================

    if (faculty.isRegistered) {
      return res.status(400).json({
        success: false,
        message:
          "This faculty account has already been registered.",
      });
    }

    // ========================================
    // VERIFY NAME
    // ========================================

    if (
      faculty.name
        .trim()
        .toLowerCase() !==
      name.trim().toLowerCase()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Entered name does not match the official faculty record.",
      });
    }

    // ========================================
    // VERIFY DEPARTMENT
    // ========================================

    if (
      faculty.department !==
      department
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Selected department does not match the official faculty record.",
      });
    }

    // ========================================
    // VERIFY DESIGNATION
    // ========================================

    if (
      faculty.designation !==
      designation
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Selected designation does not match the official faculty record.",
      });
    }

    // ========================================
    // HASH PASSWORD
    // ========================================

    const hashedPassword =
      await bcrypt.hash(
        password,
        10
      );

    // ========================================
    // UPDATE FACULTY ACCOUNT
    // ========================================

    faculty.phone =
      phone?.trim() ||
      faculty.phone;

    faculty.password =
      hashedPassword;

    faculty.isRegistered =
      true;

    faculty.registrationStatus =
      "Pending";

    faculty.accountStatus =
      "Inactive";

    await faculty.save();

    // ========================================
    // SUCCESS
    // ========================================

    return res.status(200).json({
      success: true,

      message:
        "Registration submitted successfully. Your account is waiting for administrator approval.",
    });
  } catch (error) {
    console.error(
      "Faculty registration error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to register faculty.",

      error:
        error.message,
    });
  }
};

// ========================================
// FACULTY LOGIN
// ========================================

const loginFaculty = async (
  req,
  res
) => {
  try {
    const {
      email,
      password,
    } = req.body;

    // ========================================
    // VALIDATION
    // ========================================

    if (
      !email ||
      !password
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Please enter your email and password.",
      });
    }

    const cleanEmail =
      email
        .trim()
        .toLowerCase();

    // ========================================
    // FIND FACULTY
    // ========================================

    const faculty =
      await Faculty.findOne({
        email: cleanEmail,
      }).select("+password");

    if (!faculty) {
      return res.status(401).json({
        success: false,

        message:
          "Incorrect email or password.",
      });
    }

    // ========================================
    // CHECK REGISTRATION
    // ========================================

    if (
      !faculty.isRegistered
    ) {
      return res.status(403).json({
        success: false,

        message:
          "This faculty account has not been registered yet.",
      });
    }

    // ========================================
    // CHECK PASSWORD EXISTS
    // ========================================

    if (
      !faculty.password
    ) {
      return res.status(401).json({
        success: false,

        message:
          "No password is configured for this faculty account.",
      });
    }

    // ========================================
    // CHECK PASSWORD
    // ========================================

    const passwordMatches =
      await bcrypt.compare(
        password,
        faculty.password
      );

    if (!passwordMatches) {
      return res.status(401).json({
        success: false,

        message:
          "Incorrect email or password.",
      });
    }

    // ========================================
    // PENDING REGISTRATION
    // ========================================

    if (
      faculty.registrationStatus ===
      "Pending"
    ) {
      return res.status(403).json({
        success: false,

        message:
          "Your registration is waiting for administrator approval.",
      });
    }

    // ========================================
    // REJECTED REGISTRATION
    // ========================================

    if (
      faculty.registrationStatus ===
      "Rejected"
    ) {
      return res.status(403).json({
        success: false,

        message:
          "Your registration has been rejected by the administrator.",
      });
    }

    // ========================================
    // MUST BE APPROVED
    // ========================================

    if (
      faculty.registrationStatus !==
      "Approved"
    ) {
      return res.status(403).json({
        success: false,

        message:
          "Your faculty account is not approved for login.",
      });
    }

    // ========================================
    // ACCOUNT STATUS
    // ========================================

    if (
      faculty.accountStatus !==
      "Active"
    ) {
      return res.status(403).json({
        success: false,

        message:
          faculty.accountStatus ===
          "Suspended"
            ? "Your account has been suspended. Please contact the administrator."
            : "Your account is currently inactive. Please contact the administrator.",
      });
    }

    // ========================================
    // UPDATE LAST LOGIN
    // ========================================

    faculty.lastLogin =
      new Date();

    await faculty.save();

    // ========================================
    // GENERATE JWT
    // ========================================

    const token =
      generateFacultyToken(
        faculty
      );

    // ========================================
    // REMOVE PASSWORD
    // ========================================

    const safeFaculty =
      faculty.toObject();

    delete safeFaculty.password;

    // ========================================
    // SUCCESS
    // ========================================

    return res.status(200).json({
      success: true,

      message:
        "Login successful.",

      token,

      faculty:
        safeFaculty,
    });
  } catch (error) {
    console.error(
      "Faculty login error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to login.",

      error:
        error.message,
    });
  }
};

// ========================================
// ADMIN LOGIN
// ========================================

const loginAdmin = async (
  req,
  res
) => {
  try {
    const {
      email,
      password,
    } = req.body;

    // ========================================
    // VALIDATION
    // ========================================

    if (
      !email ||
      !password
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Please enter admin email and password.",
      });
    }

    const cleanEmail =
      email
        .trim()
        .toLowerCase();

    // ========================================
    // FIND ADMIN
    // ========================================

    const admin =
      await Admin.findOne({
        email: cleanEmail,
      }).select("+password");

    if (!admin) {
      return res.status(401).json({
        success: false,

        message:
          "Incorrect admin email or password.",
      });
    }

    // ========================================
    // CHECK PASSWORD
    // ========================================

    const passwordMatches =
      await bcrypt.compare(
        password,
        admin.password
      );

    if (!passwordMatches) {
      return res.status(401).json({
        success: false,

        message:
          "Incorrect admin email or password.",
      });
    }

    // ========================================
    // CHECK ACCOUNT STATUS
    // ========================================

    if (
      admin.accountStatus !==
      "Active"
    ) {
      return res.status(403).json({
        success: false,

        message:
          "Administrator account is inactive.",
      });
    }

    // ========================================
    // UPDATE LAST LOGIN
    // ========================================

    admin.lastLogin =
      new Date();

    await admin.save();

    // ========================================
    // GENERATE ADMIN JWT
    // ========================================

    const token =
      generateAdminToken(
        admin
      );

    // ========================================
    // REMOVE PASSWORD
    // ========================================

    const safeAdmin =
      admin.toObject();

    delete safeAdmin.password;

    // ========================================
    // SUCCESS
    // ========================================

    return res.status(200).json({
      success: true,

      message:
        "Admin login successful.",

      token,

      admin:
        safeAdmin,
    });
  } catch (error) {
    console.error(
      "Admin login error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to login as administrator.",

      error:
        error.message,
    });
  }
};

// ========================================
// EXPORTS
// ========================================

module.exports = {
  registerFaculty,
  loginFaculty,
  loginAdmin,
};