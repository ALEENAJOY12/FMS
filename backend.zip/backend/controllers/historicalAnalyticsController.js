    
const HistoricalActivity = require("../models/HistoricalActivity");
const Faculty = require("../models/Faculty");

// Count records by a field
function countBy(records, field) {
  const counts = {};

  records.forEach((record) => {
    const key = record[field] || "Unknown";
    counts[key] = (counts[key] || 0) + 1;
  });

  return Object.entries(counts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
}

// Prepare analytics from historical records
function buildAnalytics(records) {
  const facultySet = new Set(
    records
      .map((record) => record.facultyId || record.facultyName)
      .filter(Boolean)
  );

  return {
    totalActivities: records.length,
    facultyCount: facultySet.size,
    byType: countBy(records, "type"),
    byAcademicYear: countBy(records, "academicYear").sort((a, b) =>
      a.name.localeCompare(b.name)
    ),
    byDepartment: countBy(records, "department"),
    byFaculty: countBy(records, "facultyName").slice(0, 10),
  };
}

// ADMIN: College-wide historical analytics
const getCollegeHistoricalAnalytics = async (req, res) => {
  try {
    // Fetch all historical activity records
    const records = await HistoricalActivity.find({})
      .select(
        "facultyId facultyName department type title academicYear startDate endDate activityDate publicationDate publicationStatus"
      )
      .sort({ academicYear: 1, facultyName: 1 })
      .lean();

    // Count all faculty master records, not just faculty
    // who have historical activity records
    const totalFaculty = await Faculty.countDocuments({});

    // Build historical activity analytics
    const analytics = buildAnalytics(records);

    return res.status(200).json({
      success: true,
      analytics,
      activities: records,
      totalFaculty,
    });
  } catch (error) {
    console.error("Error fetching college historical analytics:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch college historical analytics.",
    });
  }
};

// FACULTY: Personal historical analytics
const getPersonalHistoricalAnalytics = async (req, res) => {
  try {
    const facultyId = req.user?.facultyId;

    if (!facultyId) {
      return res.status(403).json({
        success: false,
        message: "Faculty ID not found in the authenticated user.",
      });
    }

    // Fetch only the logged-in faculty member's historical records
    const records = await HistoricalActivity.find({ facultyId })
      .select(
        "facultyId facultyName department type title academicYear startDate endDate activityDate publicationDate publicationStatus"
      )
      .sort({
        academicYear: 1,
        startDate: 1,
        activityDate: 1,
      })
      .lean();

    const analytics = buildAnalytics(records);

    return res.status(200).json({
      success: true,
      analytics,
      activities: records,
    });
  } catch (error) {
    console.error("Error fetching personal historical analytics:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch personal historical analytics.",
    });
  }
};

module.exports = {
  getCollegeHistoricalAnalytics,
  getPersonalHistoricalAnalytics,
};
