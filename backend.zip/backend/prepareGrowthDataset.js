
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const connectDB = require("./config/db");
const HistoricalActivity = require("./models/HistoricalActivity");

const TYPES = [
  "FDP",
  "NPTEL",
  "Research Paper",
  "Journal Publication",
  "Patent / IPR",
  "Conference",
  "Book Chapter",
];

function normalizeYear(value) {
  return String(value || "")
    .trim()
    .replace(/[–—]/g, "-")
    .replace(/\s+/g, "");
}

function csvEscape(value) {
  const text = String(value ?? "");
  return `"${text.replace(/"/g, '""')}"`;
}

async function prepareDataset() {
  try {
    await connectDB();

    const records = await HistoricalActivity.find({})
      .select(
        "facultyId academicYear type activityDate startDate endDate sourceActivityId"
      )
      .lean();

    const grouped = new Map();

    for (const record of records) {
      const facultyId = String(record.facultyId || "")
        .trim()
        .toUpperCase();

      const academicYear = normalizeYear(record.academicYear);
      const type = String(record.type || "").trim();

      if (!facultyId || !academicYear || !TYPES.includes(type)) {
        continue;
      }

      const key = `${facultyId}::${academicYear}`;

      if (!grouped.has(key)) {
        const row = {
          facultyId,
          academicYear,
          totalActivities: 0,
          importedRecords: 0,
          linkedLiveRecords: 0,
          datedActivities: 0,
          missingDateCount: 0,
        };

        for (const activityType of TYPES) {
          row[
            activityType
              .replace(/[^a-zA-Z0-9]/g, "")
              .replace(/^./, (c) => c.toLowerCase()) + "Count"
          ] = 0;
        }

        grouped.set(key, row);
      }

      const row = grouped.get(key);
      const categoryColumn =
        type
          .replace(/[^a-zA-Z0-9]/g, "")
          .replace(/^./, (c) => c.toLowerCase()) + "Count";

      row[categoryColumn]++;
      row.totalActivities++;

      if (record.sourceActivityId) {
        row.linkedLiveRecords++;
      } else {
        row.importedRecords++;
      }

      const date =
        record.activityDate ||
        record.startDate ||
        record.endDate;

      if (date && !Number.isNaN(new Date(date).getTime())) {
        row.datedActivities++;
      } else {
        row.missingDateCount++;
      }
    }

    const rows = [...grouped.values()].sort(
      (a, b) =>
        a.facultyId.localeCompare(b.facultyId) ||
        a.academicYear.localeCompare(b.academicYear)
    );

    const columns = [
      "facultyId",
      "academicYear",
      "totalActivities",
      "importedRecords",
      "linkedLiveRecords",
      "datedActivities",
      "missingDateCount",
      ...TYPES.map(
        (type) =>
          type
            .replace(/[^a-zA-Z0-9]/g, "")
            .replace(/^./, (c) => c.toLowerCase()) + "Count"
      ),
    ];

    const csv = [
      columns.map(csvEscape).join(","),
      ...rows.map((row) =>
        columns.map((column) => csvEscape(row[column])).join(",")
      ),
    ].join("\n");

    const outputDir = path.join(__dirname, "ml-data");
    fs.mkdirSync(outputDir, { recursive: true });

    const outputFile = path.join(
      outputDir,
      "faculty_year_activity_counts.csv"
    );

    fs.writeFileSync(outputFile, csv, "utf8");

    console.log("\nDataset preparation complete.");
    console.log("Source records:", records.length);
    console.log("Faculty-year rows:", rows.length);
    console.log(
      "Unique faculty:",
      new Set(rows.map((row) => row.facultyId)).size
    );
    console.log(
      "Academic years:",
      [...new Set(rows.map((row) => row.academicYear))].sort()
    );
    console.log("Output:", outputFile);

    console.log("\nRows by academic year:");
    console.table(
      [...rows.reduce((map, row) => {
        const item = map.get(row.academicYear) || {
          academicYear: row.academicYear,
          facultyCount: 0,
          activityCount: 0,
        };

        item.facultyCount++;
        item.activityCount += row.totalActivities;
        map.set(row.academicYear, item);
        return map;
      }, new Map()).values()]
    );

    console.log(
      "\nNote: These are activity counts, not historical FIS scores."
    );
  } catch (error) {
    console.error("Dataset preparation failed:", error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

prepareDataset();
