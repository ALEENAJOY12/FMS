
require("dotenv").config();

const mongoose = require("mongoose");
const connectDB = require("./config/db");
const HistoricalActivity = require("./models/HistoricalActivity");

async function checkRecords() {
  try {
    await connectDB();

    const total = await HistoricalActivity.countDocuments();

    const summary = await HistoricalActivity.aggregate([
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    console.log("\n--- Historical Activity Records ---");
    console.log("Total records:", total);

    console.table(
      summary.map((item) => ({
        ActivityType: item._id,
        Count: item.count,
      }))
    );
  } catch (error) {
    console.error("Error:", error.message);
  } finally {
    await mongoose.connection.close();
  }
}

checkRecords();
