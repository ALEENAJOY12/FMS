
require("dotenv").config();

const mongoose = require("mongoose");
const connectDB = require("./config/db");
const HistoricalActivity = require("./models/HistoricalActivity");

async function run() {
  try {
    await connectDB();

    const facultyYear = await HistoricalActivity.aggregate([
      {
        $group: {
          _id: {
            facultyId: "$facultyId",
            year: "$academicYear",
          },
          records: { $sum: 1 },
        },
      },
      {
        $group: {
          _id: "$_id.year",
          facultyCount: { $sum: 1 },
          records: { $sum: "$records" },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    console.log("\nFaculty coverage by academic year:");
    console.table(facultyYear);

    const dateQuality = await HistoricalActivity.aggregate([
      {
        $group: {
          _id: "$type",
          total: { $sum: 1 },
          missingYear: {
            $sum: {
              $cond: [
                { $eq: ["$academicYear", ""] },
                1,
                0,
              ],
            },
          },
          missingDate: {
            $sum: {
              $cond: [
                {
                  $eq: [
                    { $ifNull: ["$activityDate", null] },
                    null,
                  ],
                },
                1,
                0,
              ],
            },
          },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    console.log("\nHistorical data quality:");
    console.table(dateQuality);
  } catch (error) {
    console.error("Audit failed:", error.message);
  } finally {
    await mongoose.disconnect();
  }
}

run();
