require("dotenv").config();

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const connectDB = require("./config/db");
const Admin = require("./models/Admin");

// ========================================
// CREATE FIRST ADMIN
// ========================================

const createAdmin = async () => {
  try {
    // Use the same working connection as server.js
    await connectDB();

    const email =
      "admin@scmsgroup.org";

    const password =
      "Admin@123";

    // ========================================
    // CHECK EXISTING ADMIN
    // ========================================

    const existingAdmin =
      await Admin.findOne({
        email: email
          .trim()
          .toLowerCase(),
      });

    if (existingAdmin) {
      console.log(
        "Admin account already exists."
      );

      await mongoose.connection.close();

      process.exit(0);
    }

    // ========================================
    // HASH PASSWORD
    // ========================================

    const hashedPassword =
      await bcrypt.hash(
        password,
        10
      );

    // ========================================
    // CREATE ADMIN
    // ========================================

    const admin =
      await Admin.create({
        name:
          "Administrator",

        email:
          email
            .trim()
            .toLowerCase(),

        password:
          hashedPassword,

        role:
          "admin",

        accountStatus:
          "Active",
      });

    console.log(
      "Admin account created successfully."
    );

    console.log(
      "Admin ID:",
      admin._id.toString()
    );

    console.log(
      "Admin Email:",
      admin.email
    );

    // ========================================
    // CLOSE DATABASE
    // ========================================

    await mongoose.connection.close();

    console.log(
      "MongoDB connection closed."
    );

    process.exit(0);
  } catch (error) {
    console.error(
      "Unable to create admin:",
      error.message
    );

    try {
      await mongoose.connection.close();
    } catch {
      // Ignore close error
    }

    process.exit(1);
  }
};

createAdmin();