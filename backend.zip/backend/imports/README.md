# Historical Activity Import

`FMS_Historical_Activities_Cleaned.xlsx` contains only faculty matched to the current project faculty master:
- 24 Journal Publication records
- 15 FDP 2023-24 records

Historical records are stored in the `HistoricalActivity` collection and are intentionally separate from the current `Activity` collection. They therefore do not enter the normal approval workflow or the current FIS calculation.

From the backend folder, with the normal `.env` configured:

```bash
npm install
npm run import:historical -- "./imports/FMS_Historical_Activities_Cleaned.xlsx"
```

The script can be safely re-run for these two source files; it replaces only previously imported historical records from these sources.
